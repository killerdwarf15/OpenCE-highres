/*
HS.C

symbols in this file:
000AD290 0050:
	_code_000ad290 (0000)
000AD2E0 0040:
	_code_000ad2e0 (0000)
000AD320 0020:
	_code_000ad320 (0000)
000AD340 0040:
	_code_000ad340 (0000)
000AD380 0050:
	_code_000ad380 (0000)
000AD3D0 0050:
	_code_000ad3d0 (0000)
000AD420 0050:
	_code_000ad420 (0000)
000AD470 0040:
	_code_000ad470 (0000)
000AD4B0 0040:
	_code_000ad4b0 (0000)
000AD4F0 0040:
	_code_000ad4f0 (0000)
000AD530 0040:
	_code_000ad530 (0000)
000AD570 0040:
	_code_000ad570 (0000)
000AD5B0 0040:
	_code_000ad5b0 (0000)
000AD5F0 0020:
	_code_000ad5f0 (0000)
000AD610 0040:
	_code_000ad610 (0000)
000AD650 0040:
	_code_000ad650 (0000)
000AD690 0040:
	_code_000ad690 (0000)
000AD6D0 0040:
	_code_000ad6d0 (0000)
000AD710 0040:
	_code_000ad710 (0000)
000AD750 0050:
	_code_000ad750 (0000)
000AD7A0 0040:
	_code_000ad7a0 (0000)
000AD7E0 0040:
	_code_000ad7e0 (0000)
000AD820 0040:
	_code_000ad820 (0000)
000AD860 0040:
	_code_000ad860 (0000)
000AD8A0 0050:
	_code_000ad8a0 (0000)
000AD8F0 0050:
	_code_000ad8f0 (0000)
000AD940 0040:
	_code_000ad940 (0000)
000AD980 0040:
	_code_000ad980 (0000)
000AD9C0 0040:
	_code_000ad9c0 (0000)
000ADA00 0040:
	_code_000ada00 (0000)
000ADA40 0050:
	_code_000ada40 (0000)
000ADA90 0020:
	_code_000ada90 (0000)
000ADAB0 0020:
	_code_000adab0 (0000)
000ADAD0 0040:
	_code_000adad0 (0000)
000ADB10 0050:
	_code_000adb10 (0000)
000ADB60 0050:
	_code_000adb60 (0000)
000ADBB0 0050:
	_code_000adbb0 (0000)
000ADC00 0040:
	_code_000adc00 (0000)
000ADC40 0050:
	_code_000adc40 (0000)
000ADC90 0040:
	_code_000adc90 (0000)
000ADCD0 0040:
	_code_000adcd0 (0000)
000ADD10 0020:
	_code_000add10 (0000)
000ADD30 0040:
	_code_000add30 (0000)
000ADD70 0040:
	_code_000add70 (0000)
000ADDB0 0040:
	_code_000addb0 (0000)
000ADDF0 0040:
	_code_000addf0 (0000)
000ADE30 0020:
	_code_000ade30 (0000)
000ADE50 0040:
	_code_000ade50 (0000)
000ADE90 0040:
	_code_000ade90 (0000)
000ADED0 0040:
	_code_000aded0 (0000)
000ADF10 0040:
	_code_000adf10 (0000)
000ADF50 0040:
	_code_000adf50 (0000)
000ADF90 0040:
	_code_000adf90 (0000)
000ADFD0 0040:
	_code_000adfd0 (0000)
000AE010 0020:
	_code_000ae010 (0000)
000AE030 0040:
	_code_000ae030 (0000)
000AE070 0050:
	_code_000ae070 (0000)
000AE0C0 0050:
	_code_000ae0c0 (0000)
000AE110 0040:
	_code_000ae110 (0000)
000AE150 0050:
	_code_000ae150 (0000)
000AE1A0 0040:
	_code_000ae1a0 (0000)
000AE1E0 0040:
	_code_000ae1e0 (0000)
000AE220 0040:
	_code_000ae220 (0000)
000AE260 0040:
	_code_000ae260 (0000)
000AE2A0 0040:
	_code_000ae2a0 (0000)
000AE2E0 0040:
	_code_000ae2e0 (0000)
000AE320 0050:
	_code_000ae320 (0000)
000AE370 0040:
	_code_000ae370 (0000)
000AE3B0 0050:
	_code_000ae3b0 (0000)
000AE400 0050:
	_code_000ae400 (0000)
000AE450 0060:
	_code_000ae450 (0000)
000AE4B0 0050:
	_code_000ae4b0 (0000)
000AE500 0040:
	_code_000ae500 (0000)
000AE540 0040:
	_code_000ae540 (0000)
000AE580 0040:
	_code_000ae580 (0000)
000AE5C0 0040:
	_code_000ae5c0 (0000)
000AE600 0050:
	_code_000ae600 (0000)
000AE650 0050:
	_code_000ae650 (0000)
000AE6A0 0040:
	_code_000ae6a0 (0000)
000AE6E0 0040:
	_code_000ae6e0 (0000)
000AE720 0050:
	_code_000ae720 (0000)
000AE770 0050:
	_code_000ae770 (0000)
000AE7C0 0050:
	_code_000ae7c0 (0000)
000AE810 0050:
	_code_000ae810 (0000)
000AE860 0050:
	_code_000ae860 (0000)
000AE8B0 0050:
	_code_000ae8b0 (0000)
000AE900 0040:
	_code_000ae900 (0000)
000AE940 0040:
	_code_000ae940 (0000)
000AE980 0020:
	_code_000ae980 (0000)
000AE9A0 0040:
	_code_000ae9a0 (0000)
000AE9E0 0040:
	_code_000ae9e0 (0000)
000AEA20 0040:
	_code_000aea20 (0000)
000AEA60 0040:
	_code_000aea60 (0000)
000AEAA0 0040:
	_code_000aeaa0 (0000)
000AEAE0 0050:
	_code_000aeae0 (0000)
000AEB30 0050:
	_code_000aeb30 (0000)
000AEB80 0050:
	_code_000aeb80 (0000)
000AEBD0 0040:
	_code_000aebd0 (0000)
000AEC10 0040:
	_code_000aec10 (0000)
000AEC50 0040:
	_code_000aec50 (0000)
000AEC90 0030:
	_code_000aec90 (0000)
000AECC0 0040:
	_code_000aecc0 (0000)
000AED00 0040:
	_code_000aed00 (0000)
000AED40 0050:
	_code_000aed40 (0000)
000AED90 0040:
	_code_000aed90 (0000)
000AEDD0 0040:
	_code_000aedd0 (0000)
000AEE10 0040:
	_code_000aee10 (0000)
000AEE50 0050:
	_code_000aee50 (0000)
000AEEA0 0040:
	_code_000aeea0 (0000)
000AEEE0 0040:
	_code_000aeee0 (0000)
000AEF20 0040:
	_code_000aef20 (0000)
000AEF60 0050:
	_code_000aef60 (0000)
000AEFB0 0040:
	_code_000aefb0 (0000)
000AEFF0 0040:
	_code_000aeff0 (0000)
000AF030 0040:
	_code_000af030 (0000)
000AF070 0040:
	_code_000af070 (0000)
000AF0B0 0020:
	_code_000af0b0 (0000)
000AF0D0 0020:
	_code_000af0d0 (0000)
000AF0F0 0020:
	_code_000af0f0 (0000)
000AF110 0020:
	_code_000af110 (0000)
000AF130 0020:
	_code_000af130 (0000)
000AF150 0020:
	_code_000af150 (0000)
000AF170 0040:
	_code_000af170 (0000)
000AF1B0 0020:
	_code_000af1b0 (0000)
000AF1D0 0040:
	_code_000af1d0 (0000)
000AF210 0040:
	_code_000af210 (0000)
000AF250 0040:
	_code_000af250 (0000)
000AF290 0040:
	_code_000af290 (0000)
000AF2D0 0040:
	_code_000af2d0 (0000)
000AF310 0040:
	_code_000af310 (0000)
000AF350 0040:
	_code_000af350 (0000)
000AF390 0040:
	_code_000af390 (0000)
000AF3D0 0040:
	_code_000af3d0 (0000)
000AF410 0040:
	_code_000af410 (0000)
000AF450 0040:
	_code_000af450 (0000)
000AF490 0040:
	_code_000af490 (0000)
000AF4D0 0040:
	_code_000af4d0 (0000)
000AF510 0040:
	_code_000af510 (0000)
000AF550 0020:
	_code_000af550 (0000)
000AF570 0040:
	_code_000af570 (0000)
000AF5B0 0020:
	_code_000af5b0 (0000)
000AF5D0 0040:
	_code_000af5d0 (0000)
000AF610 0040:
	_code_000af610 (0000)
000AF650 0040:
	_code_000af650 (0000)
000AF690 0040:
	_code_000af690 (0000)
000AF6D0 0040:
	_code_000af6d0 (0000)
000AF710 0040:
	_code_000af710 (0000)
000AF750 0040:
	_code_000af750 (0000)
000AF790 0040:
	_code_000af790 (0000)
000AF7D0 0040:
	_code_000af7d0 (0000)
000AF810 0040:
	_code_000af810 (0000)
000AF850 0040:
	_code_000af850 (0000)
000AF890 0040:
	_code_000af890 (0000)
000AF8D0 0040:
	_code_000af8d0 (0000)
000AF910 0040:
	_code_000af910 (0000)
000AF950 0040:
	_code_000af950 (0000)
000AF990 0040:
	_code_000af990 (0000)
000AF9D0 0040:
	_code_000af9d0 (0000)
000AFA10 0040:
	_code_000afa10 (0000)
000AFA50 0040:
	_code_000afa50 (0000)
000AFA90 0040:
	_code_000afa90 (0000)
000AFAD0 0040:
	_code_000afad0 (0000)
000AFB10 0040:
	_code_000afb10 (0000)
000AFB50 0040:
	_code_000afb50 (0000)
000AFB90 0040:
	_code_000afb90 (0000)
000AFBD0 0040:
	_code_000afbd0 (0000)
000AFC10 0040:
	_code_000afc10 (0000)
000AFC50 0040:
	_code_000afc50 (0000)
000AFC90 0040:
	_code_000afc90 (0000)
000AFCD0 0040:
	_code_000afcd0 (0000)
000AFD10 0040:
	_code_000afd10 (0000)
000AFD50 0040:
	_code_000afd50 (0000)
000AFD90 0040:
	_code_000afd90 (0000)
000AFDD0 0040:
	_code_000afdd0 (0000)
000AFE10 0040:
	_code_000afe10 (0000)
000AFE50 0040:
	_code_000afe50 (0000)
000AFE90 0040:
	_code_000afe90 (0000)
000AFED0 0040:
	_code_000afed0 (0000)
000AFF10 0040:
	_code_000aff10 (0000)
000AFF50 0040:
	_code_000aff50 (0000)
000AFF90 0040:
	_code_000aff90 (0000)
000AFFD0 0040:
	_code_000affd0 (0000)
000B0010 0040:
	_code_000b0010 (0000)
000B0050 0020:
	_code_000b0050 (0000)
000B0070 0040:
	_code_000b0070 (0000)
000B00B0 0040:
	_code_000b00b0 (0000)
000B00F0 0040:
	_code_000b00f0 (0000)
000B0130 0040:
	_code_000b0130 (0000)
000B0170 0040:
	_code_000b0170 (0000)
000B01B0 0040:
	_code_000b01b0 (0000)
000B01F0 0040:
	_code_000b01f0 (0000)
000B0230 0040:
	_code_000b0230 (0000)
000B0270 0040:
	_code_000b0270 (0000)
000B02B0 0040:
	_code_000b02b0 (0000)
000B02F0 0040:
	_code_000b02f0 (0000)
000B0330 0040:
	_code_000b0330 (0000)
000B0370 0040:
	_code_000b0370 (0000)
000B03B0 0040:
	_code_000b03b0 (0000)
000B03F0 0040:
	_code_000b03f0 (0000)
000B0430 0040:
	_code_000b0430 (0000)
000B0470 0040:
	_code_000b0470 (0000)
000B04B0 0040:
	_code_000b04b0 (0000)
000B04F0 0040:
	_code_000b04f0 (0000)
000B0530 0040:
	_code_000b0530 (0000)
000B0570 0040:
	_code_000b0570 (0000)
000B05B0 0050:
	_code_000b05b0 (0000)
000B0600 0050:
	_code_000b0600 (0000)
000B0650 0050:
	_code_000b0650 (0000)
000B06A0 0050:
	_code_000b06a0 (0000)
000B06F0 0040:
	_code_000b06f0 (0000)
000B0730 0040:
	_code_000b0730 (0000)
000B0770 0050:
	_code_000b0770 (0000)
000B07C0 0050:
	_code_000b07c0 (0000)
000B0810 0040:
	_code_000b0810 (0000)
000B0850 0050:
	_code_000b0850 (0000)
000B08A0 0050:
	_code_000b08a0 (0000)
000B08F0 0050:
	_code_000b08f0 (0000)
000B0940 0050:
	_code_000b0940 (0000)
000B0990 0050:
	_code_000b0990 (0000)
000B09E0 0040:
	_code_000b09e0 (0000)
000B0A20 0040:
	_code_000b0a20 (0000)
000B0A60 0040:
	_code_000b0a60 (0000)
000B0AA0 0040:
	_code_000b0aa0 (0000)
000B0AE0 0040:
	_code_000b0ae0 (0000)
000B0B20 0040:
	_code_000b0b20 (0000)
000B0B60 0030:
	_code_000b0b60 (0000)
000B0B90 0020:
	_code_000b0b90 (0000)
000B0BB0 0020:
	_code_000b0bb0 (0000)
000B0BD0 0040:
	_code_000b0bd0 (0000)
000B0C10 0040:
	_code_000b0c10 (0000)
000B0C50 0020:
	_code_000b0c50 (0000)
000B0C70 0030:
	_code_000b0c70 (0000)
000B0CA0 0030:
	_code_000b0ca0 (0000)
000B0CD0 0020:
	_code_000b0cd0 (0000)
000B0CF0 0040:
	_code_000b0cf0 (0000)
000B0D30 0050:
	_code_000b0d30 (0000)
000B0D80 0020:
	_code_000b0d80 (0000)
000B0DA0 0030:
	_code_000b0da0 (0000)
000B0DD0 0030:
	_code_000b0dd0 (0000)
000B0E00 0030:
	_code_000b0e00 (0000)
000B0E30 0030:
	_code_000b0e30 (0000)
000B0E60 0030:
	_code_000b0e60 (0000)
000B0E90 0030:
	_code_000b0e90 (0000)
000B0EC0 0030:
	_code_000b0ec0 (0000)
000B0EF0 0030:
	_code_000b0ef0 (0000)
000B0F20 0030:
	_code_000b0f20 (0000)
000B0F50 0030:
	_code_000b0f50 (0000)
000B0F80 0030:
	_code_000b0f80 (0000)
000B0FB0 0030:
	_code_000b0fb0 (0000)
000B0FE0 0030:
	_code_000b0fe0 (0000)
000B1010 0040:
	_code_000b1010 (0000)
000B1050 0040:
	_code_000b1050 (0000)
000B1090 0020:
	_code_000b1090 (0000)
000B10B0 0040:
	_code_000b10b0 (0000)
000B10F0 0040:
	_code_000b10f0 (0000)
000B1130 0040:
	_code_000b1130 (0000)
000B1170 0040:
	_code_000b1170 (0000)
000B11B0 0040:
	_code_000b11b0 (0000)
000B11F0 0030:
	_code_000b11f0 (0000)
000B1220 0020:
	_code_000b1220 (0000)
000B1240 0020:
	_code_000b1240 (0000)
000B1260 0020:
	_code_000b1260 (0000)
000B1280 0020:
	_code_000b1280 (0000)
000B12A0 0020:
	_code_000b12a0 (0000)
000B12C0 0020:
	_code_000b12c0 (0000)
000B12E0 0040:
	_code_000b12e0 (0000)
000B1320 0020:
	_code_000b1320 (0000)
000B1340 0020:
	_code_000b1340 (0000)
000B1360 0040:
	_code_000b1360 (0000)
000B13A0 0040:
	_code_000b13a0 (0000)
000B13E0 0040:
	_code_000b13e0 (0000)
000B1420 0040:
	_code_000b1420 (0000)
000B1460 0040:
	_code_000b1460 (0000)
000B14A0 0020:
	_radiosity_hack_start_evaluate (0000)
000B14C0 0020:
	_radiosity_hack_save_evaluate (0000)
000B14E0 0020:
	_radiosity_hack_find_point_evaluate (0000)
000B1500 0020:
	_code_000b1500 (0000)
000B1520 0020:
	_code_000b1520 (0000)
000B1540 0040:
	_code_000b1540 (0000)
000B1580 0040:
	_code_000b1580 (0000)
000B15C0 0040:
	_code_000b15c0 (0000)
000B1600 0040:
	_code_000b1600 (0000)
000B1640 0050:
	_code_000b1640 (0000)
000B1690 0050:
	_code_000b1690 (0000)
000B16E0 0020:
	_code_000b16e0 (0000)
000B1700 0020:
	_code_000b1700 (0000)
000B1720 0020:
	_code_000b1720 (0000)
000B1740 0020:
	_code_000b1740 (0000)
000B1760 0040:
	_code_000b1760 (0000)
000B17A0 0040:
	_code_000b17a0 (0000)
000B17E0 0040:
	_code_000b17e0 (0000)
000B1820 0040:
	_code_000b1820 (0000)
000B1860 0020:
	_code_000b1860 (0000)
000B1880 0020:
	_code_000b1880 (0000)
000B18A0 0020:
	_code_000b18a0 (0000)
000B18C0 0030:
	_code_000b18c0 (0000)
000B18F0 0030:
	_code_000b18f0 (0000)
000B1920 0030:
	_code_000b1920 (0000)
000B1950 0030:
	_code_000b1950 (0000)
000B1980 0020:
	_code_000b1980 (0000)
000B19A0 0020:
	_code_000b19a0 (0000)
000B19C0 0020:
	_code_000b19c0 (0000)
000B19E0 0020:
	_code_000b19e0 (0000)
000B1A00 0030:
	_code_000b1a00 (0000)
000B1A30 0020:
	_code_000b1a30 (0000)
000B1A50 0020:
	_code_000b1a50 (0000)
000B1A70 0020:
	_code_000b1a70 (0000)
000B1A90 0040:
	_code_000b1a90 (0000)
000B1AD0 0040:
	_code_000b1ad0 (0000)
000B1B10 0020:
	_code_000b1b10 (0000)
000B1B30 0040:
	_code_000b1b30 (0000)
000B1B70 0040:
	_code_000b1b70 (0000)
000B1BB0 0030:
	_code_000b1bb0 (0000)
000B1BE0 0040:
	_code_000b1be0 (0000)
000B1C20 0040:
	_code_000b1c20 (0000)
000B1C60 0040:
	_code_000b1c60 (0000)
000B1CA0 0040:
	_code_000b1ca0 (0000)
000B1CE0 0040:
	_code_000b1ce0 (0000)
000B1D20 0040:
	_code_000b1d20 (0000)
000B1D60 0040:
	_code_000b1d60 (0000)
000B1DA0 0040:
	_code_000b1da0 (0000)
000B1DE0 0040:
	_code_000b1de0 (0000)
000B1E20 0050:
	_code_000b1e20 (0000)
000B1E70 0040:
	_code_000b1e70 (0000)
000B1EB0 0040:
	_code_000b1eb0 (0000)
000B1EF0 0040:
	_code_000b1ef0 (0000)
000B1F30 0040:
	_code_000b1f30 (0000)
000B1F70 0050:
	_code_000b1f70 (0000)
000B1FC0 0050:
	_code_000b1fc0 (0000)
000B2010 0040:
	_code_000b2010 (0000)
000B2050 0020:
	_code_000b2050 (0000)
000B2070 0050:
	_code_000b2070 (0000)
000B20C0 0050:
	_code_000b20c0 (0000)
000B2110 0050:
	_code_000b2110 (0000)
000B2160 0050:
	_code_000b2160 (0000)
000B21B0 0040:
	_code_000b21b0 (0000)
000B21F0 0040:
	_code_000b21f0 (0000)
000B2230 0040:
	_code_000b2230 (0000)
000B2270 0040:
	_code_000b2270 (0000)
000B22B0 0020:
	_code_000b22b0 (0000)
000B22D0 0040:
	_code_000b22d0 (0000)
000B2310 0020:
	_code_000b2310 (0000)
000B2330 0050:
	_code_000b2330 (0000)
000B2380 0050:
	_code_000b2380 (0000)
000B23D0 0040:
	_code_000b23d0 (0000)
000B2410 0040:
	_code_000b2410 (0000)
000B2450 0040:
	_code_000b2450 (0000)
000B2490 0040:
	_code_000b2490 (0000)
000B24D0 0040:
	_code_000b24d0 (0000)
000B2510 0040:
	_code_000b2510 (0000)
000B2550 0040:
	_code_000b2550 (0000)
000B2590 0040:
	_code_000b2590 (0000)
000B25D0 0040:
	_code_000b25d0 (0000)
000B2610 0040:
	_code_000b2610 (0000)
000B2650 0020:
	_code_000b2650 (0000)
000B2670 0040:
	_code_000b2670 (0000)
000B26B0 0040:
	_code_000b26b0 (0000)
000B26F0 0040:
	_code_000b26f0 (0000)
000B2730 0040:
	_code_000b2730 (0000)
000B2770 0050:
	_code_000b2770 (0000)
000B27C0 0040:
	_code_000b27c0 (0000)
000B2800 0040:
	_code_000b2800 (0000)
000B2840 0030:
	_code_000b2840 (0000)
000B2870 0040:
	_code_000b2870 (0000)
000B28B0 0040:
	_code_000b28b0 (0000)
000B28F0 0020:
	_code_000b28f0 (0000)
000B2910 0020:
	_code_000b2910 (0000)
000B2930 0020:
	_code_000b2930 (0000)
000B2950 0050:
	_code_000b2950 (0000)
000B29A0 0020:
	_code_000b29a0 (0000)
000B29C0 0040:
	_code_000b29c0 (0000)
000B2A00 0040:
	_code_000b2a00 (0000)
000B2A40 0060:
	_code_000b2a40 (0000)
000B2AA0 0060:
	_code_000b2aa0 (0000)
000B2B00 0050:
	_code_000b2b00 (0000)
000B2B50 0040:
	_code_000b2b50 (0000)
000B2B90 0020:
	_code_000b2b90 (0000)
000B2BB0 0040:
	_code_000b2bb0 (0000)
000B2BF0 0020:
	_code_000b2bf0 (0000)
000B2C10 0020:
	_code_000b2c10 (0000)
000B2C30 0020:
	_code_000b2c30 (0000)
000B2C50 0020:
	_code_000b2c50 (0000)
000B2C70 0040:
	_code_000b2c70 (0000)
000B2CB0 0030:
	_code_000b2cb0 (0000)
000B2CE0 0030:
	_code_000b2ce0 (0000)
000B2D10 0040:
	_code_000b2d10 (0000)
000B2D50 0040:
	_code_000b2d50 (0000)
000B2D90 0020:
	_code_000b2d90 (0000)
000B2DB0 0040:
	_code_000b2db0 (0000)
000B2DF0 0110:
	_hs_scenario_merge (0000)
000B2F00 00d0:
	_code_000b2f00 (0000)
000B2FD0 0010:
	_hs_dispose (0000)
000B2FE0 0010:
	_hs_recompile (0000)
000B2FF0 0050:
	_hs_update (0000)
000B3040 0060:
	_hs_node_gc (0000)
000B30A0 0050:
	_hs_function_get (0000)
000B30F0 0060:
	_hs_find_script_by_name (0000)
000B3150 0060:
	_hs_find_tag_reference_by_index (0000)
000B31B0 0050:
	_hs_global_external_get (0000)
000B3200 0040:
	_hs_global_get_type (0000)
000B3240 0040:
	_hs_global_get_name (0000)
000B3280 00e0:
	_hs_find_global_by_name (0000)
000B3360 0050:
	_hs_find_function_by_name (0000)
000B33B0 0020:
	_code_000b33b0 (0000)
000B33D0 0080:
	_code_000b33d0 (0000)
000B3450 0040:
	_code_000b3450 (0000)
000B3490 0040:
	_code_000b3490 (0000)
000B34D0 0030:
	_code_000b34d0 (0000)
000B3500 0020:
	_code_000b3500 (0000)
000B3520 0030:
	_code_000b3520 (0000)
000B3550 0030:
	_code_000b3550 (0000)
000B3580 0060:
	_code_000b3580 (0000)
000B35E0 0030:
	_code_000b35e0 (0000)
000B3610 00b0:
	_code_000b3610 (0000)
000B36C0 0030:
	_code_000b36c0 (0000)
000B36F0 0030:
	_code_000b36f0 (0000)
000B3720 0030:
	_code_000b3720 (0000)
000B3750 0030:
	_code_000b3750 (0000)
000B3780 0030:
	_code_000b3780 (0000)
000B37B0 0030:
	_code_000b37b0 (0000)
000B37E0 0030:
	_code_000b37e0 (0000)
000B3810 0030:
	_code_000b3810 (0000)
000B3840 0030:
	_code_000b3840 (0000)
000B3870 0030:
	_code_000b3870 (0000)
000B38A0 0040:
	_code_000b38a0 (0000)
000B38E0 0040:
	_code_000b38e0 (0000)
000B3920 00e0:
	_hs_tokens_enumerate (0000)
000B3A00 0110:
	_code_000b3a00 (0000)
000B3B10 0050:
	_code_000b3b10 (0000)
000B3B60 0140:
	_code_000b3b60 (0000)
000B3CA0 0070:
	_code_000b3ca0 (0000)
000B3D10 00d0:
	_code_000b3d10 (0000)
000B3DE0 00a0:
	_code_000b3de0 (0000)
000B3E80 0020:
	_code_000b3e80 (0000)
000B3EA0 0040:
	_hs_evaluate_by_name (0000)
000B3EE0 0020:
	_code_000b3ee0 (0000)
000B3F00 0050:
	_code_000b3f00 (0000)
000B3F50 0060:
	_code_000b3f50 (0000)
000B3FB0 0180:
	_hs_scenario_postprocess (0000)
000B4130 0040:
	_hs_initialize_for_new_map (0000)
000B4170 0050:
	_hs_dispose_from_old_map (0000)
000B41C0 0070:
	_hs_help (0000)
000B4230 0100:
	_hs_doc (0000)
000B4330 0060:
	_hs_hack (0000)
000B4390 0020:
	_code_000b4390 (0000)
000B43B0 0040:
	_code_000b43b0 (0000)
000B43F0 0070:
	_hs_initialize (0000)
000B4460 0250:
	_hs_compile_and_evaluate (0000)
0025D734 000a:
	??_C@_09IKEFCBLP@hs_update?$AA@ (0000)
0025D740 34bc:
	_hs_object_type_masks (0000)
	_hs_tag_reference_type_group_tags (000c)
	_hs_type_sizes (0030)
	__hs_type_boolean_default (0092)
	__hs_type_real_default (0094)
	__hs_type_short_integer_default (0098)
	__hs_type_long_integer_default (009c)
	__hs_type_script_default (00a0)
	__hs_type_trigger_volume_default (00a4)
	__hs_type_cutscene_flag_default (00a8)
	__hs_type_cutscene_camera_point_default (00ac)
	__hs_type_cutscene_title_default (00b0)
	__hs_type_cutscene_recording_default (00b4)
	__hs_type_device_group_default (00b8)
	__hs_type_ai_default (00bc)
	__hs_type_ai_command_list_default (00c0)
	__hs_type_starting_profile_default (00c4)
	__hs_type_conversation_default (00c8)
	__hs_type_navpoint_default (00cc)
	__hs_type_hud_message_default (00d0)
	__hs_type_object_list_default (00d4)
	__hs_type_sound_default (00d8)
	__hs_type_looping_sound_default (00dc)
	__hs_type_effect_default (00e0)
	__hs_type_damage_default (00e4)
	__hs_type_animation_graph_default (00e8)
	__hs_type_actor_variant_default (00ec)
	__hs_type_damage_effect_default (00f0)
	__hs_type_object_definition_default (00f4)
	__hs_type_enum_game_difficulty_default (00f8)
	__hs_type_enum_team_default (00fc)
	__hs_type_enum_ai_default_state_default (0100)
	__hs_type_enum_actor_type_default (0104)
	__hs_type_enum_hud_corner_default (0108)
	__hs_type_object_name_default (010c)
	__hs_type_object_default (0110)
	__hs_type_unit_default (0114)
	__hs_type_vehicle_default (0118)
	__hs_type_weapon_default (011c)
	__hs_type_device_default (0120)
	__hs_type_scenery_default (0124)
	_hs_function_table_count (3490)
	_hs_enum_table (3494)
00260BFC 0008:
	??_C@_07CEEMMIOB@YAHSFFZ?$AA@ (0000)
00260C04 0016:
	??_C@_0BG@FGLGKHGE@xbox_set_machine_name?$AA@ (0000)
00260C1C 0015:
	??_C@_0BF@CAOOIFOF@another?5one?5for?5zach?$AA@ (0000)
00260C34 0017:
	??_C@_0BH@MBGELAOF@network_game_start_now?$AA@ (0000)
00260C4C 001c:
	??_C@_0BM@JLJEIGJL@display?5in?9game?5help?5dialog?$AA@ (0000)
00260C68 0016:
	??_C@_0BG@KMKBMBOF@display_scenario_help?$AA@ (0000)
00260C80 000a:
	??_C@_09KGLHLKML@blah?5blah?$AA@ (0000)
00260C8C 0014:
	??_C@_0BE@DOOJAELF@ui_widget_show_path?$AA@ (0000)
00260CA0 0039:
	??_C@_0DJ@IBCEGIFG@returns?5TRUE?5if?5player0?5is?5using@ (0000)
00260CDC 001f:
	??_C@_0BP@CAFNGFCK@player0_joystick_set_is_normal?$AA@ (0000)
00260CFC 0031:
	??_C@_0DB@NFGLCOOC@returns?5TRUE?5if?5player0?8s?5look?5p@ (0000)
00260D30 001f:
	??_C@_0BP@IMKBIFBP@player0_look_pitch_is_inverted?$AA@ (0000)
00260D50 0016:
	??_C@_0BG@DNDEFBJP@invert?5player0?8s?5look?$AA@ (0000)
00260D68 001a:
	??_C@_0BK@EJDANAOH@player0_look_invert_pitch?$AA@ (0000)
00260D84 003a:
	??_C@_0DK@MCOIKBMH@unlocks?5all?5the?5solo?5player?5leve@ (0000)
00260DC0 001b:
	??_C@_0BL@IEHDGOCH@profile_unlock_solo_levels?$AA@ (0000)
00260DDC 001f:
	??_C@_0BP@POPBAPGG@for?5zach?8s?5multiplayer?5testing?$AA@ (0000)
00260DFC 001a:
	??_C@_0BK@PAJPHOCA@fast_setup_network_server?$AA@ (0000)
00260E18 0020:
	??_C@_0CA@FANKFLPA@delete?5all?5custom?5profile?5files?$AA@ (0000)
00260E38 0017:
	??_C@_0BH@FJCOEEAH@delete_save_game_files?$AA@ (0000)
00260E50 0017:
	??_C@_0BH@PCKIDBEO@enumerate?5memory?5units?$AA@ (0000)
00260E68 0017:
	??_C@_0BH@FEHDJGDP@enumerate_memory_units?$AA@ (0000)
00260E80 0021:
	??_C@_0CB@MCIGDDDM@cinematic_set_near_clip_distance@ (0000)
00260EA4 003e:
	??_C@_0DO@GBEONAKM@returns?5control?5of?5the?5screen?5ef@ (0000)
00260EE4 001d:
	??_C@_0BN@EJNOAHDO@cinematic_screen_effect_stop?$AA@ (0000)
00260F08 0050:
	??_C@_0FA@OKHANBEI@sets?5the?5video?5effect?3?5?$DMnoise?5in@ (0000)
00260F58 0022:
	??_C@_0CC@NHJBAFAF@cinematic_screen_effect_set_vide@ (0000)
00260F7C 0028:
	??_C@_0CI@CPKBMJKL@sets?5the?5desaturation?5filter?5tin@ (0000)
00260FA4 0035:
	??_C@_0DF@KOCGJHFE@cinematic_screen_effect_set_filt@ (0000)
00260FDC 0017:
	??_C@_0BH@IGNAINFN@sets?5the?5filter?5effect?$AA@ (0000)
00260FF4 0023:
	??_C@_0CD@NPCIBMNN@cinematic_screen_effect_set_filt@ (0000)
00261018 001c:
	??_C@_0BM@FLFCGJEE@sets?5the?5convolution?5effect?$AA@ (0000)
00261034 0028:
	??_C@_0CI@OAGILDE@cinematic_screen_effect_set_conv@ (0000)
0026105C 0029:
	??_C@_0CJ@HJKIODBC@starts?5screen?5effect?$DL?5pass?5TRUE?5@ (0000)
00261088 001e:
	??_C@_0BO@GJCANMAD@cinematic_screen_effect_start?$AA@ (0000)
002610A8 0022:
	??_C@_0CC@MNCCMAEM@sets?5a?5screen?5effect?5script?5valu@ (0000)
002610CC 001f:
	??_C@_0BP@JBMHCHLM@script_screen_effect_set_value?$AA@ (0000)
002610EC 0024:
	??_C@_0CE@FPOKMJPJ@rasterizer_lights_reset_for_new_@ (0000)
00261110 0029:
	??_C@_0CJ@PNELLBAD@rasterizer_model_ambient_reflect@ (0000)
0026113C 000c:
	??_C@_0M@ENNHCMDJ@average?5fps?$AA@ (0000)
00261148 001a:
	??_C@_0BK@NNMACGCK@rasterizer_fps_accumulate?$AA@ (0000)
00261164 0011:
	??_C@_0BB@LFABFOAM@flush?5all?5decals?$AA@ (0000)
00261178 0018:
	??_C@_0BI@GKALAPIJ@rasterizer_decals_flush?$AA@ (0000)
00261190 001b:
	??_C@_0BL@LAIBDBP@resets?5the?5time?5code?5timer?$AA@ (0000)
002611AC 0010:
	??_C@_0BA@IEHFOMKL@time_code_reset?$AA@ (0000)
002611BC 0021:
	??_C@_0CB@NGCABCKD@starts?1stops?5the?5time?5code?5timer@ (0000)
002611E0 0010:
	??_C@_0BA@PBNAKLNN@time_code_start?$AA@ (0000)
002611F0 001a:
	??_C@_0BK@IKBGNCDJ@shows?5the?5time?5code?5timer?$AA@ (0000)
0026120C 000f:
	??_C@_0P@DOAHBLJM@time_code_show?$AA@ (0000)
0026121C 0028:
	??_C@_0CI@IIFIOBPA@returns?5the?5ticks?5left?5on?5the?5hu@ (0000)
00261244 0014:
	??_C@_0BE@GEDNLEIH@hud_get_timer_ticks?$AA@ (0000)
00261258 0021:
	??_C@_0CB@NCMAFFLB@pauses?5or?5unpauses?5the?5hud?5timer@ (0000)
0026127C 0010:
	??_C@_0BA@GCFCPEKL@pause_hud_timer?$AA@ (0000)
0026128C 0017:
	??_C@_0BH@OOLMCLIA@displays?5the?5hud?5timer?$AA@ (0000)
002612A4 000f:
	??_C@_0P@HFGOABKL@show_hud_timer?$AA@ (0000)
002612B8 0041:
	??_C@_0EB@BDPAFGEH@sets?5the?5timer?5upper?5left?5positi@ (0000)
002612FC 0017:
	??_C@_0BH@DLPPNHMH@hud_set_timer_position?$AA@ (0000)
00261318 004b:
	??_C@_0EL@JIKCJOAB@sets?5the?5warning?5time?5for?5the?5ti@ (0000)
00261364 001b:
	??_C@_0BL@EPBJPPOE@hud_set_timer_warning_time?$AA@ (0000)
00261380 0062:
	??_C@_0GC@KNNCKAGC@sets?5the?5time?5for?5the?5timer?5to?5?$DM@ (0000)
002613E4 0013:
	??_C@_0BD@MFBDJNDH@hud_set_timer_time?$AA@ (0000)
002613F8 0028:
	??_C@_0CI@NOMIAGJC@sets?5?$DMmessage?$DO?5as?5the?5current?5ob@ (0000)
00261420 0017:
	??_C@_0BH@BNMPFDBH@hud_set_objective_text?$AA@ (0000)
00261438 0024:
	??_C@_0CE@LCEFENLE@displays?5?$DMmessage?$DO?5as?5the?5help?5t@ (0000)
0026145C 0012:
	??_C@_0BC@NFPGGFLC@hud_set_help_text?$AA@ (0000)
00261470 0029:
	??_C@_0CJ@HPDKDGML@clears?5all?5non?9state?5messages?5on@ (0000)
0026149C 0013:
	??_C@_0BD@LKLLBKBG@hud_clear_messages?$AA@ (0000)
002614B0 0021:
	??_C@_0CB@OJEJFGHH@hides?1shows?5the?5weapon?5crosshair@ (0000)
002614D4 0013:
	??_C@_0BD@NLALOAPO@hud_show_crosshair?$AA@ (0000)
002614E8 0038:
	??_C@_0DI@IOODBFOL@starts?1stops?5manual?5blinking?5of?5@ (0000)
00261520 0018:
	??_C@_0BI@HOKPNGKG@hud_blink_motion_sensor?$AA@ (0000)
00261538 0024:
	??_C@_0CE@NDOJMBJJ@hides?1shows?5the?5motion?5sensor?5pa@ (0000)
0026155C 0017:
	??_C@_0BH@DGHFNMAN@hud_show_motion_sensor?$AA@ (0000)
00261574 0031:
	??_C@_0DB@IEIBHDEG@starts?1stops?5manual?5blinking?5of?5@ (0000)
002615A8 0011:
	??_C@_0BB@KLNGMCKM@hud_blink_shield?$AA@ (0000)
002615BC 001d:
	??_C@_0BN@CFJHFKFG@hides?1shows?5the?5shield?5panel?$AA@ (0000)
002615DC 0010:
	??_C@_0BA@LHAMNNKK@hud_show_shield?$AA@ (0000)
002615EC 0031:
	??_C@_0DB@EPIBFEHI@starts?1stops?5manual?5blinking?5of?5@ (0000)
00261620 0011:
	??_C@_0BB@IBGJKAMJ@hud_blink_health?$AA@ (0000)
00261634 001d:
	??_C@_0BN@OOJHHNGI@hides?1shows?5the?5health?5panel?$AA@ (0000)
00261654 0010:
	??_C@_0BA@JNLDLPMP@hud_show_health?$AA@ (0000)
00261664 0008:
	??_C@_07CIJCEFOC@?$DMdecay?$DO?$AA@ (0000)
0026166C 0013:
	??_C@_0BD@ELIKCPHA@player_effect_stop?$AA@ (0000)
00261680 001e:
	??_C@_0BO@IKEIPMCN@?$DMmax_intensity?$DO?5?$DMattack?5time?$DO?$AA@ (0000)
002616A0 0014:
	??_C@_0BE@PIEGOELM@player_effect_start?$AA@ (0000)
002616B4 000f:
	??_C@_0P@CIAGCNDH@?$DMleft?$DO?5?$DMright?$DO?$AA@ (0000)
002616C4 001d:
	??_C@_0BN@GOKLIOF@player_effect_set_max_rumble?$AA@ (0000)
002616E4 0015:
	??_C@_0BF@DEEOEHB@?$DMyaw?$DO?5?$DMpitch?$DO?5?$DMroll?$DO?$AA@ (0000)
002616FC 001f:
	??_C@_0BP@NNKJBFGC@player_effect_set_max_rotation?$AA@ (0000)
0026171C 000c:
	??_C@_0M@NDFOOKHK@?$DMx?$DO?5?$DMy?$DO?5?$DMz?$DO?$AA@ (0000)
00261728 0022:
	??_C@_0CC@PBPBPBMK@player_effect_set_max_translatio@ (0000)
0026174C 0028:
	??_C@_0CI@JMEIKJPJ@places?5lens?5flares?5in?5the?5struct@ (0000)
00261774 001c:
	??_C@_0BM@JCBHEBHN@structure_lens_flares_place?$AA@ (0000)
00261790 0036:
	??_C@_0DG@GFIFALBC@enables?5or?5disables?5the?5suppress@ (0000)
002617C8 001b:
	??_C@_0BL@IMAEIOGC@error_overflow_suppression?$AA@ (0000)
002617E4 0024:
	??_C@_0CE@CEODJKFC@clears?5console?5text?5from?5the?5scr@ (0000)
00261808 0004:
	??_C@_03LCPHGAHP@cls?$AA@ (0000)
00261810 0046:
	??_C@_0EG@KKLLHGEB@deactivates?5a?5nav?5point?5type?5att@ (0000)
00261858 0021:
	??_C@_0CB@BBDDIBAH@deactivate_team_nav_point_object@ (0000)
00261880 0043:
	??_C@_0ED@ODKAJMBF@deactivates?5a?5nav?5point?5type?5att@ (0000)
002618C4 001f:
	??_C@_0BP@FFCAJAJL@deactivate_team_nav_point_flag?$AA@ (0000)
002618E8 004f:
	??_C@_0EP@MKKPJIHK@deactivates?5a?5nav?5point?5type?5att@ (0000)
00261938 001c:
	??_C@_0BM@BDFKKKLI@deactivate_nav_point_object?$AA@ (0000)
00261958 004c:
	??_C@_0EM@MCLLNOCO@deactivates?5a?5nav?5point?5type?5att@ (0000)
002619A4 001a:
	??_C@_0BK@DGLDEGBN@deactivate_nav_point_flag?$AA@ (0000)
002619C0 00a6:
	??_C@_0KG@IGMLMNOA@activates?5a?5nav?5point?5type?5?$DMstri@ (0000)
00261A68 001f:
	??_C@_0BP@KPCCCOGP@activate_team_nav_point_object?$AA@ (0000)
00261A88 00a3:
	??_C@_0KD@MGKHNPNF@activates?5a?5nav?5point?5type?5?$DMstri@ (0000)
00261B2C 001d:
	??_C@_0BN@DAIMJPIP@activate_team_nav_point_flag?$AA@ (0000)
00261B50 00b5:
	??_C@_0LF@IKJCPCPO@activates?5a?5nav?5point?5type?5?$DMstri@ (0000)
00261C08 001a:
	??_C@_0BK@HAFGPOEM@activate_nav_point_object?$AA@ (0000)
00261C28 00b2:
	??_C@_0LC@CEKENOAE@activates?5a?5nav?5point?5type?5?$DMstri@ (0000)
00261CDC 0018:
	??_C@_0BI@ODAHMJD@activate_nav_point_flag?$AA@ (0000)
00261CF4 002c:
	??_C@_0CM@OGNBAMKH@resets?5the?5timer?5for?5the?5help?5te@ (0000)
00261D20 0017:
	??_C@_0BH@CJIDGDO@hud_help_flash_restart?$AA@ (0000)
00261D38 0024:
	??_C@_0CE@OPDGEBCF@starts?1stops?5the?5help?5text?5flash@ (0000)
00261D5C 0016:
	??_C@_0BG@GACKMFH@enable_hud_help_flash?$AA@ (0000)
00261D74 0021:
	??_C@_0CB@CGCDPINC@shows?5or?5hides?5the?5hud?5help?5text@ (0000)
00261D98 0013:
	??_C@_0BD@MIHKMEOA@show_hud_help_text?$AA@ (0000)
00261DAC 0017:
	??_C@_0BH@ODENMIDH@shows?5or?5hides?5the?5hud?$AA@ (0000)
00261DC4 0009:
	??_C@_08KPHFCNNE@show_hud?$AA@ (0000)
00261DD0 0054:
	??_C@_0FE@KJJDLEEF@stops?5the?5vehicle?5from?5running?5r@ (0000)
00261E24 000e:
	??_C@_0O@FGHNPNL@vehicle_hover?$AA@ (0000)
00261E34 001f:
	??_C@_0BP@MGDLCPMC@enables?5or?5disables?5all?5sound?4?$AA@ (0000)
00261E54 000d:
	??_C@_0N@OHOLGAEF@sound_enable?$AA@ (0000)
00261E68 006c:
	??_C@_0GM@DFOOAOLJ@changes?5the?5gain?5on?5the?5specifie@ (0000)
00261ED4 0015:
	??_C@_0BF@LKGAHBLK@sound_class_set_gain?$AA@ (0000)
00261EF0 0047:
	??_C@_0EH@GKPOOBNM@changes?5the?5reverb?5level?5for?5all@ (0000)
00261F38 0011:
	??_C@_0BB@EPCMCDLA@debug_sounds_wet?$AA@ (0000)
00261F50 0058:
	??_C@_0FI@CEKHGMIG@changes?5the?5minimum?5and?5maximum?5@ (0000)
00261FA8 0017:
	??_C@_0BH@LDPBMGME@debug_sounds_distances?$AA@ (0000)
00261FC0 003e:
	??_C@_0DO@BKACCKKF@enables?5or?5disabled?5all?5sound?5cl@ (0000)
00262000 0014:
	??_C@_0BE@LDMBBCCF@debug_sounds_enable?$AA@ (0000)
00262018 004a:
	??_C@_0EK@MCCKPH@enables?5or?5disables?5the?5alternat@ (0000)
00262064 001c:
	??_C@_0BM@JEKEFHLC@sound_looping_set_alternate?$AA@ (0000)
00262080 0059:
	??_C@_0FJ@JMABBOAB@changes?5the?5scale?5of?5the?5sound?5?$CI@ (0000)
002620DC 0018:
	??_C@_0BI@FPFPEHJF@sound_looping_set_scale?$AA@ (0000)
002620F4 0023:
	??_C@_0CD@DIFMHGI@stops?5the?5specified?5looping?5soun@ (0000)
00262118 0013:
	??_C@_0BD@JEMGBJLF@sound_looping_stop?$AA@ (0000)
00262130 005e:
	??_C@_0FO@CAGLKPLB@plays?5a?5looping?5sound?5from?5the?5s@ (0000)
00262190 0014:
	??_C@_0BE@BDJHJOLF@sound_looping_start?$AA@ (0000)
002621A4 000a:
	??_C@_09EEPHCJJI@your?5mom?4?$AA@ (0000)
002621B0 0016:
	??_C@_0BG@LENKKDAN@sound_looping_predict?$AA@ (0000)
002621C8 0023:
	??_C@_0CD@FHEJDHCN@stops?5the?5specified?5impulse?5soun@ (0000)
002621EC 0013:
	??_C@_0BD@IEEDLPOM@sound_impulse_stop?$AA@ (0000)
00262200 003c:
	??_C@_0DM@NDOIPBIJ@returns?5the?5time?5remaining?5for?5t@ (0000)
0026223C 0013:
	??_C@_0BD@KACBNOME@sound_impulse_time?$AA@ (0000)
00262250 005f:
	??_C@_0FP@MFPKEPLL@plays?5an?5impulse?5sound?5from?5the?5@ (0000)
002622B0 0014:
	??_C@_0BE@BDAPCED@sound_impulse_start?$AA@ (0000)
002622C4 0039:
	??_C@_0DJ@FGJLODBE@don?8t?5use?5this?5for?5anything?0?5you@ (0000)
00262300 000e:
	??_C@_0O@HCENDHCL@game_reverted?$AA@ (0000)
00262310 003d:
	??_C@_0DN@IHOKOEOL@skips?5?$DMshort?$DO?5amount?5of?5game?5tic@ (0000)
00262350 0010:
	??_C@_0BA@OAHFPEKH@game_skip_ticks?$AA@ (0000)
00262360 0026:
	??_C@_0CG@HIDPKKCM@saves?5debug?5game?5state?5to?5core?2?$DM@ (0000)
00262388 000f:
	??_C@_0P@MFCLGHLI@core_save_name?$AA@ (0000)
00262398 0028:
	??_C@_0CI@HDOOAIFP@saves?5debug?5game?5state?5to?5core?2c@ (0000)
002623C0 000a:
	??_C@_09BKECKIHL@core_save?$AA@ (0000)
002623D0 004a:
	??_C@_0EK@IIJLMEMI@loads?5debug?5game?5state?5from?5core@ (0000)
0026241C 001a:
	??_C@_0BK@CCFAMLLK@core_load_name_at_startup?$AA@ (0000)
00262438 0028:
	??_C@_0CI@KNINFODM@loads?5debug?5game?5state?5from?5core@ (0000)
00262460 000f:
	??_C@_0P@LEFFFMJ@core_load_name?$AA@ (0000)
00262470 004c:
	??_C@_0EM@KNLBMOGM@loads?5debug?5game?5state?5from?5core@ (0000)
002624BC 0015:
	??_C@_0BF@EPCCFJFF@core_load_at_startup?$AA@ (0000)
002624D4 002a:
	??_C@_0CK@IDPMPJLJ@loads?5debug?5game?5state?5from?5core@ (0000)
00262500 000a:
	??_C@_09BIFPFLKP@core_load?$AA@ (0000)
00262510 006d:
	??_C@_0GN@KLGMKFNM@reverts?5to?5last?5saved?5game?0?5if?5a@ (0000)
00262580 000c:
	??_C@_0M@LCNDBCNH@game_revert?$AA@ (0000)
0026258C 0035:
	??_C@_0DF@HINGOJPJ@checks?5to?5see?5if?5the?5game?5is?5try@ (0000)
002625C4 000c:
	??_C@_0M@LBDAPPEL@game_saving?$AA@ (0000)
002625D0 0026:
	??_C@_0CG@DKLDBBEP@disregards?5player?8s?5current?5situ@ (0000)
002625F8 0019:
	??_C@_0BJ@NACHHID@game_save_totally_unsafe?$AA@ (0000)
00262618 0053:
	??_C@_0FD@LCJDHBI@checks?5to?5see?5if?5it?5is?5safe?5to?5s@ (0000)
0026266C 0015:
	??_C@_0BF@EJKFFBAI@game_save_no_timeout?$AA@ (0000)
00262684 002e:
	??_C@_0CO@DHMKLEDP@cancels?5any?5pending?5game_save?0?5t@ (0000)
002626B4 0011:
	??_C@_0BB@DIOCPBHK@game_save_cancel?$AA@ (0000)
002626C8 0050:
	??_C@_0FA@MCHOHDKF@checks?5to?5see?5if?5it?5is?5safe?5to?5s@ (0000)
00262718 000a:
	??_C@_09HOPAPABE@game_save?$AA@ (0000)
00262724 0028:
	??_C@_0CI@OOMMKHLO@returns?5TRUE?5if?5the?5game?5is?5coop@ (0000)
0026274C 0014:
	??_C@_0BE@LFFFJLCD@game_is_cooperative?$AA@ (0000)
00262760 0013:
	??_C@_0BD@NJIPFDBM@game_safe_to_speak?$AA@ (0000)
00262778 0049:
	??_C@_0EJ@GKGKGDBM@returns?5FALSE?5if?5there?5are?5bad?5g@ (0000)
002627C4 000f:
	??_C@_0P@JGCPNNFL@game_all_quiet?$AA@ (0000)
002627D8 004c:
	??_C@_0EM@NLCABHJI@returns?5FALSE?5if?5it?5would?5be?5a?5b@ (0000)
00262824 0012:
	??_C@_0BC@BBMAJAOO@game_safe_to_save?$AA@ (0000)
00262838 0037:
	??_C@_0DH@LICMOLIN@causes?5the?5player?5to?5revert?5to?5h@ (0000)
00262870 000a:
	??_C@_09CJINGGIP@game_lost?$AA@ (0000)
00262880 0050:
	??_C@_0FA@GGFGIPKB@causes?5the?5player?5to?5successfull@ (0000)
002628D0 0009:
	??_C@_08HLLDBONO@game_won?$AA@ (0000)
002628DC 0013:
	??_C@_0BD@MCBFDNML@attract_mode_start?$AA@ (0000)
002628F0 005d:
	??_C@_0FN@HLNPCMML@suppresses?5or?5enables?5the?5automa@ (0000)
00262950 0027:
	??_C@_0CH@MNPHBFOE@cinematic_suppress_bsp_object_cr@ (0000)
00262978 0037:
	??_C@_0DH@FLBLONGL@activates?5the?5chapter?5title?0?5del@ (0000)
002629B0 001c:
	??_C@_0BM@IKIOBEBH@cinematic_set_title_delayed?$AA@ (0000)
002629CC 001c:
	??_C@_0BM@FBGINGDE@activates?5the?5chapter?5title?$AA@ (0000)
002629E8 0014:
	??_C@_0BE@PGICKJPK@cinematic_set_title?$AA@ (0000)
002629FC 0023:
	??_C@_0CD@LFPEKIMI@sets?5or?5removes?5the?5letterbox?5ba@ (0000)
00262A20 0019:
	??_C@_0BJ@BAAIBGKO@cinematic_show_letterbox?$AA@ (0000)
00262A3C 001d:
	??_C@_0BN@EABCMAHC@cinematic_skip_stop_internal?$AA@ (0000)
00262A5C 001e:
	??_C@_0BO@CEFFCEN@cinematic_skip_start_internal?$AA@ (0000)
00262A80 0040:
	??_C@_0EA@MGKGLPLJ@initializes?5the?5game?5to?5end?5a?5ci@ (0000)
00262AC0 000f:
	??_C@_0P@KLJDEHEA@cinematic_stop?$AA@ (0000)
00262AD0 003e:
	??_C@_0DO@JJCBJHLG@initializes?5game?5to?5start?5a?5cine@ (0000)
00262B10 0010:
	??_C@_0BA@NOHPMNHI@cinematic_start?$AA@ (0000)
00262B20 002d:
	??_C@_0CN@CKCCKCK@does?5a?5screen?5fade?5out?5to?5a?5part@ (0000)
00262B50 0009:
	??_C@_08MNGBOMED@fade_out?$AA@ (0000)
00262B5C 002e:
	??_C@_0CO@ICBDFNKE@does?5a?5screen?5fade?5in?5from?5a?5par@ (0000)
00262B8C 0008:
	??_C@_07EMDJNCPI@fade_in?$AA@ (0000)
00262B98 0061:
	??_C@_0GB@KEOHLLFA@makes?5the?5currently?5selected?5AI?5@ (0000)
00262BFC 0014:
	??_C@_0BE@HPGEAPAO@ai_debug_speak_list?$AA@ (0000)
00262C10 0052:
	??_C@_0FC@CKCABDEL@makes?5the?5currently?5selected?5AI?5@ (0000)
00262C64 000f:
	??_C@_0P@CFKHEPC@ai_debug_speak?$AA@ (0000)
00262C74 0031:
	??_C@_0DB@BKLPLELJ@teleports?5all?5players?5to?5the?5spe@ (0000)
00262CA8 0015:
	??_C@_0BF@MNJIGNNB@ai_debug_teleport_to?$AA@ (0000)
00262CC0 001f:
	??_C@_0BP@GGJIEECC@makes?5the?5selected?5AI?5vocalize?$AA@ (0000)
00262CE0 0012:
	??_C@_0BC@EPJDOGKL@ai_debug_vocalize?$AA@ (0000)
00262CF4 003a:
	??_C@_0DK@BDAJJHIG@drops?5the?5AI?5debugging?5sound?5poi@ (0000)
00262D30 0019:
	??_C@_0BJ@BFPONJAB@ai_debug_sound_point_set?$AA@ (0000)
00262D4C 0023:
	??_C@_0CD@BPLDBJKI@cycles?5through?5AI?5line?9spray?5mod@ (0000)
00262D70 0009:
	??_C@_08DCDECFKL@ai_lines?$AA@ (0000)
00262D7C 0020:
	??_C@_0CA@IPKMICDI@tests?5sun?5occlusion?5at?5a?5point?4?$AA@ (0000)
00262D9C 0016:
	??_C@_0BG@KLAAOAPK@radiosity_debug_point?$AA@ (0000)
00262DB4 001a:
	??_C@_0BK@CKBAPKLO@saves?5radiosity?5solution?4?$AA@ (0000)
00262DD0 000f:
	??_C@_0P@BLCLEFHI@radiosity_save?$AA@ (0000)
00262DE0 001e:
	??_C@_0BO@HFIHGNPN@starts?5radiosity?5computation?4?$AA@ (0000)
00262E00 0010:
	??_C@_0BA@GJDBKMJI@radiosity_start?$AA@ (0000)
00262E10 001a:
	??_C@_0BK@DMHAJABC@displays?5the?5current?5pvs?4?$AA@ (0000)
00262E2C 000a:
	??_C@_09GOPAFGJB@debug_pvs?$AA@ (0000)
00262E38 0041:
	??_C@_0EB@NMECLPPG@enables?5or?5disables?5profile?5grap@ (0000)
00262E7C 0015:
	??_C@_0BF@FMPGFBJA@profile_graph_toggle?$AA@ (0000)
00262E94 0033:
	??_C@_0DD@OGKDPPFL@deactivates?5profile?5sections?5bas@ (0000)
00262EC8 0013:
	??_C@_0BD@MKHMGAJB@profile_deactivate?$AA@ (0000)
00262EDC 0031:
	??_C@_0DB@GDIILFNA@activates?5profile?5sections?5based@ (0000)
00262F10 0011:
	??_C@_0BB@DJLDEAFI@profile_activate?$AA@ (0000)
00262F24 0024:
	??_C@_0CE@BLACLJFE@dumps?5profile?5based?5on?5a?5substri@ (0000)
00262F48 000d:
	??_C@_0N@JBGKDHJG@profile_dump?$AA@ (0000)
00262F58 0017:
	??_C@_0BH@HDBEAPLP@resets?5profiling?5data?4?$AA@ (0000)
00262F70 000e:
	??_C@_0O@ENOKNHIH@profile_reset?$AA@ (0000)
00262F80 003c:
	??_C@_0DM@FLLMDGPG@writes?5all?5memory?5being?5used?5by?5@ (0000)
00262FBC 000b:
	??_C@_0L@KABFLLPL@debug_tags?$AA@ (0000)
00262FC8 0033:
	??_C@_0DD@GJGOAAHO@dumps?5memory?5leaks?5from?5the?5spec@ (0000)
00262FFC 0016:
	??_C@_0BG@HBMDOIMO@debug_memory_for_file?$AA@ (0000)
00263014 0023:
	??_C@_0CD@NDKKIJBE@dumps?5memory?5leaks?5by?5source?5fil@ (0000)
00263038 0015:
	??_C@_0BF@FHJINAHG@debug_memory_by_file?$AA@ (0000)
00263050 0014:
	??_C@_0BE@NCDCDBPP@dumps?5memory?5leaks?4?$AA@ (0000)
00263064 000d:
	??_C@_0N@DLNLOHGL@debug_memory?$AA@ (0000)
00263074 000d:
	??_C@_0N@HCKBCPLC@i?8m?5a?5rebel?$CB?$AA@ (0000)
00263084 0012:
	??_C@_0BC@MEOCIBOB@sound_cache_flush?$AA@ (0000)
00263098 001c:
	??_C@_0BM@NILBEDPL@don?8t?5make?5me?5kick?5your?5ass?$AA@ (0000)
002630B4 0014:
	??_C@_0BE@LLJBFLBC@texture_cache_flush?$AA@ (0000)
002630C8 0022:
	??_C@_0CC@JBFIAPDC@starts?5game?5in?5film?5playback?5mod@ (0000)
002630EC 0009:
	??_C@_08MDANPFHG@playback?$AA@ (0000)
002630F8 001a:
	??_C@_0BK@MAGCCDAB@prints?5the?5build?5version?4?$AA@ (0000)
00263114 0008:
	??_C@_07CPCPJPKL@version?$AA@ (0000)
0026311C 0028:
	??_C@_0CI@MPINILOF@returns?5the?5current?5structure?5bs@ (0000)
00263144 0014:
	??_C@_0BE@FPININIL@structure_bsp_index?$AA@ (0000)
00263158 003f:
	??_C@_0DP@GIHMMIA@takes?5off?5your?5condom?5and?5change@ (0000)
00263198 000b:
	??_C@_0L@DDOKFPLH@switch_bsp?$AA@ (0000)
002631A4 0019:
	??_C@_0BJ@LCPKLJEA@crashes?5?$CIfor?5debugging?$CJ?4?$AA@ (0000)
002631C0 0006:
	??_C@_05DLEGDHMH@crash?$AA@ (0000)
002631C8 003e:
	??_C@_0DO@BIGEHJCJ@changes?5the?5difficulty?5setting?5f@ (0000)
00263208 0014:
	??_C@_0BE@KJJMJLN@game_difficulty_set?$AA@ (0000)
0026321C 0028:
	??_C@_0CI@LIDNLFNM@changes?5the?5name?5of?5the?5multipla@ (0000)
00263244 0015:
	??_C@_0BF@DNODBFCJ@multiplayer_map_name?$AA@ (0000)
0026325C 0029:
	??_C@_0CJ@NDKJNDPN@changes?5the?5name?5of?5the?5solo?5pla@ (0000)
00263288 0009:
	??_C@_08EEDGNJFF@map_name?$AA@ (0000)
00263294 0023:
	??_C@_0CD@HOIBOJKH@starts?5the?5map?5from?5the?5beginnin@ (0000)
002632B8 000a:
	??_C@_09GBEEGLNM@map_reset?$AA@ (0000)
002632C4 0016:
	??_C@_0BG@HPFCOJP@debug_teleport_player?$AA@ (0000)
002632E0 0096:
	??_C@_0JG@OEKFOIBL@adds?1resets?5the?5player?8s?5health?0@ (0000)
00263378 0015:
	??_C@_0BF@LIPNNMGH@player_add_equipment?$AA@ (0000)
00263390 007b:
	??_C@_0HL@FKCIPEDI@returns?5true?5if?5any?5player?5has?5m@ (0000)
0026340C 0030:
	??_C@_0DA@EMDIICGH@player_action_test_move_relative@ (0000)
00263440 0073:
	??_C@_0HD@BAGPMGIO@returns?5true?5if?5any?5player?5has?5l@ (0000)
002634B4 0030:
	??_C@_0DA@LHLCMNNA@player_action_test_look_relative@ (0000)
002634E8 005f:
	??_C@_0FP@FPLNHPBL@returns?5true?5if?5any?5player?5has?5l@ (0000)
00263548 0027:
	??_C@_0CH@IPODCIJL@player_action_test_look_relative@ (0000)
00263570 005e:
	??_C@_0FO@FPFJIMKL@returns?5true?5if?5any?5player?5has?5l@ (0000)
002635D0 0026:
	??_C@_0CG@KDGNHAMI@player_action_test_look_relative@ (0000)
002635F8 005e:
	??_C@_0FO@BKLMCLDI@returns?5true?5if?5any?5player?5has?5l@ (0000)
00263658 0026:
	??_C@_0CG@FBGJOIPB@player_action_test_look_relative@ (0000)
00263680 005c:
	??_C@_0FM@OHDJPGAI@returns?5true?5if?5any?5player?5has?5l@ (0000)
002636DC 0024:
	??_C@_0CE@ELEICJFG@player_action_test_look_relative@ (0000)
00263700 0063:
	??_C@_0GD@BLMNKMDD@returns?5true?5if?5any?5player?5has?5h@ (0000)
00263764 0018:
	??_C@_0BI@JKGNCKDD@player_action_test_back?$AA@ (0000)
00263780 005d:
	??_C@_0FN@HFLAGEKC@returns?5true?5if?5any?5player?5has?5h@ (0000)
002637E0 001a:
	??_C@_0BK@KMINCOIM@player_action_test_accept?$AA@ (0000)
00263800 0065:
	??_C@_0GF@MIHAIOCO@returns?5true?5if?5any?5player?5has?5h@ (0000)
00263868 001a:
	??_C@_0BK@JDMMMEDA@player_action_test_action?$AA@ (0000)
00263888 0066:
	??_C@_0GG@HGHHGANP@returns?5true?5if?5any?5player?5has?5h@ (0000)
002638F0 0018:
	??_C@_0BI@HFGCNPKB@player_action_test_zoom?$AA@ (0000)
00263908 0067:
	??_C@_0GH@OCPKGAEC@returns?5true?5if?5any?5player?5has?5u@ (0000)
00263970 0023:
	??_C@_0CD@FLAPFCKH@player_action_test_grenade_trigg@ (0000)
00263998 0067:
	??_C@_0GH@MKJJPMMI@returns?5true?5if?5any?5player?5has?5u@ (0000)
00263A00 0023:
	??_C@_0CD@KMDPAGEB@player_action_test_primary_trigg@ (0000)
00263A28 0059:
	??_C@_0FJ@DCJENIPN@returns?5true?5if?5any?5player?5has?5j@ (0000)
00263A84 0018:
	??_C@_0BI@NGMOEHKK@player_action_test_jump?$AA@ (0000)
00263AA0 0049:
	??_C@_0EJ@OEPGPEIM@resets?5the?5player?5action?5test?5st@ (0000)
00263AEC 0019:
	??_C@_0BJ@FIMIGOAA@player_action_test_reset?$AA@ (0000)
00263B08 0029:
	??_C@_0CJ@PGGDBADL@enables?1disables?5camera?5control?5@ (0000)
00263B34 0016:
	??_C@_0BG@CJMKOGKF@player_camera_control?$AA@ (0000)
00263B50 0047:
	??_C@_0EH@IKPFKMDO@toggle?5player?5input?4?5the?5player?5@ (0000)
00263B98 0014:
	??_C@_0BE@DPPCOKHN@player_enable_input?$AA@ (0000)
00263BAC 0022:
	??_C@_0CC@OGLHJBMD@resets?5zoom?5levels?5on?5all?5player@ (0000)
00263BD0 0013:
	??_C@_0BD@DHOJJBPE@players_unzoom_all?$AA@ (0000)
00263BE4 003c:
	??_C@_0DM@FNBDMJOO@returns?5the?5actual?5current?5diffi@ (0000)
00263C20 0019:
	??_C@_0BJ@OIHMJOKB@game_difficulty_get_real?$AA@ (0000)
00263C40 006d:
	??_C@_0GN@JGKIKMEG@returns?5the?5current?5difficulty?5s@ (0000)
00263CB0 0014:
	??_C@_0BE@NFOCAJHF@game_difficulty_get?$AA@ (0000)
00263CC4 0030:
	??_C@_0DA@KFLCDPHF@gets?5ticks?5elapsed?5since?5the?5sta@ (0000)
00263CF4 000a:
	??_C@_09BJBHEIHK@game_time?$AA@ (0000)
00263D00 0014:
	??_C@_0BE@MOEAEKIP@set?5the?5game?5engine?$AA@ (0000)
00263D14 000d:
	??_C@_0N@COCPHDLO@game_variant?$AA@ (0000)
00263D24 0018:
	??_C@_0BI@FMBCCONB@changes?5the?5game?5speed?4?$AA@ (0000)
00263D3C 000b:
	??_C@_0L@EBJMMGN@game_speed?$AA@ (0000)
00263D48 002c:
	??_C@_0CM@NOFMHJPJ@loads?5the?5saved?5camera?5position?5@ (0000)
00263D74 0012:
	??_C@_0BC@KAIDKBA@debug_camera_load?$AA@ (0000)
00263D88 0026:
	??_C@_0CG@MCCPFDNK@saves?5the?5camera?5position?5and?5fa@ (0000)
00263DB0 0012:
	??_C@_0BC@IBFMJME@debug_camera_save?$AA@ (0000)
00263DC8 004b:
	??_C@_0EL@MCACPAAG@returns?5the?5number?5of?5ticks?5rema@ (0000)
00263E14 000c:
	??_C@_0M@FEMENHDC@camera_time?$AA@ (0000)
00263E20 0045:
	??_C@_0EF@MHKPPMCH@makes?5the?5scripted?5camera?5zoom?5o@ (0000)
00263E68 0010:
	??_C@_0BA@FNNDMIGA@camera_set_dead?$AA@ (0000)
00263E78 0029:
	??_C@_0CJ@FHBOKBJH@makes?5the?5scripted?5camera?5follow@ (0000)
00263EA4 0018:
	??_C@_0BI@DLHFJPKF@camera_set_first_person?$AA@ (0000)
00263EBC 0027:
	??_C@_0CH@CKGKGLPO@begins?5a?5prerecorded?5camera?5anim@ (0000)
00263EE4 0015:
	??_C@_0BF@LJDBPKGG@camera_set_animation?$AA@ (0000)
00263F00 0082:
	??_C@_0IC@IMCMBLFC@moves?5the?5camera?5to?5the?5specifie@ (0000)
00263F84 0014:
	??_C@_0BE@PHBPDFGA@camera_set_relative?$AA@ (0000)
00263F98 0053:
	??_C@_0FD@MABGALHH@moves?5the?5camera?5to?5the?5specifie@ (0000)
00263FEC 000b:
	??_C@_0L@CIJFOGOE@camera_set?$AA@ (0000)
00263FF8 0026:
	??_C@_0CG@ILCGPINM@toggles?5script?5control?5of?5the?5ca@ (0000)
00264020 000f:
	??_C@_0P@PANAGFOO@camera_control?$AA@ (0000)
00264030 005d:
	??_C@_0FN@KJHDLEGF@returns?5whether?5two?5teams?5have?5a@ (0000)
00264090 0015:
	??_C@_0BF@OADOLFIB@ai_allegiance_broken?$AA@ (0000)
002640A8 00c6:
	??_C@_0MG@MENEECDA@returns?5the?5status?5of?5a?5conversa@ (0000)
00264170 0017:
	??_C@_0BH@FMFCCBBA@ai_conversation_status?$AA@ (0000)
00264188 006e:
	??_C@_0GO@LGKCEIML@returns?5which?5line?5the?5conversat@ (0000)
002641F8 0015:
	??_C@_0BF@HNKFMNLH@ai_conversation_line?$AA@ (0000)
00264210 00d7:
	??_C@_0NH@JHEFMGMF@tries?5to?5add?5an?5entry?5to?5the?5lis@ (0000)
002642E8 0010:
	??_C@_0BA@MFJEPIKO@ai_conversation?$AA@ (0000)
002642F8 00c9:
	??_C@_0MJ@PDLKGHIC@returns?5the?5most?5severe?5combat?5s@ (0000)
002643C4 000a:
	??_C@_09FICECIL@ai_status?$AA@ (0000)
002643D0 002c:
	??_C@_0CM@IPJLMLAC@converts?5an?5ai?5reference?5to?5an?5o@ (0000)
002643FC 000a:
	??_C@_09MBEHCDKG@ai_actors?$AA@ (0000)
00264408 004f:
	??_C@_0EP@ODBFFBOF@return?5the?5number?5of?5non?9swarm?5a@ (0000)
00264458 0012:
	??_C@_0BC@HPLLKJGK@ai_nonswarm_count?$AA@ (0000)
00264470 004b:
	??_C@_0EL@IIMPGIAH@return?5the?5number?5of?5swarm?5actor@ (0000)
002644BC 000f:
	??_C@_0P@OFKPNLHN@ai_swarm_count?$AA@ (0000)
002644D0 0066:
	??_C@_0GG@FPENOKNJ@return?5the?5current?5strength?5?$CIave@ (0000)
00264538 000c:
	??_C@_0M@OIIOHEKL@ai_strength?$AA@ (0000)
00264548 0054:
	??_C@_0FE@KPJMLEMK@return?5the?5fraction?5?$FL0?91?$FN?5of?5liv@ (0000)
0026459C 0013:
	??_C@_0BD@FLJHJGCP@ai_living_fraction?$AA@ (0000)
002645B0 004c:
	??_C@_0EM@DOPNPNML@return?5the?5number?5of?5living?5acto@ (0000)
002645FC 0010:
	??_C@_0BA@IAICPKLJ@ai_living_count?$AA@ (0000)
00264610 0054:
	??_C@_0FE@INFAFBIO@return?5the?5number?5of?5actors?5that@ (0000)
00264664 0014:
	??_C@_0BE@LHHCBGEA@ai_going_to_vehicle?$AA@ (0000)
00264678 0094:
	??_C@_0JE@BOIFBAPA@gets?5the?5status?5of?5a?5number?5of?5u@ (0000)
0026470C 0017:
	??_C@_0BH@DBCBEOIB@ai_command_list_status?$AA@ (0000)
00264728 0091:
	??_C@_0JB@LENOKOFO@returns?5whether?5a?5platoon?5is?5in?5@ (0000)
002647BC 0010:
	??_C@_0BA@CIKCJCMM@ai_is_attacking?$AA@ (0000)
002647D0 0044:
	??_C@_0EE@CCBNBJI@either?5enables?5or?5disables?5autom@ (0000)
00264814 0011:
	??_C@_0BB@KKHOCPPH@ai_allow_dormant?$AA@ (0000)
00264828 0043:
	??_C@_0ED@ECMLENLA@either?5enables?5or?5disables?5charg@ (0000)
0026486C 0010:
	??_C@_0BA@DDOKBMJP@ai_allow_charge?$AA@ (0000)
0026487C 0028:
	??_C@_0CI@NLFKFBFL@makes?5an?5encounter?5change?5to?5a?5n@ (0000)
002648A4 000c:
	??_C@_0M@HJGNIGJJ@ai_set_team?$AA@ (0000)
002648B0 0035:
	??_C@_0DF@NKNKMONM@forces?5a?5group?5of?5actors?5to?5star@ (0000)
002648E8 000b:
	??_C@_0L@OLGHFNME@ai_berserk?$AA@ (0000)
002648F8 0071:
	??_C@_0HB@EJIKDAKL@links?5the?5first?5encounter?5so?5tha@ (0000)
0026496C 0013:
	??_C@_0BD@DHIAJHGB@ai_link_activation?$AA@ (0000)
00264980 0029:
	??_C@_0CJ@MHMPEHCD@tells?5a?5conversation?5that?5it?5may@ (0000)
002649AC 0018:
	??_C@_0BI@HBMMCOAA@ai_conversation_advance?$AA@ (0000)
002649C4 0034:
	??_C@_0DE@DEENDJBM@stops?5a?5conversation?5from?5playin@ (0000)
002649F8 0015:
	??_C@_0BF@LBBMOIF@ai_conversation_stop?$AA@ (0000)
00264A10 0056:
	??_C@_0FG@KBAEFLPA@sets?5the?5distance?5threshold?5whic@ (0000)
00264A68 0013:
	??_C@_0BD@CPKLJPGK@ai_follow_distance?$AA@ (0000)
00264A80 005a:
	??_C@_0FK@DIJGNAAH@sets?5the?5follow?5target?5for?5an?5en@ (0000)
00264ADC 0014:
	??_C@_0BE@BDKIHEPK@ai_follow_target_ai?$AA@ (0000)
00264AF0 003e:
	??_C@_0DO@OABAMBFA@sets?5the?5follow?5target?5for?5an?5en@ (0000)
00264B30 0016:
	??_C@_0BG@LNNJOKBM@ai_follow_target_unit?$AA@ (0000)
00264B48 0041:
	??_C@_0EB@IODABOEP@sets?5the?5follow?5target?5for?5an?5en@ (0000)
00264B8C 0019:
	??_C@_0BJ@NKIBODBE@ai_follow_target_players?$AA@ (0000)
00264BA8 0025:
	??_C@_0CF@OHNHAFOF@turns?5off?5following?5for?5an?5encou@ (0000)
00264BD0 0019:
	??_C@_0BJ@PJDBIPKF@ai_follow_target_disable?$AA@ (0000)
00264BF0 0043:
	??_C@_0ED@FABADECE@enables?5or?5disables?5a?5squad?5as?5b@ (0000)
00264C34 001e:
	??_C@_0BO@CCOKJDDJ@ai_automatic_migration_target?$AA@ (0000)
00264C54 003b:
	??_C@_0DL@OFDHAMJD@tells?5an?5actor?5to?5stop?5looking?5a@ (0000)
00264C90 0010:
	??_C@_0BA@LKGDJHLD@ai_stop_looking?$AA@ (0000)
00264CA0 0039:
	??_C@_0DJ@JOPJDMAA@tells?5an?5actor?5to?5look?5at?5an?5obj@ (0000)
00264CDC 0012:
	??_C@_0BC@HLAMCECP@ai_look_at_object?$AA@ (0000)
00264CF0 006e:
	??_C@_0GO@JOALMFGC@disables?5actors?5from?5impulsively@ (0000)
00264D60 001d:
	??_C@_0BN@JLNILHAM@ai_vehicle_enterable_disable?$AA@ (0000)
00264D80 0056:
	??_C@_0FG@GBDHBBEK@sets?5a?5vehicle?5as?5being?5impulsiv@ (0000)
00264DD8 001c:
	??_C@_0BM@PBINCDBL@ai_vehicle_enterable_actors?$AA@ (0000)
00264DF8 0066:
	??_C@_0GG@DACPFLMA@sets?5a?5vehicle?5as?5being?5impulsiv@ (0000)
00264E60 0020:
	??_C@_0CA@NPPEJHEN@ai_vehicle_enterable_actor_type?$AA@ (0000)
00264E80 004b:
	??_C@_0EL@JLDAEEFK@sets?5a?5vehicle?5as?5being?5impulsiv@ (0000)
00264ECC 001a:
	??_C@_0BK@GJNPJCCI@ai_vehicle_enterable_team?$AA@ (0000)
00264EE8 0053:
	??_C@_0FD@HFCIFLC@sets?5a?5vehicle?5as?5being?5impulsiv@ (0000)
00264F3C 001e:
	??_C@_0BO@KLJIFGLP@ai_vehicle_enterable_distance?$AA@ (0000)
00264F60 00cc:
	??_C@_0MM@OICDPAHD@sets?5a?5vehicle?5to?5?8belong?8?5to?5a?5@ (0000)
0026502C 0015:
	??_C@_0BF@MDDGNLBM@ai_vehicle_encounter?$AA@ (0000)
00265048 00b0:
	??_C@_0LA@BGPGFMO@reconnects?5all?5AI?5information?5to@ (0000)
002650F8 000d:
	??_C@_0N@KDEHKGHL@ai_reconnect?$AA@ (0000)
00265108 002c:
	??_C@_0CM@HMCMJHIH@sets?5an?5encounter?5to?5be?5playfigh@ (0000)
00265134 000d:
	??_C@_0N@LFBFBHID@ai_playfight?$AA@ (0000)
00265148 0072:
	??_C@_0HC@JIJJJEGM@sets?5the?5current?5state?5of?5a?5grou@ (0000)
002651BC 0015:
	??_C@_0BF@NDDKFDDN@ai_set_current_state?$AA@ (0000)
002651D8 0052:
	??_C@_0FC@CCMIPJJL@sets?5the?5state?5that?5a?5group?5of?5a@ (0000)
0026522C 0014:
	??_C@_0BE@FHDJKOIM@ai_set_return_state?$AA@ (0000)
00265240 0081:
	??_C@_0IB@LHCBCHIN@forces?5a?5named?5actor?5that?5is?5NOT@ (0000)
002652C4 0018:
	??_C@_0BI@JIJCFEMO@ai_force_active_by_unit?$AA@ (0000)
002652E0 0064:
	??_C@_0GE@FGJJGJIC@forces?5an?5encounter?5to?5remain?5ac@ (0000)
00265344 0010:
	??_C@_0BA@JCCJENEC@ai_force_active?$AA@ (0000)
00265358 0043:
	??_C@_0ED@EMGDOKEN@just?5like?5ai_command_list_advanc@ (0000)
0026539C 0020:
	??_C@_0CA@NNEGMCEA@ai_command_list_advance_by_unit?$AA@ (0000)
002653C0 008a:
	??_C@_0IK@IDKJEBLE@tells?5a?5group?5of?5actors?5that?5are@ (0000)
0026544C 0018:
	??_C@_0BI@PGKJPOLN@ai_command_list_advance?$AA@ (0000)
00265468 0041:
	??_C@_0EB@JPADDNII@tells?5a?5named?5unit?5to?5begin?5exec@ (0000)
002654AC 0018:
	??_C@_0BI@JFKCMHCK@ai_command_list_by_unit?$AA@ (0000)
002654C8 0046:
	??_C@_0EG@FKKPMGCE@tells?5a?5group?5of?5actors?5to?5begin@ (0000)
00265510 003d:
	??_C@_0DN@KGPGCPAI@causes?5a?5group?5of?5actors?5to?5pref@ (0000)
00265550 0017:
	??_C@_0BH@KBCJAOCM@ai_try_to_fight_player?$AA@ (0000)
00265568 004a:
	??_C@_0EK@MIPHAMFJ@causes?5a?5group?5of?5actors?5to?5pref@ (0000)
002655B4 0010:
	??_C@_0BA@COACJEKK@ai_try_to_fight?$AA@ (0000)
002655C4 003f:
	??_C@_0DP@LIDMBCHF@removes?5the?5preferential?5target?5@ (0000)
00265604 0018:
	??_C@_0BI@BBGNEJLP@ai_try_to_fight_nothing?$AA@ (0000)
00265620 0058:
	??_C@_0FI@OFACJKFH@refreshes?5the?5health?5and?5grenade@ (0000)
00265678 0009:
	??_C@_08KKHEGOEF@ai_renew?$AA@ (0000)
00265688 00b0:
	??_C@_0LA@JFFNCIAO@teleports?5a?5group?5of?5actors?5to?5t@ (0000)
00265738 0030:
	??_C@_0DA@CBDMAPFM@ai_teleport_to_starting_location@ (0000)
00265768 0050:
	??_C@_0FA@KOCCJFIK@teleports?5a?5group?5of?5actors?5to?5t@ (0000)
002657B8 0021:
	??_C@_0CB@EAKNGDFH@ai_teleport_to_starting_location@ (0000)
002657E0 0064:
	??_C@_0GE@PHCHPHID@if?5TRUE?0?5?$CKALL?$CK?5enemies?5will?5pref@ (0000)
00265844 0011:
	??_C@_0BB@FKJBCPPG@ai_prefer_target?$AA@ (0000)
00265858 0078:
	??_C@_0HI@NNICMLPM@if?5TRUE?0?5forces?5all?5actors?5to?5co@ (0000)
002658D0 000d:
	??_C@_0N@KKOCLGBG@ai_disregard?$AA@ (0000)
002658E0 00a9:
	??_C@_0KJ@MPCLAPNP@makes?5a?5list?5of?5objects?5braindea@ (0000)
0026598C 0015:
	??_C@_0BF@FEKPAHNJ@ai_braindead_by_unit?$AA@ (0000)
002659A8 0055:
	??_C@_0FF@DHBICPG@makes?5a?5group?5of?5actors?5braindea@ (0000)
00265A00 000d:
	??_C@_0N@GOELOEPC@ai_braindead?$AA@ (0000)
00265A10 0044:
	??_C@_0EE@GKDIENLI@tells?5a?5group?5of?5actors?5to?5get?5o@ (0000)
00265A54 0010:
	??_C@_0BA@DKBEIOPB@ai_exit_vehicle?$AA@ (0000)
00265A68 00c7:
	??_C@_0MH@DCJDEOFE@tells?5a?5group?5of?5actors?5to?5get?5i@ (0000)
00265B30 001a:
	??_C@_0BK@CPDAOGHE@ai_go_to_vehicle_override?$AA@ (0000)
00265B50 00b0:
	??_C@_0LA@HMDOLINK@tells?5a?5group?5of?5actors?5to?5get?5i@ (0000)
00265C00 0011:
	??_C@_0BB@CBILPDI@ai_go_to_vehicle?$AA@ (0000)
00265C14 002a:
	??_C@_0CK@DLJKIPPM@destroys?5an?5allegiance?5between?5t@ (0000)
00265C40 0015:
	??_C@_0BF@JBAFBLLJ@ai_allegiance_remove?$AA@ (0000)
00265C58 0029:
	??_C@_0CJ@EIDBKAAD@creates?5an?5allegiance?5between?5tw@ (0000)
00265C84 000e:
	??_C@_0O@MMJIJEGK@ai_allegiance?$AA@ (0000)
00265C98 0043:
	??_C@_0ED@PJCODOBM@makes?5a?5named?5vehicle?5or?5group?5o@ (0000)
00265CDC 0013:
	??_C@_0BD@KKGKCJCK@ai_migrate_by_unit?$AA@ (0000)
00265CF0 0070:
	??_C@_0HA@HABCCLGH@makes?5all?5or?5part?5of?5an?5encounte@ (0000)
00265D60 0015:
	??_C@_0BF@EICEIEFL@ai_migrate_and_speak?$AA@ (0000)
00265D78 003d:
	??_C@_0DN@NMFHKDKH@makes?5all?5or?5part?5of?5an?5encounte@ (0000)
00265DB8 000b:
	??_C@_0L@IOPAFJOP@ai_migrate?$AA@ (0000)
00265DC8 00a9:
	??_C@_0KJ@KIGAJKEC@enables?5or?5disables?5the?5maneuver@ (0000)
00265E74 0013:
	??_C@_0BD@NNDJLLMG@ai_maneuver_enable?$AA@ (0000)
00265E88 000c:
	??_C@_0M@EKPFIBEI@ai_maneuver?$AA@ (0000)
00265E98 005b:
	??_C@_0FL@LFCODCMF@makes?5all?5squads?5in?5the?5specifie@ (0000)
00265EF4 000b:
	??_C@_0L@KPNPLFPF@ai_retreat?$AA@ (0000)
00265F00 003c:
	??_C@_0DM@MHLBKFAF@makes?5the?5specified?5platoon?$CIs?$CJ?5g@ (0000)
00265F3C 000a:
	??_C@_09CAAEBFBI@ai_defend?$AA@ (0000)
00265F48 003c:
	??_C@_0DM@LLKALIEM@makes?5the?5specified?5platoon?$CIs?$CJ?5g@ (0000)
00265F84 000a:
	??_C@_09KALEDHKI@ai_attack?$AA@ (0000)
00265F90 0046:
	??_C@_0EG@IHIAFMGF@makes?5a?5squad?8s?5delay?5timer?5expi@ (0000)
00265FD8 0010:
	??_C@_0BA@DOCJEMJG@ai_timer_expire?$AA@ (0000)
00265FE8 002c:
	??_C@_0CM@EKIGCHEL@makes?5a?5squad?8s?5delay?5timer?5star@ (0000)
00266014 000f:
	??_C@_0P@MEBAAPFK@ai_timer_start?$AA@ (0000)
00266028 0042:
	??_C@_0EC@EHMIIBOP@makes?5an?5encounter?5magically?5awa@ (0000)
0026606C 0017:
	??_C@_0BH@JOJJHIME@ai_magically_see_units?$AA@ (0000)
00266084 003a:
	??_C@_0DK@FEGBCBBJ@makes?5an?5encounter?5magically?5awa@ (0000)
002660C0 0016:
	??_C@_0BG@DEOBEHIB@ai_magically_see_unit?$AA@ (0000)
002660D8 0036:
	??_C@_0DG@PGGLEFCL@makes?5an?5encounter?5magically?5awa@ (0000)
00266110 0019:
	??_C@_0BJ@BMOBLCAE@ai_magically_see_players?$AA@ (0000)
0026612C 0030:
	??_C@_0DA@OBFFCJKJ@makes?5one?5encounter?5magically?5aw@ (0000)
0026615C 001b:
	??_C@_0BL@IAFNJFPI@ai_magically_see_encounter?$AA@ (0000)
00266178 0041:
	??_C@_0EB@DKCJPPEK@enables?5or?5disables?5sight?5for?5ac@ (0000)
002661BC 000d:
	??_C@_0N@JHFGPNIE@ai_set_blind?$AA@ (0000)
002661D0 0043:
	??_C@_0ED@OJEGNMEF@enables?5or?5disables?5hearing?5for?5@ (0000)
00266214 000c:
	??_C@_0M@PKHJMINA@ai_set_deaf?$AA@ (0000)
00266220 003b:
	??_C@_0DL@EIHDNIAI@enables?5or?5disables?5respawning?5i@ (0000)
0026625C 000f:
	??_C@_0P@JFEDPAJA@ai_set_respawn?$AA@ (0000)
0026626C 003f:
	??_C@_0DP@EKKKCEPH@spawns?5a?5single?5actor?5in?5the?5spe@ (0000)
002662AC 000f:
	??_C@_0P@GPJAGKIM@ai_spawn_actor?$AA@ (0000)
002662BC 001f:
	??_C@_0BP@EDMOCONJ@clears?5the?5selected?5encounter?4?$AA@ (0000)
002662DC 000c:
	??_C@_0M@BJJOBCFB@ai_deselect?$AA@ (0000)
002662E8 0021:
	??_C@_0CB@IMAOAICA@selects?5the?5specified?5encounter?4@ (0000)
0026630C 000a:
	??_C@_09IKNHCOPL@ai_select?$AA@ (0000)
00266318 000f:
	??_C@_0P@NFGNEAKP@erases?5all?5AI?4?$AA@ (0000)
00266328 000d:
	??_C@_0N@LMGMMLFD@ai_erase_all?$AA@ (0000)
00266338 002d:
	??_C@_0CN@BLBALPHD@erases?5the?5specified?5encounter?5a@ (0000)
00266368 0009:
	??_C@_08FOFLKILD@ai_erase?$AA@ (0000)
00266378 0062:
	??_C@_0GC@HOOJIOAB@instantly?5and?5silently?5?$CIno?5anima@ (0000)
002663DC 000f:
	??_C@_0P@PLBALECA@ai_kill_silent?$AA@ (0000)
002663EC 0036:
	??_C@_0DG@DFPIOBAE@instantly?5kills?5the?5specified?5en@ (0000)
00266424 0008:
	??_C@_07EFCDNLJN@ai_kill?$AA@ (0000)
0026642C 002b:
	??_C@_0CL@DNONFKHO@places?5the?5specified?5encounter?5o@ (0000)
00266458 0009:
	??_C@_08MOLGLBAI@ai_place?$AA@ (0000)
00266464 0032:
	??_C@_0DC@DONOEKMC@detaches?5the?5specified?5list?5of?5u@ (0000)
00266498 0010:
	??_C@_0BA@BAIPPIOL@ai_detach_units?$AA@ (0000)
002664A8 0029:
	??_C@_0CJ@CBFJABMD@detaches?5the?5specified?5unit?5from@ (0000)
002664D4 000a:
	??_C@_09BBCLJKPC@ai_detach?$AA@ (0000)
002664E0 0044:
	??_C@_0EE@LFJNFJKM@attaches?5a?5unit?5to?5a?5newly?5creat@ (0000)
00266524 000f:
	??_C@_0P@MBJCCAG@ai_attach_free?$AA@ (0000)
00266538 0041:
	??_C@_0EB@NLDKDFBN@attaches?5the?5specified?5list?5of?5u@ (0000)
0026657C 0010:
	??_C@_0BA@JKBNOKGL@ai_attach_units?$AA@ (0000)
0026658C 0038:
	??_C@_0DI@DEDFGNEG@attaches?5the?5specified?5unit?5to?5t@ (0000)
002665C4 000a:
	??_C@_09ILJJGEGL@ai_attach?$AA@ (0000)
002665D0 0048:
	??_C@_0EI@LNKNGPOM@removes?5a?5set?5of?5units?5from?5thei@ (0000)
00266618 000e:
	??_C@_0O@IFIJAAHG@ai_free_units?$AA@ (0000)
00266628 0042:
	??_C@_0EC@PIEIKMAN@removes?5a?5group?5of?5actors?5from?5t@ (0000)
0026666C 0008:
	??_C@_07OELIEPHE@ai_free?$AA@ (0000)
00266674 0023:
	??_C@_0CD@GDAKKKEK@turns?5grenade?5inventory?5on?5or?5of@ (0000)
00266698 000c:
	??_C@_0M@DDEEAGDA@ai_grenades?$AA@ (0000)
002666A4 0024:
	??_C@_0CE@OAEOHMFK@turns?5impromptu?5dialogue?5on?5or?5o@ (0000)
002666C8 0015:
	??_C@_0BF@KGGDEPFH@ai_dialogue_triggers?$AA@ (0000)
002666E0 0018:
	??_C@_0BI@IDBIBNCI@turns?5all?5AI?5on?5or?5off?4?$AA@ (0000)
002666F8 001c:
	??_C@_0BM@LGBLIHFC@reloads?5the?5cheats?4txt?5file?$AA@ (0000)
00266714 000c:
	??_C@_0M@DCGGDHJF@cheats_load?$AA@ (0000)
00266720 0025:
	??_C@_0CF@MANFLMHM@cheat_active_camouflage_local_pl@ (0000)
00266748 0023:
	??_C@_0CD@KPJFPNGA@gives?5the?5player?5active?5camoufla@ (0000)
0026676C 0018:
	??_C@_0BI@FDMNAJJH@cheat_active_camouflage?$AA@ (0000)
00266784 0024:
	??_C@_0CE@KAHMNGGN@teleports?5player?5to?5camera?5locat@ (0000)
002667A8 0019:
	??_C@_0BJ@EKDBKHCH@cheat_teleport_to_camera?$AA@ (0000)
002667C4 001d:
	??_C@_0BN@NJLIOHKK@drops?5all?5vehicles?5on?5player?$AA@ (0000)
002667E4 0013:
	??_C@_0BD@HFPKPOEJ@cheat_all_vehicles?$AA@ (0000)
002667F8 001e:
	??_C@_0BO@GJGGAAHG@drops?5all?5weapons?5near?5player?$AA@ (0000)
00266818 0012:
	??_C@_0BC@IKMOIPOA@cheat_all_weapons?$AA@ (0000)
0026682C 001f:
	??_C@_0BP@CBNKKHDB@drops?5all?5powerups?5near?5player?$AA@ (0000)
0026684C 0013:
	??_C@_0BD@BLAIHAOL@cheat_all_powerups?$AA@ (0000)
00266860 0020:
	??_C@_0CA@IFHFMAEF@restores?5all?5breakable?5surfaces?$AA@ (0000)
00266880 0019:
	??_C@_0BJ@CNEJJBFJ@breakable_surfaces_reset?$AA@ (0000)
0026689C 0030:
	??_C@_0DA@OMEPDKEN@TRUE?5allows?5a?5device?5to?5change?5s@ (0000)
002668CC 0027:
	??_C@_0CH@CBAGLACL@device_group_change_only_once_mo@ (0000)
002668F8 005c:
	??_C@_0FM@GLHLKJIF@TRUE?5makes?5the?5given?5device?5open@ (0000)
00266954 0022:
	??_C@_0CC@NECNMCBN@device_operates_automatically_se@ (0000)
00266978 006c:
	??_C@_0GM@NFLNHEJK@TRUE?5makes?5the?5given?5device?5one?9@ (0000)
002669E4 0015:
	??_C@_0BF@MIJAMDHJ@device_one_sided_set?$AA@ (0000)
00266A00 0041:
	??_C@_0EB@FIJEHGJ@instantaneously?5changes?5the?5valu@ (0000)
00266A44 001b:
	??_C@_0BL@PGENOKCP@device_group_set_immediate?$AA@ (0000)
00266A60 0039:
	??_C@_0DJ@GFBFBHHL@changes?5the?5desired?5value?5of?5the@ (0000)
00266A9C 0011:
	??_C@_0BB@MBHICBO@device_group_set?$AA@ (0000)
00266AB0 0039:
	??_C@_0DJ@MFGCMNFJ@returns?5the?5desired?5value?5of?5the@ (0000)
00266AEC 0011:
	??_C@_0BB@NDGMECNG@device_group_get?$AA@ (0000)
00266B00 006a:
	??_C@_0GK@GKNIEDHE@instantaneously?5changes?5the?5posi@ (0000)
00266B6C 001e:
	??_C@_0BO@OCPGIGEO@device_set_position_immediate?$AA@ (0000)
00266B90 0060:
	??_C@_0GA@FDDNPOAN@gets?5the?5current?5position?5of?5the@ (0000)
00266BF0 0014:
	??_C@_0BE@DNCCMECG@device_get_position?$AA@ (0000)
00266C08 005f:
	??_C@_0FP@JKDOBJCN@set?5the?5desired?5position?5of?5the?5@ (0000)
00266C68 0014:
	??_C@_0BE@EJJMAIGK@device_set_position?$AA@ (0000)
00266C7C 0029:
	??_C@_0CJ@GAAMNHJM@gets?5the?5current?5power?5of?5a?5name@ (0000)
00266CA8 0011:
	??_C@_0BB@PGLDGOFO@device_get_power?$AA@ (0000)
00266CC0 0040:
	??_C@_0EA@PFHALLHB@immediately?5sets?5the?5power?5of?5a?5@ (0000)
00266D00 0011:
	??_C@_0BB@NIPGEPMM@device_set_power?$AA@ (0000)
00266D18 004d:
	??_C@_0EN@JLGAMCNG@changes?5a?5machine?8s?5never_appear@ (0000)
00266D68 0020:
	??_C@_0CA@JNONDMAB@device_set_never_appears_locked?$AA@ (0000)
00266D88 0029:
	??_C@_0CJ@EJGKGAHI@gets?5the?5unit?8s?5current?5flashlig@ (0000)
00266DB4 0022:
	??_C@_0CC@FLCKIALB@unit_get_current_flashlight_stat@ (0000)
00266DD8 0029:
	??_C@_0CJ@FJAIKOA@sets?5the?5unit?8s?5desired?5flashlig@ (0000)
00266E04 0022:
	??_C@_0CC@IKDLPDOD@unit_set_desired_flashlight_stat@ (0000)
00266E28 0029:
	??_C@_0CJ@OIPBIDAB@sets?5the?5units?8?5desired?5flashlig@ (0000)
00266E54 0023:
	??_C@_0CD@NAAEBPPP@units_set_desired_flashlight_sta@ (0000)
00266E78 0053:
	??_C@_0FD@LDBNGLOC@returns?5whether?5the?5night?9vision@ (0000)
00266ECC 0033:
	??_C@_0DD@NKPJPGFF@unit_solo_player_integrated_nigh@ (0000)
00266F00 002d:
	??_C@_0CN@NNONPEKI@stops?5gravity?5from?5working?5on?5th@ (0000)
00266F30 000f:
	??_C@_0P@PDNCGPOJ@unit_suspended?$AA@ (0000)
00266F40 0055:
	??_C@_0FF@PDOBGFBC@prevents?5any?5of?5the?5given?5units?5@ (0000)
00266F98 0010:
	??_C@_0BA@GPPEDDHL@unit_impervious?$AA@ (0000)
00266FA8 0050:
	??_C@_0FA@NFLNEMAA@prevents?5any?5of?5the?5given?5units?5@ (0000)
00266FF8 0017:
	??_C@_0BH@CBIGNEJB@unit_doesnt_drop_items?$AA@ (0000)
00267010 004f:
	??_C@_0EP@GHHLDEDP@returns?5TRUE?5if?5the?5?$DMunit?$DO?5has?5?$DM@ (0000)
00267060 0018:
	??_C@_0BI@MPIBCNND@unit_has_weapon_readied?$AA@ (0000)
00267078 0045:
	??_C@_0EF@NOCPGEAK@returns?5TRUE?5if?5the?5?$DMunit?$DO?5has?5?$DM@ (0000)
002670C0 0010:
	??_C@_0BA@JIGLGGGF@unit_has_weapon?$AA@ (0000)
002670D0 0050:
	??_C@_0FA@CADHDGGP@returns?5the?5total?5number?5of?5gren@ (0000)
00267120 001d:
	??_C@_0BN@BEACEPBD@unit_get_total_grenade_count?$AA@ (0000)
00267140 004d:
	??_C@_0EN@FKKICNJL@returns?5the?5shield?5?$FL0?01?$FN?5of?5the?5@ (0000)
00267190 0010:
	??_C@_0BA@IBNGNCGC@unit_get_shield?$AA@ (0000)
002671A0 004d:
	??_C@_0EN@LJHAOLFO@returns?5the?5health?5?$FL0?01?$FN?5of?5the?5@ (0000)
002671F0 0010:
	??_C@_0BA@KLGJLAAH@unit_get_health?$AA@ (0000)
00267200 0020:
	??_C@_0CA@PDFNCHP@returns?5the?5gunner?5of?5a?5vehicle?$AA@ (0000)
00267220 000f:
	??_C@_0P@MGPAMIFE@vehicle_gunner?$AA@ (0000)
00267230 0020:
	??_C@_0CA@PKMNMIHJ@returns?5the?5driver?5of?5a?5vehicle?$AA@ (0000)
00267250 000f:
	??_C@_0P@MNJAEBBB@vehicle_driver?$AA@ (0000)
00267260 002a:
	??_C@_0CK@HMCFKICP@returns?5a?5list?5of?5all?5riders?5in?5@ (0000)
0026728C 000f:
	??_C@_0P@BKMBKCMJ@vehicle_riders?$AA@ (0000)
0026729C 002d:
	??_C@_0CN@IPPCLMD@causes?5player?8s?5unit?5to?5start?5a?5@ (0000)
002672CC 0013:
	??_C@_0BD@BEKGOMEH@magic_melee_attack?$AA@ (0000)
002672E0 0025:
	??_C@_0CF@CDFLGNMN@this?5unit?5will?5assume?5the?5named?5@ (0000)
00267308 000e:
	??_C@_0O@DJELIMN@unit_set_seat?$AA@ (0000)
00267318 0086:
	??_C@_0IG@IPCCGLMP@all?5units?5controlled?5by?5the?5play@ (0000)
002673A0 0010:
	??_C@_0BA@DFPANKO@magic_seat_name?$AA@ (0000)
002673B0 007a:
	??_C@_0HK@NAJPIFJJ@makes?5units?5get?5out?5of?5a?5vehicle@ (0000)
0026742C 000f:
	??_C@_0P@IGENJOOF@vehicle_unload?$AA@ (0000)
00267440 00a3:
	??_C@_0KD@NMDFMIFM@makes?5a?5list?5of?5units?5?$CInamed?5or?5@ (0000)
002674E4 0013:
	??_C@_0BD@BFFKIPJH@vehicle_load_magic?$AA@ (0000)
002674F8 0038:
	??_C@_0DI@FLLBOLE@sets?5a?5group?5of?5units?8?5current?5b@ (0000)
00267530 001b:
	??_C@_0BL@HIOAOFLC@units_set_current_vitality?$AA@ (0000)
0026754C 002f:
	??_C@_0CP@LPDOKNIC@sets?5a?5unit?8s?5current?5body?5and?5s@ (0000)
0026757C 001a:
	??_C@_0BK@HCAFGIBM@unit_set_current_vitality?$AA@ (0000)
00267598 0038:
	??_C@_0DI@JNOBIEJG@sets?5a?5group?5of?5units?8?5maximum?5b@ (0000)
002675D0 001b:
	??_C@_0BL@LHGFHFHL@units_set_maximum_vitality?$AA@ (0000)
002675EC 002f:
	??_C@_0CP@CHGEDHKA@sets?5a?5unit?8s?5maximum?5body?5and?5s@ (0000)
0026761C 001a:
	??_C@_0BK@LNIAPINF@unit_set_maximum_vitality?$AA@ (0000)
00267638 001e:
	??_C@_0BO@OEIIPJL@makes?5a?5unit?5exit?5its?5vehicle?$AA@ (0000)
00267658 0012:
	??_C@_0BC@GFJICCNC@unit_exit_vehicle?$AA@ (0000)
0026766C 0039:
	??_C@_0DJ@BGJNEJFO@sets?5the?5emotion?5animation?5to?5be@ (0000)
002676A8 001b:
	??_C@_0BL@NDNADJND@unit_set_emotion_animation?$AA@ (0000)
002676C4 0038:
	??_C@_0DI@BMNJHOGG@tests?5whether?5the?5named?5seat?5has@ (0000)
002676FC 0012:
	??_C@_0BC@HFNKBLP@vehicle_test_seat?$AA@ (0000)
00267710 003e:
	??_C@_0DO@GOHNHBFA@tests?5whether?5the?5named?5seat?5has@ (0000)
00267750 0017:
	??_C@_0BH@LGLFDIJN@vehicle_test_seat_list?$AA@ (0000)
00267768 0045:
	??_C@_0EF@PMHCFDPC@puts?5the?5specified?5unit?5in?5the?5s@ (0000)
002677B0 0013:
	??_C@_0BD@EIFDDBGL@unit_enter_vehicle?$AA@ (0000)
002677C4 003a:
	??_C@_0DK@NMOGLMJF@can?5be?5used?5to?5prevent?5the?5playe@ (0000)
00267800 001d:
	??_C@_0BN@CCAMFLEB@unit_set_enterable_by_player?$AA@ (0000)
00267820 004a:
	??_C@_0EK@LLKKGHMN@sets?5a?5unit?8s?5facial?5expression?5@ (0000)
0026786C 0011:
	??_C@_0BB@PODBDPL@unit_set_emotion?$AA@ (0000)
00267880 002e:
	??_C@_0CO@PGFKKDCL@allows?5a?5unit?5to?5aim?5in?5place?5wi@ (0000)
002678B0 0019:
	??_C@_0BJ@PAGAJPFN@unit_aim_without_turning?$AA@ (0000)
002678D0 0043:
	??_C@_0ED@HHAAHJJK@returns?5TRUE?5if?5the?5given?5unit?5i@ (0000)
00267914 0021:
	??_C@_0CB@OBNOEEIJ@unit_is_playing_custom_animation@ (0000)
00267938 0085:
	??_C@_0IF@CIIAIPJG@starts?5a?5custom?5animation?5playin@ (0000)
002679C0 001f:
	??_C@_0BP@LKOJGEEP@unit_custom_animation_at_frame?$AA@ (0000)
002679E0 0069:
	??_C@_0GJ@ILKOFCMP@starts?5a?5custom?5animation?5playin@ (0000)
00267A4C 0016:
	??_C@_0BG@HLLCPHED@custom_animation_list?$AA@ (0000)
00267A68 0064:
	??_C@_0GE@KHNCFABH@starts?5a?5custom?5animation?5playin@ (0000)
00267ACC 0011:
	??_C@_0BB@JNOKOAKD@custom_animation?$AA@ (0000)
00267AE0 0036:
	??_C@_0DG@BAIMFFKD@stops?5the?5custom?5animation?5runni@ (0000)
00267B18 001b:
	??_C@_0BL@LPEGLEHI@unit_stop_custom_animation?$AA@ (0000)
00267B38 0068:
	??_C@_0GI@FIHKJGPD@returns?5the?5number?5of?5ticks?5rema@ (0000)
00267BA0 001f:
	??_C@_0BP@IJLIMOEP@unit_get_custom_animation_time?$AA@ (0000)
00267BC0 005b:
	??_C@_0FL@NGLFCNIG@kills?5a?5given?5unit?5silently?5?$CIdoe@ (0000)
00267C1C 0011:
	??_C@_0BB@HCDEJPBJ@unit_kill_silent?$AA@ (0000)
00267C30 0024:
	??_C@_0CE@BEOEFOMA@kills?5a?5given?5unit?0?5no?5saving?5th@ (0000)
00267C54 000a:
	??_C@_09JCKGJOND@unit_kill?$AA@ (0000)
00267C60 0023:
	??_C@_0CD@EKCLHBKM@closes?5the?5hatches?5on?5a?5given?5un@ (0000)
00267C84 000b:
	??_C@_0L@CGLOPMKM@unit_close?$AA@ (0000)
00267C90 0024:
	??_C@_0CE@IAMJPOOL@opens?5the?5hatches?5on?5the?5given?5u@ (0000)
00267CB4 000a:
	??_C@_09HHNAHJAL@unit_open?$AA@ (0000)
00267CC0 0045:
	??_C@_0EF@JIGLAEJM@allows?5a?5unit?5to?5blink?5or?5not?5?$CIu@ (0000)
00267D08 000f:
	??_C@_0P@OFHJNINI@unit_can_blink?$AA@ (0000)
00267D18 000f:
	??_C@_0P@KOHGGHKO@render_effects?$AA@ (0000)
00267D28 004c:
	??_C@_0EM@HEGNENGH@starts?5a?5custom?5animation?5playin@ (0000)
00267D74 0021:
	??_C@_0CB@MJFFDMKE@scenery_animation_start_at_frame@ (0000)
00267D98 0038:
	??_C@_0DI@HDMLMHBG@starts?5a?5custom?5animation?5playin@ (0000)
00267DD0 0018:
	??_C@_0BI@NAIPEEPM@scenery_animation_start?$AA@ (0000)
00267DE8 0061:
	??_C@_0GB@PNAAMEJD@returns?5the?5number?5of?5ticks?5rema@ (0000)
00267E4C 001b:
	??_C@_0BL@HBIFDEEE@scenery_get_animation_time?$AA@ (0000)
00267E68 0020:
	??_C@_0CA@JNDBIMNE@enables?1disables?5dynamic?5lights?$AA@ (0000)
00267E88 000e:
	??_C@_0O@JDONOBDH@render_lights?$AA@ (0000)
00267E98 0033:
	??_C@_0DD@JKMNMIFM@just?5another?5?$CIold?$CJ?5name?5for?5obje@ (0000)
00267ECC 0014:
	??_C@_0BE@OBDMMENK@object_pvs_activate?$AA@ (0000)
00267EE0 003d:
	??_C@_0DN@CEBCKNOM@removes?5the?5special?5place?5that?5a@ (0000)
00267F20 0011:
	??_C@_0BB@GHBOFEDF@object_pvs_clear?$AA@ (0000)
00267F38 0061:
	??_C@_0GB@ECKHBCAF@sets?5the?5specified?5cutscene?5came@ (0000)
00267F9C 0016:
	??_C@_0BG@CMHNDNPF@object_pvs_set_camera?$AA@ (0000)
00267FB8 0052:
	??_C@_0FC@BDBAFNAF@sets?5the?5specified?5object?5as?5the@ (0000)
0026800C 0016:
	??_C@_0BG@PFDINGGM@object_pvs_set_object?$AA@ (0000)
00268028 004b:
	??_C@_0EL@DEOFLCMH@loads?5textures?5necessary?5to?5draw@ (0000)
00268074 0014:
	??_C@_0BE@CANDOHOM@object_type_predict?$AA@ (0000)
00268088 004d:
	??_C@_0EN@DLJPEKEE@loads?5textures?5necessary?5to?5draw@ (0000)
002680D8 0010:
	??_C@_0BA@GADNHNL@objects_predict?$AA@ (0000)
002680E8 0043:
	??_C@_0ED@LJEAPCJE@makes?5an?5object?5pretty?5for?5the?5r@ (0000)
0026812C 0010:
	??_C@_0BA@DOCCIDKD@object_beautify?$AA@ (0000)
0026813C 0026:
	??_C@_0CG@INADBDMG@allows?5an?5object?5to?5take?5damage?5@ (0000)
00268164 0017:
	??_C@_0BH@DMIHNOIK@object_can_take_damage?$AA@ (0000)
0026817C 0026:
	??_C@_0CG@LDDALHCK@prevents?5an?5object?5from?5taking?5d@ (0000)
002681A4 001a:
	??_C@_0BK@IEMFJCFB@object_cannot_take_damage?$AA@ (0000)
002681C0 0058:
	??_C@_0FI@IIHDNBAB@causes?5all?5garbage?5objects?5excep@ (0000)
00268218 0014:
	??_C@_0BE@JMDGADEL@garbage_collect_now?$AA@ (0000)
0026822C 003d:
	??_C@_0DN@INNDALND@detaches?5from?5the?5given?5parent?5o@ (0000)
0026826C 000f:
	??_C@_0P@OLHFOJID@objects_detach?$AA@ (0000)
00268280 0043:
	??_C@_0ED@NOKAOIDB@attaches?5the?5second?5object?5to?5th@ (0000)
002682C4 000f:
	??_C@_0P@HBMHBHBK@objects_attach?$AA@ (0000)
002682D8 0069:
	??_C@_0GJ@FIJGKLEB@sets?5the?5scale?5for?5a?5given?5objec@ (0000)
00268344 0011:
	??_C@_0BB@BABOINED@object_set_scale?$AA@ (0000)
00268358 003f:
	??_C@_0DP@GMMNBCOI@FALSE?5prevents?5any?5object?5from?5c@ (0000)
00268398 0017:
	??_C@_0BH@IDPDFEDF@object_set_collideable?$AA@ (0000)
002683B0 001b:
	??_C@_0BL@EACEKMEI@debugs?5object?5memory?5usage?$AA@ (0000)
002683CC 0014:
	??_C@_0BE@PHLKBOD@objects_dump_memory?$AA@ (0000)
002683E0 002e:
	??_C@_0CO@PKNJIACC@FALSE?5prevents?5object?5from?5using@ (0000)
00268410 0022:
	??_C@_0CC@IFOACFOB@object_set_melee_attack_inhibite@ (0000)
00268434 002f:
	??_C@_0CP@EIOOENIK@FALSE?5prevents?5object?5from?5using@ (0000)
00268464 0023:
	??_C@_0CD@MJGKKBBK@object_set_ranged_attack_inhibit@ (0000)
00268488 0046:
	??_C@_0EG@EKDOLP@return?5the?5time?5remaining?5in?5the@ (0000)
002684D0 000f:
	??_C@_0P@INKEAIJI@recording_time?$AA@ (0000)
002684E0 002e:
	??_C@_0CO@JHCMNCJP@kill?5the?5specified?5unit?8s?5cutsce@ (0000)
00268510 000f:
	??_C@_0P@LPBENJLF@recording_kill?$AA@ (0000)
00268520 0071:
	??_C@_0HB@IPFOJKFP@make?5the?5specified?5vehicle?5run?5t@ (0000)
00268594 0019:
	??_C@_0BJ@BBGPLBBI@recording_play_and_hover?$AA@ (0000)
002685B0 006c:
	??_C@_0GM@GJJEJANH@make?5the?5specified?5unit?5run?5the?5@ (0000)
0026861C 001a:
	??_C@_0BK@EDBBNCIG@recording_play_and_delete?$AA@ (0000)
00268638 003e:
	??_C@_0DO@FMJIGJHB@make?5the?5specified?5unit?5run?5the?5@ (0000)
00268678 000f:
	??_C@_0P@KAJHPKFD@recording_play?$AA@ (0000)
00268688 0044:
	??_C@_0EE@OPAAOIKC@enables?5or?5disables?5breakability@ (0000)
002686CC 001a:
	??_C@_0BK@FHGMGDDD@breakable_surfaces_enable?$AA@ (0000)
002686E8 0020:
	??_C@_0CA@OOAAOPAM@numeric_countdown_timer_restart?$AA@ (0000)
00268708 001d:
	??_C@_0BN@DDDGIEFB@numeric_countdown_timer_stop?$AA@ (0000)
00268728 000e:
	??_C@_0O@PGDPPJHH@?$DMdigit_index?$DO?$AA@ (0000)
00268738 001c:
	??_C@_0BM@ODFAHEE@numeric_countdown_timer_get?$AA@ (0000)
00268754 001d:
	??_C@_0BN@HBDGLALB@?$DMmilliseconds?$DO?0?5?$DMauto_start?$DO?$AA@ (0000)
00268774 001c:
	??_C@_0BM@NBEOMHIM@numeric_countdown_timer_set?$AA@ (0000)
00268790 0012:
	??_C@_0BC@PAGFFJBM@real_random_range?$AA@ (0000)
002687A4 003f:
	??_C@_0DP@OCBKMMNF@returns?5a?5random?5value?5in?5the?5ra@ (0000)
002687E4 000d:
	??_C@_0N@DCIABLOA@random_range?$AA@ (0000)
002687F4 002c:
	??_C@_0CM@KMBJONOE@prints?5a?5description?5of?5the?5name@ (0000)
00268820 0005:
	??_C@_04PCJFHION@help?$AA@ (0000)
00268828 0048:
	??_C@_0EI@NNMGANEI@saves?5a?5file?5called?5hs_doc?4txt?5w@ (0000)
00268870 000b:
	??_C@_0L@KHBOIGJK@script_doc?$AA@ (0000)
0026887C 0014:
	??_C@_0BE@IDIKMKNE@recompiles?5scripts?4?$AA@ (0000)
00268890 0011:
	??_C@_0BB@HOBLLFAH@script_recompile?$AA@ (0000)
002688A4 0022:
	??_C@_0CC@EIOJCJGN@absolutely?5do?5not?5use?5this?5eithe@ (0000)
002688C8 000f:
	??_C@_0P@HKOILOPJ@sound_get_gain?$AA@ (0000)
002688D8 001b:
	??_C@_0BL@PFHIAAMF@absolutely?5do?5not?5use?5this?$AA@ (0000)
002688F4 000f:
	??_C@_0P@ILMEKNIE@sound_set_gain?$AA@ (0000)
00268904 0029:
	??_C@_0CJ@BAEAIGLH@deletes?5all?5objects?5of?5type?5?$DMdef@ (0000)
00268930 001d:
	??_C@_0BN@LEOIFAOL@objects_delete_by_definition?$AA@ (0000)
00268950 006b:
	??_C@_0GL@KOGGOJFE@returns?5true?5if?5any?5of?5the?5speci@ (0000)
002689BC 0015:
	??_C@_0BF@BHBIKHDF@objects_can_see_flag?$AA@ (0000)
002689D8 006d:
	??_C@_0GN@GJPHOGHP@returns?5true?5if?5any?5of?5the?5speci@ (0000)
00268A48 0017:
	??_C@_0BH@JJAKPHFH@objects_can_see_object?$AA@ (0000)
00268A60 0035:
	??_C@_0DF@KIGHKCEE@causes?5the?5specified?5damage?5at?5t@ (0000)
00268A98 000e:
	??_C@_0O@EEKIEM@damage_object?$AA@ (0000)
00268AA8 0033:
	??_C@_0DD@CDBEJFIF@causes?5the?5specified?5damage?5at?5t@ (0000)
00268ADC 000b:
	??_C@_0L@KCMNNAGD@damage_new?$AA@ (0000)
00268AE8 004d:
	??_C@_0EN@CCMAMCLJ@starts?5the?5specified?5effect?5on?5t@ (0000)
00268B38 001c:
	??_C@_0BM@FCOAPGDN@effect_new_on_object_marker?$AA@ (0000)
00268B54 0033:
	??_C@_0DD@CLDFDJAK@starts?5the?5specified?5effect?5at?5t@ (0000)
00268B88 000b:
	??_C@_0L@LLEFHBNA@effect_new?$AA@ (0000)
00268B94 0028:
	??_C@_0CI@FBLFPCBI@returns?5the?5number?5of?5objects?5in@ (0000)
00268BBC 000b:
	??_C@_0L@BHBEALGM@list_count?$AA@ (0000)
00268BC8 0023:
	??_C@_0CD@IGKBLGCE@returns?5an?5item?5in?5an?5object?5lis@ (0000)
00268BEC 0009:
	??_C@_08DIMLIFIJ@list_get?$AA@ (0000)
00268BF8 0092:
	??_C@_0JC@BFBAGNKC@sets?5the?5desired?5region?5?$CIuse?5?$CC?$CC?5@ (0000)
00268C8C 0017:
	??_C@_0BH@HNCOJEHI@object_set_permutation?$AA@ (0000)
00268CA8 0044:
	??_C@_0EE@IOIDGDHD@sets?5the?5shield?5vitality?5of?5the?5@ (0000)
00268CEC 0012:
	??_C@_0BC@MGDKGPAD@object_set_shield?$AA@ (0000)
00268D00 0043:
	??_C@_0ED@JBABOKFB@turns?5the?5specified?5object?5in?5th@ (0000)
00268D44 0012:
	??_C@_0BC@PMBMKNBG@object_set_facing?$AA@ (0000)
00268D58 0032:
	??_C@_0DC@IFJDEOJB@moves?5the?5specified?5object?5to?5th@ (0000)
00268D8C 0010:
	??_C@_0BA@PNJDFHPO@object_teleport?$AA@ (0000)
00268D9C 0021:
	??_C@_0CB@FEGLNJDK@destroys?5all?5non?5player?5objects?4@ (0000)
00268DC0 0013:
	??_C@_0BD@NHEMFJMD@object_destroy_all?$AA@ (0000)
00268DD8 0050:
	??_C@_0FA@EEIGHOKC@destroys?5all?5objects?5from?5the?5sc@ (0000)
00268E28 001a:
	??_C@_0BK@EPKACOED@object_destroy_containing?$AA@ (0000)
00268E48 0054:
	??_C@_0FE@NMGNCIDH@creates?5anew?5all?5objects?5from?5th@ (0000)
00268E9C 001e:
	??_C@_0BO@OKBPOJBB@object_create_anew_containing?$AA@ (0000)
00268EC0 004f:
	??_C@_0EP@PFELOIJ@creates?5all?5objects?5from?5the?5sce@ (0000)
00268F10 0019:
	??_C@_0BJ@GNKGFHKI@object_create_containing?$AA@ (0000)
00268F2C 003d:
	??_C@_0DN@KJNPBGB@creates?5an?5object?0?5destroying?5it@ (0000)
00268F6C 0013:
	??_C@_0BD@LLIBMBND@object_create_anew?$AA@ (0000)
00268F80 0014:
	??_C@_0BE@KFGHAKJK@destroys?5an?5object?4?$AA@ (0000)
00268F94 000f:
	??_C@_0P@DMIABPCI@object_destroy?$AA@ (0000)
00268FA4 0025:
	??_C@_0CF@DPDJKCGK@creates?5an?5object?5from?5the?5scena@ (0000)
00268FCC 000e:
	??_C@_0O@HFDGNKG@object_create?$AA@ (0000)
00268FDC 0018:
	??_C@_0BI@PAMIOLDD@volume_test_objects_all?$AA@ (0000)
00268FF8 004e:
	??_C@_0EO@BALPBDMA@returns?5true?5if?5any?5of?5the?5speci@ (0000)
00269048 0014:
	??_C@_0BE@KEMOGNCG@volume_test_objects?$AA@ (0000)
00269060 0045:
	??_C@_0EF@GJFDEEJJ@returns?5true?5if?5the?5specified?5ob@ (0000)
002690A8 0013:
	??_C@_0BD@NGKFGLOA@volume_test_object?$AA@ (0000)
002690C0 004a:
	??_C@_0EK@KGDBHKIK@moves?5all?5players?5outside?5a?5spec@ (0000)
0026910C 0023:
	??_C@_0CD@KNNNOINA@volume_teleport_players_not_insi@ (0000)
00269130 001e:
	??_C@_0BO@FPLDOIMK@returns?5a?5list?5of?5the?5players?$AA@ (0000)
00269150 0020:
	??_C@_0CA@LDDGCMAM@prints?5a?5string?5to?5the?5console?4?$AA@ (0000)
00269170 0006:
	??_C@_05IJDJACGD@print?$AA@ (0000)
00269178 0028:
	??_C@_0CI@IOCLFELG@returns?5the?5opposite?5of?5the?5expr@ (0000)
002691A0 003e:
	??_C@_0DO@IEKOMPDC@focuses?5?$CIor?5stops?5focusing?$CJ?5a?5se@ (0000)
002691E0 001d:
	??_C@_0BN@EPLLIJOE@ai_debug_communication_focus?$AA@ (0000)
00269200 005e:
	??_C@_0FO@EJILMCF@ignores?5?$CIor?5stops?5ignoring?$CJ?5a?5se@ (0000)
00269260 001e:
	??_C@_0BO@GDEPOJPD@ai_debug_communication_ignore?$AA@ (0000)
00269280 000c:
	??_C@_0M@CMIAAGDJ@?$DMstring?$CIs?$CJ?$DO?$AA@ (0000)
00269290 0043:
	??_C@_0ED@DOCPLCMK@suppresses?5?$CIor?5stops?5suppressing@ (0000)
002692D4 0020:
	??_C@_0CA@HGPDNOLF@ai_debug_communication_suppress?$AA@ (0000)
002692F4 0009:
	??_C@_08HACGAFB@?$DMobject?$DO?$AA@ (0000)
00269300 001e:
	??_C@_0BO@EKODAEJP@converts?5an?5object?5to?5a?5unit?4?$AA@ (0000)
00269320 000d:
	??_C@_0N@INJCDPPE@?$DMexpression?$DO?$AA@ (0000)
00269330 0048:
	??_C@_0EI@ONKDIOON@prints?5the?5value?5of?5an?5expressio@ (0000)
00269378 0008:
	??_C@_07PHKOPNKE@inspect?$AA@ (0000)
00269380 000e:
	??_C@_0O@DLBEFBAH@?$DMscript?5name?$DO?$AA@ (0000)
00269390 002c:
	??_C@_0CM@FONLPAAC@wakes?5a?5sleeping?5script?5in?5the?5n@ (0000)
002693BC 0005:
	??_C@_04KNLNBPHI@wake?$AA@ (0000)
002693C4 0014:
	??_C@_0BE@LPCOEJCC@?$DMboolean?$DO?5?$FL?$DMshort?$DO?$FN?$AA@ (0000)
002693D8 0091:
	??_C@_0JB@DMGHNKID@pauses?5execution?5of?5this?5script?5@ (0000)
0026946C 000c:
	??_C@_0M@MCDJNLOL@sleep_until?$AA@ (0000)
00269478 0013:
	??_C@_0BD@JPIGHOGD@?$DMshort?$DO?5?$FL?$DMscript?$DO?$FN?$AA@ (0000)
00269490 0064:
	??_C@_0GE@NJKIODHO@pauses?5execution?5of?5this?5script?5@ (0000)
002694F8 0049:
	??_C@_0EJ@ODMHDEPC@returns?5true?5if?5the?5first?5number@ (0000)
00269544 0003:
	??_C@_02EHCHHCKH@?$DM?$DN?$AA@ (0000)
00269548 0048:
	??_C@_0EI@IKIAIHKB@returns?5true?5if?5the?5first?5number@ (0000)
00269590 0003:
	??_C@_02EEKDKGMJ@?$DO?$DN?$AA@ (0000)
00269594 003d:
	??_C@_0DN@IOAMPDJO@returns?5true?5if?5the?5first?5number@ (0000)
002695D4 0002:
	??_C@_01MNNFJEPP@?$DM?$AA@ (0000)
002695D8 003c:
	??_C@_0DM@JKEGGOCN@returns?5true?5if?5the?5first?5number@ (0000)
00269614 0002:
	??_C@_01PPODPGHN@?$DO?$AA@ (0000)
00269618 002e:
	??_C@_0CO@GONKGPHE@returns?5true?5if?5two?5expressions?5@ (0000)
00269648 0003:
	??_C@_02FDNJECIE@?$CB?$DN?$AA@ (0000)
0026964C 001a:
	??_C@_0BK@JOGHKOAF@?$DMexpression?$DO?5?$DMexpression?$DO?$AA@ (0000)
00269668 002a:
	??_C@_0CK@EDJNPPMA@returns?5true?5if?5two?5expressions?5@ (0000)
00269694 0002:
	??_C@_01NEMOKFLO@?$DN?$AA@ (0000)
00269698 0032:
	??_C@_0DC@FFCAHPCD@returns?5the?5maximum?5of?5all?5speci@ (0000)
002696CC 0004:
	??_C@_03LJAEFNNE@max?$AA@ (0000)
002696D0 0032:
	??_C@_0DC@KBAHEHPN@returns?5the?5minimum?5of?5all?5speci@ (0000)
00269704 0004:
	??_C@_03KLIPLJLL@min?$AA@ (0000)
00269708 0029:
	??_C@_0CJ@LCMGJEMF@returns?5the?5quotient?5of?5two?5expr@ (0000)
00269734 0032:
	??_C@_0DC@DDIABJCL@returns?5the?5product?5of?5all?5speci@ (0000)
00269768 0012:
	??_C@_0BC@KDINODJI@?$DMnumber?$DO?5?$DMnumber?$DO?$AA@ (0000)
0026977C 002b:
	??_C@_0CL@IMLDCEJM@returns?5the?5difference?5of?5two?5ex@ (0000)
002697A8 0002:
	??_C@_01JOAMLHOP@?9?$AA@ (0000)
002697AC 000c:
	??_C@_0M@NJCPLCOP@?$DMnumber?$CIs?$CJ?$DO?$AA@ (0000)
002697B8 002e:
	??_C@_0CO@GPPKBJPG@returns?5the?5sum?5of?5all?5specified@ (0000)
002697E8 0034:
	??_C@_0DE@EDJAINOF@returns?5true?5if?5any?5specified?5ex@ (0000)
0026981C 0003:
	??_C@_02FODMLBIE@or?$AA@ (0000)
00269820 000d:
	??_C@_0N@IJOANKIM@?$DMboolean?$CIs?$CJ?$DO?$AA@ (0000)
00269830 0034:
	??_C@_0DE@JEOAKIHJ@returns?5true?5if?5all?5specified?5ex@ (0000)
00269864 0004:
	??_C@_03BOPJPIAM@and?$AA@ (0000)
00269868 001d:
	??_C@_0BN@LKJBMNLE@?$DMvariable?5name?$DO?5?$DMexpression?$DO?$AA@ (0000)
00269888 0024:
	??_C@_0CE@OOOKEKDL@set?5the?5value?5of?5a?5global?5variab@ (0000)
002698AC 0036:
	??_C@_0DG@OBCIGOKB@?$CI?$DMboolean1?$DO?5?$DMresult1?$DO?$CJ?5?$FL?$CI?$DMboolea@ (0000)
002698E4 003c:
	??_C@_0DM@JHHCNAPI@returns?5the?5value?5associated?5wit@ (0000)
00269920 0005:
	??_C@_04MHNCKKKD@cond?$AA@ (0000)
00269928 001a:
	??_C@_0BK@PGGLAFKH@?$DMboolean?$DO?5?$DMthen?$DO?5?$FL?$DMelse?$DO?$FN?$AA@ (0000)
00269944 003d:
	??_C@_0DN@KOMLNACA@returns?5one?5of?5two?5values?5based?5@ (0000)
00269984 0003:
	??_C@_02HEBPBKGD@if?$AA@ (0000)
00269988 005c:
	??_C@_0FM@BLMBCPEE@evaluates?5the?5sequence?5of?5expres@ (0000)
002699E4 000d:
	??_C@_0N@NLKOPHFP@begin_random?$AA@ (0000)
002699F4 0010:
	??_C@_0BA@BEGBAIJH@?$DMexpression?$CIs?$CJ?$DO?$AA@ (0000)
00269A08 0052:
	??_C@_0FC@KDMMBCEI@returns?5the?5last?5expression?5in?5a@ (0000)
00269A5C 0006:
	??_C@_05EAFKHBAM@begin?$AA@ (0000)
00269A64 0007:
	??_C@_06GGHJAEBN@static?$AA@ (0000)
00269A6C 000b:
	??_C@_0L@OJJGELPD@continuous?$AA@ (0000)
00269A78 0008:
	??_C@_07BOEKGHFD@dormant?$AA@ (0000)
00269A80 0008:
	??_C@_07HJMHMJAL@startup?$AA@ (0000)
00269A88 000d:
	??_C@_0N@MHGAPKHB@scenery_name?$AA@ (0000)
00269A98 000c:
	??_C@_0M@CEFHGFO@device_name?$AA@ (0000)
00269AA4 000c:
	??_C@_0M@OJHKGGFM@weapon_name?$AA@ (0000)
00269AB0 000d:
	??_C@_0N@KGGPBGNF@vehicle_name?$AA@ (0000)
00269AC0 000a:
	??_C@_09EPPCOIDC@unit_name?$AA@ (0000)
00269ACC 000c:
	??_C@_0M@EAODMCNL@object_name?$AA@ (0000)
00269AD8 0008:
	??_C@_07NJBHMOOI@scenery?$AA@ (0000)
00269AE0 0007:
	??_C@_06CHPEJBOD@device?$AA@ (0000)
00269AE8 0007:
	??_C@_06GEPNGEJI@weapon?$AA@ (0000)
00269AF0 000b:
	??_C@_0L@KLIEIMKH@hud_corner?$AA@ (0000)
00269AFC 000b:
	??_C@_0L@ELEHLNNN@actor_type?$AA@ (0000)
00269B08 0011:
	??_C@_0BB@DCFMBDKG@ai_default_state?$AA@ (0000)
00269B1C 0005:
	??_C@_04KADBPNCB@team?$AA@ (0000)
00269B24 0010:
	??_C@_0BA@MDKGMGPG@game_difficulty?$AA@ (0000)
00269B34 0012:
	??_C@_0BC@GHDJBKLF@object_definition?$AA@ (0000)
00269B48 000e:
	??_C@_0O@PKFFFIBF@damage_effect?$AA@ (0000)
00269B58 000e:
	??_C@_0O@CICOPBIO@actor_variant?$AA@ (0000)
00269B68 0010:
	??_C@_0BA@OPAAOBLJ@animation_graph?$AA@ (0000)
00269B78 000e:
	??_C@_0O@DKAGPEHJ@looping_sound?$AA@ (0000)
00269B88 0006:
	??_C@_05MHNANJII@sound?$AA@ (0000)
00269B90 000c:
	??_C@_0M@LKPGBEDO@object_list?$AA@ (0000)
00269B9C 000c:
	??_C@_0M@CHMKBGAD@hud_message?$AA@ (0000)
00269BA8 0009:
	??_C@_08EBNKPLFP@navpoint?$AA@ (0000)
00269BB4 000d:
	??_C@_0N@PEKBMEII@conversation?$AA@ (0000)
00269BC4 0011:
	??_C@_0BB@IOHHJLAM@starting_profile?$AA@ (0000)
00269BD8 0010:
	??_C@_0BA@JMEICJMJ@ai_command_list?$AA@ (0000)
00269BE8 0003:
	??_C@_02PNJEFHBE@ai?$AA@ (0000)
00269BEC 000d:
	??_C@_0N@BFIOJHBC@device_group?$AA@ (0000)
00269BFC 0013:
	??_C@_0BD@BGGDMPKJ@cutscene_recording?$AA@ (0000)
00269C10 000f:
	??_C@_0P@KCHONJIA@cutscene_title?$AA@ (0000)
00269C20 0016:
	??_C@_0BG@KEHIDGAC@cutscene_camera_point?$AA@ (0000)
00269C38 000e:
	??_C@_0O@PAJHOLHE@cutscene_flag?$AA@ (0000)
00269C48 000f:
	??_C@_0P@EIGPHCFF@trigger_volume?$AA@ (0000)
00269C58 0007:
	??_C@_06ICGJLFIM@string?$AA@ (0000)
00269C60 0005:
	??_C@_04GOKPGOLB@long?$AA@ (0000)
00269C68 0006:
	??_C@_05BFKKPKCG@short?$AA@ (0000)
00269C70 0005:
	??_C@_04DGGKDJMA@real?$AA@ (0000)
00269C78 0008:
	??_C@_07GOBOHMJA@boolean?$AA@ (0000)
00269C80 0005:
	??_C@_04GKJNKENE@void?$AA@ (0000)
00269C88 000c:
	??_C@_0M@JEPMINAN@passthrough?$AA@ (0000)
00269C94 000e:
	??_C@_0O@NCEEMOEA@function?5name?$AA@ (0000)
00269CA4 000d:
	??_C@_0N@JNIGNFNL@special?5form?$AA@ (0000)
00269CB4 0009:
	??_C@_08PMHGMICD@unparsed?$AA@ (0000)
00269CC0 0025:
	??_C@_0CF@MEBCDGOC@couldn?8t?5allocate?5script?5syntax?5@ (0000)
00269CE8 0017:
	??_C@_0BH@LAFDFIL@c?3?2halo?2SOURCE?2hs?2hs?4c?$AA@ (0000)
00269D00 000c:
	??_C@_0M@LNHMEKAO@script?5node?$AA@ (0000)
00269D0C 003c:
	??_C@_0DM@JLAIDNDM@function_index?$DO?$DN0?5?$CG?$CG?5function_in@ (0000)
00269D48 0039:
	??_C@_0DJ@GLMGFJLI@global_index?$DO?$DN0?5?$CG?$CG?5global_index?$DM@ (0000)
00269D84 0014:
	??_C@_0BE@HILGEDPG@enumeration_results?$AA@ (0000)
00269D98 0007:
	??_C@_06FJKEMHGD@global?$AA@ (0000)
00269DA0 0021:
	??_C@_0CB@IEDIOPOL@hs_token_enumerators?$FLtype_index?$FN@ (0000)
00269DC4 0015:
	??_C@_0BF@DOHFLLLG@?$CBenumeration_results?$AA@ (0000)
00269DDC 002c:
	??_C@_0CM@LNBPLIEF@maximum?5source?5files?5per?5scenari@ (0000)
00269E08 0027:
	??_C@_0CH@DBPBJIBO@couldn?8t?5read?5source?5file?5into?5m@ (0000)
00269E30 0023:
	??_C@_0CD@HCMGDMEO@maximum?5source?5file?5size?5exceede@ (0000)
00269E54 0004:
	??_C@_03DIEOBBGC@hsc?$AA@ (0000)
00269E58 0018:
	??_C@_0BI@KHFIJAAE@data?2global_scripts?4hsc?$AA@ (0000)
00269E70 0008:
	??_C@_07OMEBBDEO@scripts?$AA@ (0000)
00269E78 0008:
	??_C@_07GMBDMGII@data?2?$CFs?$AA@ (0000)
00269E80 0014:
	??_C@_0BE@NAAJJLAD@?$FL?$CFs?5line?5?$CFd?$FN?5?$CFs?3?5?$CFs?$AA@ (0000)
00269E94 001f:
	??_C@_0BP@ENCLMJH@scripts?5successfully?5compiled?4?$AA@ (0000)
00269EB4 0003:
	??_C@_02ELAABJPC@?5?$DM?$AA@ (0000)
00269EB8 0004:
	??_C@_03EEBNCBOD@?5?$CFs?$AA@ (0000)
00269EBC 0004:
	??_C@_03IBKJAJAM@?$CI?$CFs?$AA@ (0000)
00269EC0 0018:
	??_C@_0BI@OIMPOEHB@couldn?8t?5reset?5scripts?4?$AA@ (0000)
00269ED8 002e:
	??_C@_0CO@EODDAMJ@an?5unspecified?5error?5occurred?5lo@ (0000)
00269F08 0031:
	??_C@_0DB@GIFMNEEI@recompiling?5scripts?5after?5scenar@ (0000)
00269F3C 0007:
	??_C@_06BHLKBGNJ@?$CFs?$AN?6?$AN?6?$AA@ (0000)
00269F44 000b:
	??_C@_0L@OCNIEFFP@hs_doc?4txt?$AA@ (0000)
00269F50 0034:
	??_C@_0DE@GGJDPECD@you?5can?8t?5add?5an?5hs?5type?5without@ (0000)
00269F84 0005:
	??_C@_04ENHBHKMJ@?$CI?$CFs?$CJ?$AA@ (0000)
00269F8C 0009:
	??_C@_08POBEIOG@?$CIset?5?$CFs?$CJ?$AA@ (0000)
002DFA20 0da8:
	_hs_type_names (0000)
	_hs_script_type_names (00c4)
	__hs_type_string_default (00d8)
	_hs_function_table (00e0)
00453468 0012:
	_hs_enumeration_result_count (0000)
	_hs_enumeration_maximum_count (0004)
	_enumeration_results (0008)
	_hs_enumeration_substring (000c)
	_hs_recompile_pending (0010)
	_hs_syntax_data_allocated (0011)
*/

/* ---------- headers */

#include "cseries/cseries.h"
#include "cseries/errors.h"
#include "cseries/profile.h"
#include "camera/director.h"
#include "cache/sound_cache.h"
#include "hs.h"
#include "hs_library_external.h"
#include "hs_library_internal.h"
#include "object_lists.h"
#include "hs_scenario_definitions.h"
#include "ai/ai.h"
#include "ai/ai_debug.h"
#include "cache/cache_files.h"
#include "cache/physical_memory_map.h" /* port: hs_scenario_syntax_data_valid */
#include "cache/texture_cache.h"
#include "camera/camera_scripting.h"
#include "cutscene/cinematics.h"
#include "effects/player_effects.h"
#include "game/cheats.h"
#include "game/game_engine.h"
#include "game/players.h"
#include "interface/attract_mode.h"
#include "interface/hud.h"
#include "interface/terminal.h"
#include "interface/ui_widget.h"
#include "main/console.h"
#include "math/real_math.h"
#include "memory/data.h"
#include "networking/network_game_globals.h"
#include "networking/network_game_manager.h"
#include "networking/network_server_manager.h"
#include "network_votekick.h" /* port: port/linux/game/network_votekick.c */
#include "objects/damage.h"
#include "objects/object_lights.h"
#include "objects/scenery.h"
#include "physics/breakable_surfaces.h"
#include "rasterizer/rasterizer.h"
#include "render/render.h"
#include "saved games/game_state.h"
#include "saved games/saved_game_files.h"
#include "scenario/scenario.h"
#include "scenario/scenario_definitions.h"
#include "ai/ai_scenario_definitions.h"
#include "ai/ai_profile.h"
#include "ai/ai_script.h"
#include "cutscene/recorded_animation_definitions.h"
#include "cutscene/recorded_animations.h"
#include "devices/devices.h"
#include "game/game.h"
#include "interface/hud_definitions.h"
#include "interface/hud_messaging.h"
#include "interface/hud_unit.h"
#include "interface/hud_weapon.h"
#include "interface/interface.h"
#include "interface/player_ui.h"
#include "saved games/player_profile.h" /* port: profile_reset_campaign */
#include "rasterizer/rasterizer_cinematics.h"
#include "shaders/shaders.h"
#include "sound/game_sound.h"
#include "sound/sound_classes.h"
#include "sound/sound_manager.h"
#include "structures/structure_lens_flares.h"
#include "structures/structure_visibility.h"
#include "tag_files/files.h"
#include "main/main.h"
#include "units/units.h"
#include "units/vehicles.h"
#include "coop_scripts.h" /* port: port/linux/game/coop_scripts.c */
#ifdef HALO_PROFILE
#include "profile_console.h" /* port: port/linux/game/profile_console.c */
#endif
#include "structure_culling.h" /* port: port/linux/game/structure_culling.c */

/* ---------- constants */

enum
{
	scenario_starting_profile_size = 0x68,
	scenario_conversation_definition_size = 0x74,
	scenario_cutscene_flag_size = 0x5C,
	scenario_cutscene_chapter_title_size = 0x60,
	hud_globals_group_tag = 'hudg',
	hud_message_text_group_tag = 'hmt ',
};

/* ---------- macros */

#define HS_EVALUATE_NO_ARGUMENTS(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	function(); \
	hs_return(thread_index, 0); \
	return; \
}

#define HS_EVALUATE_NO_OP(evaluator) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	hs_return(thread_index, 0); \
	return; \
}

#define HS_EVALUATE_RETURN_LONG(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	hs_return(thread_index, function()); \
	return; \
}

#define HS_EVALUATE_RETURN_SHORT(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	union hs_short_result result; \
	result.value = 0; \
	result.short_value = function(); \
	hs_return(thread_index, result.value); \
	return; \
}

#define HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	union hs_boolean_result result; \
	result.value = 0; \
	result.boolean = function(); \
	hs_return(thread_index, result.value); \
	return; \
}

#define HS_EVALUATE_SHORT_FROM_LONG(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	long *arguments; \
	union hs_short_result result; \
	result.value = 0; \
	arguments = hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		result.short_value = function(arguments[0]); \
		hs_return(thread_index, result.value); \
	} \
	return; \
}

#define HS_EVALUATE_SHORT_FROM_UNSIGNED_SHORT(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	union hs_evaluation_argument *arguments; \
	union hs_short_result result; \
	result.value = 0; \
	arguments = (union hs_evaluation_argument *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		result.short_value = function(arguments[0].unsigned_short_value); \
		hs_return(thread_index, result.value); \
	} \
	return; \
}

#define HS_EVALUATE_RETURN_SHORT_FROM_ARGUMENTS(evaluator, arguments_type, expression) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	arguments_type const *arguments; \
	union hs_short_result result; \
	result.value = 0; \
	arguments = (arguments_type const *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		result.short_value = expression; \
		hs_return(thread_index, result.value); \
	} \
	return; \
}

#define HS_EVALUATE_LONG_FROM_LONG(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	long *arguments = hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
		hs_return(thread_index, function(arguments[0])); \
	return; \
}

#define HS_EVALUATE_REAL_FROM_LONG(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	long *arguments = hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		union hs_real_value result; \
		result.real_value = function(arguments[0]); \
		hs_return(thread_index, result.long_value); \
	} \
	return; \
}

#define HS_EVALUATE_REAL_FROM_UNSIGNED_SHORT(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	unsigned short *arguments = (unsigned short *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		union hs_real_value result; \
		result.real_value = function(arguments[0]); \
		hs_return(thread_index, result.long_value); \
	} \
	return; \
}

#define HS_EVALUATE_VOID_LONG(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	long *arguments = hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		function(arguments[0]); \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define HS_EVALUATE_VOID_BOOLEAN(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	union hs_evaluation_argument *arguments = (union hs_evaluation_argument *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		function(arguments[0].boolean_value); \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define HS_EVALUATE_VOID_UNSIGNED_SHORT(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	union hs_evaluation_argument *arguments = (union hs_evaluation_argument *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		function(arguments[0].unsigned_short_value); \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define HS_EVALUATE_VOID_LONG_BOOLEAN(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	union hs_evaluation_argument *arguments = (union hs_evaluation_argument *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		function(arguments[0].long_value, arguments[1].boolean_value); \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define HS_EVALUATE_VOID_LONG_LONG(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	long *arguments = hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		function(arguments[0], arguments[1]); \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define HS_EVALUATE_VOID_SHORT_SHORT(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	union hs_evaluation_argument *arguments = (union hs_evaluation_argument *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		function(arguments[0].short_value, arguments[1].unsigned_short_value); \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define HS_EVALUATE_VOID_LONG_UNSIGNED_SHORT(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	union hs_evaluation_argument *arguments = (union hs_evaluation_argument *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		function(arguments[0].long_value, arguments[1].unsigned_short_value); \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define HS_EVALUATE_VOID_UNSIGNED_SHORT(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	union hs_evaluation_argument *arguments = (union hs_evaluation_argument *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		function(arguments[0].unsigned_short_value); \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define HS_EVALUATE_VOID_BOOLEAN(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	union hs_evaluation_argument *arguments = (union hs_evaluation_argument *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		function(arguments[0].boolean_value); \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define HS_EVALUATE_VOID_STRING(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	struct hs_arguments_string *arguments = (struct hs_arguments_string *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		function(arguments->value); \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define HS_EVALUATE_VOID_LONG_STRING(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	struct hs_arguments_long_string *arguments = (struct hs_arguments_long_string *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		function(arguments->value0, arguments->value1); \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define HS_EVALUATE_VOID_LONG_LONG_STRING(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	struct hs_arguments_long_long_string *arguments = (struct hs_arguments_long_long_string *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		function(arguments->value0, arguments->value1, arguments->value2); \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define HS_EVALUATE_VOID_SHORT_BOOLEAN(evaluator, function) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	union hs_evaluation_argument *arguments = (union hs_evaluation_argument *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		function(arguments[0].short_value, arguments[1].boolean_value); \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define HS_EVALUATE_VOID_FROM_ARGUMENTS(evaluator, arguments_type, expression) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	arguments_type const *arguments; \
	arguments = (arguments_type const *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		expression; \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define hud_globals_definition_get(index) \
	((struct hud_globals_definition *)tag_get(hud_globals_group_tag, (index)))
#define hud_message_text_definition_get(index) \
	((struct hud_message_text_definition *)tag_get(hud_message_text_group_tag, (index)))

#define HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(evaluator, arguments_type, real_index, expression) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	arguments_type const *arguments; \
	arguments = (arguments_type const *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		real real_argument = arguments[real_index].real_value; \
		expression; \
		hs_return(thread_index, 0); \
	} \
	return; \
}

#define HS_EVALUATE_RETURN_BOOLEAN(evaluator, arguments_type, expression) \
static void evaluator( \
	short function_index, \
	long thread_index, \
	boolean initialize) \
{ \
	arguments_type const *arguments; \
	union hs_boolean_result result; \
	result.value = 0; \
	arguments = (arguments_type const *)hs_macro_function_evaluate(function_index, thread_index, initialize); \
	if (arguments) \
	{ \
		result.boolean = expression; \
		hs_return(thread_index, result.value); \
	} \
	return; \
}

/* ---------- structures */

struct hs_object_list_get_element_arguments
{
	long object_list_index;
	unsigned short element_index;
};

union hs_real_value
{
	real real_value;
	long long_value;
};

union hs_short_result
{
	short short_value;
	long value;
};

union hs_evaluation_argument
{
	long long_value;
	real real_value;
	short short_value;
	unsigned short unsigned_short_value;
	boolean boolean_value;
	char const *string_value;
};

struct hs_arguments_boolean
{
	boolean value;
};

struct hs_arguments_long
{
	long value;
};

struct hs_arguments_word
{
	word value;
};

struct hs_arguments_short_long
{
	short value0;
	word pad0;
	long value1;
};

struct hs_arguments_long_word
{
	long value0;
	word value1;
};

struct hs_arguments_string
{
	char const *value;
};

struct hs_arguments_long_string
{
	long value0;
	char const *value1;
};

struct hs_arguments_long_long
{
	long value0;
	long value1;
};

struct hs_arguments_long_long_string
{
	long value0;
	long value1;
	char const *value2;
};

struct hs_arguments_short_word
{
	short value0;
	word pad0;
	word value1;
};

struct hs_arguments_long_long_long
{
	long value0;
	char const *value1;
	long value2;
};

struct hud_message_text_definition
{
	byte reserved_000[0x20];
	struct tag_block messages;
};

struct hud_message_definition
{
	byte reserved[0x40];
};

struct hud_waypoint_arrow_definition
{
	byte reserved[0x68];
};

typedef void (*hs_token_enumerator)(
	void);

struct hs_function_table_storage
{
	struct hs_function_definition const *functions[418 + 7];
	struct profile_section profile;
	hs_token_enumerator token_enumerators[18];
};

struct hs_arguments_long_string_string
{
	long value0;
	char const *value1;
	char const *value2;
};

struct hs_arguments_long_string_long_string
{
	long value0;
	char const *value1;
	long value2;
	char const *value3;
};

struct hs_arguments_long_long_string_word
{
	long value0;
	long value1;
	char const *value2;
	word value3;
};

struct hs_arguments_long_long_long_boolean
{
	long value0;
	long value1;
	char const *value2;
	boolean value3;
};

struct hs_arguments_long_long_long_boolean_word
{
	long value0;
	long value1;
	char const *value2;
	boolean value3;
	byte pad3[3];
	word value4;
};

struct hs_arguments_real
{
	real value;
};

struct hs_arguments_real_real
{
	real value0;
	real value1;
};

struct hs_arguments_real_real_real
{
	real value0;
	real value1;
	real value2;
};

struct hs_arguments_real_real_real_real
{
	real value0;
	real value1;
	real value2;
	real value3;
};

struct hs_arguments_word_word_word_real
{
	word value0;
	word pad0;
	word value1;
	word pad1;
	word value2;
	word pad2;
	real value3;
};

struct hs_arguments_word_word_long_real
{
	word value0;
	word pad0;
	word value1;
	word pad1;
	long value2;
	real value3;
};

struct hs_arguments_real_real_real_real_boolean_real
{
	real value0;
	real value1;
	real value2;
	real value3;
	boolean value4;
	byte pad4[3];
	real value5;
};

struct hs_arguments_long_real_word
{
	long value0;
	real value1;
	word value2;
};

struct hs_arguments_long_real_real
{
	long value0;
	real value1;
	real value2;
};

struct hs_arguments_real_real_real_word
{
	real value0;
	real value1;
	real value2;
	word value3;
};

struct hs_arguments_short_word_real_real_real
{
	short value0;
	word pad0;
	word value1;
	word pad1;
	real value2;
	real value3;
	real value4;
};

struct hs_arguments_word_word_word
{
	word value0;
	word pad0;
	word value1;
	word pad1;
	word value2;
};

struct hs_arguments_word_word_long
{
	word value0;
	word pad0;
	word value1;
	word pad1;
	long value2;
};

struct hs_arguments_long_word_boolean
{
	long value0;
	word value1;
	word pad1;
	boolean value2;
};

union hs_boolean_result
{
	boolean boolean;
	long value;
};

/* ---------- prototypes */

static long alphabetize(
	char const **left,
	char const **right);
void unit_scripting_set_maximum_vitality(
	long unit_index,
	real body_vitality,
	real shield_vitality);
void units_scripting_set_maximum_vitality(
	long object_list_index,
	real body_vitality,
	real shield_vitality);
void unit_scripting_set_current_vitality(
	long unit_index,
	real body_vitality,
	real shield_vitality);
void units_scripting_set_current_vitality(
	long object_list_index,
	real body_vitality,
	real shield_vitality);
void rasterizer_model_ambient_reflection_tint(
	real alpha,
	real red,
	real green,
	real blue);
short unit_scripting_get_grenade_count(
	long unit_index);
void hs_help(
	char const *function_name);
boolean unit_scripting_start_user_animation_list(
	long object_list_index,
	long animation_graph_index,
	char const *animation_name,
	boolean interpolate);
boolean unit_scripting_has_weapon(
	long unit_index,
	long weapon_definition_index);
boolean unit_scripting_has_weapon_readied(
	long unit_index,
	long weapon_definition_index);
void unit_scripting_impervious(
	long object_list_index,
	boolean impervious);
real unit_scripting_get_health(
	long unit_index);
real unit_scripting_get_shield(
	long unit_index);
void hs_doc(
	void);
void hs_dispose_from_old_map(
	void);
static long alphabetize_file_references(
	struct file_reference const *left,
	struct file_reference const *right);
int isspace(
	int character);
boolean hs_scenario_merge(
	struct scenario *scenario,
	struct scenario *source_scenario);
static void hs_allocate(
	void);
static boolean hs_scenario_syntax_data_valid(
	struct scenario const *scenario);
static boolean hs_scenario_string_constants_valid(
	struct scenario const *scenario);
static void hs_scenario_scripts_disable(
	struct scenario *scenario);
/* port: the script function allowlist */
static struct hs_syntax_node const *hs_syntax_try_get(
	long expression_index);
static boolean hs_syntax_node_linked_twice(
	long expression_index);
static short hs_syntax_node_refusal(
	struct hs_syntax_node const *expression,
	char const **name);
static short hs_expression_refusal(
	long root_expression_index,
	char const **name);
static void hs_scenario_functions_check(
	struct scenario *scenario);
static boolean hs_rebuild_source(
	void);
static boolean hs_compile_source(
	void);
boolean hs_scenario_postprocess(
	boolean restore_syntax_data);

/* ---------- constants */

#define MAXIMUM_HS_SYNTAX_NODES_PER_SCENARIO 19001
/* port: the size of the "hs globals" array (hs_runtime_initialize), which
holds the external globals and the map's */
#define MAXIMUM_HS_GLOBALS 0x400
/* port: the scripts block's maximum (hs_scripts_block) */
#define MAXIMUM_HS_SCRIPTS_PER_SCENARIO 512

/* port: a script node's flags (as hs_compile.c and hs_runtime.c have them) */
enum
{
	_hs_syntax_node_primitive_bit = 0,
	_hs_syntax_node_script_bit,
	_hs_syntax_node_variable_bit,
	_hs_syntax_node_permanent_bit,
};

/* port: why a map's script may not have a node (hs_syntax_node_refusal) */
enum
{
	_hs_node_refusal_none = 0,
	_hs_node_refusal_function,
	_hs_node_refusal_global,
	_hs_node_refusal_arguments,
	_hs_node_refusal_damaged,
	/* port: a downloaded map's (hs_functions_denied_to_downloaded_maps) */
	_hs_node_refusal_downloaded_function,
	_hs_node_refusal_downloaded_global,
};

/* ---------- globals */

static short hs_enumeration_result_count = 0;
static short hs_enumeration_maximum_count = 0;
static char const **enumeration_results = NULL;
static char const *hs_enumeration_substring = NULL;
static boolean hs_recompile_pending = FALSE;
static boolean hs_syntax_data_allocated = FALSE;
/* port: the map's scripts and global initializers that call a function
maps may not (hs_scenario_functions_check) */
static unsigned long hs_scenario_disabled_scripts[BIT_VECTOR_SIZE_IN_LONGS(MAXIMUM_HS_SCRIPTS_PER_SCENARIO)];
static unsigned long hs_scenario_disabled_globals[BIT_VECTOR_SIZE_IN_LONGS(MAXIMUM_HS_GLOBALS)];
/* port: the nodes linked to, then walked (hs_scenario_functions_check) */
static unsigned long hs_syntax_nodes_marked[BIT_VECTOR_SIZE_IN_LONGS(MAXIMUM_HS_SYNTAX_NODES_PER_SCENARIO)];
#define hs_token_enumerators hs_function_table.token_enumerators
struct data_array *hs_syntax_data;
extern long global_scenario_index;
extern struct hs_function_table_storage hs_function_table;
extern short const hs_external_global_count;
extern struct hs_external_global_definition *hs_external_globals[];
extern char const *hs_script_type_names[];
extern char const *hs_type_names[];

/* ---------- structures */

struct hs_function_definition_with_1_parameter
{
	struct hs_function_definition definition;
	short parameter_types[1];
};

struct hs_function_definition_with_2_parameters
{
	struct hs_function_definition definition;
	short parameter_types[2];
};

struct hs_function_definition_with_3_parameters
{
	struct hs_function_definition definition;
	short parameter_types[3];
};

struct hs_function_definition_with_4_parameters
{
	struct hs_function_definition definition;
	short parameter_types[4];
};

struct hs_function_definition_with_5_parameters
{
	struct hs_function_definition definition;
	short parameter_types[5];
};

struct hs_function_definition_with_6_parameters
{
	struct hs_function_definition definition;
	short parameter_types[6];
};

/* ---------- prototypes */

static void ai_debug_sound_point_set_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_debug_speak_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_debug_speak_list_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_debug_teleport_to_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_debug_vocalize_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_globals_ai_active_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_globals_dialogue_triggers_enabled_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_globals_grenades_enabled_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_profile_change_render_spray_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_allegiance_broken_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_allegiance_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_allegiance_remove_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_allow_charge_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_allow_dormant_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_attach_free_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_attach_unit_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_attach_units_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_attack_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_automatic_migration_target_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_berserk_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_braindead_by_unit_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_braindead_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_command_list_advance_by_unit_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_command_list_advance_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_command_list_by_unit_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_command_list_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_command_list_status_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_conversation_advance_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_conversation_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_conversation_line_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_conversation_status_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_conversation_stop_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_defend_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_deselect_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_detach_unit_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_detach_units_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_erase_all_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_erase_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_exit_vehicle_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_follow_distance_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_follow_target_ai_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_follow_target_disable_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_follow_target_players_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_follow_target_unit_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_force_active_by_unit_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_force_active_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_free_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_free_units_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_go_to_vehicle_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_go_to_vehicle_override_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_going_to_vehicle_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_ignore_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_is_attacking_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_kill_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_kill_silent_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_link_activation_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_living_count_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_living_fraction_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_look_at_object_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_magically_see_encounter_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_magically_see_players_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_magically_see_unit_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_magically_see_units_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_maneuver_enable_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_maneuver_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_migrate_and_speak_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_migrate_by_unit_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_migrate_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_nonswarm_count_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_place_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_playfight_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_prefer_target_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_reconnect_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_renew_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_retreat_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_select_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_set_blind_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_set_current_state_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_set_deaf_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_set_respawn_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_set_return_state_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_set_team_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_spawn_actor_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_status_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_stop_looking_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_strength_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_swarm_count_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_teleport_starting_location_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_teleport_starting_location_if_unsupported_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_timer_expire_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_timer_start_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_try_to_fight_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_try_to_fight_nothing_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_try_to_fight_player_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_vehicle_encounter_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_vehicle_enterable_actor_type_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_vehicle_enterable_actors_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_vehicle_enterable_disable_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_vehicle_enterable_distance_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ai_scripting_vehicle_enterable_team_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void attract_mode_start_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void breakable_surfaces_enable_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void breakable_surfaces_reset_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cheat_active_camouflage_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cheat_active_camouflage_local_player_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cheat_all_powerups_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cheat_all_vehicles_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cheat_all_weapons_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cheat_teleport_to_camera_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cheats_load_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cinematic_set_title_delayed_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cinematic_set_title_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cinematic_show_letterbox_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cinematic_skip_start_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cinematic_skip_stop_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cinematic_start_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cinematic_stop_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void cinematic_suppress_bsp_object_creation_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void debug_dump_memory_by_file_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void debug_dump_memory_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void debug_dump_memory_for_file_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void debug_player_teleport_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void debug_pvs_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void debug_sound_classes_enable_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void debug_sound_classes_set_distances_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void debug_sound_classes_set_wet_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void device_get_position_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void device_get_power_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void device_group_change_only_once_more_set_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void device_group_get_value_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void device_group_set_actual_value_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void device_group_set_desired_value_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void device_one_sided_set_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void device_operates_automatically_set_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void device_set_actual_position_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void device_set_desired_position_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void device_set_never_appears_locked_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void device_set_power_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void director_load_camera_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void director_save_camera_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void director_script_camera_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void display_scenario_help_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void enumerate_memory_units_test_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void errors_overflow_suppression_enable_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void game_all_quiet_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void game_difficulty_level_get_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void game_difficulty_level_get_ignore_easy_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void game_is_cooperative_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void game_safe_to_save_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void game_safe_to_speak_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void game_set_game_variant_from_name_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void game_state_reverted_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void game_time_get_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void game_time_set_speed_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void garbage_collect_now_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void global_structure_bsp_index_get_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_damage_new_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_damage_object_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_doc_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_effect_new_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_effect_new_from_object_marker_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_help_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_not_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_object_create_anew_containing_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_object_create_anew_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_object_create_containing_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_object_create_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_object_destroy_all_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_object_destroy_containing_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_object_destroy_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_object_list_get_element_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_object_set_facing_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_object_set_permutation_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_object_set_shield_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_object_teleport_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_objects_can_see_flag_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_objects_can_see_object_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_objects_delete_by_definition_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_objects_predict_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_players_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_print_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_recompile_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_sound_get_gain_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_sound_set_gain_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_teleport_players_not_in_trigger_volume_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_trigger_volume_test_objects_all_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_trigger_volume_test_objects_any_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hud_activate_team_nav_point_with_flag_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hud_activate_team_nav_point_with_object_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hud_deactivate_team_nav_point_with_flag_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hud_deactivate_team_nav_point_with_object_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hud_unit_activate_nav_point_with_flag_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hud_unit_activate_nav_point_with_object_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hud_unit_deactivate_nav_point_with_flag_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hud_unit_deactivate_nav_point_with_object_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void lights_enable_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_crash_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_load_core_at_startup_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_load_core_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_load_core_name_at_startup_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_load_core_name_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_lost_map_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_print_version_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_reset_map_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_revert_map_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_save_cancel_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_save_core_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_save_core_name_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_save_map_no_timeout_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_save_map_nonsafe_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_save_map_safe_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_saving_map_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_set_difficulty_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_set_game_connection_to_film_playback_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_set_map_name_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_set_multiplayer_map_name_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_skip_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void main_won_map_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void network_game_client_request_immediate_start_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void numeric_countdown_timer_get_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void numeric_countdown_timer_restart_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void numeric_countdown_timer_set_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void numeric_countdown_timer_stop_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void object_beautify_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void object_can_take_damage_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void object_cannot_take_damage_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void object_definition_predict_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void object_list_count_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void object_list_from_ai_reference_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void object_pvs_activate_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void object_pvs_clear_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void object_pvs_set_camera_point_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void object_pvs_set_object_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void object_scripting_set_collideable_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void object_set_melee_attack_inhibited_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void object_set_ranged_attack_inhibited_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void objects_dump_memory_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void objects_scripting_attach_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void objects_scripting_detach_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void objects_scripting_set_scale_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player0_joystick_set_is_normal_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player0_look_invert_pitch_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player0_look_pitch_is_inverted_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_add_equipment_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_control_action_test_accept_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_control_action_test_action_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_control_action_test_back_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_control_action_test_grenade_trigger_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_control_action_test_jump_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_control_action_test_look_relative_all_directions_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_control_action_test_look_relative_down_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_control_action_test_look_relative_left_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_control_action_test_look_relative_right_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_control_action_test_look_relative_up_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_control_action_test_move_relative_all_directions_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_control_action_test_primary_trigger_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_control_action_test_reset_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_control_action_test_zoom_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_effect_screen_fade_in_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_effect_screen_fade_out_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_input_enable_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_ui_activate_all_solo_levels_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void player_ui_fast_setup_network_server_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void players_unzoom_all_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void profile_dump_to_file_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void profile_graph_toggle_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void profile_initialize_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void profile_sections_activate_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void profile_sections_deactivate_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void radiosity_hack_find_point_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void radiosity_hack_save_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void radiosity_hack_start_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void random_range_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void rasterizer_decals_flush_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void rasterizer_fps_accumulate_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void rasterizer_lights_reset_for_new_map_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void rasterizer_model_ambient_reflection_tint_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void rasterizer_screen_effect_set_convolution_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void rasterizer_screen_effect_set_filter_desaturation_tint_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void rasterizer_screen_effect_set_filter_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void rasterizer_screen_effect_set_video_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void rasterizer_screen_effect_start_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void rasterizer_screen_effect_stop_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void rasterizer_script_screen_effect_set_value_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void rasterizer_set_near_clip_distance_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void real_random_range_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void recorded_animation_get_time_left_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void recorded_animation_kill_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void recorded_animation_play_and_delete_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void recorded_animation_play_and_hover_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void recorded_animation_play_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void render_effects_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void saved_game_files_delete_all_custom_profiles_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scenario_switch_structure_bsp_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scenario_trigger_volume_test_object_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scenery_animation_start_at_frame_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scenery_animation_start_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scenery_get_animation_time_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_camera_set_absolute_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_camera_set_animation_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_camera_set_dead_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_camera_set_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_camera_set_first_person_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_camera_time_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_foley_predict_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_blink_health_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_blink_motion_sensor_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_blink_shield_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_get_timer_ticks_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_messages_clear_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_pause_timer_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_restart_flashing_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_set_flashing_state_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_set_objective_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_set_state_message_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_set_timer_position_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_set_timer_time_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_set_timer_warning_cutoff_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_show_crosshair_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_show_health_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_show_motion_sensor_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_show_shield_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_show_timer_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_time_code_reset_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_time_code_show_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_hud_time_code_start_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_looping_sound_set_alternate_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_looping_sound_set_scale_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_looping_sound_start_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_looping_sound_stop_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_player_control_set_camera_control_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_player_effect_set_rotation_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_player_effect_set_rumble_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_player_effect_set_translation_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_player_effect_start_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_player_effect_stop_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_show_hud_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_show_hud_help_text_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_sound_new_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_sound_stop_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripted_sound_time_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripting_magic_melee_attack_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void scripting_set_magic_base_seat_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void sound_cache_flush_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void sound_class_set_gain_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void sound_enable_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void structure_lens_flares_place_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void tag_groups_dump_memory_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void terminal_clear_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void texture_cache_flush_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void ui_widget_debug_show_path_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_aim_without_turning_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_close_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_custom_animation_at_frame_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_get_current_flashlight_state_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_get_custom_animation_time_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_is_playing_custom_animation_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_kill_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_kill_silent_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_open_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_can_blink_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_doesnt_drop_items_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_enter_vehicle_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_exit_vehicle_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_get_grenade_count_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_get_health_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_get_shield_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_has_weapon_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_has_weapon_readied_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_impervious_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_set_current_vitality_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_set_emotion_animation_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_set_maximum_vitality_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_set_seat_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_start_user_animation_list_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_suspended_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_unit_driver_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_unit_gunner_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_unit_riders_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_vehicle_test_seat_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_scripting_vehicle_test_seat_list_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_set_desired_flashlight_state_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_set_emotion_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_set_enterable_by_player_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_solo_player_integrated_night_vision_is_active_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_start_user_animation_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void unit_stop_custom_animation_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void units_scripting_set_current_vitality_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void units_scripting_set_maximum_vitality_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void units_set_desired_flashlight_state_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void vehicle_hover_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void vehicle_scripting_load_magic_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void vehicle_scripting_unload_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void xbox_set_machine_name_evaluate(
	short function_index,
	long thread_index,
	boolean initialize);
static void hs_enumerate_special_form_names(
	void);
static void hs_enumerate_script_type_names(
	void);
static void hs_enumerate_type_names(
	void);
static void hs_enumerate_function_names(
	void);
static void hs_enumerate_script_names(
	void);
static void hs_enumerate_variable_names(
	void);
static void hs_enumerate_ai_names(
	void);
static void hs_enumerate_ai_command_list_names(
	void);
static void hs_enumerate_starting_profile_names(
	void);
static void hs_enumerate_conversation_names(
	void);
static void hs_enumerate_object_names(
	void);
static void hs_enumerate_trigger_volume_names(
	void);
static void hs_enumerate_cutscene_flag_names(
	void);
static void hs_enumerate_cutscene_camera_point_names(
	void);
static void hs_enumerate_cutscene_title_names(
	void);
static void hs_enumerate_cutscene_recording_names(
	void);
static void hs_enumerate_navpoints(
	void);
static void hs_enumerate_hud_messages(
	void);

extern char const *global_game_difficulty_level_names[];
extern char const *global_game_team_names[];
extern char const *global_actor_type_names[];
extern char const *global_hud_anchor_names[];

/* ---------- globals */

char const *hs_type_names[NUMBER_OF_HS_TYPES]=
{
	"unparsed",
	"special form",
	"function name",
	"passthrough",
	"void",
	"boolean",
	"real",
	"short",
	"long",
	"string",
	"script",
	"trigger_volume",
	"cutscene_flag",
	"cutscene_camera_point",
	"cutscene_title",
	"cutscene_recording",
	"device_group",
	"ai",
	"ai_command_list",
	"starting_profile",
	"conversation",
	"navpoint",
	"hud_message",
	"object_list",
	"sound",
	"effect",
	"damage",
	"looping_sound",
	"animation_graph",
	"actor_variant",
	"damage_effect",
	"object_definition",
	"game_difficulty",
	"team",
	"ai_default_state",
	"actor_type",
	"hud_corner",
	"object",
	"unit",
	"vehicle",
	"weapon",
	"device",
	"scenery",
	"object_name",
	"unit_name",
	"vehicle_name",
	"weapon_name",
	"device_name",
	"scenery_name",
};

char const *hs_script_type_names[]=
{
	"startup",
	"dormant",
	"continuous",
	"static",
	"stub",
};

word const hs_object_type_masks[NUMBER_OF_HS_OBJECT_TYPES]=
{
	0xFFFF,
	0x0003,
	0x0002,
	0x0004,
	0x0380,
	0x0040,
};

tag const hs_tag_reference_type_group_tags[]=
{
	'snd!',
	'effe',
	'jpt!',
	'lsnd',
	'antr',
	'actv',
	'jpt!',
	'obje',
};

short const hs_type_sizes[NUMBER_OF_HS_TYPES]=
{
	0,
	0,
	0,
	0,
	0,
	1,
	4,
	2,
	4,
	4,
	4,
	2,
	2,
	2,
	2,
	2,
	2,
	4,
	2,
	2,
	2,
	2,
	2,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	2,
	2,
	2,
	2,
	2,
	4,
	4,
	4,
	4,
	4,
	4,
	2,
	2,
	2,
	2,
	2,
	2,
};

boolean const _hs_type_boolean_default= FALSE;
real const _hs_type_real_default= 0.0f;
short const _hs_type_short_integer_default= 0;
long const _hs_type_long_integer_default= 0;
char const *_hs_type_string_default= "";
short const _hs_type_script_default= NONE;
short const _hs_type_trigger_volume_default= NONE;
short const _hs_type_cutscene_flag_default= NONE;
short const _hs_type_cutscene_camera_point_default= NONE;
short const _hs_type_cutscene_title_default= NONE;
short const _hs_type_cutscene_recording_default= NONE;
short const _hs_type_device_group_default= NONE;
long const _hs_type_ai_default= NONE;
short const _hs_type_ai_command_list_default= NONE;
short const _hs_type_starting_profile_default= NONE;
short const _hs_type_conversation_default= NONE;
short const _hs_type_navpoint_default= NONE;
short const _hs_type_hud_message_default= NONE;
long const _hs_type_object_list_default= NONE;
long const _hs_type_sound_default= NONE;
long const _hs_type_looping_sound_default= NONE;
long const _hs_type_effect_default= NONE;
long const _hs_type_damage_default= NONE;
long const _hs_type_animation_graph_default= NONE;
long const _hs_type_actor_variant_default= NONE;
long const _hs_type_damage_effect_default= NONE;
long const _hs_type_object_definition_default= NONE;
short const _hs_type_enum_game_difficulty_default= NONE;
short const _hs_type_enum_team_default= NONE;
short const _hs_type_enum_ai_default_state_default= NONE;
short const _hs_type_enum_actor_type_default= NONE;
short const _hs_type_enum_hud_corner_default= NONE;
short const _hs_type_object_name_default= NONE;
long const _hs_type_object_default= NONE;
long const _hs_type_unit_default= NONE;
long const _hs_type_vehicle_default= NONE;
long const _hs_type_weapon_default= NONE;
long const _hs_type_device_default= NONE;
long const _hs_type_scenery_default= NONE;

/* the <script>_definition names below are recovered from the 2003 PC demo PDB and the HCEX PDB (file
 * statics in hs.obj): each demo struct has January's script-name string, return type and parameter
 * list, in the same table order. four stems differ from the script names (add, subtract, multiply,
 * object_to_unit); xbox_set_machine_name_definition is HCEX-only; the eight hs_*_definition names that
 * neither PDB attests keep their descriptive hs_ prefix. */
static struct hs_function_definition const begin_definition=
{
	_hs_passthrough,
	0,
	"begin",
	hs_parse_begin,
	hs_evaluate_begin,
	"returns the last expression in a sequence after evaluating the sequence in order.",
	"<expression(s)>",
	0,
};

static struct hs_function_definition const begin_random_definition=
{
	_hs_passthrough,
	0,
	"begin_random",
	hs_parse_begin,
	hs_evaluate_begin_random,
	"evaluates the sequence of expressions in random order and returns the last value evaluated.",
	"<expression(s)>",
	0,
};

static struct hs_function_definition const if_definition=
{
	_hs_passthrough,
	0,
	"if",
	hs_parse_if,
	hs_evaluate_if,
	"returns one of two values based on the value of a condition.",
	"<boolean> <then> [<else>]",
	0,
};

static struct hs_function_definition const cond_definition=
{
	_hs_passthrough,
	0,
	"cond",
	hs_parse_cond,
	NULL,
	"returns the value associated with the first true condition.",
	"(<boolean1> <result1>) [(<boolean2> <result2>) [...]]",
	0,
};

static struct hs_function_definition const set_definition=
{
	_hs_passthrough,
	0,
	"set",
	hs_parse_set,
	hs_evaluate_set,
	"set the value of a global variable.",
	"<variable name> <expression>",
	0,
};

static struct hs_function_definition const and_definition=
{
	_hs_type_boolean,
	0,
	"and",
	hs_parse_logical,
	hs_evaluate_logical,
	"returns true if all specified expressions are true.",
	"<boolean(s)>",
	0,
};

static struct hs_function_definition const or_definition=
{
	_hs_type_boolean,
	0,
	"or",
	hs_parse_logical,
	hs_evaluate_logical,
	"returns true if any specified expressions are true.",
	"<boolean(s)>",
	0,
};

static struct hs_function_definition const add_definition=
{
	_hs_type_real,
	0,
	"+",
	hs_parse_arithmetic,
	hs_evaluate_arithmetic,
	"returns the sum of all specified expressions.",
	"<number(s)>",
	0,
};

static struct hs_function_definition const subtract_definition=
{
	_hs_type_real,
	0,
	"-",
	hs_parse_arithmetic,
	hs_evaluate_arithmetic,
	"returns the difference of two expressions.",
	"<number> <number>",
	0,
};

static struct hs_function_definition const multiply_definition=
{
	_hs_type_real,
	0,
	"*",
	hs_parse_arithmetic,
	hs_evaluate_arithmetic,
	"returns the product of all specified expressions.",
	"<number(s)>",
	0,
};

static struct hs_function_definition const divide_definition=
{
	_hs_type_real,
	0,
	"/",
	hs_parse_arithmetic,
	hs_evaluate_arithmetic,
	"returns the quotient of two expressions.",
	"<number> <number>",
	0,
};

static struct hs_function_definition const min_definition=
{
	_hs_type_real,
	0,
	"min",
	hs_parse_arithmetic,
	hs_evaluate_arithmetic,
	"returns the minimum of all specified expressions.",
	"<number(s)>",
	0,
};

static struct hs_function_definition const max_definition=
{
	_hs_type_real,
	0,
	"max",
	hs_parse_arithmetic,
	hs_evaluate_arithmetic,
	"returns the maximum of all specified expressions.",
	"<number(s)>",
	0,
};

static struct hs_function_definition const equal_definition=
{
	_hs_type_boolean,
	0,
	"=",
	hs_parse_equality,
	hs_evaluate_equality,
	"returns true if two expressions are equal",
	"<expression> <expression>",
	0,
};

static struct hs_function_definition const not_equal_definition=
{
	_hs_type_boolean,
	0,
	"!=",
	hs_parse_equality,
	hs_evaluate_equality,
	"returns true if two expressions are not equal",
	"<expression> <expression>",
	0,
};

static struct hs_function_definition const gt_definition=
{
	_hs_type_boolean,
	0,
	">",
	hs_parse_inequality,
	hs_evaluate_inequality,
	"returns true if the first number is larger than the second.",
	"<number> <number>",
	0,
};

static struct hs_function_definition const lt_definition=
{
	_hs_type_boolean,
	0,
	"<",
	hs_parse_inequality,
	hs_evaluate_inequality,
	"returns true if the first number is smaller than the second.",
	"<number> <number>",
	0,
};

static struct hs_function_definition const gte_definition=
{
	_hs_type_boolean,
	0,
	">=",
	hs_parse_inequality,
	hs_evaluate_inequality,
	"returns true if the first number is larger than or equal to the second.",
	"<number> <number>",
	0,
};

static struct hs_function_definition const lte_definition=
{
	_hs_type_boolean,
	0,
	"<=",
	hs_parse_inequality,
	hs_evaluate_inequality,
	"returns true if the first number is smaller than or equal to the second.",
	"<number> <number>",
	0,
};

static struct hs_function_definition const sleep_definition=
{
	_hs_type_void,
	0,
	"sleep",
	hs_parse_sleep,
	hs_evaluate_sleep,
	"pauses execution of this script (or, optionally, another script) for the specified number of ticks.",
	"<short> [<script>]",
	0,
};

static struct hs_function_definition const sleep_until_definition=
{
	_hs_type_void,
	0,
	"sleep_until",
	hs_parse_sleep_until,
	hs_evaluate_sleep_until,
	"pauses execution of this script until the specified condition is true, checking once per second unless a different number of ticks is specified.",
	"<boolean> [<short>]",
	0,
};

static struct hs_function_definition const wake_definition=
{
	_hs_type_void,
	0,
	"wake",
	hs_parse_wake,
	hs_evaluate_wake,
	"wakes a sleeping script in the next update.",
	"<script name>",
	0,
};

static struct hs_function_definition const inspect_definition=
{
	_hs_type_void,
	0,
	"inspect",
	hs_parse_inspect,
	hs_evaluate_inspect,
	"prints the value of an expression to the screen for debugging purposes.",
	"<expression>",
	0,
};

static struct hs_function_definition const object_to_unit_definition=
{
	_hs_type_unit,
	0,
	"unit",
	hs_parse_object_cast_up,
	hs_evaluate_object_cast_up,
	"converts an object to a unit.",
	"<object>",
	0,
};

static struct hs_function_definition const ai_debug_communication_suppress_definition=
{
	_hs_type_void,
	0,
	"ai_debug_communication_suppress",
	hs_parse_debug_string,
	hs_evaluate_debug_string,
	"suppresses (or stops suppressing) a set of AI communication types.",
	"<string(s)>",
	0,
};

static struct hs_function_definition const ai_debug_communication_ignore_definition=
{
	_hs_type_void,
	0,
	"ai_debug_communication_ignore",
	hs_parse_debug_string,
	hs_evaluate_debug_string,
	"ignores (or stops ignoring) a set of AI communication types when printing out communications.",
	"<string(s)>",
	0,
};

static struct hs_function_definition const ai_debug_communication_focus_definition=
{
	_hs_type_void,
	0,
	"ai_debug_communication_focus",
	hs_parse_debug_string,
	hs_evaluate_debug_string,
	"focuses (or stops focusing) a set of unit vocalization types.",
	"<string(s)>",
	0,
};

static struct hs_function_definition_with_1_parameter const not_definition=
{
	{
		_hs_type_boolean,
		0,
		"not",
		hs_macro_function_parse,
		hs_not_evaluate,
		"returns the opposite of the expression.",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const print_definition=
{
	{
		_hs_type_void,
		0,
		"print",
		hs_macro_function_parse,
		hs_print_evaluate,
		"prints a string to the console.",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition const players_definition=
{
	_hs_type_object_list,
	0,
	"players",
	hs_macro_function_parse,
	hs_players_evaluate,
	"returns a list of the players",
	NULL,
	0,
};

static struct hs_function_definition_with_2_parameters const volume_teleport_players_not_inside_definition=
{
	{
		_hs_type_void,
		0,
		"volume_teleport_players_not_inside",
		hs_macro_function_parse,
		hs_teleport_players_not_in_trigger_volume_evaluate,
		"moves all players outside a specified trigger volume to a specified flag.",
		NULL,
		2,
		{ _hs_type_trigger_volume },
	},
	{ _hs_type_cutscene_flag },
};

static struct hs_function_definition_with_2_parameters const volume_test_object_definition=
{
	{
		_hs_type_boolean,
		0,
		"volume_test_object",
		hs_macro_function_parse,
		scenario_trigger_volume_test_object_evaluate,
		"returns true if the specified object is within the specified volume.",
		NULL,
		2,
		{ _hs_type_trigger_volume },
	},
	{ _hs_type_object },
};

static struct hs_function_definition_with_2_parameters const volume_test_objects_definition=
{
	{
		_hs_type_boolean,
		0,
		"volume_test_objects",
		hs_macro_function_parse,
		hs_trigger_volume_test_objects_any_evaluate,
		"returns true if any of the specified objects are within the specified volume.",
		NULL,
		2,
		{ _hs_type_trigger_volume },
	},
	{ _hs_type_object_list },
};

static struct hs_function_definition_with_2_parameters const volume_test_objects_all_definition=
{
	{
		_hs_type_boolean,
		0,
		"volume_test_objects_all",
		hs_macro_function_parse,
		hs_trigger_volume_test_objects_all_evaluate,
		"returns true if any of the specified objects are within the specified volume.",
		NULL,
		2,
		{ _hs_type_trigger_volume },
	},
	{ _hs_type_object_list },
};

static struct hs_function_definition_with_1_parameter const object_create_definition=
{
	{
		_hs_type_void,
		0,
		"object_create",
		hs_macro_function_parse,
		hs_object_create_evaluate,
		"creates an object from the scenario.",
		NULL,
		1,
		{ _hs_type_object_name },
	},
};

static struct hs_function_definition_with_1_parameter const object_destroy_definition=
{
	{
		_hs_type_void,
		0,
		"object_destroy",
		hs_macro_function_parse,
		hs_object_destroy_evaluate,
		"destroys an object.",
		NULL,
		1,
		{ _hs_type_object },
	},
};

static struct hs_function_definition_with_1_parameter const object_create_anew_definition=
{
	{
		_hs_type_void,
		0,
		"object_create_anew",
		hs_macro_function_parse,
		hs_object_create_anew_evaluate,
		"creates an object, destroying it first if it already exists.",
		NULL,
		1,
		{ _hs_type_object_name },
	},
};

static struct hs_function_definition_with_1_parameter const object_create_containing_definition=
{
	{
		_hs_type_void,
		0,
		"object_create_containing",
		hs_macro_function_parse,
		hs_object_create_containing_evaluate,
		"creates all objects from the scenario whose names contain the given substring.",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_1_parameter const object_create_anew_containing_definition=
{
	{
		_hs_type_void,
		0,
		"object_create_anew_containing",
		hs_macro_function_parse,
		hs_object_create_anew_containing_evaluate,
		"creates anew all objects from the scenario whose names contain the given substring.",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_1_parameter const object_destroy_containing_definition=
{
	{
		_hs_type_void,
		0,
		"object_destroy_containing",
		hs_macro_function_parse,
		hs_object_destroy_containing_evaluate,
		"destroys all objects from the scenario whose names contain the given substring.",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition const object_destroy_all_definition=
{
	_hs_type_void,
	0,
	"object_destroy_all",
	hs_macro_function_parse,
	hs_object_destroy_all_evaluate,
	"destroys all non player objects.",
	NULL,
	0,
};

static struct hs_function_definition_with_2_parameters const object_teleport_definition=
{
	{
		_hs_type_void,
		0,
		"object_teleport",
		hs_macro_function_parse,
		hs_object_teleport_evaluate,
		"moves the specified object to the specified flag.",
		NULL,
		2,
		{ _hs_type_object },
	},
	{ _hs_type_cutscene_flag },
};

static struct hs_function_definition_with_2_parameters const object_set_facing_definition=
{
	{
		_hs_type_void,
		0,
		"object_set_facing",
		hs_macro_function_parse,
		hs_object_set_facing_evaluate,
		"turns the specified object in the direction of the specified flag.",
		NULL,
		2,
		{ _hs_type_object },
	},
	{ _hs_type_cutscene_flag },
};

static struct hs_function_definition_with_2_parameters const object_set_shield_definition=
{
	{
		_hs_type_void,
		0,
		"object_set_shield",
		hs_macro_function_parse,
		hs_object_set_shield_evaluate,
		"sets the shield vitality of the specified object (between 0 and 1).",
		NULL,
		2,
		{ _hs_type_object },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_3_parameters const object_set_permutation_definition=
{
	{
		_hs_type_void,
		0,
		"object_set_permutation",
		hs_macro_function_parse,
		hs_object_set_permutation_evaluate,
		"sets the desired region (use \"\" for all regions) to the permutation with the given name, e.g. (object_set_permutation flood \"right arm\" ~damaged)",
		NULL,
		3,
		{ _hs_type_object },
	},
	{ _hs_type_string, _hs_type_string },
};

static struct hs_function_definition_with_2_parameters const list_get_definition=
{
	{
		_hs_type_object,
		0,
		"list_get",
		hs_macro_function_parse,
		hs_object_list_get_element_evaluate,
		"returns an item in an object list.",
		NULL,
		2,
		{ _hs_type_object_list },
	},
	{ _hs_type_short_integer },
};

static struct hs_function_definition_with_1_parameter const list_count_definition=
{
	{
		_hs_type_short_integer,
		0,
		"list_count",
		hs_macro_function_parse,
		object_list_count_evaluate,
		"returns the number of objects in a list",
		NULL,
		1,
		{ _hs_type_object_list },
	},
};

static struct hs_function_definition_with_2_parameters const effect_new_definition=
{
	{
		_hs_type_void,
		0,
		"effect_new",
		hs_macro_function_parse,
		hs_effect_new_evaluate,
		"starts the specified effect at the specified flag.",
		NULL,
		2,
		{ _hs_type_effect },
	},
	{ _hs_type_cutscene_flag },
};

static struct hs_function_definition_with_3_parameters const effect_new_on_object_marker_definition=
{
	{
		_hs_type_void,
		0,
		"effect_new_on_object_marker",
		hs_macro_function_parse,
		hs_effect_new_from_object_marker_evaluate,
		"starts the specified effect on the specified object at the specified marker.",
		NULL,
		3,
		{ _hs_type_effect },
	},
	{ _hs_type_object, _hs_type_string },
};

static struct hs_function_definition_with_2_parameters const damage_new_definition=
{
	{
		_hs_type_void,
		0,
		"damage_new",
		hs_macro_function_parse,
		hs_damage_new_evaluate,
		"causes the specified damage at the specified flag.",
		NULL,
		2,
		{ _hs_type_damage },
	},
	{ _hs_type_cutscene_flag },
};

static struct hs_function_definition_with_2_parameters const damage_object_definition=
{
	{
		_hs_type_void,
		0,
		"damage_object",
		hs_macro_function_parse,
		hs_damage_object_evaluate,
		"causes the specified damage at the specified object.",
		NULL,
		2,
		{ _hs_type_damage },
	},
	{ _hs_type_object },
};

static struct hs_function_definition_with_3_parameters const objects_can_see_object_definition=
{
	{
		_hs_type_boolean,
		0,
		"objects_can_see_object",
		hs_macro_function_parse,
		hs_objects_can_see_object_evaluate,
		"returns true if any of the specified units are looking within the specified number of degrees of the object.",
		NULL,
		3,
		{ _hs_type_object_list },
	},
	{ _hs_type_object, _hs_type_real },
};

static struct hs_function_definition_with_3_parameters const objects_can_see_flag_definition=
{
	{
		_hs_type_boolean,
		0,
		"objects_can_see_flag",
		hs_macro_function_parse,
		hs_objects_can_see_flag_evaluate,
		"returns true if any of the specified units are looking within the specified number of degrees of the flag.",
		NULL,
		3,
		{ _hs_type_object_list },
	},
	{ _hs_type_cutscene_flag, _hs_type_real },
};

static struct hs_function_definition_with_1_parameter const objects_delete_by_definition_definition=
{
	{
		_hs_type_void,
		0,
		"objects_delete_by_definition",
		hs_macro_function_parse,
		hs_objects_delete_by_definition_evaluate,
		"deletes all objects of type <definition>",
		NULL,
		1,
		{ _hs_type_object_definition },
	},
};

static struct hs_function_definition_with_2_parameters const sound_set_gain_definition=
{
	{
		_hs_type_void,
		0,
		"sound_set_gain",
		hs_macro_function_parse,
		hs_sound_set_gain_evaluate,
		"absolutely do not use this",
		NULL,
		2,
		{ _hs_type_string },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_1_parameter const sound_get_gain_definition=
{
	{
		_hs_type_real,
		0,
		"sound_get_gain",
		hs_macro_function_parse,
		hs_sound_get_gain_evaluate,
		"absolutely do not use this either",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition const script_recompile_definition=
{
	_hs_type_void,
	0,
	"script_recompile",
	hs_macro_function_parse,
	hs_recompile_evaluate,
	"recompiles scripts.",
	NULL,
	0,
};

static struct hs_function_definition const script_doc_definition=
{
	_hs_type_void,
	0,
	"script_doc",
	hs_macro_function_parse,
	hs_doc_evaluate,
	"saves a file called hs_doc.txt with parameters for all script commands.",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const help_definition=
{
	{
		_hs_type_void,
		0,
		"help",
		hs_macro_function_parse,
		hs_help_evaluate,
		"prints a description of the named function.",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_2_parameters const random_range_definition=
{
	{
		_hs_type_short_integer,
		0,
		"random_range",
		hs_macro_function_parse,
		random_range_evaluate,
		"returns a random value in the range [lower bound, upper bound)",
		NULL,
		2,
		{ _hs_type_short_integer },
	},
	{ _hs_type_short_integer },
};

static struct hs_function_definition_with_2_parameters const real_random_range_definition=
{
	{
		_hs_type_real,
		0,
		"real_random_range",
		hs_macro_function_parse,
		real_random_range_evaluate,
		"returns a random value in the range [lower bound, upper bound)",
		NULL,
		2,
		{ _hs_type_real },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_2_parameters const numeric_countdown_timer_set_definition=
{
	{
		_hs_type_void,
		0,
		"numeric_countdown_timer_set",
		hs_macro_function_parse,
		numeric_countdown_timer_set_evaluate,
		"<milliseconds>, <auto_start>",
		NULL,
		2,
		{ _hs_type_long_integer },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_1_parameter const numeric_countdown_timer_get_definition=
{
	{
		_hs_type_short_integer,
		0,
		"numeric_countdown_timer_get",
		hs_macro_function_parse,
		numeric_countdown_timer_get_evaluate,
		"<digit_index>",
		NULL,
		1,
		{ _hs_type_short_integer },
	},
};

static struct hs_function_definition const numeric_countdown_timer_stop_definition=
{
	_hs_type_void,
	0,
	"numeric_countdown_timer_stop",
	hs_macro_function_parse,
	numeric_countdown_timer_stop_evaluate,
	"",
	NULL,
	0,
};

static struct hs_function_definition const numeric_countdown_timer_restart_definition=
{
	_hs_type_void,
	0,
	"numeric_countdown_timer_restart",
	hs_macro_function_parse,
	numeric_countdown_timer_restart_evaluate,
	"",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const breakable_surfaces_enable_definition=
{
	{
		_hs_type_void,
		0,
		"breakable_surfaces_enable",
		hs_macro_function_parse,
		breakable_surfaces_enable_evaluate,
		"enables or disables breakability of all breakable surfaces on level",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_2_parameters const recording_play_definition=
{
	{
		_hs_type_boolean,
		0,
		"recording_play",
		hs_macro_function_parse,
		recorded_animation_play_evaluate,
		"make the specified unit run the specified cutscene recording.",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_cutscene_recording },
};

static struct hs_function_definition_with_2_parameters const recording_play_and_delete_definition=
{
	{
		_hs_type_boolean,
		0,
		"recording_play_and_delete",
		hs_macro_function_parse,
		recorded_animation_play_and_delete_evaluate,
		"make the specified unit run the specified cutscene recording, deletes the unit when the animation finishes.",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_cutscene_recording },
};

static struct hs_function_definition_with_2_parameters const recording_play_and_hover_definition=
{
	{
		_hs_type_boolean,
		0,
		"recording_play_and_hover",
		hs_macro_function_parse,
		recorded_animation_play_and_hover_evaluate,
		"make the specified vehicle run the specified cutscene recording, hovers the vehicle when the animation finishes.",
		NULL,
		2,
		{ _hs_type_vehicle },
	},
	{ _hs_type_cutscene_recording },
};

static struct hs_function_definition_with_1_parameter const recording_kill_definition=
{
	{
		_hs_type_void,
		0,
		"recording_kill",
		hs_macro_function_parse,
		recorded_animation_kill_evaluate,
		"kill the specified unit's cutscene recording.",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_1_parameter const recording_time_definition=
{
	{
		_hs_type_short_integer,
		0,
		"recording_time",
		hs_macro_function_parse,
		recorded_animation_get_time_left_evaluate,
		"return the time remaining in the specified unit's cutscene recording.",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_2_parameters const object_set_ranged_attack_inhibited_definition=
{
	{
		_hs_type_void,
		0,
		"object_set_ranged_attack_inhibited",
		hs_macro_function_parse,
		object_set_ranged_attack_inhibited_evaluate,
		"FALSE prevents object from using ranged attack",
		NULL,
		2,
		{ _hs_type_object },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const object_set_melee_attack_inhibited_definition=
{
	{
		_hs_type_void,
		0,
		"object_set_melee_attack_inhibited",
		hs_macro_function_parse,
		object_set_melee_attack_inhibited_evaluate,
		"FALSE prevents object from using melee attack",
		NULL,
		2,
		{ _hs_type_object },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition const objects_dump_memory_definition=
{
	_hs_type_void,
	0,
	"objects_dump_memory",
	hs_macro_function_parse,
	objects_dump_memory_evaluate,
	"debugs object memory usage",
	NULL,
	0,
};

static struct hs_function_definition_with_2_parameters const object_set_collideable_definition=
{
	{
		_hs_type_void,
		0,
		"object_set_collideable",
		hs_macro_function_parse,
		object_scripting_set_collideable_evaluate,
		"FALSE prevents any object from colliding with the given object",
		NULL,
		2,
		{ _hs_type_object },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_3_parameters const object_set_scale_definition=
{
	{
		_hs_type_void,
		0,
		"object_set_scale",
		hs_macro_function_parse,
		objects_scripting_set_scale_evaluate,
		"sets the scale for a given object and interpolates over the given number of frames to achieve that scale",
		NULL,
		3,
		{ _hs_type_object },
	},
	{ _hs_type_real, _hs_type_short_integer },
};

static struct hs_function_definition_with_4_parameters const objects_attach_definition=
{
	{
		_hs_type_void,
		0,
		"objects_attach",
		hs_macro_function_parse,
		objects_scripting_attach_evaluate,
		"attaches the second object to the first; both strings can be empty",
		NULL,
		4,
		{ _hs_type_object },
	},
	{ _hs_type_string, _hs_type_object, _hs_type_string },
};

static struct hs_function_definition_with_2_parameters const objects_detach_definition=
{
	{
		_hs_type_void,
		0,
		"objects_detach",
		hs_macro_function_parse,
		objects_scripting_detach_evaluate,
		"detaches from the given parent object the given child object",
		NULL,
		2,
		{ _hs_type_object },
	},
	{ _hs_type_object },
};

static struct hs_function_definition const garbage_collect_now_definition=
{
	_hs_type_void,
	0,
	"garbage_collect_now",
	hs_macro_function_parse,
	garbage_collect_now_evaluate,
	"causes all garbage objects except those visible to a player to be collected immediately",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const object_cannot_take_damage_definition=
{
	{
		_hs_type_void,
		0,
		"object_cannot_take_damage",
		hs_macro_function_parse,
		object_cannot_take_damage_evaluate,
		"prevents an object from taking damage",
		NULL,
		1,
		{ _hs_type_object_list },
	},
};

static struct hs_function_definition_with_1_parameter const object_can_take_damage_definition=
{
	{
		_hs_type_void,
		0,
		"object_can_take_damage",
		hs_macro_function_parse,
		object_can_take_damage_evaluate,
		"allows an object to take damage again",
		NULL,
		1,
		{ _hs_type_object_list },
	},
};

static struct hs_function_definition_with_2_parameters const object_beautify_definition=
{
	{
		_hs_type_void,
		0,
		"object_beautify",
		hs_macro_function_parse,
		object_beautify_evaluate,
		"makes an object pretty for the remainder of the levels' cutscenes.",
		NULL,
		2,
		{ _hs_type_object },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_1_parameter const objects_predict_definition=
{
	{
		_hs_type_void,
		0,
		"objects_predict",
		hs_macro_function_parse,
		hs_objects_predict_evaluate,
		"loads textures necessary to draw a objects that are about to come on-screen.",
		NULL,
		1,
		{ _hs_type_object_list },
	},
};

static struct hs_function_definition_with_1_parameter const object_type_predict_definition=
{
	{
		_hs_type_void,
		0,
		"object_type_predict",
		hs_macro_function_parse,
		object_definition_predict_evaluate,
		"loads textures necessary to draw an object that's about to come on-screen.",
		NULL,
		1,
		{ _hs_type_object_definition },
	},
};

static struct hs_function_definition_with_1_parameter const object_pvs_set_object_definition=
{
	{
		_hs_type_void,
		0,
		"object_pvs_set_object",
		hs_macro_function_parse,
		object_pvs_set_object_evaluate,
		"sets the specified object as the special place that activates everything it sees.",
		NULL,
		1,
		{ _hs_type_object },
	},
};

static struct hs_function_definition_with_1_parameter const object_pvs_set_camera_definition=
{
	{
		_hs_type_void,
		0,
		"object_pvs_set_camera",
		hs_macro_function_parse,
		object_pvs_set_camera_point_evaluate,
		"sets the specified cutscene camera point as the special place that activates everything it sees.",
		NULL,
		1,
		{ _hs_type_cutscene_camera_point },
	},
};

static struct hs_function_definition const object_pvs_clear_definition=
{
	_hs_type_void,
	0,
	"object_pvs_clear",
	hs_macro_function_parse,
	object_pvs_clear_evaluate,
	"removes the special place that activates everything it sees.",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const object_pvs_activate_definition=
{
	{
		_hs_type_void,
		0,
		"object_pvs_activate",
		hs_macro_function_parse,
		object_pvs_activate_evaluate,
		"just another (old) name for object_pvs_set_object.",
		NULL,
		1,
		{ _hs_type_object },
	},
};

static struct hs_function_definition_with_1_parameter const render_lights_definition=
{
	{
		_hs_type_boolean,
		0,
		"render_lights",
		hs_macro_function_parse,
		lights_enable_evaluate,
		"enables/disables dynamic lights",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const scenery_get_animation_time_definition=
{
	{
		_hs_type_short_integer,
		0,
		"scenery_get_animation_time",
		hs_macro_function_parse,
		scenery_get_animation_time_evaluate,
		"returns the number of ticks remaining in a custom animation (or zero, if the animation is over).",
		NULL,
		1,
		{ _hs_type_scenery },
	},
};

static struct hs_function_definition_with_3_parameters const scenery_animation_start_definition=
{
	{
		_hs_type_void,
		0,
		"scenery_animation_start",
		hs_macro_function_parse,
		scenery_animation_start_evaluate,
		"starts a custom animation playing on a piece of scenery",
		NULL,
		3,
		{ _hs_type_scenery },
	},
	{ _hs_type_animation_graph, _hs_type_string },
};

static struct hs_function_definition_with_4_parameters const scenery_animation_start_at_frame_definition=
{
	{
		_hs_type_void,
		0,
		"scenery_animation_start_at_frame",
		hs_macro_function_parse,
		scenery_animation_start_at_frame_evaluate,
		"starts a custom animation playing on a piece of scenery at a specific frame",
		NULL,
		4,
		{ _hs_type_scenery },
	},
	{ _hs_type_animation_graph, _hs_type_string, _hs_type_short_integer },
};

static struct hs_function_definition_with_1_parameter const render_effects_definition=
{
	{
		_hs_type_void,
		0,
		"render_effects",
		hs_macro_function_parse,
		render_effects_evaluate,
		"",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_2_parameters const unit_can_blink_definition=
{
	{
		_hs_type_void,
		0,
		"unit_can_blink",
		hs_macro_function_parse,
		unit_scripting_can_blink_evaluate,
		"allows a unit to blink or not (units never blink when they are dead)",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_1_parameter const unit_open_definition=
{
	{
		_hs_type_void,
		0,
		"unit_open",
		hs_macro_function_parse,
		unit_open_evaluate,
		"opens the hatches on the given unit",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_1_parameter const unit_close_definition=
{
	{
		_hs_type_void,
		0,
		"unit_close",
		hs_macro_function_parse,
		unit_close_evaluate,
		"closes the hatches on a given unit",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_1_parameter const unit_kill_definition=
{
	{
		_hs_type_void,
		0,
		"unit_kill",
		hs_macro_function_parse,
		unit_kill_evaluate,
		"kills a given unit, no saving throw",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_1_parameter const unit_kill_silent_definition=
{
	{
		_hs_type_void,
		0,
		"unit_kill_silent",
		hs_macro_function_parse,
		unit_kill_silent_evaluate,
		"kills a given unit silently (doesn't make them play their normal death animation or sound)",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_1_parameter const unit_get_custom_animation_time_definition=
{
	{
		_hs_type_short_integer,
		0,
		"unit_get_custom_animation_time",
		hs_macro_function_parse,
		unit_get_custom_animation_time_evaluate,
		"returns the number of ticks remaining in a unit's custom animation (or zero, if the animation is over).",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_1_parameter const unit_stop_custom_animation_definition=
{
	{
		_hs_type_void,
		0,
		"unit_stop_custom_animation",
		hs_macro_function_parse,
		unit_stop_custom_animation_evaluate,
		"stops the custom animation running on the given unit.",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_4_parameters const custom_animation_definition=
{
	{
		_hs_type_boolean,
		0,
		"custom_animation",
		hs_macro_function_parse,
		unit_start_user_animation_evaluate,
		"starts a custom animation playing on a unit (interpolates into animation if last parameter is TRUE)",
		NULL,
		4,
		{ _hs_type_unit },
	},
	{ _hs_type_animation_graph, _hs_type_string, _hs_type_boolean },
};

static struct hs_function_definition_with_4_parameters const custom_animation_list_definition=
{
	{
		_hs_type_boolean,
		0,
		"custom_animation_list",
		hs_macro_function_parse,
		unit_scripting_start_user_animation_list_evaluate,
		"starts a custom animation playing on a unit list (interpolates into animation if last parameter is TRUE)",
		NULL,
		4,
		{ _hs_type_object_list },
	},
	{ _hs_type_animation_graph, _hs_type_string, _hs_type_boolean },
};

static struct hs_function_definition_with_5_parameters const unit_custom_animation_at_frame_definition=
{
	{
		_hs_type_boolean,
		0,
		"unit_custom_animation_at_frame",
		hs_macro_function_parse,
		unit_custom_animation_at_frame_evaluate,
		"starts a custom animation playing on a unit at a specific frame index(interpolates into animation if next to last parameter is TRUE)",
		NULL,
		5,
		{ _hs_type_unit },
	},
	{ _hs_type_animation_graph, _hs_type_string, _hs_type_boolean, _hs_type_short_integer },
};

static struct hs_function_definition_with_1_parameter const unit_is_playing_custom_animation_definition=
{
	{
		_hs_type_boolean,
		0,
		"unit_is_playing_custom_animation",
		hs_macro_function_parse,
		unit_is_playing_custom_animation_evaluate,
		"returns TRUE if the given unit is still playing a custom animation",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_2_parameters const unit_aim_without_turning_definition=
{
	{
		_hs_type_void,
		0,
		"unit_aim_without_turning",
		hs_macro_function_parse,
		unit_aim_without_turning_evaluate,
		"allows a unit to aim in place without turning",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const unit_set_emotion_definition=
{
	{
		_hs_type_void,
		0,
		"unit_set_emotion",
		hs_macro_function_parse,
		unit_set_emotion_evaluate,
		"sets a unit's facial expression (-1 is none, other values depend on unit)",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_short_integer },
};

static struct hs_function_definition_with_2_parameters const unit_set_enterable_by_player_definition=
{
	{
		_hs_type_void,
		0,
		"unit_set_enterable_by_player",
		hs_macro_function_parse,
		unit_set_enterable_by_player_evaluate,
		"can be used to prevent the player from entering a vehicle",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_3_parameters const unit_enter_vehicle_definition=
{
	{
		_hs_type_void,
		0,
		"unit_enter_vehicle",
		hs_macro_function_parse,
		unit_scripting_enter_vehicle_evaluate,
		"puts the specified unit in the specified vehicle (in the named seat)",
		NULL,
		3,
		{ _hs_type_unit },
	},
	{ _hs_type_vehicle, _hs_type_string },
};

static struct hs_function_definition_with_3_parameters const vehicle_test_seat_list_definition=
{
	{
		_hs_type_boolean,
		0,
		"vehicle_test_seat_list",
		hs_macro_function_parse,
		unit_scripting_vehicle_test_seat_list_evaluate,
		"tests whether the named seat has an object in the object list",
		NULL,
		3,
		{ _hs_type_vehicle },
	},
	{ _hs_type_string, _hs_type_object_list },
};

static struct hs_function_definition_with_3_parameters const vehicle_test_seat_definition=
{
	{
		_hs_type_boolean,
		0,
		"vehicle_test_seat",
		hs_macro_function_parse,
		unit_scripting_vehicle_test_seat_evaluate,
		"tests whether the named seat has a specified unit in it",
		NULL,
		3,
		{ _hs_type_vehicle },
	},
	{ _hs_type_string, _hs_type_unit },
};

static struct hs_function_definition_with_2_parameters const unit_set_emotion_animation_definition=
{
	{
		_hs_type_void,
		0,
		"unit_set_emotion_animation",
		hs_macro_function_parse,
		unit_scripting_set_emotion_animation_evaluate,
		"sets the emotion animation to be used for the given unit",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_string },
};

static struct hs_function_definition_with_1_parameter const unit_exit_vehicle_definition=
{
	{
		_hs_type_void,
		0,
		"unit_exit_vehicle",
		hs_macro_function_parse,
		unit_scripting_exit_vehicle_evaluate,
		"makes a unit exit its vehicle",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_3_parameters const unit_set_maximum_vitality_definition=
{
	{
		_hs_type_void,
		0,
		"unit_set_maximum_vitality",
		hs_macro_function_parse,
		unit_scripting_set_maximum_vitality_evaluate,
		"sets a unit's maximum body and shield vitality",
		NULL,
		3,
		{ _hs_type_unit },
	},
	{ _hs_type_real, _hs_type_real },
};

static struct hs_function_definition_with_3_parameters const units_set_maximum_vitality_definition=
{
	{
		_hs_type_void,
		0,
		"units_set_maximum_vitality",
		hs_macro_function_parse,
		units_scripting_set_maximum_vitality_evaluate,
		"sets a group of units' maximum body and shield vitality",
		NULL,
		3,
		{ _hs_type_object_list },
	},
	{ _hs_type_real, _hs_type_real },
};

static struct hs_function_definition_with_3_parameters const unit_set_current_vitality_definition=
{
	{
		_hs_type_void,
		0,
		"unit_set_current_vitality",
		hs_macro_function_parse,
		unit_scripting_set_current_vitality_evaluate,
		"sets a unit's current body and shield vitality",
		NULL,
		3,
		{ _hs_type_unit },
	},
	{ _hs_type_real, _hs_type_real },
};

static struct hs_function_definition_with_3_parameters const units_set_current_vitality_definition=
{
	{
		_hs_type_void,
		0,
		"units_set_current_vitality",
		hs_macro_function_parse,
		units_scripting_set_current_vitality_evaluate,
		"sets a group of units' current body and shield vitality",
		NULL,
		3,
		{ _hs_type_object_list },
	},
	{ _hs_type_real, _hs_type_real },
};

static struct hs_function_definition_with_3_parameters const vehicle_load_magic_definition=
{
	{
		_hs_type_short_integer,
		0,
		"vehicle_load_magic",
		hs_macro_function_parse,
		vehicle_scripting_load_magic_evaluate,
		"makes a list of units (named or by encounter) magically get into a vehicle, in the substring-specified seats (e.g. CD-passenger... empty string matches all seats)",
		NULL,
		3,
		{ _hs_type_unit },
	},
	{ _hs_type_string, _hs_type_object_list },
};

static struct hs_function_definition_with_2_parameters const vehicle_unload_definition=
{
	{
		_hs_type_short_integer,
		0,
		"vehicle_unload",
		hs_macro_function_parse,
		vehicle_scripting_unload_evaluate,
		"makes units get out of a vehicle from the substring-specified seats (e.g. CD-passenger... empty string matches all seats)",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_string },
};

static struct hs_function_definition_with_1_parameter const magic_seat_name_definition=
{
	{
		_hs_type_void,
		0,
		"magic_seat_name",
		hs_macro_function_parse,
		scripting_set_magic_base_seat_evaluate,
		"all units controlled by the player will assume the given seat name (valid values are 'asleep', 'alert', 'stand', 'crouch' and 'flee')",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_2_parameters const unit_set_seat_definition=
{
	{
		_hs_type_void,
		0,
		"unit_set_seat",
		hs_macro_function_parse,
		unit_scripting_set_seat_evaluate,
		"this unit will assume the named seat",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_string },
};

static struct hs_function_definition const magic_melee_attack_definition=
{
	_hs_type_void,
	0,
	"magic_melee_attack",
	hs_macro_function_parse,
	scripting_magic_melee_attack_evaluate,
	"causes player's unit to start a melee attack",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const vehicle_riders_definition=
{
	{
		_hs_type_object_list,
		0,
		"vehicle_riders",
		hs_macro_function_parse,
		unit_scripting_unit_riders_evaluate,
		"returns a list of all riders in a vehicle",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_1_parameter const vehicle_driver_definition=
{
	{
		_hs_type_unit,
		0,
		"vehicle_driver",
		hs_macro_function_parse,
		unit_scripting_unit_driver_evaluate,
		"returns the driver of a vehicle",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_1_parameter const vehicle_gunner_definition=
{
	{
		_hs_type_unit,
		0,
		"vehicle_gunner",
		hs_macro_function_parse,
		unit_scripting_unit_gunner_evaluate,
		"returns the gunner of a vehicle",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_1_parameter const unit_get_health_definition=
{
	{
		_hs_type_real,
		0,
		"unit_get_health",
		hs_macro_function_parse,
		unit_scripting_get_health_evaluate,
		"returns the health [0,1] of the unit, returns -1 if the unit does not exists",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_1_parameter const unit_get_shield_definition=
{
	{
		_hs_type_real,
		0,
		"unit_get_shield",
		hs_macro_function_parse,
		unit_scripting_get_shield_evaluate,
		"returns the shield [0,1] of the unit, returns -1 if the unit does not exists",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_1_parameter const unit_get_total_grenade_count_definition=
{
	{
		_hs_type_short_integer,
		0,
		"unit_get_total_grenade_count",
		hs_macro_function_parse,
		unit_scripting_get_grenade_count_evaluate,
		"returns the total number of grenades for the given unit, 0 if it does not exist",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_2_parameters const unit_has_weapon_definition=
{
	{
		_hs_type_boolean,
		0,
		"unit_has_weapon",
		hs_macro_function_parse,
		unit_scripting_has_weapon_evaluate,
		"returns TRUE if the <unit> has <object> as a weapon, FALSE otherwise",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_object_definition },
};

static struct hs_function_definition_with_2_parameters const unit_has_weapon_readied_definition=
{
	{
		_hs_type_boolean,
		0,
		"unit_has_weapon_readied",
		hs_macro_function_parse,
		unit_scripting_has_weapon_readied_evaluate,
		"returns TRUE if the <unit> has <object> as the primary weapon, FALSE otherwise",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_object_definition },
};

static struct hs_function_definition_with_1_parameter const unit_doesnt_drop_items_definition=
{
	{
		_hs_type_void,
		0,
		"unit_doesnt_drop_items",
		hs_macro_function_parse,
		unit_scripting_doesnt_drop_items_evaluate,
		"prevents any of the given units from dropping weapons or grenades when they die",
		NULL,
		1,
		{ _hs_type_object_list },
	},
};

static struct hs_function_definition_with_2_parameters const unit_impervious_definition=
{
	{
		_hs_type_void,
		0,
		"unit_impervious",
		hs_macro_function_parse,
		unit_scripting_impervious_evaluate,
		"prevents any of the given units from being knocked around or playing ping animations",
		NULL,
		2,
		{ _hs_type_object_list },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const unit_suspended_definition=
{
	{
		_hs_type_void,
		0,
		"unit_suspended",
		hs_macro_function_parse,
		unit_scripting_suspended_evaluate,
		"stops gravity from working on the given unit",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition const unit_solo_player_integrated_night_vision_is_active_definition=
{
	_hs_type_boolean,
	0,
	"unit_solo_player_integrated_night_vision_is_active",
	hs_macro_function_parse,
	unit_solo_player_integrated_night_vision_is_active_evaluate,
	"returns whether the night-vision mode could be activated via the flashlight button",
	NULL,
	0,
};

static struct hs_function_definition_with_2_parameters const units_set_desired_flashlight_state_definition=
{
	{
		_hs_type_void,
		0,
		"units_set_desired_flashlight_state",
		hs_macro_function_parse,
		units_set_desired_flashlight_state_evaluate,
		"sets the units' desired flashlight state",
		NULL,
		2,
		{ _hs_type_object_list },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const unit_set_desired_flashlight_state_definition=
{
	{
		_hs_type_void,
		0,
		"unit_set_desired_flashlight_state",
		hs_macro_function_parse,
		unit_set_desired_flashlight_state_evaluate,
		"sets the unit's desired flashlight state",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_1_parameter const unit_get_current_flashlight_state_definition=
{
	{
		_hs_type_boolean,
		0,
		"unit_get_current_flashlight_state",
		hs_macro_function_parse,
		unit_get_current_flashlight_state_evaluate,
		"gets the unit's current flashlight state",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_2_parameters const device_set_never_appears_locked_definition=
{
	{
		_hs_type_void,
		0,
		"device_set_never_appears_locked",
		hs_macro_function_parse,
		device_set_never_appears_locked_evaluate,
		"changes a machine's never_appears_locked flag, but only if paul is a bastard",
		NULL,
		2,
		{ _hs_type_device },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const device_set_power_definition=
{
	{
		_hs_type_void,
		0,
		"device_set_power",
		hs_macro_function_parse,
		device_set_power_evaluate,
		"immediately sets the power of a named device to the given value",
		NULL,
		2,
		{ _hs_type_device },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_1_parameter const device_get_power_definition=
{
	{
		_hs_type_real,
		0,
		"device_get_power",
		hs_macro_function_parse,
		device_get_power_evaluate,
		"gets the current power of a named device",
		NULL,
		1,
		{ _hs_type_device },
	},
};

static struct hs_function_definition_with_2_parameters const device_set_position_definition=
{
	{
		_hs_type_boolean,
		0,
		"device_set_position",
		hs_macro_function_parse,
		device_set_desired_position_evaluate,
		"set the desired position of the given device (used for devices without explicit device groups)",
		NULL,
		2,
		{ _hs_type_device },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_1_parameter const device_get_position_definition=
{
	{
		_hs_type_real,
		0,
		"device_get_position",
		hs_macro_function_parse,
		device_get_position_evaluate,
		"gets the current position of the given device (used for devices without explicit device groups)",
		NULL,
		1,
		{ _hs_type_device },
	},
};

static struct hs_function_definition_with_2_parameters const device_set_position_immediate_definition=
{
	{
		_hs_type_void,
		0,
		"device_set_position_immediate",
		hs_macro_function_parse,
		device_set_actual_position_evaluate,
		"instantaneously changes the position of the given device (used for devices without explicit device groups",
		NULL,
		2,
		{ _hs_type_device },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_1_parameter const device_group_get_definition=
{
	{
		_hs_type_real,
		0,
		"device_group_get",
		hs_macro_function_parse,
		device_group_get_value_evaluate,
		"returns the desired value of the specified device group.",
		NULL,
		1,
		{ _hs_type_device_group },
	},
};

static struct hs_function_definition_with_2_parameters const device_group_set_definition=
{
	{
		_hs_type_boolean,
		0,
		"device_group_set",
		hs_macro_function_parse,
		device_group_set_desired_value_evaluate,
		"changes the desired value of the specified device group.",
		NULL,
		2,
		{ _hs_type_device_group },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_2_parameters const device_group_set_immediate_definition=
{
	{
		_hs_type_void,
		0,
		"device_group_set_immediate",
		hs_macro_function_parse,
		device_group_set_actual_value_evaluate,
		"instantaneously changes the value of the specified device group.",
		NULL,
		2,
		{ _hs_type_device_group },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_2_parameters const device_one_sided_set_definition=
{
	{
		_hs_type_void,
		0,
		"device_one_sided_set",
		hs_macro_function_parse,
		device_one_sided_set_evaluate,
		"TRUE makes the given device one-sided (only able to be opened from one direction), FALSE makes it two-sided",
		NULL,
		2,
		{ _hs_type_device },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const device_operates_automatically_set_definition=
{
	{
		_hs_type_void,
		0,
		"device_operates_automatically_set",
		hs_macro_function_parse,
		device_operates_automatically_set_evaluate,
		"TRUE makes the given device open automatically when any biped is nearby, FALSE makes it not",
		NULL,
		2,
		{ _hs_type_device },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const device_group_change_only_once_more_set_definition=
{
	{
		_hs_type_void,
		0,
		"device_group_change_only_once_more_set",
		hs_macro_function_parse,
		device_group_change_only_once_more_set_evaluate,
		"TRUE allows a device to change states only once",
		NULL,
		2,
		{ _hs_type_device_group },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition const breakable_surfaces_reset_definition=
{
	_hs_type_void,
	0,
	"breakable_surfaces_reset",
	hs_macro_function_parse,
	breakable_surfaces_reset_evaluate,
	"restores all breakable surfaces",
	NULL,
	0,
};

static struct hs_function_definition const cheat_all_powerups_definition=
{
	_hs_type_void,
	0,
	"cheat_all_powerups",
	hs_macro_function_parse,
	cheat_all_powerups_evaluate,
	"drops all powerups near player",
	NULL,
	0,
};

static struct hs_function_definition const cheat_all_weapons_definition=
{
	_hs_type_void,
	0,
	"cheat_all_weapons",
	hs_macro_function_parse,
	cheat_all_weapons_evaluate,
	"drops all weapons near player",
	NULL,
	0,
};

static struct hs_function_definition const cheat_all_vehicles_definition=
{
	_hs_type_void,
	0,
	"cheat_all_vehicles",
	hs_macro_function_parse,
	cheat_all_vehicles_evaluate,
	"drops all vehicles on player",
	NULL,
	0,
};

static struct hs_function_definition const cheat_teleport_to_camera_definition=
{
	_hs_type_void,
	0,
	"cheat_teleport_to_camera",
	hs_macro_function_parse,
	cheat_teleport_to_camera_evaluate,
	"teleports player to camera location",
	NULL,
	0,
};

static struct hs_function_definition const cheat_active_camouflage_definition=
{
	_hs_type_void,
	0,
	"cheat_active_camouflage",
	hs_macro_function_parse,
	cheat_active_camouflage_evaluate,
	"gives the player active camouflage",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const cheat_active_camouflage_local_player_definition=
{
	{
		_hs_type_void,
		0,
		"cheat_active_camouflage_local_player",
		hs_macro_function_parse,
		cheat_active_camouflage_local_player_evaluate,
		"gives the player active camouflage",
		NULL,
		1,
		{ _hs_type_short_integer },
	},
};

static struct hs_function_definition const cheats_load_definition=
{
	_hs_type_void,
	0,
	"cheats_load",
	hs_macro_function_parse,
	cheats_load_evaluate,
	"reloads the cheats.txt file",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const ai_definition=
{
	{
		_hs_type_void,
		0,
		"ai",
		hs_macro_function_parse,
		ai_globals_ai_active_evaluate,
		"turns all AI on or off.",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const ai_dialogue_triggers_definition=
{
	{
		_hs_type_void,
		0,
		"ai_dialogue_triggers",
		hs_macro_function_parse,
		ai_globals_dialogue_triggers_enabled_evaluate,
		"turns impromptu dialogue on or off.",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const ai_grenades_definition=
{
	{
		_hs_type_void,
		0,
		"ai_grenades",
		hs_macro_function_parse,
		ai_globals_grenades_enabled_evaluate,
		"turns grenade inventory on or off.",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const ai_free_definition=
{
	{
		_hs_type_void,
		0,
		"ai_free",
		hs_macro_function_parse,
		ai_scripting_free_evaluate,
		"removes a group of actors from their encounter and sets them free",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_free_units_definition=
{
	{
		_hs_type_void,
		0,
		"ai_free_units",
		hs_macro_function_parse,
		ai_scripting_free_units_evaluate,
		"removes a set of units from their encounter (if any) and sets them free",
		NULL,
		1,
		{ _hs_type_object_list },
	},
};

static struct hs_function_definition_with_2_parameters const ai_attach_definition=
{
	{
		_hs_type_void,
		0,
		"ai_attach",
		hs_macro_function_parse,
		ai_scripting_attach_unit_evaluate,
		"attaches the specified unit to the specified encounter.",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_ai },
};

static struct hs_function_definition_with_2_parameters const ai_attach_units_definition=
{
	{
		_hs_type_void,
		0,
		"ai_attach_units",
		hs_macro_function_parse,
		ai_scripting_attach_units_evaluate,
		"attaches the specified list of units to the specified encounter.",
		NULL,
		2,
		{ _hs_type_object_list },
	},
	{ _hs_type_ai },
};

static struct hs_function_definition_with_2_parameters const ai_attach_free_definition=
{
	{
		_hs_type_void,
		0,
		"ai_attach_free",
		hs_macro_function_parse,
		ai_scripting_attach_free_evaluate,
		"attaches a unit to a newly created free actor of the specified type",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_actor_variant },
};

static struct hs_function_definition_with_1_parameter const ai_detach_definition=
{
	{
		_hs_type_void,
		0,
		"ai_detach",
		hs_macro_function_parse,
		ai_scripting_detach_unit_evaluate,
		"detaches the specified unit from all AI.",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_1_parameter const ai_detach_units_definition=
{
	{
		_hs_type_void,
		0,
		"ai_detach_units",
		hs_macro_function_parse,
		ai_scripting_detach_units_evaluate,
		"detaches the specified list of units from all AI.",
		NULL,
		1,
		{ _hs_type_object_list },
	},
};

static struct hs_function_definition_with_1_parameter const ai_place_definition=
{
	{
		_hs_type_void,
		0,
		"ai_place",
		hs_macro_function_parse,
		ai_scripting_place_evaluate,
		"places the specified encounter on the map.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_kill_definition=
{
	{
		_hs_type_void,
		0,
		"ai_kill",
		hs_macro_function_parse,
		ai_scripting_kill_evaluate,
		"instantly kills the specified encounter and/or squad.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_kill_silent_definition=
{
	{
		_hs_type_void,
		0,
		"ai_kill_silent",
		hs_macro_function_parse,
		ai_scripting_kill_silent_evaluate,
		"instantly and silently (no animation or sound played) kills the specified encounter and/or squad.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_erase_definition=
{
	{
		_hs_type_void,
		0,
		"ai_erase",
		hs_macro_function_parse,
		ai_scripting_erase_evaluate,
		"erases the specified encounter and/or squad.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition const ai_erase_all_definition=
{
	_hs_type_void,
	0,
	"ai_erase_all",
	hs_macro_function_parse,
	ai_scripting_erase_all_evaluate,
	"erases all AI.",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const ai_select_definition=
{
	{
		_hs_type_void,
		0,
		"ai_select",
		hs_macro_function_parse,
		ai_scripting_select_evaluate,
		"selects the specified encounter.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition const ai_deselect_definition=
{
	_hs_type_void,
	0,
	"ai_deselect",
	hs_macro_function_parse,
	ai_scripting_deselect_evaluate,
	"clears the selected encounter.",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const ai_spawn_actor_definition=
{
	{
		_hs_type_void,
		0,
		"ai_spawn_actor",
		hs_macro_function_parse,
		ai_scripting_spawn_actor_evaluate,
		"spawns a single actor in the specified encounter and/or squad.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_2_parameters const ai_set_respawn_definition=
{
	{
		_hs_type_void,
		0,
		"ai_set_respawn",
		hs_macro_function_parse,
		ai_scripting_set_respawn_evaluate,
		"enables or disables respawning in the specified encounter.",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const ai_set_deaf_definition=
{
	{
		_hs_type_void,
		0,
		"ai_set_deaf",
		hs_macro_function_parse,
		ai_scripting_set_deaf_evaluate,
		"enables or disables hearing for actors in the specified encounter.",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const ai_set_blind_definition=
{
	{
		_hs_type_void,
		0,
		"ai_set_blind",
		hs_macro_function_parse,
		ai_scripting_set_blind_evaluate,
		"enables or disables sight for actors in the specified encounter.",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const ai_magically_see_encounter_definition=
{
	{
		_hs_type_void,
		0,
		"ai_magically_see_encounter",
		hs_macro_function_parse,
		ai_scripting_magically_see_encounter_evaluate,
		"makes one encounter magically aware of another.",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_ai },
};

static struct hs_function_definition_with_1_parameter const ai_magically_see_players_definition=
{
	{
		_hs_type_void,
		0,
		"ai_magically_see_players",
		hs_macro_function_parse,
		ai_scripting_magically_see_players_evaluate,
		"makes an encounter magically aware of nearby players.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_2_parameters const ai_magically_see_unit_definition=
{
	{
		_hs_type_void,
		0,
		"ai_magically_see_unit",
		hs_macro_function_parse,
		ai_scripting_magically_see_unit_evaluate,
		"makes an encounter magically aware of the specified unit.",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_unit },
};

static struct hs_function_definition_with_2_parameters const ai_magically_see_units_definition=
{
	{
		_hs_type_void,
		0,
		"ai_magically_see_units",
		hs_macro_function_parse,
		ai_scripting_magically_see_units_evaluate,
		"makes an encounter magically aware of the specified set of units.",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_object_list },
};

static struct hs_function_definition_with_1_parameter const ai_timer_start_definition=
{
	{
		_hs_type_void,
		0,
		"ai_timer_start",
		hs_macro_function_parse,
		ai_scripting_timer_start_evaluate,
		"makes a squad's delay timer start counting.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_timer_expire_definition=
{
	{
		_hs_type_void,
		0,
		"ai_timer_expire",
		hs_macro_function_parse,
		ai_scripting_timer_expire_evaluate,
		"makes a squad's delay timer expire and releases them to enter combat.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_attack_definition=
{
	{
		_hs_type_void,
		0,
		"ai_attack",
		hs_macro_function_parse,
		ai_scripting_attack_evaluate,
		"makes the specified platoon(s) go into the attacking state.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_defend_definition=
{
	{
		_hs_type_void,
		0,
		"ai_defend",
		hs_macro_function_parse,
		ai_scripting_defend_evaluate,
		"makes the specified platoon(s) go into the defending state.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_retreat_definition=
{
	{
		_hs_type_void,
		0,
		"ai_retreat",
		hs_macro_function_parse,
		ai_scripting_retreat_evaluate,
		"makes all squads in the specified platoon(s) maneuver to their designated maneuver squads.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_maneuver_definition=
{
	{
		_hs_type_void,
		0,
		"ai_maneuver",
		hs_macro_function_parse,
		ai_scripting_maneuver_evaluate,
		"makes all squads in the specified platoon(s) maneuver to their designated maneuver squads.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_2_parameters const ai_maneuver_enable_definition=
{
	{
		_hs_type_void,
		0,
		"ai_maneuver_enable",
		hs_macro_function_parse,
		ai_scripting_maneuver_enable_evaluate,
		"enables or disables the maneuver/retreat rule for an encounter or platoon. the rule will still trigger, but none of the actors will be given the order to change squads.",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const ai_migrate_definition=
{
	{
		_hs_type_void,
		0,
		"ai_migrate",
		hs_macro_function_parse,
		ai_scripting_migrate_evaluate,
		"makes all or part of an encounter move to another encounter.",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_ai },
};

static struct hs_function_definition_with_3_parameters const ai_migrate_and_speak_definition=
{
	{
		_hs_type_void,
		0,
		"ai_migrate_and_speak",
		hs_macro_function_parse,
		ai_scripting_migrate_and_speak_evaluate,
		"makes all or part of an encounter move to another encounter, and say their 'advance' or 'retreat' speech lines.",
		NULL,
		3,
		{ _hs_type_ai },
	},
	{ _hs_type_ai, _hs_type_string },
};

static struct hs_function_definition_with_2_parameters const ai_migrate_by_unit_definition=
{
	{
		_hs_type_void,
		0,
		"ai_migrate_by_unit",
		hs_macro_function_parse,
		ai_scripting_migrate_by_unit_evaluate,
		"makes a named vehicle or group of units move to another encounter.",
		NULL,
		2,
		{ _hs_type_object_list },
	},
	{ _hs_type_ai },
};

static struct hs_function_definition_with_2_parameters const ai_allegiance_definition=
{
	{
		_hs_type_void,
		0,
		"ai_allegiance",
		hs_macro_function_parse,
		ai_scripting_allegiance_evaluate,
		"creates an allegiance between two teams.",
		NULL,
		2,
		{ _hs_type_enum_team },
	},
	{ _hs_type_enum_team },
};

static struct hs_function_definition_with_2_parameters const ai_allegiance_remove_definition=
{
	{
		_hs_type_void,
		0,
		"ai_allegiance_remove",
		hs_macro_function_parse,
		ai_scripting_allegiance_remove_evaluate,
		"destroys an allegiance between two teams.",
		NULL,
		2,
		{ _hs_type_enum_team },
	},
	{ _hs_type_enum_team },
};

static struct hs_function_definition_with_3_parameters const ai_go_to_vehicle_definition=
{
	{
		_hs_type_void,
		0,
		"ai_go_to_vehicle",
		hs_macro_function_parse,
		ai_scripting_go_to_vehicle_evaluate,
		"tells a group of actors to get into a vehicle, in the substring-specified seats (e.g. passenger for pelican)... does not interrupt any actors who are already going to vehicles",
		NULL,
		3,
		{ _hs_type_ai },
	},
	{ _hs_type_unit, _hs_type_string },
};

static struct hs_function_definition_with_3_parameters const ai_go_to_vehicle_override_definition=
{
	{
		_hs_type_void,
		0,
		"ai_go_to_vehicle_override",
		hs_macro_function_parse,
		ai_scripting_go_to_vehicle_override_evaluate,
		"tells a group of actors to get into a vehicle, in the substring-specified seats (e.g. passenger for pelican)... NB: any actors who are already going to vehicles will stop and go to this one instead!",
		NULL,
		3,
		{ _hs_type_ai },
	},
	{ _hs_type_unit, _hs_type_string },
};

static struct hs_function_definition_with_1_parameter const ai_exit_vehicle_definition=
{
	{
		_hs_type_void,
		0,
		"ai_exit_vehicle",
		hs_macro_function_parse,
		ai_scripting_exit_vehicle_evaluate,
		"tells a group of actors to get out of any vehicles that they are in",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_2_parameters const ai_braindead_definition=
{
	{
		_hs_type_void,
		0,
		"ai_braindead",
		hs_macro_function_parse,
		ai_scripting_braindead_evaluate,
		"makes a group of actors braindead, or restores them to life (in their initial state)",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const ai_braindead_by_unit_definition=
{
	{
		_hs_type_void,
		0,
		"ai_braindead_by_unit",
		hs_macro_function_parse,
		ai_scripting_braindead_by_unit_evaluate,
		"makes a list of objects braindead, or restores them to life. if you pass in a vehicle index, it makes all actors in that vehicle braindead (including any built-in guns)",
		NULL,
		2,
		{ _hs_type_object_list },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const ai_disregard_definition=
{
	{
		_hs_type_void,
		0,
		"ai_disregard",
		hs_macro_function_parse,
		ai_scripting_ignore_evaluate,
		"if TRUE, forces all actors to completely disregard the specified units, otherwise lets them acknowledge the units again",
		NULL,
		2,
		{ _hs_type_object_list },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const ai_prefer_target_definition=
{
	{
		_hs_type_void,
		0,
		"ai_prefer_target",
		hs_macro_function_parse,
		ai_scripting_prefer_target_evaluate,
		"if TRUE, *ALL* enemies will prefer to attack the specified units. if FALSE, removes the preference.",
		NULL,
		2,
		{ _hs_type_object_list },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_1_parameter const ai_teleport_to_starting_location_definition=
{
	{
		_hs_type_void,
		0,
		"ai_teleport_to_starting_location",
		hs_macro_function_parse,
		ai_scripting_teleport_starting_location_evaluate,
		"teleports a group of actors to the starting locations of their current squad(s)",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_teleport_to_starting_location_if_unsupported_definition=
{
	{
		_hs_type_void,
		0,
		"ai_teleport_to_starting_location_if_unsupported",
		hs_macro_function_parse,
		ai_scripting_teleport_starting_location_if_unsupported_evaluate,
		"teleports a group of actors to the starting locations of their current squad(s), only if they are not supported by solid ground (i.e. if they are falling after switching BSPs)",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_renew_definition=
{
	{
		_hs_type_void,
		0,
		"ai_renew",
		hs_macro_function_parse,
		ai_scripting_renew_evaluate,
		"refreshes the health and grenade count of a group of actors, so they are as good as new",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_try_to_fight_nothing_definition=
{
	{
		_hs_type_void,
		0,
		"ai_try_to_fight_nothing",
		hs_macro_function_parse,
		ai_scripting_try_to_fight_nothing_evaluate,
		"removes the preferential target setting from a group of actors",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_2_parameters const ai_try_to_fight_definition=
{
	{
		_hs_type_void,
		0,
		"ai_try_to_fight",
		hs_macro_function_parse,
		ai_scripting_try_to_fight_evaluate,
		"causes a group of actors to preferentially target another group of actors",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_ai },
};

static struct hs_function_definition_with_1_parameter const ai_try_to_fight_player_definition=
{
	{
		_hs_type_void,
		0,
		"ai_try_to_fight_player",
		hs_macro_function_parse,
		ai_scripting_try_to_fight_player_evaluate,
		"causes a group of actors to preferentially target the player",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_2_parameters const ai_command_list_definition=
{
	{
		_hs_type_void,
		0,
		"ai_command_list",
		hs_macro_function_parse,
		ai_scripting_command_list_evaluate,
		"tells a group of actors to begin executing the specified command list",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_ai_command_list },
};

static struct hs_function_definition_with_2_parameters const ai_command_list_by_unit_definition=
{
	{
		_hs_type_void,
		0,
		"ai_command_list_by_unit",
		hs_macro_function_parse,
		ai_scripting_command_list_by_unit_evaluate,
		"tells a named unit to begin executing the specified command list",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_ai_command_list },
};

static struct hs_function_definition_with_1_parameter const ai_command_list_advance_definition=
{
	{
		_hs_type_void,
		0,
		"ai_command_list_advance",
		hs_macro_function_parse,
		ai_scripting_command_list_advance_evaluate,
		"tells a group of actors that are running a command list that they may advance further along the list (if they are waiting for a stimulus)",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_command_list_advance_by_unit_definition=
{
	{
		_hs_type_void,
		0,
		"ai_command_list_advance_by_unit",
		hs_macro_function_parse,
		ai_scripting_command_list_advance_by_unit_evaluate,
		"just like ai_command_list_advance but operates upon a unit instead",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_2_parameters const ai_force_active_definition=
{
	{
		_hs_type_void,
		0,
		"ai_force_active",
		hs_macro_function_parse,
		ai_scripting_force_active_evaluate,
		"forces an encounter to remain active (i.e. not freeze in place) even if there are no players nearby",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const ai_force_active_by_unit_definition=
{
	{
		_hs_type_void,
		0,
		"ai_force_active_by_unit",
		hs_macro_function_parse,
		ai_scripting_force_active_by_unit_evaluate,
		"forces a named actor that is NOT in an encounter to remain active (i.e. not freeze in place) even if there are no players nearby",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const ai_set_return_state_definition=
{
	{
		_hs_type_void,
		0,
		"ai_set_return_state",
		hs_macro_function_parse,
		ai_scripting_set_return_state_evaluate,
		"sets the state that a group of actors will return to when they have nothing to do",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_enum_ai_default_state },
};

static struct hs_function_definition_with_2_parameters const ai_set_current_state_definition=
{
	{
		_hs_type_void,
		0,
		"ai_set_current_state",
		hs_macro_function_parse,
		ai_scripting_set_current_state_evaluate,
		"sets the current state of a group of actors. WARNING: may have unpredictable results on actors that are in combat",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_enum_ai_default_state },
};

static struct hs_function_definition_with_2_parameters const ai_playfight_definition=
{
	{
		_hs_type_void,
		0,
		"ai_playfight",
		hs_macro_function_parse,
		ai_scripting_playfight_evaluate,
		"sets an encounter to be playfighting or not",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition const ai_reconnect_definition=
{
	_hs_type_void,
	0,
	"ai_reconnect",
	hs_macro_function_parse,
	ai_scripting_reconnect_evaluate,
	"reconnects all AI information to the current structure bsp (use this after you create encounters or command lists in sapien, or place new firing points or command list points)",
	NULL,
	0,
};

static struct hs_function_definition_with_2_parameters const ai_vehicle_encounter_definition=
{
	{
		_hs_type_void,
		0,
		"ai_vehicle_encounter",
		hs_macro_function_parse,
		ai_scripting_vehicle_encounter_evaluate,
		"sets a vehicle to 'belong' to a particular encounter/squad. any actors who get into the vehicle will be placed in this squad. NB: vehicles potentially drivable by multiple teams need their own encounter!",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_ai },
};

static struct hs_function_definition_with_2_parameters const ai_vehicle_enterable_distance_definition=
{
	{
		_hs_type_void,
		0,
		"ai_vehicle_enterable_distance",
		hs_macro_function_parse,
		ai_scripting_vehicle_enterable_distance_evaluate,
		"sets a vehicle as being impulsively enterable for actors within a certain distance",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_2_parameters const ai_vehicle_enterable_team_definition=
{
	{
		_hs_type_void,
		0,
		"ai_vehicle_enterable_team",
		hs_macro_function_parse,
		ai_scripting_vehicle_enterable_team_evaluate,
		"sets a vehicle as being impulsively enterable for actors on a certain team",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_enum_team },
};

static struct hs_function_definition_with_2_parameters const ai_vehicle_enterable_actor_type_definition=
{
	{
		_hs_type_void,
		0,
		"ai_vehicle_enterable_actor_type",
		hs_macro_function_parse,
		ai_scripting_vehicle_enterable_actor_type_evaluate,
		"sets a vehicle as being impulsively enterable for actors of a certain type (grunt, elite, marine etc)",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_enum_actor_type },
};

static struct hs_function_definition_with_2_parameters const ai_vehicle_enterable_actors_definition=
{
	{
		_hs_type_void,
		0,
		"ai_vehicle_enterable_actors",
		hs_macro_function_parse,
		ai_scripting_vehicle_enterable_actors_evaluate,
		"sets a vehicle as being impulsively enterable for a certain encounter/squad of actors",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_ai },
};

static struct hs_function_definition_with_1_parameter const ai_vehicle_enterable_disable_definition=
{
	{
		_hs_type_void,
		0,
		"ai_vehicle_enterable_disable",
		hs_macro_function_parse,
		ai_scripting_vehicle_enterable_disable_evaluate,
		"disables actors from impulsively getting into a vehicle (this is the default state for newly placed vehicles)",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_2_parameters const ai_look_at_object_definition=
{
	{
		_hs_type_void,
		0,
		"ai_look_at_object",
		hs_macro_function_parse,
		ai_scripting_look_at_object_evaluate,
		"tells an actor to look at an object until further notice",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_object },
};

static struct hs_function_definition_with_1_parameter const ai_stop_looking_definition=
{
	{
		_hs_type_void,
		0,
		"ai_stop_looking",
		hs_macro_function_parse,
		ai_scripting_stop_looking_evaluate,
		"tells an actor to stop looking at whatever it's looking at",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_2_parameters const ai_automatic_migration_target_definition=
{
	{
		_hs_type_void,
		0,
		"ai_automatic_migration_target",
		hs_macro_function_parse,
		ai_scripting_automatic_migration_target_evaluate,
		"enables or disables a squad as being an automatic migration target",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_1_parameter const ai_follow_target_disable_definition=
{
	{
		_hs_type_void,
		0,
		"ai_follow_target_disable",
		hs_macro_function_parse,
		ai_scripting_follow_target_disable_evaluate,
		"turns off following for an encounter",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_follow_target_players_definition=
{
	{
		_hs_type_void,
		0,
		"ai_follow_target_players",
		hs_macro_function_parse,
		ai_scripting_follow_target_players_evaluate,
		"sets the follow target for an encounter to be the closest player",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_2_parameters const ai_follow_target_unit_definition=
{
	{
		_hs_type_void,
		0,
		"ai_follow_target_unit",
		hs_macro_function_parse,
		ai_scripting_follow_target_unit_evaluate,
		"sets the follow target for an encounter to be a specific unit",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_unit },
};

static struct hs_function_definition_with_2_parameters const ai_follow_target_ai_definition=
{
	{
		_hs_type_void,
		0,
		"ai_follow_target_ai",
		hs_macro_function_parse,
		ai_scripting_follow_target_ai_evaluate,
		"sets the follow target for an encounter to be a group of AI (encounter, squad or platoon)",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_ai },
};

static struct hs_function_definition_with_2_parameters const ai_follow_distance_definition=
{
	{
		_hs_type_void,
		0,
		"ai_follow_distance",
		hs_macro_function_parse,
		ai_scripting_follow_distance_evaluate,
		"sets the distance threshold which will cause squads to migrate when following someone",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_1_parameter const ai_conversation_stop_definition=
{
	{
		_hs_type_void,
		0,
		"ai_conversation_stop",
		hs_macro_function_parse,
		ai_scripting_conversation_stop_evaluate,
		"stops a conversation from playing or trying to play",
		NULL,
		1,
		{ _hs_type_conversation },
	},
};

static struct hs_function_definition_with_1_parameter const ai_conversation_advance_definition=
{
	{
		_hs_type_void,
		0,
		"ai_conversation_advance",
		hs_macro_function_parse,
		ai_scripting_conversation_advance_evaluate,
		"tells a conversation that it may advance",
		NULL,
		1,
		{ _hs_type_conversation },
	},
};

static struct hs_function_definition_with_2_parameters const ai_link_activation_definition=
{
	{
		_hs_type_void,
		0,
		"ai_link_activation",
		hs_macro_function_parse,
		ai_scripting_link_activation_evaluate,
		"links the first encounter so that it will be made active whenever it detects that the second encounter is active",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_ai },
};

static struct hs_function_definition_with_2_parameters const ai_berserk_definition=
{
	{
		_hs_type_void,
		0,
		"ai_berserk",
		hs_macro_function_parse,
		ai_scripting_berserk_evaluate,
		"forces a group of actors to start or stop berserking",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const ai_set_team_definition=
{
	{
		_hs_type_void,
		0,
		"ai_set_team",
		hs_macro_function_parse,
		ai_scripting_set_team_evaluate,
		"makes an encounter change to a new team",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_enum_team },
};

static struct hs_function_definition_with_2_parameters const ai_allow_charge_definition=
{
	{
		_hs_type_void,
		0,
		"ai_allow_charge",
		hs_macro_function_parse,
		ai_scripting_allow_charge_evaluate,
		"either enables or disables charging behavior for a group of actors",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const ai_allow_dormant_definition=
{
	{
		_hs_type_void,
		0,
		"ai_allow_dormant",
		hs_macro_function_parse,
		ai_scripting_allow_dormant_evaluate,
		"either enables or disables automatic dormancy for a group of actors",
		NULL,
		2,
		{ _hs_type_ai },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_1_parameter const ai_is_attacking_definition=
{
	{
		_hs_type_boolean,
		0,
		"ai_is_attacking",
		hs_macro_function_parse,
		ai_scripting_is_attacking_evaluate,
		"returns whether a platoon is in the attacking mode (or if an encounter is specified, returns whether any platoon in that encounter is attacking)",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_command_list_status_definition=
{
	{
		_hs_type_short_integer,
		0,
		"ai_command_list_status",
		hs_macro_function_parse,
		ai_scripting_command_list_status_evaluate,
		"gets the status of a number of units running command lists: 0 = none, 1 = finished command list, 2 = waiting for stimulus, 3 = running command list",
		NULL,
		1,
		{ _hs_type_object_list },
	},
};

static struct hs_function_definition_with_1_parameter const ai_going_to_vehicle_definition=
{
	{
		_hs_type_short_integer,
		0,
		"ai_going_to_vehicle",
		hs_macro_function_parse,
		ai_scripting_going_to_vehicle_evaluate,
		"return the number of actors that are still trying to get into the specified vehicle",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_1_parameter const ai_living_count_definition=
{
	{
		_hs_type_short_integer,
		0,
		"ai_living_count",
		hs_macro_function_parse,
		ai_scripting_living_count_evaluate,
		"return the number of living actors in the specified encounter and/or squad.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_living_fraction_definition=
{
	{
		_hs_type_real,
		0,
		"ai_living_fraction",
		hs_macro_function_parse,
		ai_scripting_living_fraction_evaluate,
		"return the fraction [0-1] of living actors in the specified encounter and/or squad.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_strength_definition=
{
	{
		_hs_type_real,
		0,
		"ai_strength",
		hs_macro_function_parse,
		ai_scripting_strength_evaluate,
		"return the current strength (average body vitality from 0-1) of the specified encounter and/or squad.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_swarm_count_definition=
{
	{
		_hs_type_short_integer,
		0,
		"ai_swarm_count",
		hs_macro_function_parse,
		ai_scripting_swarm_count_evaluate,
		"return the number of swarm actors in the specified encounter and/or squad.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_nonswarm_count_definition=
{
	{
		_hs_type_short_integer,
		0,
		"ai_nonswarm_count",
		hs_macro_function_parse,
		ai_scripting_nonswarm_count_evaluate,
		"return the number of non-swarm actors in the specified encounter and/or squad.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_actors_definition=
{
	{
		_hs_type_object_list,
		0,
		"ai_actors",
		hs_macro_function_parse,
		object_list_from_ai_reference_evaluate,
		"converts an ai reference to an object list.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_status_definition=
{
	{
		_hs_type_short_integer,
		0,
		"ai_status",
		hs_macro_function_parse,
		ai_scripting_status_evaluate,
		"returns the most severe combat status of a group of actors (0=inactive, 1=noncombat, 2=guarding, 3=search/suspicious, 4=definite enemy(heard or magic awareness), 5=visible enemy, 6=engaging in combat.",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_conversation_definition=
{
	{
		_hs_type_boolean,
		0,
		"ai_conversation",
		hs_macro_function_parse,
		ai_scripting_conversation_evaluate,
		"tries to add an entry to the list of conversations waiting to play. returns FALSE if the required units could not be found to play the conversation, or if the player is too far away and the 'delay' flag is not set.",
		NULL,
		1,
		{ _hs_type_conversation },
	},
};

static struct hs_function_definition_with_1_parameter const ai_conversation_line_definition=
{
	{
		_hs_type_short_integer,
		0,
		"ai_conversation_line",
		hs_macro_function_parse,
		ai_scripting_conversation_line_evaluate,
		"returns which line the conversation is currently playing, or 999 if the conversation is not currently playing",
		NULL,
		1,
		{ _hs_type_conversation },
	},
};

static struct hs_function_definition_with_1_parameter const ai_conversation_status_definition=
{
	{
		_hs_type_short_integer,
		0,
		"ai_conversation_status",
		hs_macro_function_parse,
		ai_scripting_conversation_status_evaluate,
		"returns the status of a conversation (0=none, 1=trying to begin, 2=waiting for guys to get in position, 3=playing, 4=waiting to advance, 5=could not begin, 6=finished successfully, 7=aborted midway",
		NULL,
		1,
		{ _hs_type_conversation },
	},
};

static struct hs_function_definition_with_2_parameters const ai_allegiance_broken_definition=
{
	{
		_hs_type_boolean,
		0,
		"ai_allegiance_broken",
		hs_macro_function_parse,
		ai_scripting_allegiance_broken_evaluate,
		"returns whether two teams have an allegiance that is currently broken by traitorous behavior",
		NULL,
		2,
		{ _hs_type_enum_team },
	},
	{ _hs_type_enum_team },
};

static struct hs_function_definition_with_1_parameter const camera_control_definition=
{
	{
		_hs_type_void,
		0,
		"camera_control",
		hs_macro_function_parse,
		director_script_camera_evaluate,
		"toggles script control of the camera.",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_2_parameters const camera_set_definition=
{
	{
		_hs_type_void,
		0,
		"camera_set",
		hs_macro_function_parse,
		scripted_camera_set_absolute_evaluate,
		"moves the camera to the specified camera point over the specified number of ticks.",
		NULL,
		2,
		{ _hs_type_cutscene_camera_point },
	},
	{ _hs_type_short_integer },
};

static struct hs_function_definition_with_3_parameters const camera_set_relative_definition=
{
	{
		_hs_type_void,
		0,
		"camera_set_relative",
		hs_macro_function_parse,
		scripted_camera_set_evaluate,
		"moves the camera to the specified camera point over the specified number of ticks (position is relative to the specified object).",
		NULL,
		3,
		{ _hs_type_cutscene_camera_point },
	},
	{ _hs_type_short_integer, _hs_type_object },
};

static struct hs_function_definition_with_2_parameters const camera_set_animation_definition=
{
	{
		_hs_type_void,
		0,
		"camera_set_animation",
		hs_macro_function_parse,
		scripted_camera_set_animation_evaluate,
		"begins a prerecorded camera animation.",
		NULL,
		2,
		{ _hs_type_animation_graph },
	},
	{ _hs_type_string },
};

static struct hs_function_definition_with_1_parameter const camera_set_first_person_definition=
{
	{
		_hs_type_void,
		0,
		"camera_set_first_person",
		hs_macro_function_parse,
		scripted_camera_set_first_person_evaluate,
		"makes the scripted camera follow a unit.",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition_with_1_parameter const camera_set_dead_definition=
{
	{
		_hs_type_void,
		0,
		"camera_set_dead",
		hs_macro_function_parse,
		scripted_camera_set_dead_evaluate,
		"makes the scripted camera zoom out around a unit as if it were dead.",
		NULL,
		1,
		{ _hs_type_unit },
	},
};

static struct hs_function_definition const camera_time_definition=
{
	_hs_type_short_integer,
	0,
	"camera_time",
	hs_macro_function_parse,
	scripted_camera_time_evaluate,
	"returns the number of ticks remaining in the current camera interpolation.",
	NULL,
	0,
};

static struct hs_function_definition const debug_camera_save_definition=
{
	_hs_type_void,
	0,
	"debug_camera_save",
	hs_macro_function_parse,
	director_save_camera_evaluate,
	"saves the camera position and facing.",
	NULL,
	0,
};

static struct hs_function_definition const debug_camera_load_definition=
{
	_hs_type_void,
	0,
	"debug_camera_load",
	hs_macro_function_parse,
	director_load_camera_evaluate,
	"loads the saved camera position and facing.",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const game_speed_definition=
{
	{
		_hs_type_void,
		0,
		"game_speed",
		hs_macro_function_parse,
		game_time_set_speed_evaluate,
		"changes the game speed.",
		NULL,
		1,
		{ _hs_type_real },
	},
};

static struct hs_function_definition_with_1_parameter const game_variant_definition=
{
	{
		_hs_type_void,
		0,
		"game_variant",
		hs_macro_function_parse,
		game_set_game_variant_from_name_evaluate,
		"set the game engine",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition const game_time_definition=
{
	_hs_type_long_integer,
	0,
	"game_time",
	hs_macro_function_parse,
	game_time_get_evaluate,
	"gets ticks elapsed since the start of the game.",
	NULL,
	0,
};

static struct hs_function_definition const game_difficulty_get_definition=
{
	_hs_type_enum_game_difficulty,
	0,
	"game_difficulty_get",
	hs_macro_function_parse,
	game_difficulty_level_get_ignore_easy_evaluate,
	"returns the current difficulty setting, but lies to you and will never return easy, instead returning normal",
	NULL,
	0,
};

static struct hs_function_definition const game_difficulty_get_real_definition=
{
	_hs_type_enum_game_difficulty,
	0,
	"game_difficulty_get_real",
	hs_macro_function_parse,
	game_difficulty_level_get_evaluate,
	"returns the actual current difficulty setting without lying",
	NULL,
	0,
};

static struct hs_function_definition const players_unzoom_all_definition=
{
	_hs_type_void,
	0,
	"players_unzoom_all",
	hs_macro_function_parse,
	players_unzoom_all_evaluate,
	"resets zoom levels on all players",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const player_enable_input_definition=
{
	{
		_hs_type_void,
		0,
		"player_enable_input",
		hs_macro_function_parse,
		player_input_enable_evaluate,
		"toggle player input. the player can still free-look, but nothing else.",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const player_camera_control_definition=
{
	{
		_hs_type_boolean,
		0,
		"player_camera_control",
		hs_macro_function_parse,
		scripted_player_control_set_camera_control_evaluate,
		"enables/disables camera control globally",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition const player_action_test_reset_definition=
{
	_hs_type_void,
	0,
	"player_action_test_reset",
	hs_macro_function_parse,
	player_control_action_test_reset_evaluate,
	"resets the player action test state so that all tests will return false.",
	NULL,
	0,
};

static struct hs_function_definition const player_action_test_jump_definition=
{
	_hs_type_boolean,
	0,
	"player_action_test_jump",
	hs_macro_function_parse,
	player_control_action_test_jump_evaluate,
	"returns true if any player has jumped since the last call to (player_action_test_reset).",
	NULL,
	0,
};

static struct hs_function_definition const player_action_test_primary_trigger_definition=
{
	_hs_type_boolean,
	0,
	"player_action_test_primary_trigger",
	hs_macro_function_parse,
	player_control_action_test_primary_trigger_evaluate,
	"returns true if any player has used primary trigger since the last call to (player_action_test_reset).",
	NULL,
	0,
};

static struct hs_function_definition const player_action_test_grenade_trigger_definition=
{
	_hs_type_boolean,
	0,
	"player_action_test_grenade_trigger",
	hs_macro_function_parse,
	player_control_action_test_grenade_trigger_evaluate,
	"returns true if any player has used grenade trigger since the last call to (player_action_test_reset).",
	NULL,
	0,
};

static struct hs_function_definition const player_action_test_zoom_definition=
{
	_hs_type_boolean,
	0,
	"player_action_test_zoom",
	hs_macro_function_parse,
	player_control_action_test_zoom_evaluate,
	"returns true if any player has hit the zoom button since the last call to (player_action_test_reset).",
	NULL,
	0,
};

static struct hs_function_definition const player_action_test_action_definition=
{
	_hs_type_boolean,
	0,
	"player_action_test_action",
	hs_macro_function_parse,
	player_control_action_test_action_evaluate,
	"returns true if any player has hit the action key since the last call to (player_action_test_reset).",
	NULL,
	0,
};

static struct hs_function_definition const player_action_test_accept_definition=
{
	_hs_type_boolean,
	0,
	"player_action_test_accept",
	hs_macro_function_parse,
	player_control_action_test_accept_evaluate,
	"returns true if any player has hit accept since the last call to (player_action_test_reset).",
	NULL,
	0,
};

static struct hs_function_definition const player_action_test_back_definition=
{
	_hs_type_boolean,
	0,
	"player_action_test_back",
	hs_macro_function_parse,
	player_control_action_test_back_evaluate,
	"returns true if any player has hit the back key since the last call to (player_action_test_reset).",
	NULL,
	0,
};

static struct hs_function_definition const player_action_test_look_relative_up_definition=
{
	_hs_type_boolean,
	0,
	"player_action_test_look_relative_up",
	hs_macro_function_parse,
	player_control_action_test_look_relative_up_evaluate,
	"returns true if any player has looked up since the last call to (player_action_test_reset).",
	NULL,
	0,
};

static struct hs_function_definition const player_action_test_look_relative_down_definition=
{
	_hs_type_boolean,
	0,
	"player_action_test_look_relative_down",
	hs_macro_function_parse,
	player_control_action_test_look_relative_down_evaluate,
	"returns true if any player has looked down since the last call to (player_action_test_reset).",
	NULL,
	0,
};

static struct hs_function_definition const player_action_test_look_relative_left_definition=
{
	_hs_type_boolean,
	0,
	"player_action_test_look_relative_left",
	hs_macro_function_parse,
	player_control_action_test_look_relative_left_evaluate,
	"returns true if any player has looked left since the last call to (player_action_test_reset).",
	NULL,
	0,
};

static struct hs_function_definition const player_action_test_look_relative_right_definition=
{
	_hs_type_boolean,
	0,
	"player_action_test_look_relative_right",
	hs_macro_function_parse,
	player_control_action_test_look_relative_right_evaluate,
	"returns true if any player has looked right since the last call to (player_action_test_reset).",
	NULL,
	0,
};

static struct hs_function_definition const player_action_test_look_relative_all_directions_definition=
{
	_hs_type_boolean,
	0,
	"player_action_test_look_relative_all_directions",
	hs_macro_function_parse,
	player_control_action_test_look_relative_all_directions_evaluate,
	"returns true if any player has looked up, down, left, and right since the last call to (player_action_test_reset).",
	NULL,
	0,
};

static struct hs_function_definition const player_action_test_move_relative_all_directions_definition=
{
	_hs_type_boolean,
	0,
	"player_action_test_move_relative_all_directions",
	hs_macro_function_parse,
	player_control_action_test_move_relative_all_directions_evaluate,
	"returns true if any player has moved forward, backward, left, and right since the last call to (player_action_test_reset).",
	NULL,
	0,
};

static struct hs_function_definition_with_3_parameters const player_add_equipment_definition=
{
	{
		_hs_type_void,
		0,
		"player_add_equipment",
		hs_macro_function_parse,
		player_add_equipment_evaluate,
		"adds/resets the player's health, shield, and inventory (weapons and grenades) to the named profile. resets if third parameter is true, adds if false.",
		NULL,
		3,
		{ _hs_type_unit },
	},
	{ _hs_type_starting_profile, _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const hs_debug_teleport_player_definition=
{
	{
		_hs_type_void,
		0,
		"debug_teleport_player",
		hs_macro_function_parse,
		debug_player_teleport_evaluate,
		"",
		NULL,
		2,
		{ _hs_type_short_integer },
	},
	{ _hs_type_short_integer },
};

static struct hs_function_definition const map_reset_definition=
{
	_hs_type_void,
	0,
	"map_reset",
	hs_macro_function_parse,
	main_reset_map_evaluate,
	"starts the map from the beginning.",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const map_name_definition=
{
	{
		_hs_type_void,
		0,
		"map_name",
		hs_macro_function_parse,
		main_set_map_name_evaluate,
		"changes the name of the solo player map.",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_1_parameter const multiplayer_map_name_definition=
{
	{
		_hs_type_void,
		0,
		"multiplayer_map_name",
		hs_macro_function_parse,
		main_set_multiplayer_map_name_evaluate,
		"changes the name of the multiplayer map",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_1_parameter const game_difficulty_set_definition=
{
	{
		_hs_type_void,
		0,
		"game_difficulty_set",
		hs_macro_function_parse,
		main_set_difficulty_evaluate,
		"changes the difficulty setting for the next map to be loaded.",
		NULL,
		1,
		{ _hs_type_enum_game_difficulty },
	},
};

static struct hs_function_definition_with_1_parameter const crash_definition=
{
	{
		_hs_type_void,
		0,
		"crash",
		hs_macro_function_parse,
		main_crash_evaluate,
		"crashes (for debugging).",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_1_parameter const switch_bsp_definition=
{
	{
		_hs_type_void,
		0,
		"switch_bsp",
		hs_macro_function_parse,
		scenario_switch_structure_bsp_evaluate,
		"takes off your condom and changes to a different structure bsp",
		NULL,
		1,
		{ _hs_type_short_integer },
	},
};

static struct hs_function_definition const structure_bsp_index_definition=
{
	_hs_type_short_integer,
	0,
	"structure_bsp_index",
	hs_macro_function_parse,
	global_structure_bsp_index_get_evaluate,
	"returns the current structure bsp index",
	NULL,
	0,
};

static struct hs_function_definition const version_definition=
{
	_hs_type_void,
	0,
	"version",
	hs_macro_function_parse,
	main_print_version_evaluate,
	"prints the build version.",
	NULL,
	0,
};

static struct hs_function_definition const playback_definition=
{
	_hs_type_void,
	0,
	"playback",
	hs_macro_function_parse,
	main_set_game_connection_to_film_playback_evaluate,
	"starts game in film playback mode",
	NULL,
	0,
};

static struct hs_function_definition const texture_cache_flush_definition=
{
	_hs_type_void,
	0,
	"texture_cache_flush",
	hs_macro_function_parse,
	texture_cache_flush_evaluate,
	"don't make me kick your ass",
	NULL,
	0,
};

static struct hs_function_definition const sound_cache_flush_definition=
{
	_hs_type_void,
	0,
	"sound_cache_flush",
	hs_macro_function_parse,
	sound_cache_flush_evaluate,
	"i'm a rebel!",
	NULL,
	0,
};

static struct hs_function_definition const debug_memory_definition=
{
	_hs_type_void,
	0,
	"debug_memory",
	hs_macro_function_parse,
	debug_dump_memory_evaluate,
	"dumps memory leaks.",
	NULL,
	0,
};

static struct hs_function_definition const debug_memory_by_file_definition=
{
	_hs_type_void,
	0,
	"debug_memory_by_file",
	hs_macro_function_parse,
	debug_dump_memory_by_file_evaluate,
	"dumps memory leaks by source file.",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const debug_memory_for_file_definition=
{
	{
		_hs_type_void,
		0,
		"debug_memory_for_file",
		hs_macro_function_parse,
		debug_dump_memory_for_file_evaluate,
		"dumps memory leaks from the specified source file.",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition const debug_tags_definition=
{
	_hs_type_void,
	0,
	"debug_tags",
	hs_macro_function_parse,
	tag_groups_dump_memory_evaluate,
	"writes all memory being used by tag files into tag_dump.txt",
	NULL,
	0,
};

static struct hs_function_definition const profile_reset_definition=
{
	_hs_type_void,
	0,
	"profile_reset",
	hs_macro_function_parse,
	profile_initialize_evaluate,
	"resets profiling data.",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const profile_dump_definition=
{
	{
		_hs_type_void,
		0,
		"profile_dump",
		hs_macro_function_parse,
		profile_dump_to_file_evaluate,
		"dumps profile based on a substring.",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_1_parameter const profile_activate_definition=
{
	{
		_hs_type_void,
		0,
		"profile_activate",
		hs_macro_function_parse,
		profile_sections_activate_evaluate,
		"activates profile sections based on a substring.",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_1_parameter const profile_deactivate_definition=
{
	{
		_hs_type_void,
		0,
		"profile_deactivate",
		hs_macro_function_parse,
		profile_sections_deactivate_evaluate,
		"deactivates profile sections based on a substring.",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_1_parameter const profile_graph_toggle_definition=
{
	{
		_hs_type_void,
		0,
		"profile_graph_toggle",
		hs_macro_function_parse,
		profile_graph_toggle_evaluate,
		"enables or disables profile graph display of a particular value.",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_1_parameter const hs_debug_pvs_definition=
{
	{
		_hs_type_void,
		0,
		"debug_pvs",
		hs_macro_function_parse,
		debug_pvs_evaluate,
		"displays the current pvs.",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition const hs_radiosity_start_definition=
{
	_hs_type_void,
	0,
	"radiosity_start",
	hs_macro_function_parse,
	radiosity_hack_start_evaluate,
	"starts radiosity computation.",
	NULL,
	0,
};

static struct hs_function_definition const hs_radiosity_save_definition=
{
	_hs_type_void,
	0,
	"radiosity_save",
	hs_macro_function_parse,
	radiosity_hack_save_evaluate,
	"saves radiosity solution.",
	NULL,
	0,
};

static struct hs_function_definition const hs_radiosity_debug_point_definition=
{
	_hs_type_void,
	0,
	"radiosity_debug_point",
	hs_macro_function_parse,
	radiosity_hack_find_point_evaluate,
	"tests sun occlusion at a point.",
	NULL,
	0,
};

static struct hs_function_definition const ai_lines_definition=
{
	_hs_type_void,
	0,
	"ai_lines",
	hs_macro_function_parse,
	ai_profile_change_render_spray_evaluate,
	"cycles through AI line-spray modes",
	NULL,
	0,
};

static struct hs_function_definition const ai_debug_sound_point_set_definition=
{
	_hs_type_void,
	0,
	"ai_debug_sound_point_set",
	hs_macro_function_parse,
	ai_debug_sound_point_set_evaluate,
	"drops the AI debugging sound point at the camera location",
	NULL,
	0,
};

static struct hs_function_definition_with_2_parameters const ai_debug_vocalize_definition=
{
	{
		_hs_type_void,
		0,
		"ai_debug_vocalize",
		hs_macro_function_parse,
		ai_debug_vocalize_evaluate,
		"makes the selected AI vocalize",
		NULL,
		2,
		{ _hs_type_string },
	},
	{ _hs_type_string },
};

static struct hs_function_definition_with_1_parameter const ai_debug_teleport_to_definition=
{
	{
		_hs_type_void,
		0,
		"ai_debug_teleport_to",
		hs_macro_function_parse,
		ai_debug_teleport_to_evaluate,
		"teleports all players to the specified encounter",
		NULL,
		1,
		{ _hs_type_ai },
	},
};

static struct hs_function_definition_with_1_parameter const ai_debug_speak_definition=
{
	{
		_hs_type_void,
		0,
		"ai_debug_speak",
		hs_macro_function_parse,
		ai_debug_speak_evaluate,
		"makes the currently selected AI speak a vocalization (e.g. ai_speak \"pain minor\")",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_1_parameter const ai_debug_speak_list_definition=
{
	{
		_hs_type_void,
		0,
		"ai_debug_speak_list",
		hs_macro_function_parse,
		ai_debug_speak_list_evaluate,
		"makes the currently selected AI speak a list of vocalizations (e.g. ai_speak_list \"involuntary\")",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_4_parameters const fade_in_definition=
{
	{
		_hs_type_void,
		0,
		"fade_in",
		hs_macro_function_parse,
		player_effect_screen_fade_in_evaluate,
		"does a screen fade in from a particular color",
		NULL,
		4,
		{ _hs_type_real },
	},
	{ _hs_type_real, _hs_type_real, _hs_type_short_integer },
};

static struct hs_function_definition_with_4_parameters const fade_out_definition=
{
	{
		_hs_type_void,
		0,
		"fade_out",
		hs_macro_function_parse,
		player_effect_screen_fade_out_evaluate,
		"does a screen fade out to a particular color",
		NULL,
		4,
		{ _hs_type_real },
	},
	{ _hs_type_real, _hs_type_real, _hs_type_short_integer },
};

static struct hs_function_definition const cinematic_start_definition=
{
	_hs_type_void,
	0,
	"cinematic_start",
	hs_macro_function_parse,
	cinematic_start_evaluate,
	"initializes game to start a cinematic (interruptive) cutscene",
	NULL,
	0,
};

static struct hs_function_definition const cinematic_stop_definition=
{
	_hs_type_void,
	0,
	"cinematic_stop",
	hs_macro_function_parse,
	cinematic_stop_evaluate,
	"initializes the game to end a cinematic (interruptive) cutscene",
	NULL,
	0,
};

static struct hs_function_definition const cinematic_skip_start_internal_definition=
{
	_hs_type_void,
	0,
	"cinematic_skip_start_internal",
	hs_macro_function_parse,
	cinematic_skip_start_evaluate,
	"",
	NULL,
	0,
};

static struct hs_function_definition const cinematic_skip_stop_internal_definition=
{
	_hs_type_void,
	0,
	"cinematic_skip_stop_internal",
	hs_macro_function_parse,
	cinematic_skip_stop_evaluate,
	"",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const cinematic_show_letterbox_definition=
{
	{
		_hs_type_void,
		0,
		"cinematic_show_letterbox",
		hs_macro_function_parse,
		cinematic_show_letterbox_evaluate,
		"sets or removes the letterbox bars",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const cinematic_set_title_definition=
{
	{
		_hs_type_void,
		0,
		"cinematic_set_title",
		hs_macro_function_parse,
		cinematic_set_title_evaluate,
		"activates the chapter title",
		NULL,
		1,
		{ _hs_type_cutscene_title },
	},
};

static struct hs_function_definition_with_2_parameters const cinematic_set_title_delayed_definition=
{
	{
		_hs_type_void,
		0,
		"cinematic_set_title_delayed",
		hs_macro_function_parse,
		cinematic_set_title_delayed_evaluate,
		"activates the chapter title, delayed by <real> seconds",
		NULL,
		2,
		{ _hs_type_cutscene_title },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_1_parameter const cinematic_suppress_bsp_object_creation_definition=
{
	{
		_hs_type_void,
		0,
		"cinematic_suppress_bsp_object_creation",
		hs_macro_function_parse,
		cinematic_suppress_bsp_object_creation_evaluate,
		"suppresses or enables the automatic creation of objects during cutscenes due to a bsp switch",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition const attract_mode_start_definition=
{
	_hs_type_void,
	0,
	"attract_mode_start",
	hs_macro_function_parse,
	attract_mode_start_evaluate,
	"",
	NULL,
	0,
};

static struct hs_function_definition const game_won_definition=
{
	_hs_type_void,
	0,
	"game_won",
	hs_macro_function_parse,
	main_won_map_evaluate,
	"causes the player to successfully finish the current level and move to the next",
	NULL,
	0,
};

static struct hs_function_definition const game_lost_definition=
{
	_hs_type_void,
	0,
	"game_lost",
	hs_macro_function_parse,
	main_lost_map_evaluate,
	"causes the player to revert to his previous saved game",
	NULL,
	0,
};

static struct hs_function_definition const game_safe_to_save_definition=
{
	_hs_type_boolean,
	0,
	"game_safe_to_save",
	hs_macro_function_parse,
	game_safe_to_save_evaluate,
	"returns FALSE if it would be a bad idea to save the player's game right now",
	NULL,
	0,
};

static struct hs_function_definition const game_all_quiet_definition=
{
	_hs_type_boolean,
	0,
	"game_all_quiet",
	hs_macro_function_parse,
	game_all_quiet_evaluate,
	"returns FALSE if there are bad guys around, projectiles in the air, etc.",
	NULL,
	0,
};

static struct hs_function_definition const game_safe_to_speak_definition=
{
	_hs_type_boolean,
	0,
	"game_safe_to_speak",
	hs_macro_function_parse,
	game_safe_to_speak_evaluate,
	"returns FALSE if it would be a bad idea to save the player's game right now",
	NULL,
	0,
};

static struct hs_function_definition const game_is_cooperative_definition=
{
	_hs_type_boolean,
	0,
	"game_is_cooperative",
	hs_macro_function_parse,
	game_is_cooperative_evaluate,
	"returns TRUE if the game is cooperative",
	NULL,
	0,
};

static struct hs_function_definition const game_save_definition=
{
	_hs_type_void,
	0,
	"game_save",
	hs_macro_function_parse,
	main_save_map_safe_evaluate,
	"checks to see if it is safe to save game, then saves (gives up after 8 seconds)",
	NULL,
	0,
};

static struct hs_function_definition const game_save_cancel_definition=
{
	_hs_type_void,
	0,
	"game_save_cancel",
	hs_macro_function_parse,
	main_save_cancel_evaluate,
	"cancels any pending game_save, timeout or not",
	NULL,
	0,
};

static struct hs_function_definition const game_save_no_timeout_definition=
{
	_hs_type_void,
	0,
	"game_save_no_timeout",
	hs_macro_function_parse,
	main_save_map_no_timeout_evaluate,
	"checks to see if it is safe to save game, then saves (this version never gives up)",
	NULL,
	0,
};

static struct hs_function_definition const game_save_totally_unsafe_definition=
{
	_hs_type_void,
	0,
	"game_save_totally_unsafe",
	hs_macro_function_parse,
	main_save_map_nonsafe_evaluate,
	"disregards player's current situation",
	NULL,
	0,
};

static struct hs_function_definition const game_saving_definition=
{
	_hs_type_boolean,
	0,
	"game_saving",
	hs_macro_function_parse,
	main_saving_map_evaluate,
	"checks to see if the game is trying to save the map.",
	NULL,
	0,
};

static struct hs_function_definition const game_revert_definition=
{
	_hs_type_void,
	0,
	"game_revert",
	hs_macro_function_parse,
	main_revert_map_evaluate,
	"reverts to last saved game, if any (for testing, the first bastard that does this to me gets it in the head)",
	NULL,
	0,
};

static struct hs_function_definition const core_load_definition=
{
	_hs_type_void,
	0,
	"core_load",
	hs_macro_function_parse,
	main_load_core_evaluate,
	"loads debug game state from core\\core.bin",
	NULL,
	0,
};

static struct hs_function_definition const core_load_at_startup_definition=
{
	_hs_type_void,
	0,
	"core_load_at_startup",
	hs_macro_function_parse,
	main_load_core_at_startup_evaluate,
	"loads debug game state from core\\core.bin as soon as the map is initialized",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const core_load_name_definition=
{
	{
		_hs_type_void,
		0,
		"core_load_name",
		hs_macro_function_parse,
		main_load_core_name_evaluate,
		"loads debug game state from core\\<path>",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_1_parameter const core_load_name_at_startup_definition=
{
	{
		_hs_type_void,
		0,
		"core_load_name_at_startup",
		hs_macro_function_parse,
		main_load_core_name_at_startup_evaluate,
		"loads debug game state from core\\<path> as soon as the map is initialized",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition const core_save_definition=
{
	_hs_type_void,
	0,
	"core_save",
	hs_macro_function_parse,
	main_save_core_evaluate,
	"saves debug game state to core\\core.bin",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const core_save_name_definition=
{
	{
		_hs_type_void,
		0,
		"core_save_name",
		hs_macro_function_parse,
		main_save_core_name_evaluate,
		"saves debug game state to core\\<path>",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition_with_1_parameter const game_skip_ticks_definition=
{
	{
		_hs_type_void,
		0,
		"game_skip_ticks",
		hs_macro_function_parse,
		main_skip_evaluate,
		"skips <short> amount of game ticks. ONLY USE IN CUTSCENES!!!",
		NULL,
		1,
		{ _hs_type_short_integer },
	},
};

static struct hs_function_definition const game_reverted_definition=
{
	_hs_type_boolean,
	0,
	"game_reverted",
	hs_macro_function_parse,
	game_state_reverted_evaluate,
	"don't use this for anything, you black-hearted bastards.",
	NULL,
	0,
};

static struct hs_function_definition_with_3_parameters const sound_impulse_start_definition=
{
	{
		_hs_type_void,
		0,
		"sound_impulse_start",
		hs_macro_function_parse,
		scripted_sound_new_evaluate,
		"plays an impulse sound from the specified source object (or \"none\"), with the specified scale.",
		NULL,
		3,
		{ _hs_type_sound },
	},
	{ _hs_type_object, _hs_type_real },
};

static struct hs_function_definition_with_1_parameter const sound_impulse_time_definition=
{
	{
		_hs_type_long_integer,
		0,
		"sound_impulse_time",
		hs_macro_function_parse,
		scripted_sound_time_evaluate,
		"returns the time remaining for the specified impulse sound.",
		NULL,
		1,
		{ _hs_type_sound },
	},
};

static struct hs_function_definition_with_1_parameter const sound_impulse_stop_definition=
{
	{
		_hs_type_void,
		0,
		"sound_impulse_stop",
		hs_macro_function_parse,
		scripted_sound_stop_evaluate,
		"stops the specified impulse sound.",
		NULL,
		1,
		{ _hs_type_sound },
	},
};

static struct hs_function_definition_with_1_parameter const sound_looping_predict_definition=
{
	{
		_hs_type_void,
		0,
		"sound_looping_predict",
		hs_macro_function_parse,
		scripted_foley_predict_evaluate,
		"your mom.",
		NULL,
		1,
		{ _hs_type_looping_sound },
	},
};

static struct hs_function_definition_with_3_parameters const sound_looping_start_definition=
{
	{
		_hs_type_void,
		0,
		"sound_looping_start",
		hs_macro_function_parse,
		scripted_looping_sound_start_evaluate,
		"plays a looping sound from the specified source object (or \"none\"), with the specified scale.",
		NULL,
		3,
		{ _hs_type_looping_sound },
	},
	{ _hs_type_object, _hs_type_real },
};

static struct hs_function_definition_with_1_parameter const sound_looping_stop_definition=
{
	{
		_hs_type_void,
		0,
		"sound_looping_stop",
		hs_macro_function_parse,
		scripted_looping_sound_stop_evaluate,
		"stops the specified looping sound.",
		NULL,
		1,
		{ _hs_type_looping_sound },
	},
};

static struct hs_function_definition_with_2_parameters const sound_looping_set_scale_definition=
{
	{
		_hs_type_void,
		0,
		"sound_looping_set_scale",
		hs_macro_function_parse,
		scripted_looping_sound_set_scale_evaluate,
		"changes the scale of the sound (which should affect the volume) within the range 0 to 1.",
		NULL,
		2,
		{ _hs_type_looping_sound },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_2_parameters const sound_looping_set_alternate_definition=
{
	{
		_hs_type_void,
		0,
		"sound_looping_set_alternate",
		hs_macro_function_parse,
		scripted_looping_sound_set_alternate_evaluate,
		"enables or disables the alternate loop/alternate end for a looping sound.",
		NULL,
		2,
		{ _hs_type_looping_sound },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_2_parameters const debug_sounds_enable_definition=
{
	{
		_hs_type_void,
		0,
		"debug_sounds_enable",
		hs_macro_function_parse,
		debug_sound_classes_enable_evaluate,
		"enables or disabled all sound classes matching the substring.",
		NULL,
		2,
		{ _hs_type_string },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_3_parameters const debug_sounds_distances_definition=
{
	{
		_hs_type_void,
		0,
		"debug_sounds_distances",
		hs_macro_function_parse,
		debug_sound_classes_set_distances_evaluate,
		"changes the minimum and maximum distances for all sound classes matching the substring.",
		NULL,
		3,
		{ _hs_type_string },
	},
	{ _hs_type_real, _hs_type_real },
};

static struct hs_function_definition_with_2_parameters const debug_sounds_wet_definition=
{
	{
		_hs_type_void,
		0,
		"debug_sounds_wet",
		hs_macro_function_parse,
		debug_sound_classes_set_wet_evaluate,
		"changes the reverb level for all sound classes matching the substring.",
		NULL,
		2,
		{ _hs_type_string },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_3_parameters const sound_class_set_gain_definition=
{
	{
		_hs_type_void,
		0,
		"sound_class_set_gain",
		hs_macro_function_parse,
		sound_class_set_gain_evaluate,
		"changes the gain on the specified sound class(es) to the specified game over the specified number of ticks.",
		NULL,
		3,
		{ _hs_type_string },
	},
	{ _hs_type_real, _hs_type_short_integer },
};

static struct hs_function_definition_with_1_parameter const sound_enable_definition=
{
	{
		_hs_type_void,
		0,
		"sound_enable",
		hs_macro_function_parse,
		sound_enable_evaluate,
		"enables or disables all sound.",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_2_parameters const vehicle_hover_definition=
{
	{
		_hs_type_void,
		0,
		"vehicle_hover",
		hs_macro_function_parse,
		vehicle_hover_evaluate,
		"stops the vehicle from running real physics and runs fake hovering physics instead.",
		NULL,
		2,
		{ _hs_type_vehicle },
	},
	{ _hs_type_boolean },
};

static struct hs_function_definition_with_1_parameter const show_hud_definition=
{
	{
		_hs_type_boolean,
		0,
		"show_hud",
		hs_macro_function_parse,
		scripted_show_hud_evaluate,
		"shows or hides the hud",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const show_hud_help_text_definition=
{
	{
		_hs_type_boolean,
		0,
		"show_hud_help_text",
		hs_macro_function_parse,
		scripted_show_hud_help_text_evaluate,
		"shows or hides the hud help text",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const enable_hud_help_flash_definition=
{
	{
		_hs_type_void,
		0,
		"enable_hud_help_flash",
		hs_macro_function_parse,
		scripted_hud_set_flashing_state_evaluate,
		"starts/stops the help text flashing",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition const hud_help_flash_restart_definition=
{
	_hs_type_void,
	0,
	"hud_help_flash_restart",
	hs_macro_function_parse,
	scripted_hud_restart_flashing_evaluate,
	"resets the timer for the help text flashing",
	NULL,
	0,
};

static struct hs_function_definition_with_4_parameters const activate_nav_point_flag_definition=
{
	{
		_hs_type_void,
		0,
		"activate_nav_point_flag",
		hs_macro_function_parse,
		hud_unit_activate_nav_point_with_flag_evaluate,
		"activates a nav point type <string> attached to (local) player <unit> anchored to a flag with a vertical offset <real>. If the player is not local to the machine, this will fail",
		NULL,
		4,
		{ _hs_type_navpoint },
	},
	{ _hs_type_unit, _hs_type_cutscene_flag, _hs_type_real },
};

static struct hs_function_definition_with_4_parameters const activate_nav_point_object_definition=
{
	{
		_hs_type_void,
		0,
		"activate_nav_point_object",
		hs_macro_function_parse,
		hud_unit_activate_nav_point_with_object_evaluate,
		"activates a nav point type <string> attached to (local) player <unit> anchored to an object with a vertical offset <real>. If the player is not local to the machine, this will fail",
		NULL,
		4,
		{ _hs_type_navpoint },
	},
	{ _hs_type_unit, _hs_type_object, _hs_type_real },
};

static struct hs_function_definition_with_4_parameters const activate_team_nav_point_flag_definition=
{
	{
		_hs_type_void,
		0,
		"activate_team_nav_point_flag",
		hs_macro_function_parse,
		hud_activate_team_nav_point_with_flag_evaluate,
		"activates a nav point type <string> attached to a team anchored to a flag with a vertical offset <real>. If the player is not local to the machine, this will fail",
		NULL,
		4,
		{ _hs_type_navpoint },
	},
	{ _hs_type_enum_team, _hs_type_cutscene_flag, _hs_type_real },
};

static struct hs_function_definition_with_4_parameters const activate_team_nav_point_object_definition=
{
	{
		_hs_type_void,
		0,
		"activate_team_nav_point_object",
		hs_macro_function_parse,
		hud_activate_team_nav_point_with_object_evaluate,
		"activates a nav point type <string> attached to a team anchored to an object with a vertical offset <real>. If the player is not local to the machine, this will fail",
		NULL,
		4,
		{ _hs_type_navpoint },
	},
	{ _hs_type_enum_team, _hs_type_object, _hs_type_real },
};

static struct hs_function_definition_with_2_parameters const deactivate_nav_point_flag_definition=
{
	{
		_hs_type_void,
		0,
		"deactivate_nav_point_flag",
		hs_macro_function_parse,
		hud_unit_deactivate_nav_point_with_flag_evaluate,
		"deactivates a nav point type attached to a player <unit> anchored to a flag",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_cutscene_flag },
};

static struct hs_function_definition_with_2_parameters const deactivate_nav_point_object_definition=
{
	{
		_hs_type_void,
		0,
		"deactivate_nav_point_object",
		hs_macro_function_parse,
		hud_unit_deactivate_nav_point_with_object_evaluate,
		"deactivates a nav point type attached to a player <unit> anchored to an object",
		NULL,
		2,
		{ _hs_type_unit },
	},
	{ _hs_type_object },
};

static struct hs_function_definition_with_2_parameters const deactivate_team_nav_point_flag_definition=
{
	{
		_hs_type_void,
		0,
		"deactivate_team_nav_point_flag",
		hs_macro_function_parse,
		hud_deactivate_team_nav_point_with_flag_evaluate,
		"deactivates a nav point type attached to a team anchored to a flag",
		NULL,
		2,
		{ _hs_type_enum_team },
	},
	{ _hs_type_cutscene_flag },
};

static struct hs_function_definition_with_2_parameters const deactivate_team_nav_point_object_definition=
{
	{
		_hs_type_void,
		0,
		"deactivate_team_nav_point_object",
		hs_macro_function_parse,
		hud_deactivate_team_nav_point_with_object_evaluate,
		"deactivates a nav point type attached to a team anchored to an object",
		NULL,
		2,
		{ _hs_type_enum_team },
	},
	{ _hs_type_object },
};

static struct hs_function_definition const cls_definition=
{
	_hs_type_void,
	0,
	"cls",
	hs_macro_function_parse,
	terminal_clear_evaluate,
	"clears console text from the screen",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const error_overflow_suppression_definition=
{
	{
		_hs_type_void,
		0,
		"error_overflow_suppression",
		hs_macro_function_parse,
		errors_overflow_suppression_enable_evaluate,
		"enables or disables the suppression of error spamming",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition const structure_lens_flares_place_definition=
{
	_hs_type_void,
	0,
	"structure_lens_flares_place",
	hs_macro_function_parse,
	structure_lens_flares_place_evaluate,
	"places lens flares in the structure bsp",
	NULL,
	0,
};

static struct hs_function_definition_with_3_parameters const player_effect_set_max_translation_definition=
{
	{
		_hs_type_void,
		0,
		"player_effect_set_max_translation",
		hs_macro_function_parse,
		scripted_player_effect_set_translation_evaluate,
		"<x> <y> <z>",
		NULL,
		3,
		{ _hs_type_real },
	},
	{ _hs_type_real, _hs_type_real },
};

static struct hs_function_definition_with_3_parameters const player_effect_set_max_rotation_definition=
{
	{
		_hs_type_void,
		0,
		"player_effect_set_max_rotation",
		hs_macro_function_parse,
		scripted_player_effect_set_rotation_evaluate,
		"<yaw> <pitch> <roll>",
		NULL,
		3,
		{ _hs_type_real },
	},
	{ _hs_type_real, _hs_type_real },
};

static struct hs_function_definition_with_2_parameters const hs_player_effect_set_max_rumble_definition=
{
	{
		_hs_type_void,
		0,
		"player_effect_set_max_rumble",
		hs_macro_function_parse,
		scripted_player_effect_set_rumble_evaluate,
		"<left> <right>",
		NULL,
		2,
		{ _hs_type_real },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_2_parameters const player_effect_start_definition=
{
	{
		_hs_type_void,
		0,
		"player_effect_start",
		hs_macro_function_parse,
		scripted_player_effect_start_evaluate,
		"<max_intensity> <attack time>",
		NULL,
		2,
		{ _hs_type_real },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_1_parameter const player_effect_stop_definition=
{
	{
		_hs_type_void,
		0,
		"player_effect_stop",
		hs_macro_function_parse,
		scripted_player_effect_stop_evaluate,
		"<decay>",
		NULL,
		1,
		{ _hs_type_real },
	},
};

static struct hs_function_definition_with_1_parameter const hud_show_health_definition=
{
	{
		_hs_type_void,
		0,
		"hud_show_health",
		hs_macro_function_parse,
		scripted_hud_show_health_evaluate,
		"hides/shows the health panel",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const hud_blink_health_definition=
{
	{
		_hs_type_void,
		0,
		"hud_blink_health",
		hs_macro_function_parse,
		scripted_hud_blink_health_evaluate,
		"starts/stops manual blinking of the health panel",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const hud_show_shield_definition=
{
	{
		_hs_type_void,
		0,
		"hud_show_shield",
		hs_macro_function_parse,
		scripted_hud_show_shield_evaluate,
		"hides/shows the shield panel",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const hud_blink_shield_definition=
{
	{
		_hs_type_void,
		0,
		"hud_blink_shield",
		hs_macro_function_parse,
		scripted_hud_blink_shield_evaluate,
		"starts/stops manual blinking of the shield panel",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const hud_show_motion_sensor_definition=
{
	{
		_hs_type_void,
		0,
		"hud_show_motion_sensor",
		hs_macro_function_parse,
		scripted_hud_show_motion_sensor_evaluate,
		"hides/shows the motion sensor panel",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const hud_blink_motion_sensor_definition=
{
	{
		_hs_type_void,
		0,
		"hud_blink_motion_sensor",
		hs_macro_function_parse,
		scripted_hud_blink_motion_sensor_evaluate,
		"starts/stops manual blinking of the motion sensor panel",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const hud_show_crosshair_definition=
{
	{
		_hs_type_void,
		0,
		"hud_show_crosshair",
		hs_macro_function_parse,
		scripted_hud_show_crosshair_evaluate,
		"hides/shows the weapon crosshair",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition const hud_clear_messages_definition=
{
	_hs_type_void,
	0,
	"hud_clear_messages",
	hs_macro_function_parse,
	scripted_hud_messages_clear_evaluate,
	"clears all non-state messages on the hud",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const hud_set_help_text_definition=
{
	{
		_hs_type_void,
		0,
		"hud_set_help_text",
		hs_macro_function_parse,
		scripted_hud_set_state_message_evaluate,
		"displays <message> as the help text",
		NULL,
		1,
		{ _hs_type_hud_message },
	},
};

static struct hs_function_definition_with_1_parameter const hud_set_objective_text_definition=
{
	{
		_hs_type_void,
		0,
		"hud_set_objective_text",
		hs_macro_function_parse,
		scripted_hud_set_objective_evaluate,
		"sets <message> as the current objective",
		NULL,
		1,
		{ _hs_type_hud_message },
	},
};

static struct hs_function_definition_with_2_parameters const hud_set_timer_time_definition=
{
	{
		_hs_type_void,
		0,
		"hud_set_timer_time",
		hs_macro_function_parse,
		scripted_hud_set_timer_time_evaluate,
		"sets the time for the timer to <short> minutes and <short> seconds, and starts and displays timer",
		NULL,
		2,
		{ _hs_type_short_integer },
	},
	{ _hs_type_short_integer },
};

static struct hs_function_definition_with_2_parameters const hud_set_timer_warning_time_definition=
{
	{
		_hs_type_void,
		0,
		"hud_set_timer_warning_time",
		hs_macro_function_parse,
		scripted_hud_set_timer_warning_cutoff_evaluate,
		"sets the warning time for the timer to <short> minutes and <short> seconds",
		NULL,
		2,
		{ _hs_type_short_integer },
	},
	{ _hs_type_short_integer },
};

static struct hs_function_definition_with_3_parameters const hud_set_timer_position_definition=
{
	{
		_hs_type_void,
		0,
		"hud_set_timer_position",
		hs_macro_function_parse,
		scripted_hud_set_timer_position_evaluate,
		"sets the timer upper left position to (x, y)=>(<short>, <short>)",
		NULL,
		3,
		{ _hs_type_short_integer },
	},
	{ _hs_type_short_integer, _hs_type_enum_hud_corner },
};

static struct hs_function_definition_with_1_parameter const show_hud_timer_definition=
{
	{
		_hs_type_void,
		0,
		"show_hud_timer",
		hs_macro_function_parse,
		scripted_hud_show_timer_evaluate,
		"displays the hud timer",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const pause_hud_timer_definition=
{
	{
		_hs_type_void,
		0,
		"pause_hud_timer",
		hs_macro_function_parse,
		scripted_hud_pause_timer_evaluate,
		"pauses or unpauses the hud timer",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition const hud_get_timer_ticks_definition=
{
	_hs_type_short_integer,
	0,
	"hud_get_timer_ticks",
	hs_macro_function_parse,
	scripted_hud_get_timer_ticks_evaluate,
	"returns the ticks left on the hud timer",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const time_code_show_definition=
{
	{
		_hs_type_void,
		0,
		"time_code_show",
		hs_macro_function_parse,
		scripted_hud_time_code_show_evaluate,
		"shows the time code timer",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const time_code_start_definition=
{
	{
		_hs_type_void,
		0,
		"time_code_start",
		hs_macro_function_parse,
		scripted_hud_time_code_start_evaluate,
		"starts/stops the time code timer",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition const time_code_reset_definition=
{
	_hs_type_void,
	0,
	"time_code_reset",
	hs_macro_function_parse,
	scripted_hud_time_code_reset_evaluate,
	"resets the time code timer",
	NULL,
	0,
};

static struct hs_function_definition const rasterizer_decals_flush_definition=
{
	_hs_type_void,
	0,
	"rasterizer_decals_flush",
	hs_macro_function_parse,
	rasterizer_decals_flush_evaluate,
	"flush all decals",
	NULL,
	0,
};

static struct hs_function_definition const rasterizer_fps_accumulate_definition=
{
	_hs_type_void,
	0,
	"rasterizer_fps_accumulate",
	hs_macro_function_parse,
	rasterizer_fps_accumulate_evaluate,
	"average fps",
	NULL,
	0,
};

static struct hs_function_definition_with_4_parameters const rasterizer_model_ambient_reflection_tint_definition=
{
	{
		_hs_type_void,
		0,
		"rasterizer_model_ambient_reflection_tint",
		hs_macro_function_parse,
		rasterizer_model_ambient_reflection_tint_evaluate,
		"",
		NULL,
		4,
		{ _hs_type_real },
	},
	{ _hs_type_real, _hs_type_real, _hs_type_real },
};

static struct hs_function_definition const rasterizer_lights_reset_for_new_map_definition=
{
	_hs_type_void,
	0,
	"rasterizer_lights_reset_for_new_map",
	hs_macro_function_parse,
	rasterizer_lights_reset_for_new_map_evaluate,
	"",
	NULL,
	0,
};

static struct hs_function_definition_with_2_parameters const script_screen_effect_set_value_definition=
{
	{
		_hs_type_void,
		0,
		"script_screen_effect_set_value",
		hs_macro_function_parse,
		rasterizer_script_screen_effect_set_value_evaluate,
		"sets a screen effect script value",
		NULL,
		2,
		{ _hs_type_short_integer },
	},
	{ _hs_type_real },
};

static struct hs_function_definition_with_1_parameter const cinematic_screen_effect_start_definition=
{
	{
		_hs_type_void,
		0,
		"cinematic_screen_effect_start",
		hs_macro_function_parse,
		rasterizer_screen_effect_start_evaluate,
		"starts screen effect; pass TRUE to clear",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_5_parameters const cinematic_screen_effect_set_convolution_definition=
{
	{
		_hs_type_void,
		0,
		"cinematic_screen_effect_set_convolution",
		hs_macro_function_parse,
		rasterizer_screen_effect_set_convolution_evaluate,
		"sets the convolution effect",
		NULL,
		5,
		{ _hs_type_short_integer },
	},
	{ _hs_type_short_integer, _hs_type_real, _hs_type_real, _hs_type_real },
};

static struct hs_function_definition_with_6_parameters const cinematic_screen_effect_set_filter_definition=
{
	{
		_hs_type_void,
		0,
		"cinematic_screen_effect_set_filter",
		hs_macro_function_parse,
		rasterizer_screen_effect_set_filter_evaluate,
		"sets the filter effect",
		NULL,
		6,
		{ _hs_type_real },
	},
	{ _hs_type_real, _hs_type_real, _hs_type_real, _hs_type_boolean, _hs_type_real },
};

static struct hs_function_definition_with_3_parameters const cinematic_screen_effect_set_filter_desaturation_tint_definition=
{
	{
		_hs_type_void,
		0,
		"cinematic_screen_effect_set_filter_desaturation_tint",
		hs_macro_function_parse,
		rasterizer_screen_effect_set_filter_desaturation_tint_evaluate,
		"sets the desaturation filter tint color",
		NULL,
		3,
		{ _hs_type_real },
	},
	{ _hs_type_real, _hs_type_real },
};

static struct hs_function_definition_with_2_parameters const cinematic_screen_effect_set_video_definition=
{
	{
		_hs_type_void,
		0,
		"cinematic_screen_effect_set_video",
		hs_macro_function_parse,
		rasterizer_screen_effect_set_video_evaluate,
		"sets the video effect: <noise intensity[0,1]>, <overbright: 0=none, 1=2x, 2=4x>",
		NULL,
		2,
		{ _hs_type_short_integer },
	},
	{ _hs_type_real },
};

static struct hs_function_definition const cinematic_screen_effect_stop_definition=
{
	_hs_type_void,
	0,
	"cinematic_screen_effect_stop",
	hs_macro_function_parse,
	rasterizer_screen_effect_stop_evaluate,
	"returns control of the screen effects to the rest of the game",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const cinematic_set_near_clip_distance_definition=
{
	{
		_hs_type_void,
		0,
		"cinematic_set_near_clip_distance",
		hs_macro_function_parse,
		rasterizer_set_near_clip_distance_evaluate,
		"",
		NULL,
		1,
		{ _hs_type_real },
	},
};

static struct hs_function_definition const hs_enumerate_memory_units_definition=
{
	_hs_type_void,
	0,
	"enumerate_memory_units",
	hs_macro_function_parse,
	enumerate_memory_units_test_evaluate,
	"enumerate memory units",
	NULL,
	0,
};

static struct hs_function_definition const delete_save_game_files_definition=
{
	_hs_type_void,
	0,
	"delete_save_game_files",
	hs_macro_function_parse,
	saved_game_files_delete_all_custom_profiles_evaluate,
	"delete all custom profile files",
	NULL,
	0,
};

static struct hs_function_definition const fast_setup_network_server_definition=
{
	_hs_type_void,
	0,
	"fast_setup_network_server",
	hs_macro_function_parse,
	player_ui_fast_setup_network_server_evaluate,
	"for zach's multiplayer testing",
	NULL,
	0,
};

static struct hs_function_definition const profile_unlock_solo_levels_definition=
{
	_hs_type_void,
	0,
	"profile_unlock_solo_levels",
	hs_macro_function_parse,
	player_ui_activate_all_solo_levels_evaluate,
	"unlocks all the solo player levels for player 1's profile",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const player0_look_invert_pitch_definition=
{
	{
		_hs_type_void,
		0,
		"player0_look_invert_pitch",
		hs_macro_function_parse,
		player0_look_invert_pitch_evaluate,
		"invert player0's look",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition const player0_look_pitch_is_inverted_definition=
{
	_hs_type_boolean,
	0,
	"player0_look_pitch_is_inverted",
	hs_macro_function_parse,
	player0_look_pitch_is_inverted_evaluate,
	"returns TRUE if player0's look pitch is inverted",
	NULL,
	0,
};

static struct hs_function_definition const player0_joystick_set_is_normal_definition=
{
	_hs_type_boolean,
	0,
	"player0_joystick_set_is_normal",
	hs_macro_function_parse,
	player0_joystick_set_is_normal_evaluate,
	"returns TRUE if player0 is using the normal joystick set",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const ui_widget_show_path_definition=
{
	{
		_hs_type_void,
		0,
		"ui_widget_show_path",
		hs_macro_function_parse,
		ui_widget_debug_show_path_evaluate,
		"blah blah",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition_with_1_parameter const display_scenario_help_definition=
{
	{
		_hs_type_void,
		0,
		"display_scenario_help",
		hs_macro_function_parse,
		display_scenario_help_evaluate,
		"display in-game help dialog",
		NULL,
		1,
		{ _hs_type_short_integer },
	},
};

static struct hs_function_definition const hs_network_game_start_now_definition=
{
	_hs_type_void,
	0,
	"network_game_start_now",
	hs_macro_function_parse,
	network_game_client_request_immediate_start_evaluate,
	"another one for zach",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const xbox_set_machine_name_definition=
{
	{
		_hs_type_void,
		0,
		"xbox_set_machine_name",
		hs_macro_function_parse,
		xbox_set_machine_name_evaluate,
		"YAHSFFZ",
		NULL,
		1,
		{ _hs_type_string },
	},
};

/* port: Halo PC's sv_say and sv_end_game, which Custom Edition maps' scripts
call (lookout_classic's and the Halo Kart maps' sv_say). They go at the end
of the table: Xbox maps call functions by their place in it, Custom Edition
maps by name (custom_edition_scripts.c). Every machine runs the scripts */

/* (each machine shows the message to its own players) */
static void hs_sv_say(
	char const *message)
{
	wchar_t text[128];
	short local_player_index;
	long length = 0;
	long index;

	/* (without '|', which the HUD's text takes with the character after it
	as one: at the end, the string's terminator) */
	for (index = 0; message && message[index] && length < NUMBEROF(text) - 1; index++)
	{
		if (message[index] != '|')
		{
			text[length++] = (unsigned char)message[index];
		}
	}
	text[length] = 0;
	for (local_player_index = 0; local_player_index < MAXIMUM_LOCAL_PLAYERS; local_player_index++)
	{
		if (local_player_get_player_index(local_player_index) != NONE)
			hud_print_message(local_player_index, text);
	}

	return;
}

/* (the host ends the game, as its time running out does) */
static void hs_sv_end_game(
	void)
{
	if (global_network_game_server_get() && game_engine_running())
		game_engine_end_game();

	return;
}

HS_EVALUATE_VOID_STRING(hs_sv_say_evaluate, hs_sv_say)
HS_EVALUATE_NO_ARGUMENTS(hs_sv_end_game_evaluate, hs_sv_end_game)

static struct hs_function_definition_with_1_parameter const sv_say_definition=
{
	{
		_hs_type_void,
		0,
		"sv_say",
		hs_macro_function_parse,
		hs_sv_say_evaluate,
		"Halo PC's: shows every player a message.",
		NULL,
		1,
		{ _hs_type_string },
	},
};

static struct hs_function_definition const sv_end_game_definition=
{
	_hs_type_void,
	0,
	"sv_end_game",
	hs_macro_function_parse,
	hs_sv_end_game_evaluate,
	"Halo PC's: the host ends the game.",
	NULL,
	0,
};

/* port: the mods' tags played over the map's on this machine
(the main menu's Mods: port/linux/game/mods.c), at the console */
void mods_reload(void);
void mods_enable(boolean enabled);
void mods_list(void);

HS_EVALUATE_NO_ARGUMENTS(hs_mods_reload_evaluate, mods_reload)
HS_EVALUATE_VOID_BOOLEAN(hs_mods_enable_evaluate, mods_enable)
HS_EVALUATE_NO_ARGUMENTS(hs_mods_list_evaluate, mods_list)

static struct hs_function_definition const mods_reload_definition=
{
	_hs_type_void,
	0,
	"mods_reload",
	hs_macro_function_parse,
	hs_mods_reload_evaluate,
	"finds the mods again and reads their tag files again (all sounds stop if any changed).",
	NULL,
	0,
};

static struct hs_function_definition_with_1_parameter const mods_enable_definition=
{
	{
		_hs_type_void,
		0,
		"mods_enable",
		hs_macro_function_parse,
		hs_mods_enable_evaluate,
		"plays the mods' sounds, bitmaps, text and models, or (false) the map's own, until the map changes.",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

static struct hs_function_definition const mods_list_definition=
{
	_hs_type_void,
	0,
	"mods_list",
	hs_macro_function_parse,
	hs_mods_list_evaluate,
	"lists the mods in the mods folder, and what they play on this map.",
	NULL,
	0,
};

/* port: the culling tests change only this machine's rendering */
HS_EVALUATE_VOID_LONG(hs_structure_culling_evaluate, structure_culling_set_tests)

static struct hs_function_definition_with_1_parameter const structure_culling_definition=
{
	{
		_hs_type_void,
		0,
		"structure_culling",
		hs_macro_function_parse,
		hs_structure_culling_evaluate,
		"which structure culling tests run, as bits (1 triangle planes, 2 bucket facing, 4 triangle facing, 8 finer buckets, 16 near first); 0 is the original walk.",
		NULL,
		1,
		{ _hs_type_long_integer },
	},
};

/* port: the debug view changes only this machine's rendering */
HS_EVALUATE_VOID_BOOLEAN(hs_debug_structure_culling_evaluate, structure_culling_debug)

static struct hs_function_definition_with_1_parameter const debug_structure_culling_definition=
{
	{
		_hs_type_void,
		0,
		"debug_structure_culling",
		hs_macro_function_parse,
		hs_debug_structure_culling_evaluate,
		"draws the structure triangles culled for the culling camera (red: outside the view, blue: facing away) and the counts.",
		NULL,
		1,
		{ _hs_type_boolean },
	},
};

long const hs_function_table_count= 418 + 7;

struct hs_enum_definition const hs_enum_table[]=
{
	{ 4, 0, global_game_difficulty_level_names },
	{ 10, 0, global_game_team_names },
	{ 12, 0, global_ai_default_state_names },
	{ 16, 0, global_actor_type_names },
	{ 5, 0, global_hud_anchor_names },
};

struct hs_function_table_storage hs_function_table=
{
	{
		&begin_definition,
		&begin_random_definition,
		&if_definition,
		&cond_definition,
		&set_definition,
		&and_definition,
		&or_definition,
		&add_definition,
		&subtract_definition,
		&multiply_definition,
		&divide_definition,
		&min_definition,
		&max_definition,
		&equal_definition,
		&not_equal_definition,
		&gt_definition,
		&lt_definition,
		&gte_definition,
		&lte_definition,
		&sleep_definition,
		&sleep_until_definition,
		&wake_definition,
		&inspect_definition,
		&object_to_unit_definition,
		&ai_debug_communication_suppress_definition,
		&ai_debug_communication_ignore_definition,
		&ai_debug_communication_focus_definition,
		&not_definition.definition,
		&print_definition.definition,
		&players_definition,
		&volume_teleport_players_not_inside_definition.definition,
		&volume_test_object_definition.definition,
		&volume_test_objects_definition.definition,
		&volume_test_objects_all_definition.definition,
		&object_teleport_definition.definition,
		&object_set_facing_definition.definition,
		&object_set_shield_definition.definition,
		&object_set_permutation_definition.definition,
		&object_create_definition.definition,
		&object_destroy_definition.definition,
		&object_create_anew_definition.definition,
		&object_create_containing_definition.definition,
		&object_create_anew_containing_definition.definition,
		&object_destroy_containing_definition.definition,
		&object_destroy_all_definition,
		&list_get_definition.definition,
		&list_count_definition.definition,
		&effect_new_definition.definition,
		&effect_new_on_object_marker_definition.definition,
		&damage_new_definition.definition,
		&damage_object_definition.definition,
		&objects_can_see_object_definition.definition,
		&objects_can_see_flag_definition.definition,
		&objects_delete_by_definition_definition.definition,
		&sound_set_gain_definition.definition,
		&sound_get_gain_definition.definition,
		&script_recompile_definition,
		&script_doc_definition,
		&help_definition.definition,
		&random_range_definition.definition,
		&real_random_range_definition.definition,
		&numeric_countdown_timer_set_definition.definition,
		&numeric_countdown_timer_get_definition.definition,
		&numeric_countdown_timer_stop_definition,
		&numeric_countdown_timer_restart_definition,
		&breakable_surfaces_enable_definition.definition,
		&recording_play_definition.definition,
		&recording_play_and_delete_definition.definition,
		&recording_play_and_hover_definition.definition,
		&recording_kill_definition.definition,
		&recording_time_definition.definition,
		&object_set_ranged_attack_inhibited_definition.definition,
		&object_set_melee_attack_inhibited_definition.definition,
		&objects_dump_memory_definition,
		&object_set_collideable_definition.definition,
		&object_set_scale_definition.definition,
		&objects_attach_definition.definition,
		&objects_detach_definition.definition,
		&garbage_collect_now_definition,
		&object_cannot_take_damage_definition.definition,
		&object_can_take_damage_definition.definition,
		&object_beautify_definition.definition,
		&objects_predict_definition.definition,
		&object_type_predict_definition.definition,
		&object_pvs_activate_definition.definition,
		&object_pvs_set_object_definition.definition,
		&object_pvs_set_camera_definition.definition,
		&object_pvs_clear_definition,
		&render_lights_definition.definition,
		&scenery_get_animation_time_definition.definition,
		&scenery_animation_start_definition.definition,
		&scenery_animation_start_at_frame_definition.definition,
		&render_effects_definition.definition,
		&unit_can_blink_definition.definition,
		&unit_open_definition.definition,
		&unit_close_definition.definition,
		&unit_kill_definition.definition,
		&unit_kill_silent_definition.definition,
		&unit_get_custom_animation_time_definition.definition,
		&unit_stop_custom_animation_definition.definition,
		&unit_custom_animation_at_frame_definition.definition,
		&custom_animation_definition.definition,
		&custom_animation_list_definition.definition,
		&unit_is_playing_custom_animation_definition.definition,
		&unit_aim_without_turning_definition.definition,
		&unit_set_emotion_definition.definition,
		&unit_set_enterable_by_player_definition.definition,
		&unit_enter_vehicle_definition.definition,
		&vehicle_test_seat_list_definition.definition,
		&vehicle_test_seat_definition.definition,
		&unit_set_emotion_animation_definition.definition,
		&unit_exit_vehicle_definition.definition,
		&unit_set_maximum_vitality_definition.definition,
		&units_set_maximum_vitality_definition.definition,
		&unit_set_current_vitality_definition.definition,
		&units_set_current_vitality_definition.definition,
		&vehicle_load_magic_definition.definition,
		&vehicle_unload_definition.definition,
		&magic_seat_name_definition.definition,
		&unit_set_seat_definition.definition,
		&magic_melee_attack_definition,
		&vehicle_riders_definition.definition,
		&vehicle_driver_definition.definition,
		&vehicle_gunner_definition.definition,
		&unit_get_health_definition.definition,
		&unit_get_shield_definition.definition,
		&unit_get_total_grenade_count_definition.definition,
		&unit_has_weapon_definition.definition,
		&unit_has_weapon_readied_definition.definition,
		&unit_doesnt_drop_items_definition.definition,
		&unit_impervious_definition.definition,
		&unit_suspended_definition.definition,
		&unit_solo_player_integrated_night_vision_is_active_definition,
		&units_set_desired_flashlight_state_definition.definition,
		&unit_set_desired_flashlight_state_definition.definition,
		&unit_get_current_flashlight_state_definition.definition,
		&device_set_never_appears_locked_definition.definition,
		&device_get_power_definition.definition,
		&device_set_power_definition.definition,
		&device_set_position_definition.definition,
		&device_get_position_definition.definition,
		&device_set_position_immediate_definition.definition,
		&device_group_get_definition.definition,
		&device_group_set_definition.definition,
		&device_group_set_immediate_definition.definition,
		&device_one_sided_set_definition.definition,
		&device_operates_automatically_set_definition.definition,
		&device_group_change_only_once_more_set_definition.definition,
		&breakable_surfaces_reset_definition,
		&cheat_all_powerups_definition,
		&cheat_all_weapons_definition,
		&cheat_all_vehicles_definition,
		&cheat_teleport_to_camera_definition,
		&cheat_active_camouflage_definition,
		&cheat_active_camouflage_local_player_definition.definition,
		&cheats_load_definition,
		&ai_free_definition.definition,
		&ai_free_units_definition.definition,
		&ai_attach_definition.definition,
		&ai_attach_free_definition.definition,
		&ai_detach_definition.definition,
		&ai_place_definition.definition,
		&ai_kill_definition.definition,
		&ai_kill_silent_definition.definition,
		&ai_erase_definition.definition,
		&ai_erase_all_definition,
		&ai_select_definition.definition,
		&ai_deselect_definition,
		&ai_spawn_actor_definition.definition,
		&ai_set_respawn_definition.definition,
		&ai_set_deaf_definition.definition,
		&ai_set_blind_definition.definition,
		&ai_magically_see_encounter_definition.definition,
		&ai_magically_see_players_definition.definition,
		&ai_magically_see_unit_definition.definition,
		&ai_timer_start_definition.definition,
		&ai_timer_expire_definition.definition,
		&ai_attack_definition.definition,
		&ai_defend_definition.definition,
		&ai_retreat_definition.definition,
		&ai_maneuver_definition.definition,
		&ai_maneuver_enable_definition.definition,
		&ai_migrate_definition.definition,
		&ai_migrate_and_speak_definition.definition,
		&ai_migrate_by_unit_definition.definition,
		&ai_allegiance_definition.definition,
		&ai_allegiance_remove_definition.definition,
		&ai_living_count_definition.definition,
		&ai_living_fraction_definition.definition,
		&ai_strength_definition.definition,
		&ai_swarm_count_definition.definition,
		&ai_nonswarm_count_definition.definition,
		&ai_actors_definition.definition,
		&ai_go_to_vehicle_definition.definition,
		&ai_go_to_vehicle_override_definition.definition,
		&ai_going_to_vehicle_definition.definition,
		&ai_exit_vehicle_definition.definition,
		&ai_braindead_definition.definition,
		&ai_braindead_by_unit_definition.definition,
		&ai_disregard_definition.definition,
		&ai_prefer_target_definition.definition,
		&ai_teleport_to_starting_location_definition.definition,
		&ai_teleport_to_starting_location_if_unsupported_definition.definition,
		&ai_renew_definition.definition,
		&ai_try_to_fight_nothing_definition.definition,
		&ai_try_to_fight_definition.definition,
		&ai_try_to_fight_player_definition.definition,
		&ai_command_list_definition.definition,
		&ai_command_list_by_unit_definition.definition,
		&ai_command_list_advance_definition.definition,
		&ai_command_list_advance_by_unit_definition.definition,
		&ai_command_list_status_definition.definition,
		&ai_is_attacking_definition.definition,
		&ai_force_active_definition.definition,
		&ai_force_active_by_unit_definition.definition,
		&ai_set_return_state_definition.definition,
		&ai_set_current_state_definition.definition,
		&ai_playfight_definition.definition,
		&ai_status_definition.definition,
		&ai_reconnect_definition,
		&ai_vehicle_encounter_definition.definition,
		&ai_vehicle_enterable_distance_definition.definition,
		&ai_vehicle_enterable_team_definition.definition,
		&ai_vehicle_enterable_actor_type_definition.definition,
		&ai_vehicle_enterable_actors_definition.definition,
		&ai_vehicle_enterable_disable_definition.definition,
		&ai_look_at_object_definition.definition,
		&ai_stop_looking_definition.definition,
		&ai_automatic_migration_target_definition.definition,
		&ai_follow_target_disable_definition.definition,
		&ai_follow_target_players_definition.definition,
		&ai_follow_target_unit_definition.definition,
		&ai_follow_target_ai_definition.definition,
		&ai_follow_distance_definition.definition,
		&ai_conversation_definition.definition,
		&ai_conversation_stop_definition.definition,
		&ai_conversation_advance_definition.definition,
		&ai_conversation_line_definition.definition,
		&ai_conversation_status_definition.definition,
		&ai_link_activation_definition.definition,
		&ai_berserk_definition.definition,
		&ai_set_team_definition.definition,
		&ai_allow_charge_definition.definition,
		&ai_allow_dormant_definition.definition,
		&ai_allegiance_broken_definition.definition,
		&camera_control_definition.definition,
		&camera_set_definition.definition,
		&camera_set_relative_definition.definition,
		&camera_set_animation_definition.definition,
		&camera_set_first_person_definition.definition,
		&camera_set_dead_definition.definition,
		&camera_time_definition,
		&debug_camera_load_definition,
		&debug_camera_save_definition,
		&game_speed_definition.definition,
		&game_time_definition,
		&game_variant_definition.definition,
		&game_difficulty_get_definition,
		&game_difficulty_get_real_definition,
		&map_reset_definition,
		&map_name_definition.definition,
		&multiplayer_map_name_definition.definition,
		&game_difficulty_set_definition.definition,
		&crash_definition.definition,
		&switch_bsp_definition.definition,
		&structure_bsp_index_definition,
		&version_definition,
		&playback_definition,
		&texture_cache_flush_definition,
		&sound_cache_flush_definition,
		&debug_memory_definition,
		&debug_memory_by_file_definition,
		&debug_memory_for_file_definition.definition,
		&debug_tags_definition,
		&profile_reset_definition,
		&profile_dump_definition.definition,
		&profile_activate_definition.definition,
		&profile_deactivate_definition.definition,
		&profile_graph_toggle_definition.definition,
		&hs_debug_pvs_definition.definition,
		&hs_radiosity_start_definition,
		&hs_radiosity_save_definition,
		&hs_radiosity_debug_point_definition,
		&ai_definition.definition,
		&ai_dialogue_triggers_definition.definition,
		&ai_grenades_definition.definition,
		&ai_lines_definition,
		&ai_debug_sound_point_set_definition,
		&ai_debug_vocalize_definition.definition,
		&ai_debug_teleport_to_definition.definition,
		&ai_debug_speak_definition.definition,
		&ai_debug_speak_list_definition.definition,
		&fade_in_definition.definition,
		&fade_out_definition.definition,
		&cinematic_start_definition,
		&cinematic_stop_definition,
		&cinematic_skip_start_internal_definition,
		&cinematic_skip_stop_internal_definition,
		&cinematic_show_letterbox_definition.definition,
		&cinematic_set_title_definition.definition,
		&cinematic_set_title_delayed_definition.definition,
		&cinematic_suppress_bsp_object_creation_definition.definition,
		&attract_mode_start_definition,
		&game_won_definition,
		&game_lost_definition,
		&game_safe_to_save_definition,
		&game_all_quiet_definition,
		&game_safe_to_speak_definition,
		&game_is_cooperative_definition,
		&game_save_definition,
		&game_save_cancel_definition,
		&game_save_no_timeout_definition,
		&game_save_totally_unsafe_definition,
		&game_saving_definition,
		&game_revert_definition,
		&game_reverted_definition,
		&core_save_definition,
		&core_save_name_definition.definition,
		&core_load_definition,
		&core_load_at_startup_definition,
		&core_load_name_definition.definition,
		&core_load_name_at_startup_definition.definition,
		&game_skip_ticks_definition.definition,
		&sound_impulse_start_definition.definition,
		&sound_impulse_time_definition.definition,
		&sound_impulse_stop_definition.definition,
		&sound_looping_predict_definition.definition,
		&sound_looping_start_definition.definition,
		&sound_looping_stop_definition.definition,
		&sound_looping_set_scale_definition.definition,
		&sound_looping_set_alternate_definition.definition,
		&debug_sounds_enable_definition.definition,
		&debug_sounds_distances_definition.definition,
		&debug_sounds_wet_definition.definition,
		&sound_enable_definition.definition,
		&sound_class_set_gain_definition.definition,
		&vehicle_hover_definition.definition,
		&players_unzoom_all_definition,
		&player_enable_input_definition.definition,
		&player_camera_control_definition.definition,
		&player_action_test_reset_definition,
		&player_action_test_jump_definition,
		&player_action_test_primary_trigger_definition,
		&player_action_test_grenade_trigger_definition,
		&player_action_test_zoom_definition,
		&player_action_test_action_definition,
		&player_action_test_accept_definition,
		&player_action_test_back_definition,
		&player_action_test_look_relative_up_definition,
		&player_action_test_look_relative_down_definition,
		&player_action_test_look_relative_left_definition,
		&player_action_test_look_relative_right_definition,
		&player_action_test_look_relative_all_directions_definition,
		&player_action_test_move_relative_all_directions_definition,
		&player_add_equipment_definition.definition,
		&hs_debug_teleport_player_definition.definition,
		&show_hud_definition.definition,
		&show_hud_help_text_definition.definition,
		&enable_hud_help_flash_definition.definition,
		&hud_help_flash_restart_definition,
		&activate_nav_point_flag_definition.definition,
		&activate_nav_point_object_definition.definition,
		&activate_team_nav_point_flag_definition.definition,
		&activate_team_nav_point_object_definition.definition,
		&deactivate_nav_point_flag_definition.definition,
		&deactivate_nav_point_object_definition.definition,
		&deactivate_team_nav_point_flag_definition.definition,
		&deactivate_team_nav_point_object_definition.definition,
		&cls_definition,
		&error_overflow_suppression_definition.definition,
		&structure_lens_flares_place_definition,
		&player_effect_set_max_translation_definition.definition,
		&player_effect_set_max_rotation_definition.definition,
		&hs_player_effect_set_max_rumble_definition.definition,
		&player_effect_start_definition.definition,
		&player_effect_stop_definition.definition,
		&hud_show_health_definition.definition,
		&hud_blink_health_definition.definition,
		&hud_show_shield_definition.definition,
		&hud_blink_shield_definition.definition,
		&hud_show_motion_sensor_definition.definition,
		&hud_blink_motion_sensor_definition.definition,
		&hud_show_crosshair_definition.definition,
		&hud_clear_messages_definition,
		&hud_set_help_text_definition.definition,
		&hud_set_objective_text_definition.definition,
		&hud_set_timer_time_definition.definition,
		&hud_set_timer_warning_time_definition.definition,
		&hud_set_timer_position_definition.definition,
		&show_hud_timer_definition.definition,
		&pause_hud_timer_definition.definition,
		&hud_get_timer_ticks_definition,
		&time_code_show_definition.definition,
		&time_code_start_definition.definition,
		&time_code_reset_definition,
		&rasterizer_decals_flush_definition,
		&rasterizer_fps_accumulate_definition,
		&rasterizer_model_ambient_reflection_tint_definition.definition,
		&rasterizer_lights_reset_for_new_map_definition,
		&script_screen_effect_set_value_definition.definition,
		&cinematic_screen_effect_start_definition.definition,
		&cinematic_screen_effect_set_convolution_definition.definition,
		&cinematic_screen_effect_set_filter_definition.definition,
		&cinematic_screen_effect_set_filter_desaturation_tint_definition.definition,
		&cinematic_screen_effect_set_video_definition.definition,
		&cinematic_screen_effect_stop_definition,
		&cinematic_set_near_clip_distance_definition.definition,
		&hs_enumerate_memory_units_definition,
		&delete_save_game_files_definition,
		&fast_setup_network_server_definition,
		&profile_unlock_solo_levels_definition,
		&player0_look_invert_pitch_definition.definition,
		&player0_look_pitch_is_inverted_definition,
		&player0_joystick_set_is_normal_definition,
		&ui_widget_show_path_definition.definition,
		&display_scenario_help_definition.definition,
		&hs_network_game_start_now_definition,
		&xbox_set_machine_name_definition.definition,
		&sv_say_definition.definition,
		&sv_end_game_definition,
		&mods_reload_definition,
		&mods_enable_definition.definition,
		&mods_list_definition,
		&structure_culling_definition.definition, /* port: local structure culling switch */
		&debug_structure_culling_definition.definition, /* port: local culling debug view */
	},
	{
		"hs_update",
		NONE,
		TRUE,
	},
	{
		hs_enumerate_special_form_names,
		hs_enumerate_script_type_names,
		hs_enumerate_type_names,
		hs_enumerate_function_names,
		hs_enumerate_script_names,
		hs_enumerate_variable_names,
		hs_enumerate_ai_names,
		hs_enumerate_ai_command_list_names,
		hs_enumerate_starting_profile_names,
		hs_enumerate_conversation_names,
		hs_enumerate_object_names,
		hs_enumerate_trigger_volume_names,
		hs_enumerate_cutscene_flag_names,
		hs_enumerate_cutscene_camera_point_names,
		hs_enumerate_cutscene_title_names,
		hs_enumerate_cutscene_recording_names,
		hs_enumerate_navpoints,
		hs_enumerate_hud_messages,
	},
};

/* port: the functions a map's scripts may call, by the function table's
index (hs_scenario_functions_check). The console's expressions may call
any. Allowed are gameplay's: AI, objects, units, devices, cinematics,
the camera, sound, the HUD, and the game progress and checkpoints the
shipped campaign uses. Not allowed are files, raw game state (core\),
the console's and the developer's tools (debug, profiling, cheats,
crash), switching maps or the game engine, the network, and the
player's own settings. Every function the shipped maps' scripts call is
allowed (291 of them). A function added to the table is not allowed until
it is listed here */
static boolean const hs_function_allowed_in_maps[]=
{
	/* the language: forms, logic, arithmetic, threads, casts */
	TRUE, /* begin */
	TRUE, /* begin_random */
	TRUE, /* if */
	FALSE, /* cond: compiled to if, it has no evaluator */
	TRUE, /* set */
	TRUE, /* and */
	TRUE, /* or */
	TRUE, /* + */
	TRUE, /* - */
	TRUE, /* * */
	TRUE, /* / */
	TRUE, /* min */
	TRUE, /* max */
	TRUE, /* = */
	TRUE, /* != */
	TRUE, /* > */
	TRUE, /* < */
	TRUE, /* >= */
	TRUE, /* <= */
	TRUE, /* sleep */
	TRUE, /* sleep_until */
	TRUE, /* wake */
	TRUE, /* inspect */
	TRUE, /* unit */
	FALSE, /* ai_debug_communication_suppress: AI debugging */
	FALSE, /* ai_debug_communication_ignore: AI debugging */
	FALSE, /* ai_debug_communication_focus: AI debugging */
	TRUE, /* not */
	TRUE, /* print */

	/* players, trigger volumes, objects, effects, damage */
	TRUE, /* players */
	TRUE, /* volume_teleport_players_not_inside */
	TRUE, /* volume_test_object */
	TRUE, /* volume_test_objects */
	TRUE, /* volume_test_objects_all */
	TRUE, /* object_teleport */
	TRUE, /* object_set_facing */
	TRUE, /* object_set_shield */
	TRUE, /* object_set_permutation */
	TRUE, /* object_create */
	TRUE, /* object_destroy */
	TRUE, /* object_create_anew */
	TRUE, /* object_create_containing */
	TRUE, /* object_create_anew_containing */
	TRUE, /* object_destroy_containing */
	TRUE, /* object_destroy_all */
	TRUE, /* list_get */
	TRUE, /* list_count */
	TRUE, /* effect_new */
	TRUE, /* effect_new_on_object_marker */
	TRUE, /* damage_new */
	TRUE, /* damage_object */
	TRUE, /* objects_can_see_object */
	TRUE, /* objects_can_see_flag */
	TRUE, /* objects_delete_by_definition */

	/* sound gain; the console */
	FALSE, /* sound_set_gain: the master gain, the player's setting */
	FALSE, /* sound_get_gain: the master gain, the player's setting */
	FALSE, /* script_recompile: the console */
	FALSE, /* script_doc: writes hs_doc.txt */
	FALSE, /* help: the console */

	/* random numbers, the countdown timer, recordings, objects */
	TRUE, /* random_range */
	TRUE, /* real_random_range */
	TRUE, /* numeric_countdown_timer_set */
	TRUE, /* numeric_countdown_timer_get */
	TRUE, /* numeric_countdown_timer_stop */
	TRUE, /* numeric_countdown_timer_restart */
	TRUE, /* breakable_surfaces_enable */
	TRUE, /* recording_play */
	TRUE, /* recording_play_and_delete */
	TRUE, /* recording_play_and_hover */
	TRUE, /* recording_kill */
	TRUE, /* recording_time */
	TRUE, /* object_set_ranged_attack_inhibited */
	TRUE, /* object_set_melee_attack_inhibited */
	FALSE, /* objects_dump_memory: a debug dump */
	TRUE, /* object_set_collideable */
	TRUE, /* object_set_scale */
	TRUE, /* objects_attach */
	TRUE, /* objects_detach */
	TRUE, /* garbage_collect_now */
	TRUE, /* object_cannot_take_damage */
	TRUE, /* object_can_take_damage */
	TRUE, /* object_beautify */
	TRUE, /* objects_predict */
	TRUE, /* object_type_predict */
	TRUE, /* object_pvs_activate */
	TRUE, /* object_pvs_set_object */
	TRUE, /* object_pvs_set_camera */
	TRUE, /* object_pvs_clear */
	TRUE, /* render_lights */

	/* scenery */
	TRUE, /* scenery_get_animation_time */
	TRUE, /* scenery_animation_start */
	TRUE, /* scenery_animation_start_at_frame */
	FALSE, /* render_effects: a render debug toggle */

	/* units and vehicles */
	TRUE, /* unit_can_blink */
	TRUE, /* unit_open */
	TRUE, /* unit_close */
	TRUE, /* unit_kill */
	TRUE, /* unit_kill_silent */
	TRUE, /* unit_get_custom_animation_time */
	TRUE, /* unit_stop_custom_animation */
	TRUE, /* unit_custom_animation_at_frame */
	TRUE, /* custom_animation */
	TRUE, /* custom_animation_list */
	TRUE, /* unit_is_playing_custom_animation */
	TRUE, /* unit_aim_without_turning */
	TRUE, /* unit_set_emotion */
	TRUE, /* unit_set_enterable_by_player */
	TRUE, /* unit_enter_vehicle */
	TRUE, /* vehicle_test_seat_list */
	TRUE, /* vehicle_test_seat */
	TRUE, /* unit_set_emotion_animation */
	TRUE, /* unit_exit_vehicle */
	TRUE, /* unit_set_maximum_vitality */
	TRUE, /* units_set_maximum_vitality */
	TRUE, /* unit_set_current_vitality */
	TRUE, /* units_set_current_vitality */
	TRUE, /* vehicle_load_magic */
	TRUE, /* vehicle_unload */
	TRUE, /* magic_seat_name */
	TRUE, /* unit_set_seat */
	TRUE, /* magic_melee_attack */
	TRUE, /* vehicle_riders */
	TRUE, /* vehicle_driver */
	TRUE, /* vehicle_gunner */
	TRUE, /* unit_get_health */
	TRUE, /* unit_get_shield */
	TRUE, /* unit_get_total_grenade_count */
	TRUE, /* unit_has_weapon */
	TRUE, /* unit_has_weapon_readied */
	TRUE, /* unit_doesnt_drop_items */
	TRUE, /* unit_impervious */
	TRUE, /* unit_suspended */
	TRUE, /* unit_solo_player_integrated_night_vision_is_active */
	TRUE, /* units_set_desired_flashlight_state */
	TRUE, /* unit_set_desired_flashlight_state */
	TRUE, /* unit_get_current_flashlight_state */

	/* devices, breakable surfaces */
	TRUE, /* device_set_never_appears_locked */
	TRUE, /* device_get_power */
	TRUE, /* device_set_power */
	TRUE, /* device_set_position */
	TRUE, /* device_get_position */
	TRUE, /* device_set_position_immediate */
	TRUE, /* device_group_get */
	TRUE, /* device_group_set */
	TRUE, /* device_group_set_immediate */
	TRUE, /* device_one_sided_set */
	TRUE, /* device_operates_automatically_set */
	TRUE, /* device_group_change_only_once_more_set */
	TRUE, /* breakable_surfaces_reset */

	/* cheats */
	FALSE, /* cheat_all_powerups: a cheat */
	FALSE, /* cheat_all_weapons: a cheat */
	FALSE, /* cheat_all_vehicles: a cheat */
	FALSE, /* cheat_teleport_to_camera: a cheat */
	FALSE, /* cheat_active_camouflage: a cheat */
	FALSE, /* cheat_active_camouflage_local_player: a cheat */
	FALSE, /* cheats_load: reads cheats.txt */

	/* AI */
	TRUE, /* ai_free */
	TRUE, /* ai_free_units */
	TRUE, /* ai_attach */
	TRUE, /* ai_attach_free */
	TRUE, /* ai_detach */
	TRUE, /* ai_place */
	TRUE, /* ai_kill */
	TRUE, /* ai_kill_silent */
	TRUE, /* ai_erase */
	TRUE, /* ai_erase_all */
	FALSE, /* ai_select: AI debugging (the debug selection) */
	FALSE, /* ai_deselect: AI debugging (the debug selection) */
	TRUE, /* ai_spawn_actor */
	TRUE, /* ai_set_respawn */
	TRUE, /* ai_set_deaf */
	TRUE, /* ai_set_blind */
	TRUE, /* ai_magically_see_encounter */
	TRUE, /* ai_magically_see_players */
	TRUE, /* ai_magically_see_unit */
	TRUE, /* ai_timer_start */
	TRUE, /* ai_timer_expire */
	TRUE, /* ai_attack */
	TRUE, /* ai_defend */
	TRUE, /* ai_retreat */
	TRUE, /* ai_maneuver */
	TRUE, /* ai_maneuver_enable */
	TRUE, /* ai_migrate */
	TRUE, /* ai_migrate_and_speak */
	TRUE, /* ai_migrate_by_unit */
	TRUE, /* ai_allegiance */
	TRUE, /* ai_allegiance_remove */
	TRUE, /* ai_living_count */
	TRUE, /* ai_living_fraction */
	TRUE, /* ai_strength */
	TRUE, /* ai_swarm_count */
	TRUE, /* ai_nonswarm_count */
	TRUE, /* ai_actors */
	TRUE, /* ai_go_to_vehicle */
	TRUE, /* ai_go_to_vehicle_override */
	TRUE, /* ai_going_to_vehicle */
	TRUE, /* ai_exit_vehicle */
	TRUE, /* ai_braindead */
	TRUE, /* ai_braindead_by_unit */
	TRUE, /* ai_disregard */
	TRUE, /* ai_prefer_target */
	TRUE, /* ai_teleport_to_starting_location */
	TRUE, /* ai_teleport_to_starting_location_if_unsupported */
	TRUE, /* ai_renew */
	TRUE, /* ai_try_to_fight_nothing */
	TRUE, /* ai_try_to_fight */
	TRUE, /* ai_try_to_fight_player */
	TRUE, /* ai_command_list */
	TRUE, /* ai_command_list_by_unit */
	TRUE, /* ai_command_list_advance */
	TRUE, /* ai_command_list_advance_by_unit */
	TRUE, /* ai_command_list_status */
	TRUE, /* ai_is_attacking */
	TRUE, /* ai_force_active */
	TRUE, /* ai_force_active_by_unit */
	TRUE, /* ai_set_return_state */
	TRUE, /* ai_set_current_state */
	TRUE, /* ai_playfight */
	TRUE, /* ai_status */
	TRUE, /* ai_reconnect */
	TRUE, /* ai_vehicle_encounter */
	TRUE, /* ai_vehicle_enterable_distance */
	TRUE, /* ai_vehicle_enterable_team */
	TRUE, /* ai_vehicle_enterable_actor_type */
	TRUE, /* ai_vehicle_enterable_actors */
	TRUE, /* ai_vehicle_enterable_disable */
	TRUE, /* ai_look_at_object */
	TRUE, /* ai_stop_looking */
	TRUE, /* ai_automatic_migration_target */
	TRUE, /* ai_follow_target_disable */
	TRUE, /* ai_follow_target_players */
	TRUE, /* ai_follow_target_unit */
	TRUE, /* ai_follow_target_ai */
	TRUE, /* ai_follow_distance */
	TRUE, /* ai_conversation */
	TRUE, /* ai_conversation_stop */
	TRUE, /* ai_conversation_advance */
	TRUE, /* ai_conversation_line */
	TRUE, /* ai_conversation_status */
	TRUE, /* ai_link_activation */
	TRUE, /* ai_berserk */
	TRUE, /* ai_set_team */
	TRUE, /* ai_allow_charge */
	TRUE, /* ai_allow_dormant */
	TRUE, /* ai_allegiance_broken */

	/* the camera */
	TRUE, /* camera_control */
	TRUE, /* camera_set */
	TRUE, /* camera_set_relative */
	TRUE, /* camera_set_animation */
	TRUE, /* camera_set_first_person */
	TRUE, /* camera_set_dead */
	TRUE, /* camera_time */

	/* the game: speed, time, difficulty, map, BSP; developer tools */
	FALSE, /* debug_camera_load: reads the saved camera file */
	FALSE, /* debug_camera_save: writes the saved camera file */
	TRUE, /* game_speed */
	TRUE, /* game_time */
	FALSE, /* game_variant: sets the game engine */
	TRUE, /* game_difficulty_get */
	TRUE, /* game_difficulty_get_real */
	FALSE, /* map_reset: restarts the map */
	FALSE, /* map_name: switches map */
	FALSE, /* multiplayer_map_name: switches map */
	FALSE, /* game_difficulty_set: the next map's difficulty */
	FALSE, /* crash: crashes */
	TRUE, /* switch_bsp */
	TRUE, /* structure_bsp_index */
	FALSE, /* version: the console */
	FALSE, /* playback: film playback */
	FALSE, /* texture_cache_flush: a developer tool */
	FALSE, /* sound_cache_flush: a developer tool */
	FALSE, /* debug_memory: a debug dump */
	FALSE, /* debug_memory_by_file: a debug dump */
	FALSE, /* debug_memory_for_file: a debug dump */
	FALSE, /* debug_tags: writes tag_dump.txt */
	FALSE, /* profile_reset: profiling */
	FALSE, /* profile_dump: profiling */
	FALSE, /* profile_activate: profiling */
	FALSE, /* profile_deactivate: profiling */
	FALSE, /* profile_graph_toggle: profiling */
	FALSE, /* debug_pvs: a render debug toggle */
	FALSE, /* radiosity_start: a lighting tool */
	FALSE, /* radiosity_save: a lighting tool, writes files */
	FALSE, /* radiosity_debug_point: a lighting tool */

	/* AI globals; AI debugging */
	TRUE, /* ai */
	TRUE, /* ai_dialogue_triggers */
	TRUE, /* ai_grenades */
	FALSE, /* ai_lines: AI debugging */
	FALSE, /* ai_debug_sound_point_set: AI debugging */
	FALSE, /* ai_debug_vocalize: AI debugging */
	FALSE, /* ai_debug_teleport_to: AI debugging */
	FALSE, /* ai_debug_speak: AI debugging */
	FALSE, /* ai_debug_speak_list: AI debugging */

	/* cinematics */
	TRUE, /* fade_in */
	TRUE, /* fade_out */
	TRUE, /* cinematic_start */
	TRUE, /* cinematic_stop */
	TRUE, /* cinematic_skip_start_internal */
	TRUE, /* cinematic_skip_stop_internal */
	TRUE, /* cinematic_show_letterbox */
	TRUE, /* cinematic_set_title */
	TRUE, /* cinematic_set_title_delayed */
	TRUE, /* cinematic_suppress_bsp_object_creation */
	FALSE, /* attract_mode_start: leaves the game for the attract movie */

	/* game progress and checkpoints (the saved-game system scripts use) */
	TRUE, /* game_won */
	TRUE, /* game_lost */
	TRUE, /* game_safe_to_save */
	TRUE, /* game_all_quiet */
	TRUE, /* game_safe_to_speak */
	TRUE, /* game_is_cooperative */
	TRUE, /* game_save */
	TRUE, /* game_save_cancel */
	TRUE, /* game_save_no_timeout */
	TRUE, /* game_save_totally_unsafe */
	TRUE, /* game_saving */
	TRUE, /* game_revert */
	TRUE, /* game_reverted */

	/* core files: raw game state */
	FALSE, /* core_save: writes raw game state under core */
	FALSE, /* core_save_name: writes raw game state under core */
	FALSE, /* core_load: loads raw game state from under core */
	FALSE, /* core_load_at_startup: loads raw game state from under core */
	FALSE, /* core_load_name: loads raw game state from under core */
	FALSE, /* core_load_name_at_startup: loads raw game state from under core */

	/* skipping ticks, sound */
	TRUE, /* game_skip_ticks */
	TRUE, /* sound_impulse_start */
	TRUE, /* sound_impulse_time */
	TRUE, /* sound_impulse_stop */
	TRUE, /* sound_looping_predict */
	TRUE, /* sound_looping_start */
	TRUE, /* sound_looping_stop */
	TRUE, /* sound_looping_set_scale */
	TRUE, /* sound_looping_set_alternate */
	FALSE, /* debug_sounds_enable: sound debugging */
	FALSE, /* debug_sounds_distances: sound debugging */
	FALSE, /* debug_sounds_wet: sound debugging */
	FALSE, /* sound_enable: all sound, the player's setting */
	TRUE, /* sound_class_set_gain */

	/* vehicles, players, player input tests */
	TRUE, /* vehicle_hover */
	TRUE, /* players_unzoom_all */
	TRUE, /* player_enable_input */
	TRUE, /* player_camera_control */
	TRUE, /* player_action_test_reset */
	TRUE, /* player_action_test_jump */
	TRUE, /* player_action_test_primary_trigger */
	TRUE, /* player_action_test_grenade_trigger */
	TRUE, /* player_action_test_zoom */
	TRUE, /* player_action_test_action */
	TRUE, /* player_action_test_accept */
	TRUE, /* player_action_test_back */
	TRUE, /* player_action_test_look_relative_up */
	TRUE, /* player_action_test_look_relative_down */
	TRUE, /* player_action_test_look_relative_left */
	TRUE, /* player_action_test_look_relative_right */
	TRUE, /* player_action_test_look_relative_all_directions */
	TRUE, /* player_action_test_move_relative_all_directions */
	TRUE, /* player_add_equipment */
	FALSE, /* debug_teleport_player: a debug teleport */

	/* the HUD, nav points, the console, player effects, the time code */
	TRUE, /* show_hud */
	TRUE, /* show_hud_help_text */
	TRUE, /* enable_hud_help_flash */
	TRUE, /* hud_help_flash_restart */
	TRUE, /* activate_nav_point_flag */
	TRUE, /* activate_nav_point_object */
	TRUE, /* activate_team_nav_point_flag */
	TRUE, /* activate_team_nav_point_object */
	TRUE, /* deactivate_nav_point_flag */
	TRUE, /* deactivate_nav_point_object */
	TRUE, /* deactivate_team_nav_point_flag */
	TRUE, /* deactivate_team_nav_point_object */
	TRUE, /* cls */
	FALSE, /* error_overflow_suppression: the error log's own state */
	FALSE, /* structure_lens_flares_place: an editing tool */
	TRUE, /* player_effect_set_max_translation */
	TRUE, /* player_effect_set_max_rotation */
	TRUE, /* player_effect_set_max_rumble */
	TRUE, /* player_effect_start */
	TRUE, /* player_effect_stop */
	TRUE, /* hud_show_health */
	TRUE, /* hud_blink_health */
	TRUE, /* hud_show_shield */
	TRUE, /* hud_blink_shield */
	TRUE, /* hud_show_motion_sensor */
	TRUE, /* hud_blink_motion_sensor */
	TRUE, /* hud_show_crosshair */
	TRUE, /* hud_clear_messages */
	TRUE, /* hud_set_help_text */
	TRUE, /* hud_set_objective_text */
	TRUE, /* hud_set_timer_time */
	TRUE, /* hud_set_timer_warning_time */
	TRUE, /* hud_set_timer_position */
	TRUE, /* show_hud_timer */
	TRUE, /* pause_hud_timer */
	TRUE, /* hud_get_timer_ticks */
	TRUE, /* time_code_show */
	TRUE, /* time_code_start */
	TRUE, /* time_code_reset */

	/* the rasterizer, screen effects */
	TRUE, /* rasterizer_decals_flush */
	FALSE, /* rasterizer_fps_accumulate: the frame rate display */
	TRUE, /* rasterizer_model_ambient_reflection_tint */
	TRUE, /* rasterizer_lights_reset_for_new_map */
	TRUE, /* script_screen_effect_set_value */
	TRUE, /* cinematic_screen_effect_start */
	TRUE, /* cinematic_screen_effect_set_convolution */
	TRUE, /* cinematic_screen_effect_set_filter */
	TRUE, /* cinematic_screen_effect_set_filter_desaturation_tint */
	TRUE, /* cinematic_screen_effect_set_video */
	TRUE, /* cinematic_screen_effect_stop */
	TRUE, /* cinematic_set_near_clip_distance */

	/* saved-game devices, profiles, the network, menus, help */
	FALSE, /* enumerate_memory_units: the saved-game devices */
	FALSE, /* delete_save_game_files: deletes profiles and saved games */
	FALSE, /* fast_setup_network_server: starts a network game */
	FALSE, /* profile_unlock_solo_levels: the player's profile */
	TRUE, /* player0_look_invert_pitch */
	TRUE, /* player0_look_pitch_is_inverted */
	TRUE, /* player0_joystick_set_is_normal */
	FALSE, /* ui_widget_show_path: a menu debug toggle */
	TRUE, /* display_scenario_help */
	FALSE, /* network_game_start_now: starts a network game */
	FALSE, /* xbox_set_machine_name: the machine's name */

	/* Halo PC's, for Custom Edition maps */
	TRUE, /* sv_say */
	TRUE, /* sv_end_game: the host's */

	/* the port's, for this machine's mods */
	FALSE, /* mods_reload */
	FALSE, /* mods_enable */
	FALSE, /* mods_list */

	/* port: local structure rendering */
	FALSE, /* structure_culling: this machine's rendering */
	FALSE, /* debug_structure_culling: this machine's rendering */
};
typedef char verify_hs_function_allowed_in_maps_size[
	NUMBEROF(hs_function_allowed_in_maps) == NUMBEROF(hs_function_table.functions) ? 1 : -1];

/* port: the arguments the special forms' evaluators read (hs_runtime.c), by
the function table's index; NONE is any number (hs_syntax_node_refusal). The
rest's are their parameters'. The shipped maps' all have these */
static struct
{
	short minimum;
	short maximum;
} const hs_special_form_argument_counts[]=
{
	{ 0, NONE }, /* begin */
	{ 1, 32 }, /* begin_random: its bit vector holds 32 */
	{ 2, 3 }, /* if */
	{ 0, NONE }, /* cond (a map may not call it) */
	{ 2, 2 }, /* set */
	{ 0, NONE }, /* and */
	{ 0, NONE }, /* or */
	{ 0, NONE }, /* + */
	{ 0, NONE }, /* - */
	{ 0, NONE }, /* * */
	{ 0, NONE }, /* / */
	{ 0, NONE }, /* min */
	{ 0, NONE }, /* max */
	{ 2, 2 }, /* = */
	{ 2, 2 }, /* != */
	{ 2, 2 }, /* > */
	{ 2, 2 }, /* < */
	{ 2, 2 }, /* >= */
	{ 2, 2 }, /* <= */
	{ 1, 2 }, /* sleep */
	{ 1, 3 }, /* sleep_until */
	{ 1, 1 }, /* wake */
	{ 1, 1 }, /* inspect */
	{ 1, 1 }, /* unit */
	{ 0, NONE }, /* ai_debug_communication_suppress */
	{ 0, NONE }, /* ai_debug_communication_ignore */
	{ 0, NONE }, /* ai_debug_communication_focus */
};
typedef char verify_hs_special_form_argument_counts_size[
	NUMBEROF(hs_special_form_argument_counts) == _hs_function_debug_string__last+1 ? 1 : -1];

/* ---------- public code */

boolean hs_scenario_merge(
	struct scenario *scenario,
	struct scenario *source_scenario)
{
	boolean success = TRUE;
	struct tag_block *source_files;
	short source_file_index;

	source_file_index = 0;
	source_files = &source_scenario->hs_source_files;

	for (; source_file_index<source_files->count; source_file_index++)
	{
		struct hs_source_file *source_file;
		struct tag_block *files;
		short file_index;

		source_file = TAG_BLOCK_GET_ELEMENT(source_files, source_file_index, struct hs_source_file);
		files = &scenario->hs_source_files;
		for (file_index = 0; file_index<files->count; file_index++)
		{
			struct hs_source_file *file;

			file = TAG_BLOCK_GET_ELEMENT(files, file_index, struct hs_source_file);
			if (_stricmp(source_file->name, file->name) == 0)
				break;
		}
		if (file_index == files->count)
		{
			short new_file_index;

			new_file_index = tag_block_add_element(files);
			if (new_file_index != NONE)
			{
				struct hs_source_file *file;

				file = TAG_BLOCK_GET_ELEMENT(files, new_file_index, struct hs_source_file);
				csstrcpy(file->name, source_file->name);
				if (tag_data_resize(&file->source, source_file->source.size))
				{
					csmemcpy(file->source.address, source_file->source.address, source_file->source.size);
				}
				else
				{
					success = FALSE;
				}
			}
			else
			{
				success = FALSE;
			}
		}
	}
	tag_block_resize(&scenario->hs_scripts, 0);

	return success;
}

/* port: the scenario's script data as the map holds it, the header of its
data array too (which hs_scenario_postprocess and the data array code go by,
the nodes' count above all): inside the tag cache, and the data array of
script nodes it has room for. The shipped maps' all are, of 19001 nodes
(their names differ: a30's is "static script node"). */
static boolean hs_scenario_syntax_data_valid(
	struct scenario const *scenario)
{
	long const syntax_data_size =
		sizeof(struct data_array)+MAXIMUM_HS_SYNTAX_NODES_PER_SCENARIO*sizeof(struct hs_syntax_node);
	byte const *address = (byte const *)scenario->hs_syntax_data.address;
	struct data_array const *data = (struct data_array const *)address;

	/* (in the loaded map's tag cache: this build's, or a Custom Edition
	map's, cache_file_tag_cache_contains) */
	if (scenario->hs_syntax_data.size != syntax_data_size ||
		!cache_file_tag_cache_contains(address, syntax_data_size) ||
		((unsigned long)address & 3))
	{
		return FALSE;
	}

	return data->signature == 'd@t@' &&
		data->maximum_count == MAXIMUM_HS_SYNTAX_NODES_PER_SCENARIO &&
		data->size == sizeof(struct hs_syntax_node) &&
		data->valid &&
		data->count >= 0 &&
		data->count <= data->maximum_count &&
		data->actual_count >= 0 &&
		data->actual_count <= data->count &&
		data->first_free_absolute_index >= 0 &&
		data->first_free_absolute_index <= data->maximum_count &&
		hs_scenario_string_constants_valid(scenario);
}

/* port: the scenario's script strings as the map holds them (the names
and strings its nodes point into): inside the tag cache, with the 0x400
bytes at their end that the console's expressions are written to
(hs_compile_expression). The shipped maps' all are */
static boolean hs_scenario_string_constants_valid(
	struct scenario const *scenario)
{
	byte const *address = (byte const *)scenario->hs_string_constants.address;
	long size = scenario->hs_string_constants.size;

	return size >= 0x400 &&
		cache_file_tag_cache_contains(address, size);
}

/* port: the scenario runs no scripts, its script data not being sound: a
cache file's blocks can't be resized (tag_block_resize), so the counts are
let go of in place, and no global is initialized or script thread started
(hs_runtime_initialize_for_new_map) against nodes that aren't there */
static void hs_scenario_scripts_disable(
	struct scenario *scenario)
{
	scenario->hs_scripts.count = 0;
	scenario->hs_globals.count = 0;

	return;
}

/* port: a script node as datum_get finds it (the array's count bounds it),
or NULL */
static struct hs_syntax_node const *hs_syntax_try_get(
	long expression_index)
{
	if (DATUM_INDEX_TO_ABSOLUTE_INDEX(expression_index)>=hs_syntax_data->count)
		return NULL;

	return (struct hs_syntax_node const *)datum_try_and_get(hs_syntax_data, expression_index);
}

/* port: marks the node a link names, and whether a link had already: a node
two links name (or a loop) is as damaged as the shipped maps' never are */
static boolean hs_syntax_node_linked_twice(
	long expression_index)
{
	long absolute_index = DATUM_INDEX_TO_ABSOLUTE_INDEX(expression_index);
	boolean twice;

	if (expression_index == NONE || !hs_syntax_try_get(expression_index))
		return FALSE;
	twice = BIT_VECTOR_TEST_FLAG(hs_syntax_nodes_marked, absolute_index);
	BIT_VECTOR_SET_FLAG(hs_syntax_nodes_marked, absolute_index, TRUE);

	return twice;
}

/* port: what a downloaded map's scripts (map_share_map_downloaded: one map
sharing downloaded, or game.downloaded_maps names) may not call or set, on top
of what no map's may (hs_function_allowed_in_maps,
hs_external_global_settable_by_maps): what changes the player's settings
(their profile's), other players' games (ending a game for everyone, the
HUD text every player sees), and the globals that outlive the map (they
keep their values into the maps played after it, a host's other players'
among them) */
static char const *const hs_functions_denied_to_downloaded_maps[]=
{
	"player0_look_invert_pitch",
	"sv_end_game",
	"sv_say",
	NULL
};

static char const *const hs_globals_denied_to_downloaded_maps[]=
{
	"cheat_deathless_player",
	"rider_ejection",
	"stun_enable",
	"rasterizer_near_clip_distance",
	"rasterizer_far_clip_distance",
	"rasterizer_first_person_weapon_near_clip_distance",
	"rasterizer_first_person_weapon_far_clip_distance",
	NULL
};

/* port: whether the map whose scripts are checked is a downloaded one
(hs_scenario_functions_check) */
static boolean hs_scenario_downloaded = FALSE;

static boolean hs_name_listed(
	char const *name,
	char const *const *list)
{
	for (; name && *list; list++)
	{
		if (!csstrcmp(name, *list))
			return TRUE;
	}

	return FALSE;
}

/* port: why a map's script may not have the node (_hs_node_refusal_none if
it may), and the function or global it names. A map may not have:
- a link (to the next argument, or a call's first node) that isn't a node:
the runtime goes through it (hs_syntax_get);
- a call to a function a map may not call (hs_function_allowed_in_maps), or
with arguments its evaluator would read past (hs_arguments_evaluate, the
special forms', begin_random's bit vector of 32);
- a set whose variable isn't a global's name (hs_evaluate_set takes its index
from the node as it is), or names an external global a map may not set
(hs_external_global_settable_by_maps);
- a wake whose argument isn't a script.
Only a node with a value's type that is neither a constant nor a script's
call is a function's call (hs_evaluate, hs_thread_main); its function's and
its globals' indices are the ones hs_compile_postprocess found by name */
static short hs_syntax_node_refusal(
	struct hs_syntax_node const *expression,
	char const **name)
{
	struct hs_syntax_node const *predicate;
	struct hs_syntax_node const *first_argument = NULL;
	struct hs_function_definition const *function;
	short function_index;
	short minimum_count;
	short maximum_count;

	*name = NULL;
	/* (a node that isn't permanent is a console expression's, which
	hs_node_gc deletes from under the script) */
	if (!TEST_FLAG(expression->flags, _hs_syntax_node_permanent_bit))
		return _hs_node_refusal_damaged;
	if (expression->next_node_index != NONE && !hs_syntax_try_get(expression->next_node_index))
		return _hs_node_refusal_damaged;
	if (TEST_FLAG(expression->flags, _hs_syntax_node_primitive_bit))
		return _hs_node_refusal_none;
	predicate = hs_syntax_try_get(expression->data);
	if (!predicate)
		return _hs_node_refusal_damaged;
	if (TEST_FLAG(expression->flags, _hs_syntax_node_script_bit) || !hs_type_valid(expression->type))
		return _hs_node_refusal_none;

	function_index = expression->function_index;
	if (function_index<0 || function_index>=(short)NUMBEROF(hs_function_allowed_in_maps))
		return _hs_node_refusal_damaged;
	function = hs_function_get(function_index);
	*name = function->name;
	if (!hs_function_allowed_in_maps[function_index])
		return _hs_node_refusal_function;
	/* port: a downloaded map's (hs_functions_denied_to_downloaded_maps) */
	if (hs_scenario_downloaded && hs_name_listed(function->name, hs_functions_denied_to_downloaded_maps))
		return _hs_node_refusal_downloaded_function;

	if (function->parse == hs_macro_function_parse)
	{
		minimum_count = maximum_count = function->parameter_count;
	}
	else if (function_index<(short)NUMBEROF(hs_special_form_argument_counts))
	{
		minimum_count = hs_special_form_argument_counts[function_index].minimum;
		maximum_count = hs_special_form_argument_counts[function_index].maximum;
	}
	else
	{
		minimum_count = 0;
		maximum_count = NONE;
	}
	/* (counted no further than one past the most it may have) */
	if (maximum_count != NONE)
	{
		long argument_index = predicate->next_node_index;
		short argument_count = 0;

		while (argument_index != NONE && argument_count<=maximum_count)
		{
			struct hs_syntax_node const *argument = hs_syntax_try_get(argument_index);

			if (!argument)
				return _hs_node_refusal_damaged;
			/* (a function's argument is of the type it takes, as the
			compiler made it: hs_arguments_evaluate hands the function the
			value as that type) */
			if (function->parse == hs_macro_function_parse &&
				argument_count<function->parameter_count &&
				argument->type != function->parameter_types[argument_count])
			{
				return _hs_node_refusal_damaged;
			}
			if (!first_argument)
				first_argument = argument;
			argument_count++;
			argument_index = argument->next_node_index;
		}
		if (argument_count<minimum_count || argument_count>maximum_count)
			return _hs_node_refusal_arguments;
	}

	if (function_index == _hs_function_set)
	{
		short designator = (short)first_argument->data;

		if (!TEST_FLAG(first_argument->flags, _hs_syntax_node_primitive_bit) ||
			!TEST_FLAG(first_argument->flags, _hs_syntax_node_variable_bit) ||
			hs_global_get_type(designator) == _hs_unparsed)
		{
			return _hs_node_refusal_damaged;
		}
		/* (and its value is of the global's type, which the global is
		read as) */
		{
			struct hs_syntax_node const *value = hs_syntax_try_get(first_argument->next_node_index);

			if (!value || value->type != hs_global_get_type(designator))
				return _hs_node_refusal_damaged;
		}
		if ((designator & 0x8000) && !hs_external_global_settable_by_maps(designator & 0x7FFF))
		{
			*name = hs_global_external_get(designator & 0x7FFF)->name;
			return _hs_node_refusal_global;
		}
		/* port: a downloaded map's (hs_globals_denied_to_downloaded_maps) */
		if ((designator & 0x8000) && hs_scenario_downloaded &&
			hs_name_listed(hs_global_external_get(designator & 0x7FFF)->name, hs_globals_denied_to_downloaded_maps))
		{
			*name = hs_global_external_get(designator & 0x7FFF)->name;
			return _hs_node_refusal_downloaded_global;
		}
	}
	else if (function_index == _hs_function_wake)
	{
		if (!TEST_FLAG(first_argument->flags, _hs_syntax_node_primitive_bit) ||
			first_argument->type != _hs_type_script)
		{
			return _hs_node_refusal_damaged;
		}
	}

	return _hs_node_refusal_none;
}

/* port: whether a script's or global's root node is of the type the
script returns or the global holds, as the compiler made it: the runtime
reads its value as that type (hs_script_evaluate, the global's
initialization). No root is of any type */
static boolean hs_root_type_valid(
	long root_expression_index,
	short type)
{
	struct hs_syntax_node const *root;

	if (root_expression_index == NONE)
		return TRUE;
	root = hs_syntax_try_get(root_expression_index);

	return !root || root->type == type;
}

/* port: why the map's expression may not run (hs_syntax_node_refusal; a node
it links to twice, or a loop, is damaged), and the function or global it
names. Each node is walked once, so the stack holds no more than the nodes
there are */
static short hs_expression_refusal(
	long root_expression_index,
	char const **name)
{
	static long stack[MAXIMUM_HS_SYNTAX_NODES_PER_SCENARIO+1];
	long stack_count = 0;

	*name = NULL;
	csmemset(hs_syntax_nodes_marked, 0, sizeof(hs_syntax_nodes_marked));
	stack[stack_count++] = root_expression_index;
	while (stack_count>0)
	{
		struct hs_syntax_node const *expression = hs_syntax_try_get(stack[--stack_count]);
		long child_index;
		short refusal;

		if (!expression)
			continue;
		refusal = hs_syntax_node_refusal(expression, name);
		if (refusal != _hs_node_refusal_none)
			return refusal;
		if (TEST_FLAG(expression->flags, _hs_syntax_node_primitive_bit))
			continue;

		/* (a call's function name, then its arguments) */
		child_index = expression->data;
		while (child_index != NONE)
		{
			struct hs_syntax_node const *child = hs_syntax_try_get(child_index);
			long absolute_index = DATUM_INDEX_TO_ABSOLUTE_INDEX(child_index);

			/* (a link that isn't a node: the node it is in is refused as it
			is walked) */
			if (!child)
				break;
			if (BIT_VECTOR_TEST_FLAG(hs_syntax_nodes_marked, absolute_index))
			{
				*name = NULL;
				return _hs_node_refusal_damaged;
			}
			BIT_VECTOR_SET_FLAG(hs_syntax_nodes_marked, absolute_index, TRUE);
			stack[stack_count++] = child_index;
			child_index = child->next_node_index;
		}
	}

	return _hs_node_refusal_none;
}

/* port: a map's script that may not run (hs_syntax_node_refusal: one that
calls a function a map may not, sets an external global it may not, or
holds a node the runtime would go wrong on) doesn't: a startup, dormant or
continuous script gets no thread, and a static one returns its type's
default (hs_runtime.c). A global whose initializer may not run starts at its
type's default. Every node is looked at once first; the shipped maps' are
all sound, none is linked to twice, and then no script is walked. The
console's expressions, compiled later, may call and set anything */
static void hs_scenario_functions_check(
	struct scenario *scenario)
{
	long expression_index;
	short script_index;
	short global_index;
	short refusal;
	char const *name;
	boolean refused = FALSE;
	boolean linked_twice = FALSE;
	short first_refusal = _hs_node_refusal_none;
	char const *first_name = NULL;
	char const *first_owner = NULL;
	char const *first_kind = NULL;
	short disabled_script_count = 0;
	short disabled_global_count = 0;
	char reason[128];

	/* port: a downloaded map's are held to tighter rules (map_share.c's
	map_share_map_downloaded) */
	hs_scenario_downloaded = map_share_map_downloaded(cache_file_loaded_map_name());
	if (hs_scenario_downloaded)
		error(_error_silent, "%s is a downloaded map: its scripts may call and set less", cache_file_loaded_map_name());
	csmemset(hs_syntax_nodes_marked, 0, sizeof(hs_syntax_nodes_marked));
	for (script_index = 0; script_index<scenario->hs_scripts.count; script_index++)
	{
		struct hs_script const *script = TAG_BLOCK_GET_ELEMENT(
			&scenario->hs_scripts,
			script_index,
			struct hs_script);

		if (hs_syntax_node_linked_twice(script->root_expression_index))
			linked_twice = TRUE;
		if (!hs_root_type_valid(script->root_expression_index, script->return_type))
			refused = TRUE;
	}
	for (global_index = 0; global_index<scenario->hs_globals.count; global_index++)
	{
		struct hs_global const *global = TAG_BLOCK_GET_ELEMENT(
			&scenario->hs_globals,
			global_index,
			struct hs_global);

		if (hs_syntax_node_linked_twice(global->initialization_expression_index))
			linked_twice = TRUE;
		if (!hs_root_type_valid(global->initialization_expression_index, global->type))
			refused = TRUE;
	}
	for (expression_index = data_next_index(hs_syntax_data, NONE);
		expression_index != NONE;
		expression_index = data_next_index(hs_syntax_data, expression_index))
	{
		struct hs_syntax_node const *expression = hs_syntax_try_get(expression_index);

		if (hs_syntax_node_refusal(expression, &name) != _hs_node_refusal_none)
			refused = TRUE;
		if (hs_syntax_node_linked_twice(expression->next_node_index))
			linked_twice = TRUE;
		if (!TEST_FLAG(expression->flags, _hs_syntax_node_primitive_bit) &&
			hs_syntax_node_linked_twice(expression->data))
		{
			linked_twice = TRUE;
		}
	}
	if (!refused && !linked_twice)
		return;

	for (script_index = 0; script_index<scenario->hs_scripts.count; script_index++)
	{
		struct hs_script const *script = TAG_BLOCK_GET_ELEMENT(
			&scenario->hs_scripts,
			script_index,
			struct hs_script);

		refusal = hs_expression_refusal(script->root_expression_index, &name);
		if (refusal == _hs_node_refusal_none && !hs_root_type_valid(script->root_expression_index, script->return_type))
		{
			name = NULL;
			refusal = _hs_node_refusal_damaged;
		}
		if (refusal != _hs_node_refusal_none)
		{
			BIT_VECTOR_SET_FLAG(hs_scenario_disabled_scripts, script_index, TRUE);
			if (!first_owner)
			{
				first_refusal = refusal;
				first_name = name;
				first_owner = script->name;
				first_kind = "script";
			}
			disabled_script_count++;
		}
	}
	for (global_index = 0; global_index<scenario->hs_globals.count; global_index++)
	{
		struct hs_global const *global = TAG_BLOCK_GET_ELEMENT(
			&scenario->hs_globals,
			global_index,
			struct hs_global);

		refusal = hs_expression_refusal(global->initialization_expression_index, &name);
		if (refusal == _hs_node_refusal_none && !hs_root_type_valid(global->initialization_expression_index, global->type))
		{
			name = NULL;
			refusal = _hs_node_refusal_damaged;
		}
		if (refusal != _hs_node_refusal_none)
		{
			BIT_VECTOR_SET_FLAG(hs_scenario_disabled_globals, global_index, TRUE);
			if (!first_owner)
			{
				first_refusal = refusal;
				first_name = name;
				first_owner = global->name;
				first_kind = "global";
			}
			disabled_global_count++;
		}
	}

	if (first_owner)
	{
		switch (first_refusal)
		{
		case _hs_node_refusal_function:
			csprintf(reason, "calls %s, which a map's scripts may not", first_name);
			break;
		case _hs_node_refusal_global:
			csprintf(reason, "sets %s, which a map's scripts may not", first_name);
			break;
		/* port: a downloaded map's */
		case _hs_node_refusal_downloaded_function:
			csprintf(reason, "calls %s, which a downloaded map's scripts may not", first_name);
			break;
		case _hs_node_refusal_downloaded_global:
			csprintf(reason, "sets %s, which a downloaded map's scripts may not", first_name);
			break;
		case _hs_node_refusal_arguments:
			csprintf(reason, "calls %s with arguments it doesn't take", first_name);
			break;
		default:
			csprintf(reason, "has a damaged script node");
			break;
		}
		error(_error_silent, "the map's %s %.32s %s; %d scripts won't run, %d globals start at their defaults",
			first_kind,
			first_owner,
			reason,
			disabled_script_count,
			disabled_global_count);
	}

	return;
}

boolean hs_scenario_script_disabled(
	short script_index)
{
	return script_index>=0 &&
		script_index<MAXIMUM_HS_SCRIPTS_PER_SCENARIO &&
		BIT_VECTOR_TEST_FLAG(hs_scenario_disabled_scripts, script_index);
}

boolean hs_scenario_global_initializer_disabled(
	short global_index)
{
	return global_index>=0 &&
		global_index<MAXIMUM_HS_GLOBALS &&
		BIT_VECTOR_TEST_FLAG(hs_scenario_disabled_globals, global_index);
}

static void hs_allocate(
	void)
{
	struct scenario *scenario;

	scenario = global_scenario_index != NONE ? global_scenario_get() : NULL;
	/* port: as the map holds it only when it is sound */
	if (scenario &&
		scenario->hs_syntax_data.size ==
			sizeof(struct data_array)+MAXIMUM_HS_SYNTAX_NODES_PER_SCENARIO*sizeof(struct hs_syntax_node) &&
		hs_scenario_syntax_data_valid(scenario))
	{
		return;
	}

	/* port: script data a map holds that isn't sound is the map's, in the
	tag cache: it isn't freed or replaced (what the Xbox did here, freeing
	tag memory), the map runs no scripts, and an array of the port's own,
	made once, stands in for it */
	if (scenario)
	{
		hs_scenario_scripts_disable(scenario);
		/* port: strings that aren't sound aren't gone by either, the
		console's expressions included (hs_compile_expression refuses a
		scenario without room for them) */
		if (!hs_scenario_string_constants_valid(scenario))
			scenario->hs_string_constants.size = 0;
		if (hs_syntax_data && hs_syntax_data_allocated)
			return;
		error(0, "the scenario's script data is missing or damaged; its scripts won't run");
	}

	hs_syntax_data = data_new(
		"script node",
		MAXIMUM_HS_SYNTAX_NODES_PER_SCENARIO,
		sizeof(struct hs_syntax_node));
	if (hs_syntax_data)
	{
		data_make_valid(hs_syntax_data);
		hs_syntax_data_allocated = TRUE;
	}
	else
	{
		error(0, "couldn't allocate script syntax data");
	}
	return;
}

void hs_dispose(
	void)
{
	hs_runtime_dispose_from_old_map();
	object_lists_dispose();
	return;
}

void hs_initialize(
	void)
{
	struct scenario *scenario;

	match_vassert(
		"c:\\halo\\SOURCE\\hs\\hs.c",
		245,
		hs_type_names[48],
		"you can't add an hs type without defining its name.");
	object_lists_initialize();
	hs_runtime_initialize();
	scenario = global_scenario_index != NONE ? global_scenario_get() : NULL;
	hs_allocate();
	if (scenario && scenario->hs_syntax_data.size)
		hs_scenario_postprocess(FALSE);
	object_lists_initialize_for_new_map();
	hs_runtime_initialize_for_new_map();
	return;
}

void hs_hack(
	void)
{
	struct scenario *scenario;

	if (hs_rebuild_source())
	{
		hs_compile_source();
		hs_dispose_from_old_map();
		scenario = global_scenario_index != NONE ? global_scenario_get() : NULL;
		hs_allocate();
		if (scenario && scenario->hs_syntax_data.size)
			hs_scenario_postprocess(FALSE);
		object_lists_initialize_for_new_map();
		hs_runtime_initialize_for_new_map();
	}
	return;
}

/* January expands this helper inline in hs_compile_and_evaluate (its source-file
 * branch folds away there but leaves the dead loop's alignment pad before the
 * error call) and keeps an out-of-line private-ABI copy for hs_compile_source. */
static void hs_compile_source_error(
	char const *error_source,
	char *error_message,
	struct hs_source_file const *source_file,
	char const *source)
{
	char *newline = NULL;

	if (error_message)
	{
		newline = strchr(error_message, '\n');
		if (newline)
			*newline = 0;
	}

	if (source_file && newline)
	{
		short line = 1;

		while (newline > source)
		{
			if (*newline == '\n')
				line++;
			newline--;
		}
		error(2, "[%s line %d] %s: %s", source_file->name, line, error_source, error_message);
	}
	else
	{
		error(2, "%s: %s", error_source, error_message);
	}
	return;
}

static boolean hs_compile_source(
	void)
{
	struct scenario *scenario;
	struct tag_block const *source_files;
	boolean success;
	char const *error_source;
	char const *error_message;
	short source_file_index;

	scenario = global_scenario_get();
	success = TRUE;
	hs_compile_initialize(TRUE);
	source_file_index = 0;
	source_files = &scenario->hs_source_files;
	while (source_file_index<source_files->count)
	{
		struct hs_source_file const *source_file;
		char const *source;

		source_file = TAG_BLOCK_GET_ELEMENT(
			source_files,
			source_file_index,
			struct hs_source_file);
		/*
		 * BUG (original): January and HCEA pass these outputs in reverse.
		 * A corrected build should pass &error_message, &error_source.
		 */
		hs_compile(
			source_file->source.size,
			tag_data_get_pointer(
				&source_file->source,
				0,
				source_file->source.size),
			&error_source,
			&error_message);
		if (error_source)
		{
			source = tag_data_get_pointer(
				&source_file->source,
				0,
				source_file->source.size);
			hs_compile_source_error(
				error_source,
				(char *)error_message,
				source_file,
				source);
			success = FALSE;
		}
		source_file_index++;
	}

	if (success)
		console_printf(FALSE, "scripts successfully compiled.");
	hs_compile_dispose();
	return success;
}

static boolean hs_rebuild_source_file(
	struct file_reference *file)
{
	struct scenario *scenario;
	struct tag_block *source_files;
	struct hs_source_file *source_file;
	void *source;
	unsigned long source_size;
	short source_file_index;
	char name[MAXIMUM_FILENAME_LENGTH+1];

	scenario = global_scenario_get();
	if (file_exists(file))
	{
		source_files = &scenario->hs_source_files;
		source_file_index = tag_block_add_element(source_files);
		if (source_file_index != NONE)
		{
			source_file = TAG_BLOCK_GET_ELEMENT(
				source_files,
				source_file_index,
				struct hs_source_file);
			source = file_read_into_memory(file, &source_size);
			if (source)
			{
				if (tag_data_resize(&source_file->source, source_size))
				{
					file_reference_get_name(file, FLAG(_name_filename_bit), name);
					csstrncpy(source_file->name, name, NUMBEROF(source_file->name)-1);
					source_file->name[NUMBEROF(source_file->name)-1] = 0;
					csmemcpy(
						tag_data_get_pointer(&source_file->source, 0, source_size),
						source,
						source_size);
					return TRUE;
				}
				error(2, "maximum source file size exceeded.");
				return FALSE;
			}
			error(2, "couldn't read source file into memory.");
			return FALSE;
		}
		error(2, "maximum source files per scenario exceeded.");
	}
	return FALSE;
}

static boolean hs_rebuild_source(
	void)
{
	boolean success = TRUE;
	char scenario_path[MAXIMUM_FILENAME_LENGTH+1];
	struct file_reference global_scripts;
	char extension[MAXIMUM_FILENAME_LENGTH+1];
	struct file_reference scripts_directory;
	struct file_reference source_files[8];
	short source_file_count;
	short source_file_index;
	char *scripts_name;

	tag_block_resize(&global_scenario_get()->hs_source_files, 0);
	/* port: snprintf (a map's tag's name may be any length) */
	snprintf(scenario_path, sizeof(scenario_path), "data\\%s", tag_get_name(global_scenario_index));
	scripts_name = strrchr(scenario_path, '\\') + 1;
	snprintf(scripts_name, sizeof(scenario_path) - (scripts_name - scenario_path), "scripts");
	file_reference_create_from_path(
		&global_scripts,
		"data\\global_scripts.hsc",
		FALSE);
	if (file_exists(&global_scripts))
		success = hs_rebuild_source_file(&global_scripts);

	file_reference_create_from_path(&scripts_directory, scenario_path, TRUE);
	source_file_count = (short)find_files(
		0,
		&scripts_directory,
		NUMBEROF(source_files),
		source_files);
	qsort(
		source_files,
		source_file_count,
		sizeof(struct file_reference),
		(int (__cdecl *)(void const *, void const *))alphabetize_file_references);
	for (source_file_index = 0; source_file_index<source_file_count; source_file_index++)
	{
		file_reference_get_name(
			&source_files[source_file_index],
			FLAG(_name_extension_bit),
			extension);
		if (csstrcmp(extension, "hsc") == 0 &&
			!hs_rebuild_source_file(&source_files[source_file_index]))
		{
			success = FALSE;
		}
	}
	return success;
}

void hs_update(
	void)
{
	profile_enter(hs_function_table.profile);
	hs_runtime_update();
	profile_exit(hs_function_table.profile);
	return;
}

void hs_node_gc(
	void)
{
	long syntax_node_index;

	for (syntax_node_index = data_next_index(hs_syntax_data, NONE);
		syntax_node_index != NONE;
		syntax_node_index = data_next_index(hs_syntax_data, syntax_node_index))
	{
		struct hs_syntax_node *syntax_node;

		syntax_node = (struct hs_syntax_node *)datum_get(hs_syntax_data, syntax_node_index);
		if (!(((byte)syntax_node->flags) & 8))
			datum_delete(hs_syntax_data, syntax_node_index);
	}
	return;
}

/* port: some multiplayer maps keep a copy of the place for each game type,
with its own sky. The script's first switch_bsp is the copy for the type the
host started. A later switch to another copy reloads the level every couple
of seconds, so that request is ignored. Cleared for each map. */
static short scripted_multiplayer_bsp = NONE;
static boolean scripted_multiplayer_bsp_reported = FALSE;

void hs_initialize_for_new_map(
	void)
{
	struct scenario *scenario;

	scripted_multiplayer_bsp = NONE;
	scripted_multiplayer_bsp_reported = FALSE;
	scenario = global_scenario_index != NONE ? global_scenario_get() : NULL;
	hs_allocate();
	if (scenario && scenario->hs_syntax_data.size)
		hs_scenario_postprocess(FALSE);
	object_lists_initialize_for_new_map();
	hs_runtime_initialize_for_new_map();
	return;
}

void hs_dispose_from_old_map(
	void)
{
	if (hs_syntax_data)
	{
		hs_node_gc();
		if (hs_syntax_data_allocated)
		{
			data_make_invalid(hs_syntax_data);
			data_dispose(hs_syntax_data);
			hs_syntax_data_allocated = FALSE;
		}
		hs_syntax_data = NULL;
	}
	/* port: the old map's disabled scripts and globals are not the next's
	(whose scripts may not be postprocessed: hs_scenario_postprocess clears
	them only then) */
	csmemset(hs_scenario_disabled_scripts, 0, sizeof(hs_scenario_disabled_scripts));
	csmemset(hs_scenario_disabled_globals, 0, sizeof(hs_scenario_disabled_globals));
	hs_runtime_dispose_from_old_map();
	object_lists_dispose_from_old_map();
	return;
}

void hs_recompile(
	void)
{
	hs_recompile_pending = TRUE;
	return;
}

struct hs_function_definition *hs_function_get(
	short function_index)
{
	match_assert(
		"c:\\halo\\SOURCE\\hs\\hs.c",
		522,
		function_index>=0 && function_index<hs_function_table_count);

	return hs_function_table.functions[function_index];
}

short hs_find_script_by_name(
	char const *name)
{
	short script_index;

	if (global_scenario_index != NONE)
	{
		struct scenario *scenario;

		scenario = global_scenario_get();
		for (script_index = 0; script_index<scenario->hs_scripts.count; script_index++)
		{
			struct hs_script const *script;

			script = TAG_BLOCK_GET_ELEMENT(&scenario->hs_scripts, script_index, struct hs_script);
			if (csstrcmp(name, script->name) == 0)
				return script_index;
		}
	}

	return NONE;
}

short hs_find_global_by_name(
	char const *name)
{
	short global_index;

	for (global_index = 0; global_index<hs_external_global_count; global_index++)
	{
		if (_stricmp(name, hs_global_external_get(global_index)->name) == 0)
			return global_index | 0x8000;
	}

	if (global_scenario_index != NONE)
	{
		struct scenario *scenario;

		scenario = global_scenario_get();
		for (global_index = 0; global_index<scenario->hs_globals.count; global_index++)
		{
			struct hs_global const *global;

			global = TAG_BLOCK_GET_ELEMENT(
				&global_scenario_get()->hs_globals,
				global_index,
				struct hs_global);
			if (_stricmp(name, global->name) == 0)
				return global_index & ~0x8000;
		}
	}

	return NONE;
}

short hs_find_tag_reference_by_index(
	long tag_index)
{
	short reference_index;

	if (global_scenario_index != NONE)
	{
		struct scenario *scenario;

		scenario = global_scenario_get();
		for (reference_index = 0; reference_index<scenario->hs_references.count; reference_index++)
		{
			struct hs_reference const *reference;

			reference = TAG_BLOCK_GET_ELEMENT(&scenario->hs_references, reference_index, struct hs_reference);
			if (reference->reference.index == tag_index)
				return reference_index;
		}
	}

	return NONE;
}

struct hs_external_global_definition *hs_global_external_get(
	short global_index)
{
	match_assert(
		"c:\\halo\\SOURCE\\hs\\hs.c",
		576,
		global_index>=0 && global_index<hs_external_global_count);

	return hs_external_globals[global_index];
}

short hs_global_get_type(
	short global_index)
{
	/* port: a global that isn't there (a map's syntax node names it) has
	no type */
	if (global_index & 0x8000)
	{
		if ((global_index & 0x7FFF) >= hs_external_global_count)
			return _hs_unparsed;

		return hs_global_external_get(global_index & 0x7FFF)->type;
	}
	if ((global_index & 0x7FFF) >= global_scenario_get()->hs_globals.count)
		return _hs_unparsed;

	return TAG_BLOCK_GET_ELEMENT(
		&global_scenario_get()->hs_globals,
		global_index & 0x7FFF,
		struct hs_global)->type;
}

char const *hs_global_get_name(
	short global_index)
{
	if (global_index & 0x8000)
		return hs_global_external_get(global_index & 0x7FFF)->name;

	return TAG_BLOCK_GET_ELEMENT(
		&global_scenario_get()->hs_globals,
		global_index & 0x7FFF,
		struct hs_global)->name;
}

short hs_find_function_by_name(
	char const *name)
{
	short function_index;

	for (function_index = 0; function_index<hs_function_table_count; function_index++)
	{
		if (_stricmp(hs_function_table.functions[function_index]->name, name) == 0)
			return function_index;
	}

	return NONE;
}

boolean hs_evaluate_by_name(
	char const *name)
{
	short script_index;

	script_index = hs_find_script_by_name(name);
	if (script_index != NONE)
	{
		struct hs_script const *script;

		script = TAG_BLOCK_GET_ELEMENT(
			&global_scenario_get()->hs_scripts,
			script_index,
			struct hs_script);
		/* port: a script that doesn't run (hs_scenario_functions_check)
		isn't run here either */
		if (!hs_scenario_script_disabled(script_index))
			hs_runtime_evaluate(script->root_expression_index);
		return TRUE;
	}

	return FALSE;
}

static void hs_get_function_parameters_string(
	short function_index,
	char *result)
{
	struct hs_function_definition const *function;
	short parameter_index;

	function = hs_function_get(function_index);
	sprintf(result, "(%s", function->name);
	if (function->usage)
	{
		sprintf(result + csstrlen(result), " %s", function->usage);
	}
	else
	{
		for (parameter_index = 0; parameter_index<function->parameter_count; parameter_index++)
		{
			csstrcat(result, " <");
			csstrcat(result, hs_type_names[function->parameter_types[parameter_index]]);
			csstrcat(result, ">");
		}
	}
	csstrcat(result, ")");
	return;
}

static void hs_get_function_documentation_string(
	short function_index,
	char *result)
{
	csstrcpy(result, hs_function_get(function_index)->help);

	return;
}

void hs_help(
	char const *function_name)
{
	char result[2048];
	short function_index;

	function_index = hs_find_function_by_name(function_name);
	if (function_index != NONE)
	{
		/* port: printed through "%s" (the text isn't a format) */
		hs_get_function_parameters_string(function_index, result);
		console_printf(FALSE, "%s", result);
		hs_get_function_documentation_string(function_index, result);
		console_printf(FALSE, "%s", result);
	}
	return;
}

void hs_doc(
	void)
{
	char result[2048];
	FILE *file;
	short function_index;

	file = fopen("hs_doc.txt", "w");
	for (function_index = 0; function_index<hs_function_table_count; function_index++)
	{
		hs_function_get(function_index);
		hs_get_function_parameters_string(function_index, result);
		fprintf(file, "%s\r\n", result);
		csstrcpy(result, hs_function_get(function_index)->help);
		fprintf(file, "%s\r\n\r\n", result);
	}
	fclose(file);
	return;
}

short hs_tokens_enumerate(
	char const *substring,
	long type_flags,
	char const **results,
	short maximum_count)
{
	short type_index;

	match_assert(
		"c:\\halo\\SOURCE\\hs\\hs.c",
		920,
		!enumeration_results);
	hs_enumeration_maximum_count = maximum_count;
	hs_enumeration_result_count = 0;
	enumeration_results = results;
	hs_enumeration_substring = substring;
	if (!substring)
		hs_enumeration_substring = "";

	for (type_index = 0; type_index<18; type_index++)
	{
		match_assert(
			"c:\\halo\\SOURCE\\hs\\hs.c",
			929,
			hs_token_enumerators[type_index]);
		if (type_flags & (1 << type_index))
			hs_token_enumerators[type_index]();
	}

	qsort(
		(void *)results,
		hs_enumeration_result_count,
		sizeof(*results),
		(int (__cdecl *)(void const *, void const *))alphabetize);
	enumeration_results = NULL;
	return hs_enumeration_result_count;
}

static void hs_tokens_enumerate_add_string(
	char const *token)
{
	match_assert(
		"c:\\halo\\SOURCE\\hs\\hs.c",
		666,
		enumeration_results);
	if (hs_enumeration_result_count<hs_enumeration_maximum_count &&
		_strnicmp(token, hs_enumeration_substring, csstrlen(hs_enumeration_substring)) == 0)
	{
		short result_index;
		short new_result_count;

		result_index = hs_enumeration_result_count;
		new_result_count = (short)(result_index + 1);
		enumeration_results[result_index] = token;
		hs_enumeration_result_count = new_result_count;
	}
	return;
}

static void hs_enumerate_block_data(
	struct tag_block const *block,
	short name_offset,
	long element_size)
{
	short element_index;

	for (element_index = 0; element_index<block->count; element_index++)
	{
		byte const *element;

		element = (byte const *)tag_block_get_element_with_size(
			block,
			element_index,
			element_size);
		hs_tokens_enumerate_add_string((char const *)(element + name_offset));
	}
	return;
}

static void hs_enumerate_scenario_data(
	short block_offset,
	short name_offset,
	long element_size)
{
	if (global_scenario_index != NONE)
	{
		struct tag_block const *block;

		block = (struct tag_block const *)((byte const *)global_scenario_get() + block_offset);
		hs_enumerate_block_data(block, name_offset, element_size);
	}
	return;
}

static void hs_enumerate_from_string_list(
	char const **names,
	short first,
	short last)
{
	short index;

	for (index = first; index<last; index++)
		hs_tokens_enumerate_add_string(names[index]);
	return;
}

static void hs_enumerate_special_form_names(
	void)
{
	hs_tokens_enumerate_add_string("script");
	hs_tokens_enumerate_add_string("global");
	return;
}

static void hs_enumerate_script_type_names(
	void)
{
	hs_enumerate_from_string_list(hs_script_type_names, 0, 5);
	return;
}

static void hs_enumerate_type_names(
	void)
{
	hs_enumerate_from_string_list(hs_type_names, 4, 49);
	return;
}

static void hs_enumerate_function_names(
	void)
{
	short function_index;

	for (function_index = 0; function_index<hs_function_table_count; function_index++)
		hs_tokens_enumerate_add_string(hs_function_get(function_index)->name);
	return;
}

static void hs_enumerate_script_names(
	void)
{
	hs_enumerate_scenario_data(offsetof(struct scenario, hs_scripts), 0, sizeof(struct hs_script));
	return;
}

static void hs_enumerate_variable_names(
	void)
{
	short global_index;

	for (global_index = 0; global_index<hs_external_global_count; global_index++)
		hs_tokens_enumerate_add_string(hs_global_external_get(global_index)->name);

	if (global_scenario_index != NONE)
	{
		struct scenario *scenario;
		struct tag_block const *globals;

		scenario = global_scenario_get();
		globals = &scenario->hs_globals;
		for (global_index = 0; global_index<globals->count; global_index++)
		{
			struct hs_global const *global;

			global = TAG_BLOCK_GET_ELEMENT(globals, global_index, struct hs_global);
			hs_tokens_enumerate_add_string(global->name);
		}
	}
	return;
}

static void hs_enumerate_ai_names(
	void)
{
	hs_enumerate_scenario_data(offsetof(struct scenario, ai_encounters), 0, sizeof(struct encounter_definition));
	return;
}

static void hs_enumerate_ai_command_list_names(
	void)
{
	hs_enumerate_scenario_data(offsetof(struct scenario, ai_command_lists), 0, sizeof(struct ai_command_list_definition));
	return;
}

static void hs_enumerate_starting_profile_names(
	void)
{
	hs_enumerate_scenario_data(offsetof(struct scenario, starting_profiles), 0, scenario_starting_profile_size);
	return;
}

static void hs_enumerate_conversation_names(
	void)
{
	hs_enumerate_scenario_data(offsetof(struct scenario, ai_conversations), 0, scenario_conversation_definition_size);
	return;
}

static void hs_enumerate_object_names(
	void)
{
	hs_enumerate_scenario_data(offsetof(struct scenario, object_names), 0, sizeof(struct scenario_object_name));
	return;
}

static void hs_enumerate_trigger_volume_names(
	void)
{
	hs_enumerate_scenario_data(offsetof(struct scenario, trigger_volumes), 4, sizeof(struct scenario_trigger_volume));
	return;
}

static void hs_enumerate_cutscene_flag_names(
	void)
{
	hs_enumerate_scenario_data(offsetof(struct scenario, cutscene_flags), 4, scenario_cutscene_flag_size);
	return;
}

static void hs_enumerate_cutscene_camera_point_names(
	void)
{
	hs_enumerate_scenario_data(offsetof(struct scenario, cutscene_camera_points), 4, sizeof(struct scenario_cutscene_camera_point));
	return;
}

static void hs_enumerate_cutscene_title_names(
	void)
{
	hs_enumerate_scenario_data(offsetof(struct scenario, cutscene_chapter_titles), 4, scenario_cutscene_chapter_title_size);
	return;
}

static void hs_enumerate_cutscene_recording_names(
	void)
{
	hs_enumerate_scenario_data(offsetof(struct scenario, recorded_animations), 0, sizeof(struct recorded_animation_definition));
	return;
}

static void hs_enumerate_navpoints(
	void)
{
	long hud_globals_index;

	hud_globals_index = interface_get_tag_index(_interface_hud_globals);
	if (hud_globals_index != NONE)
	{
		struct hud_globals_definition const *hud_globals;

		hud_globals = hud_globals_definition_get(
			interface_get_tag_index(_interface_hud_globals));
		hs_enumerate_block_data(
			&hud_globals->waypoint.arrows,
			0,
			sizeof(struct hud_waypoint_arrow_definition));
	}
	return;
}

static void hs_enumerate_hud_messages(
	void)
{
	if (global_scenario_get()->hud_messages.index != NONE)
	{
		struct hud_message_text_definition const *hud_messages;

		hud_messages = hud_message_text_definition_get(
			global_scenario_get()->hud_messages.index);
		hs_enumerate_block_data(&hud_messages->messages, 0, sizeof(struct hud_message_definition));
	}
	return;
}

static long alphabetize_file_references(
	struct file_reference const *left,
	struct file_reference const *right)
{
	char left_name[MAXIMUM_FILENAME_LENGTH+1];
	char right_name[MAXIMUM_FILENAME_LENGTH+1];

	file_reference_get_name(left, FLAG(_name_filename_bit), left_name);
	file_reference_get_name(right, FLAG(_name_filename_bit), right_name);
	return _stricmp(left_name, right_name);
}

static long alphabetize(
	char const **left,
	char const **right)
{
	return _stricmp(*left, *right);
}

/* port: in network co-op, once any player is safe (coop_scripts.c) */
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(game_safe_to_save_evaluate, coop_scripts_safe_to_save)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(game_all_quiet_evaluate, game_all_quiet)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(game_safe_to_speak_evaluate, game_safe_to_speak)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(game_is_cooperative_evaluate, game_is_cooperative)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(main_saving_map_evaluate, main_saving_map)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(game_state_reverted_evaluate, game_state_reverted)

HS_EVALUATE_NO_ARGUMENTS(hs_object_destroy_all_evaluate, hs_object_destroy_all)
HS_EVALUATE_NO_ARGUMENTS(numeric_countdown_timer_stop_evaluate, numeric_countdown_timer_stop)
HS_EVALUATE_NO_ARGUMENTS(numeric_countdown_timer_restart_evaluate, numeric_countdown_timer_restart)
HS_EVALUATE_NO_ARGUMENTS(objects_dump_memory_evaluate, objects_dump_memory)
HS_EVALUATE_NO_ARGUMENTS(garbage_collect_now_evaluate, garbage_collect_now)
HS_EVALUATE_NO_ARGUMENTS(object_pvs_clear_evaluate, object_pvs_clear)
HS_EVALUATE_NO_ARGUMENTS(breakable_surfaces_reset_evaluate, breakable_surfaces_reset)
HS_EVALUATE_NO_ARGUMENTS(cheat_all_powerups_evaluate, cheat_all_powerups)
HS_EVALUATE_NO_ARGUMENTS(cheat_all_weapons_evaluate, cheat_all_weapons)
HS_EVALUATE_NO_ARGUMENTS(cheat_all_vehicles_evaluate, cheat_all_vehicles)
HS_EVALUATE_NO_ARGUMENTS(cheat_teleport_to_camera_evaluate, cheat_teleport_to_camera)
HS_EVALUATE_NO_ARGUMENTS(cheat_active_camouflage_evaluate, cheat_active_camouflage)
HS_EVALUATE_NO_ARGUMENTS(scripting_magic_melee_attack_evaluate, scripting_magic_melee_attack)
HS_EVALUATE_NO_ARGUMENTS(cheats_load_evaluate, cheats_load)
HS_EVALUATE_NO_ARGUMENTS(ai_scripting_erase_all_evaluate, ai_scripting_erase_all)
HS_EVALUATE_NO_ARGUMENTS(ai_scripting_deselect_evaluate, ai_scripting_deselect)
HS_EVALUATE_NO_ARGUMENTS(ai_scripting_reconnect_evaluate, ai_scripting_reconnect)
HS_EVALUATE_NO_ARGUMENTS(director_save_camera_evaluate, director_save_camera)
HS_EVALUATE_NO_ARGUMENTS(director_load_camera_evaluate, director_load_camera)
HS_EVALUATE_NO_ARGUMENTS(players_unzoom_all_evaluate, players_unzoom_all)
HS_EVALUATE_NO_ARGUMENTS(player_control_action_test_reset_evaluate, player_control_action_test_reset)
HS_EVALUATE_NO_ARGUMENTS(main_reset_map_evaluate, main_reset_map)
HS_EVALUATE_NO_ARGUMENTS(main_print_version_evaluate, main_print_version)
HS_EVALUATE_NO_ARGUMENTS(main_set_game_connection_to_film_playback_evaluate, main_set_game_connection_to_film_playback)
HS_EVALUATE_NO_ARGUMENTS(texture_cache_flush_evaluate, texture_cache_flush)
HS_EVALUATE_NO_ARGUMENTS(sound_cache_flush_evaluate, sound_cache_flush)
HS_EVALUATE_NO_ARGUMENTS(debug_dump_memory_evaluate, debug_dump_memory)
HS_EVALUATE_NO_ARGUMENTS(debug_dump_memory_by_file_evaluate, debug_dump_memory_by_file)
HS_EVALUATE_NO_ARGUMENTS(profile_initialize_evaluate, profile_initialize)
HS_EVALUATE_NO_ARGUMENTS(ai_profile_change_render_spray_evaluate, ai_profile_change_render_spray)
HS_EVALUATE_NO_ARGUMENTS(ai_debug_sound_point_set_evaluate, ai_debug_sound_point_set)
HS_EVALUATE_NO_ARGUMENTS(cinematic_start_evaluate, cinematic_start)
HS_EVALUATE_NO_ARGUMENTS(cinematic_stop_evaluate, cinematic_stop)
HS_EVALUATE_NO_ARGUMENTS(cinematic_skip_start_evaluate, cinematic_skip_start)
HS_EVALUATE_NO_ARGUMENTS(cinematic_skip_stop_evaluate, cinematic_skip_stop)
HS_EVALUATE_NO_ARGUMENTS(attract_mode_start_evaluate, attract_mode_start)
HS_EVALUATE_NO_ARGUMENTS(main_won_map_evaluate, main_won_map)
HS_EVALUATE_NO_ARGUMENTS(main_lost_map_evaluate, main_lost_map)
HS_EVALUATE_NO_ARGUMENTS(main_save_map_safe_evaluate, main_save_map_safe)
HS_EVALUATE_NO_ARGUMENTS(main_save_cancel_evaluate, main_save_cancel)
HS_EVALUATE_NO_ARGUMENTS(main_save_map_no_timeout_evaluate, main_save_map_no_timeout)
HS_EVALUATE_NO_ARGUMENTS(main_save_map_nonsafe_evaluate, main_save_map_nonsafe)
HS_EVALUATE_NO_ARGUMENTS(main_revert_map_evaluate, main_revert_map)
HS_EVALUATE_NO_ARGUMENTS(main_load_core_evaluate, main_load_core)
HS_EVALUATE_NO_ARGUMENTS(main_load_core_at_startup_evaluate, main_load_core_at_startup)
HS_EVALUATE_NO_ARGUMENTS(main_save_core_evaluate, main_save_core)
HS_EVALUATE_NO_ARGUMENTS(scripted_hud_restart_flashing_evaluate, scripted_hud_restart_flashing)
HS_EVALUATE_NO_ARGUMENTS(terminal_clear_evaluate, terminal_clear)
HS_EVALUATE_NO_ARGUMENTS(structure_lens_flares_place_evaluate, structure_lens_flares_place)
HS_EVALUATE_NO_ARGUMENTS(scripted_hud_messages_clear_evaluate, scripted_hud_messages_clear)
HS_EVALUATE_NO_ARGUMENTS(scripted_hud_time_code_reset_evaluate, scripted_hud_time_code_reset)
HS_EVALUATE_NO_ARGUMENTS(rasterizer_decals_flush_evaluate, rasterizer_decals_flush)
HS_EVALUATE_NO_ARGUMENTS(rasterizer_fps_accumulate_evaluate, rasterizer_fps_accumulate)
HS_EVALUATE_NO_ARGUMENTS(rasterizer_lights_reset_for_new_map_evaluate, rasterizer_lights_reset_for_new_map)
HS_EVALUATE_NO_ARGUMENTS(rasterizer_screen_effect_stop_evaluate, rasterizer_screen_effect_stop)
HS_EVALUATE_NO_ARGUMENTS(enumerate_memory_units_test_evaluate, enumerate_memory_units_test)
HS_EVALUATE_NO_ARGUMENTS(saved_game_files_delete_all_custom_profiles_evaluate, saved_game_files_delete_all_custom_profiles)
HS_EVALUATE_NO_ARGUMENTS(player_ui_fast_setup_network_server_evaluate, player_ui_fast_setup_network_server)
HS_EVALUATE_NO_ARGUMENTS(player_ui_activate_all_solo_levels_evaluate, player_ui_activate_all_solo_levels)
HS_EVALUATE_NO_ARGUMENTS(network_game_client_request_immediate_start_evaluate, network_game_client_request_immediate_start)
HS_EVALUATE_NO_ARGUMENTS(hs_doc_evaluate, hs_doc)
HS_EVALUATE_NO_OP(tag_groups_dump_memory_evaluate)
HS_EVALUATE_NO_OP(radiosity_hack_start_evaluate)
HS_EVALUATE_NO_OP(radiosity_hack_save_evaluate)
HS_EVALUATE_NO_OP(radiosity_hack_find_point_evaluate)
HS_EVALUATE_RETURN_LONG(hs_players_evaluate, hs_players)
HS_EVALUATE_RETURN_LONG(game_time_get_evaluate, game_time_get)
HS_EVALUATE_RETURN_SHORT(scripted_camera_time_evaluate, scripted_camera_time)
HS_EVALUATE_RETURN_SHORT(game_difficulty_level_get_ignore_easy_evaluate, game_difficulty_level_get_ignore_easy)
HS_EVALUATE_RETURN_SHORT(game_difficulty_level_get_evaluate, game_difficulty_level_get)
HS_EVALUATE_RETURN_SHORT(global_structure_bsp_index_get_evaluate, global_structure_bsp_index_get)
HS_EVALUATE_RETURN_SHORT(scripted_hud_get_timer_ticks_evaluate, scripted_hud_get_timer_ticks)
HS_EVALUATE_SHORT_FROM_LONG(object_list_count_evaluate, object_list_count)
HS_EVALUATE_SHORT_FROM_UNSIGNED_SHORT(numeric_countdown_timer_get_evaluate, numeric_countdown_timer_get)
HS_EVALUATE_SHORT_FROM_LONG(recorded_animation_get_time_left_evaluate, recorded_animation_get_time_left)
HS_EVALUATE_SHORT_FROM_LONG(scenery_get_animation_time_evaluate, scenery_get_animation_time)
HS_EVALUATE_SHORT_FROM_LONG(unit_get_custom_animation_time_evaluate, unit_get_custom_animation_time)
HS_EVALUATE_SHORT_FROM_LONG(unit_scripting_get_grenade_count_evaluate, unit_scripting_get_grenade_count)
HS_EVALUATE_SHORT_FROM_LONG(ai_scripting_command_list_status_evaluate, ai_scripting_command_list_status)
HS_EVALUATE_SHORT_FROM_LONG(ai_scripting_going_to_vehicle_evaluate, ai_scripting_going_to_vehicle)
HS_EVALUATE_SHORT_FROM_LONG(ai_scripting_living_count_evaluate, ai_scripting_living_count)
HS_EVALUATE_SHORT_FROM_LONG(ai_scripting_swarm_count_evaluate, ai_scripting_swarm_count)
HS_EVALUATE_SHORT_FROM_LONG(ai_scripting_nonswarm_count_evaluate, ai_scripting_nonswarm_count)
HS_EVALUATE_SHORT_FROM_LONG(ai_scripting_status_evaluate, ai_scripting_status)
HS_EVALUATE_SHORT_FROM_UNSIGNED_SHORT(ai_scripting_conversation_line_evaluate, ai_scripting_conversation_line)
HS_EVALUATE_SHORT_FROM_UNSIGNED_SHORT(ai_scripting_conversation_status_evaluate, ai_scripting_conversation_status)
HS_EVALUATE_RETURN_SHORT_FROM_ARGUMENTS(vehicle_scripting_load_magic_evaluate, struct hs_arguments_long_long_long, (vehicle_scripting_load_magic(arguments->value0, arguments->value1, arguments->value2)))
HS_EVALUATE_RETURN_SHORT_FROM_ARGUMENTS(vehicle_scripting_unload_evaluate, struct hs_arguments_long_long, (vehicle_scripting_unload(arguments->value0, (char const *)arguments->value1)))
HS_EVALUATE_LONG_FROM_LONG(unit_scripting_unit_riders_evaluate, unit_scripting_unit_riders)
HS_EVALUATE_LONG_FROM_LONG(unit_scripting_unit_driver_evaluate, unit_scripting_unit_driver)
HS_EVALUATE_LONG_FROM_LONG(unit_scripting_unit_gunner_evaluate, unit_scripting_unit_gunner)
HS_EVALUATE_LONG_FROM_LONG(object_list_from_ai_reference_evaluate, object_list_from_ai_reference)
HS_EVALUATE_LONG_FROM_LONG(scripted_sound_time_evaluate, scripted_sound_time)
HS_EVALUATE_VOID_LONG(hs_object_destroy_evaluate, hs_object_destroy)
HS_EVALUATE_VOID_LONG(recorded_animation_kill_evaluate, recorded_animation_kill)
HS_EVALUATE_VOID_LONG(object_cannot_take_damage_evaluate, object_cannot_take_damage)
HS_EVALUATE_VOID_LONG(object_can_take_damage_evaluate, object_can_take_damage)
HS_EVALUATE_VOID_LONG(hs_objects_predict_evaluate, hs_objects_predict)
HS_EVALUATE_VOID_LONG(object_definition_predict_evaluate, object_definition_predict)
HS_EVALUATE_VOID_LONG(object_pvs_set_object_evaluate, object_pvs_set_object)
HS_EVALUATE_VOID_LONG(object_pvs_activate_evaluate, object_pvs_activate)
HS_EVALUATE_VOID_LONG(unit_open_evaluate, unit_open)
HS_EVALUATE_VOID_LONG(unit_close_evaluate, unit_close)
HS_EVALUATE_VOID_LONG(unit_kill_evaluate, unit_kill)
HS_EVALUATE_VOID_LONG(unit_kill_silent_evaluate, unit_kill_silent)
HS_EVALUATE_VOID_LONG(unit_stop_custom_animation_evaluate, unit_stop_custom_animation)
HS_EVALUATE_VOID_LONG(unit_scripting_exit_vehicle_evaluate, unit_scripting_exit_vehicle)
HS_EVALUATE_VOID_LONG(unit_scripting_doesnt_drop_items_evaluate, unit_scripting_doesnt_drop_items)
HS_EVALUATE_VOID_LONG(ai_scripting_free_evaluate, ai_scripting_free)
HS_EVALUATE_VOID_LONG(ai_scripting_free_units_evaluate, ai_scripting_free_units)
HS_EVALUATE_VOID_LONG(ai_scripting_detach_unit_evaluate, ai_scripting_detach_unit)
HS_EVALUATE_VOID_LONG(ai_scripting_detach_units_evaluate, ai_scripting_detach_units)
HS_EVALUATE_VOID_LONG(ai_scripting_place_evaluate, ai_scripting_place)
HS_EVALUATE_VOID_LONG(ai_scripting_kill_evaluate, ai_scripting_kill)
HS_EVALUATE_VOID_LONG(ai_scripting_kill_silent_evaluate, ai_scripting_kill_silent)
HS_EVALUATE_VOID_LONG(ai_scripting_erase_evaluate, ai_scripting_erase)
HS_EVALUATE_VOID_LONG(ai_scripting_select_evaluate, ai_scripting_select)
HS_EVALUATE_VOID_LONG(ai_scripting_spawn_actor_evaluate, ai_scripting_spawn_actor)
HS_EVALUATE_VOID_LONG(ai_scripting_magically_see_players_evaluate, ai_scripting_magically_see_players)
HS_EVALUATE_VOID_LONG(ai_scripting_timer_start_evaluate, ai_scripting_timer_start)
HS_EVALUATE_VOID_LONG(ai_scripting_timer_expire_evaluate, ai_scripting_timer_expire)
HS_EVALUATE_VOID_LONG(ai_scripting_attack_evaluate, ai_scripting_attack)
HS_EVALUATE_VOID_LONG(ai_scripting_defend_evaluate, ai_scripting_defend)
HS_EVALUATE_VOID_LONG(ai_scripting_retreat_evaluate, ai_scripting_retreat)
HS_EVALUATE_VOID_UNSIGNED_SHORT(hs_object_create_evaluate, hs_object_create)
HS_EVALUATE_VOID_UNSIGNED_SHORT(hs_object_create_anew_evaluate, hs_object_create_anew)
HS_EVALUATE_VOID_UNSIGNED_SHORT(object_pvs_set_camera_point_evaluate, object_pvs_set_camera_point)
HS_EVALUATE_VOID_UNSIGNED_SHORT(cheat_active_camouflage_local_player_evaluate, cheat_active_camouflage_local_player)
HS_EVALUATE_VOID_BOOLEAN(breakable_surfaces_enable_evaluate, breakable_surfaces_enable)
HS_EVALUATE_VOID_BOOLEAN(render_effects_evaluate, render_effects)
HS_EVALUATE_VOID_BOOLEAN(ai_globals_ai_active_evaluate, ai_globals_ai_active)
HS_EVALUATE_VOID_BOOLEAN(ai_globals_dialogue_triggers_enabled_evaluate, ai_globals_dialogue_triggers_enabled)
HS_EVALUATE_VOID_BOOLEAN(ai_globals_grenades_enabled_evaluate, ai_globals_grenades_enabled)
HS_EVALUATE_VOID_STRING(hs_print_evaluate, hs_print)
HS_EVALUATE_VOID_STRING(hs_object_create_containing_evaluate, hs_object_create_containing)
HS_EVALUATE_VOID_STRING(hs_object_create_anew_containing_evaluate, hs_object_create_anew_containing)
HS_EVALUATE_VOID_STRING(hs_object_destroy_containing_evaluate, hs_object_destroy_containing)
HS_EVALUATE_VOID_LONG(hs_objects_delete_by_definition_evaluate, hs_objects_delete_by_definition)
HS_EVALUATE_VOID_STRING(scripting_set_magic_base_seat_evaluate, scripting_set_magic_base_seat)
HS_EVALUATE_VOID_LONG_BOOLEAN(object_set_ranged_attack_inhibited_evaluate, object_set_ranged_attack_inhibited)
HS_EVALUATE_VOID_LONG_BOOLEAN(object_set_melee_attack_inhibited_evaluate, object_set_melee_attack_inhibited)
HS_EVALUATE_VOID_LONG_BOOLEAN(object_scripting_set_collideable_evaluate, object_scripting_set_collideable)
HS_EVALUATE_VOID_LONG_BOOLEAN(unit_scripting_can_blink_evaluate, unit_scripting_can_blink)
HS_EVALUATE_VOID_LONG_BOOLEAN(unit_aim_without_turning_evaluate, unit_aim_without_turning)
HS_EVALUATE_VOID_LONG_BOOLEAN(unit_set_enterable_by_player_evaluate, unit_set_enterable_by_player)
HS_EVALUATE_VOID_LONG_BOOLEAN(unit_scripting_impervious_evaluate, unit_scripting_impervious)
HS_EVALUATE_VOID_LONG_BOOLEAN(unit_scripting_suspended_evaluate, unit_scripting_suspended)
HS_EVALUATE_VOID_LONG_BOOLEAN(units_set_desired_flashlight_state_evaluate, units_set_desired_flashlight_state)
HS_EVALUATE_VOID_LONG_BOOLEAN(unit_set_desired_flashlight_state_evaluate, unit_set_desired_flashlight_state)
HS_EVALUATE_VOID_LONG_BOOLEAN(device_set_never_appears_locked_evaluate, device_set_never_appears_locked)
HS_EVALUATE_VOID_LONG_BOOLEAN(device_one_sided_set_evaluate, device_one_sided_set)
HS_EVALUATE_VOID_LONG_BOOLEAN(device_operates_automatically_set_evaluate, device_operates_automatically_set)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_set_respawn_evaluate, ai_scripting_set_respawn)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_set_deaf_evaluate, ai_scripting_set_deaf)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_set_blind_evaluate, ai_scripting_set_blind)
HS_EVALUATE_VOID_LONG_LONG(hs_damage_object_evaluate, hs_damage_object)
HS_EVALUATE_VOID_LONG_LONG(objects_scripting_detach_evaluate, objects_scripting_detach)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_attach_unit_evaluate, ai_scripting_attach_unit)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_attach_units_evaluate, ai_scripting_attach_units)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_attach_free_evaluate, ai_scripting_attach_free)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_magically_see_encounter_evaluate, ai_scripting_magically_see_encounter)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_magically_see_unit_evaluate, ai_scripting_magically_see_unit)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_magically_see_units_evaluate, ai_scripting_magically_see_units)
HS_EVALUATE_VOID_LONG_UNSIGNED_SHORT(hs_object_teleport_evaluate, hs_object_teleport)
HS_EVALUATE_VOID_LONG_UNSIGNED_SHORT(hs_object_set_facing_evaluate, hs_object_set_facing)
HS_EVALUATE_VOID_LONG_UNSIGNED_SHORT(hs_effect_new_evaluate, hs_effect_new)
HS_EVALUATE_VOID_LONG_UNSIGNED_SHORT(hs_damage_new_evaluate, hs_damage_new)
HS_EVALUATE_VOID_LONG_BOOLEAN(numeric_countdown_timer_set_evaluate, numeric_countdown_timer_set)
HS_EVALUATE_VOID_LONG_STRING(unit_scripting_set_emotion_animation_evaluate, unit_scripting_set_emotion_animation)
HS_EVALUATE_VOID_LONG_STRING(unit_scripting_set_seat_evaluate, unit_scripting_set_seat)
HS_EVALUATE_VOID_SHORT_BOOLEAN(device_group_change_only_once_more_set_evaluate, device_group_change_only_once_more_set)
HS_EVALUATE_VOID_LONG_UNSIGNED_SHORT(unit_set_emotion_evaluate, unit_set_emotion)
HS_EVALUATE_VOID_LONG_LONG_STRING(unit_scripting_enter_vehicle_evaluate, unit_scripting_enter_vehicle)

HS_EVALUATE_VOID_FROM_ARGUMENTS(
	hs_teleport_players_not_in_trigger_volume_evaluate,
	struct hs_arguments_short_word,
	hs_teleport_players_not_in_trigger_volume(arguments->value0, arguments->value1))
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	hs_object_set_shield_evaluate,
	union hs_evaluation_argument,
	1,
	hs_object_set_shield(arguments[0].long_value, real_argument))
HS_EVALUATE_VOID_FROM_ARGUMENTS(
	hs_object_set_permutation_evaluate,
	struct hs_arguments_long_string_string,
	hs_object_set_permutation(arguments->value0, arguments->value1, arguments->value2))
HS_EVALUATE_VOID_FROM_ARGUMENTS(
	hs_effect_new_from_object_marker_evaluate,
	struct hs_arguments_long_long_string,
	hs_effect_new_from_object_marker(arguments->value0, arguments->value1, arguments->value2))
static void hs_objects_can_see_object_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	union hs_evaluation_argument const *arguments;
	union hs_boolean_result result;

	result.value = 0;
	arguments = (union hs_evaluation_argument const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double degrees = arguments[2].real_value;

		result.boolean = hs_objects_can_see_object(arguments[0].long_value, arguments[1].long_value, degrees);
		hs_return(thread_index, result.value);
	}

	return;
}
static void hs_objects_can_see_flag_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	union hs_evaluation_argument const *arguments;
	union hs_boolean_result result;

	result.value = 0;
	arguments = (union hs_evaluation_argument const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double degrees = arguments[2].real_value;

		result.boolean = hs_objects_can_see_flag(arguments[0].long_value, arguments[1].unsigned_short_value, degrees);
		hs_return(thread_index, result.value);
	}

	return;
}
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	hs_sound_set_gain_evaluate,
	union hs_evaluation_argument,
	1,
	hs_sound_set_gain(arguments[0].string_value, real_argument))
static void objects_scripting_set_scale_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_long_real_word const *arguments;

	arguments = (struct hs_arguments_long_real_word const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;

		objects_scripting_set_scale(arguments->value0, value1, arguments->value2);
		hs_return(thread_index, 0);
	}

	return;
}
HS_EVALUATE_VOID_FROM_ARGUMENTS(
	objects_scripting_attach_evaluate,
	struct hs_arguments_long_string_long_string,
	objects_scripting_attach(arguments->value0, arguments->value1, arguments->value2, arguments->value3))
HS_EVALUATE_VOID_LONG_BOOLEAN(object_beautify_evaluate, object_beautify)
HS_EVALUATE_VOID_FROM_ARGUMENTS(
	scenery_animation_start_evaluate,
	struct hs_arguments_long_long_string,
	scenery_animation_start(arguments->value0, arguments->value1, arguments->value2))
HS_EVALUATE_VOID_FROM_ARGUMENTS(
	scenery_animation_start_at_frame_evaluate,
	struct hs_arguments_long_long_string_word,
	scenery_animation_start_at_frame(arguments->value0, arguments->value1, arguments->value2, arguments->value3))
static void unit_scripting_set_maximum_vitality_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_long_real_real const *arguments;

	arguments = (struct hs_arguments_long_real_real const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;
		double value2 = arguments->value2;

		unit_scripting_set_maximum_vitality(arguments->value0, value1, value2);
		hs_return(thread_index, 0);
	}

	return;
}
static void units_scripting_set_maximum_vitality_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_long_real_real const *arguments;

	arguments = (struct hs_arguments_long_real_real const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;
		double value2 = arguments->value2;

		units_scripting_set_maximum_vitality(arguments->value0, value1, value2);
		hs_return(thread_index, 0);
	}

	return;
}
static void unit_scripting_set_current_vitality_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_long_real_real const *arguments;

	arguments = (struct hs_arguments_long_real_real const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;
		double value2 = arguments->value2;

		unit_scripting_set_current_vitality(arguments->value0, value1, value2);
		hs_return(thread_index, 0);
	}

	return;
}
static void units_scripting_set_current_vitality_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_long_real_real const *arguments;

	arguments = (struct hs_arguments_long_real_real const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;
		double value2 = arguments->value2;

		units_scripting_set_current_vitality(arguments->value0, value1, value2);
		hs_return(thread_index, 0);
	}

	return;
}
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	device_set_power_evaluate,
	union hs_evaluation_argument,
	1,
	device_set_power(arguments[0].long_value, real_argument))
static void device_set_desired_position_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	union hs_evaluation_argument const *arguments;
	union hs_boolean_result result;

	result.value = 0;
	arguments = (union hs_evaluation_argument const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double position = arguments[1].real_value;

		result.boolean = device_set_desired_position(arguments[0].long_value, position);
		hs_return(thread_index, result.value);
	}

	return;
}
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	device_set_actual_position_evaluate,
	union hs_evaluation_argument,
	1,
	device_set_actual_position(arguments[0].long_value, real_argument))
static void device_group_set_desired_value_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	union hs_evaluation_argument const *arguments;
	union hs_boolean_result result;

	result.value = 0;
	arguments = (union hs_evaluation_argument const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double desired_value = arguments[1].real_value;

		result.boolean = device_group_set_desired_value(arguments[0].short_value, desired_value);
		hs_return(thread_index, result.value);
	}

	return;
}
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	device_group_set_actual_value_evaluate,
	union hs_evaluation_argument,
	1,
	device_group_set_actual_value(arguments[0].short_value, real_argument))
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	ai_scripting_vehicle_enterable_distance_evaluate,
	union hs_evaluation_argument,
	1,
	ai_scripting_vehicle_enterable_distance(arguments[0].long_value, real_argument))
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	ai_scripting_follow_distance_evaluate,
	union hs_evaluation_argument,
	1,
	ai_scripting_follow_distance(arguments[0].long_value, real_argument))
static void player_effect_screen_fade_in_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_real_real_real_word const *arguments;

	arguments = (struct hs_arguments_real_real_real_word const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;
		double value2 = arguments->value2;

#if defined(HALO_ARM64_GUEST) || defined(HALO_ANDROID_ARMV7) /* port */
		player_effect_screen_fade_in(*(real const *)&arguments->value0, (real)value1, (real)value2, arguments->value3);
#else
		player_effect_screen_fade_in(arguments->value0, value1, value2, arguments->value3);
#endif
		hs_return(thread_index, 0);
	}

	return;
}
static void player_effect_screen_fade_out_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_real_real_real_word const *arguments;

	arguments = (struct hs_arguments_real_real_real_word const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;
		double value2 = arguments->value2;

#if defined(HALO_ARM64_GUEST) || defined(HALO_ANDROID_ARMV7) /* port */
		player_effect_screen_fade_out(*(real const *)&arguments->value0, (real)value1, (real)value2, arguments->value3);
#else
		player_effect_screen_fade_out(arguments->value0, value1, value2, arguments->value3);
#endif
		hs_return(thread_index, 0);
	}

	return;
}
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	cinematic_set_title_delayed_evaluate,
	union hs_evaluation_argument,
	1,
	cinematic_set_title_delayed(arguments[0].short_value, real_argument))
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	scripted_sound_new_evaluate,
	union hs_evaluation_argument,
	2,
	scripted_sound_new(arguments[0].long_value, arguments[1].long_value, real_argument))
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	scripted_looping_sound_start_evaluate,
	union hs_evaluation_argument,
	2,
	scripted_looping_sound_start(arguments[0].long_value, arguments[1].long_value, real_argument))
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	scripted_looping_sound_set_scale_evaluate,
	union hs_evaluation_argument,
	1,
	scripted_looping_sound_set_scale(arguments[0].long_value, real_argument))
static void debug_sound_classes_set_distances_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_long_real_real const *arguments;

	arguments = (struct hs_arguments_long_real_real const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;
		double value2 = arguments->value2;

		debug_sound_classes_set_distances((char const *)arguments->value0, value1, value2);
		hs_return(thread_index, 0);
	}

	return;
}
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	debug_sound_classes_set_wet_evaluate,
	union hs_evaluation_argument,
	1,
	debug_sound_classes_set_wet((char const *)arguments[0].long_value, real_argument))
static void sound_class_set_gain_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_long_real_word const *arguments;

	arguments = (struct hs_arguments_long_real_word const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;

		sound_class_set_gain((char const *)arguments->value0, value1, arguments->value2);
		hs_return(thread_index, 0);
	}

	return;
}
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	hud_unit_activate_nav_point_with_flag_evaluate,
	union hs_evaluation_argument,
	3,
	hud_unit_activate_nav_point_with_flag(arguments[0].unsigned_short_value, arguments[1].long_value, arguments[2].unsigned_short_value, real_argument))
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	hud_unit_activate_nav_point_with_object_evaluate,
	union hs_evaluation_argument,
	3,
	hud_unit_activate_nav_point_with_object(arguments[0].unsigned_short_value, arguments[1].long_value, arguments[2].long_value, real_argument))
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	hud_activate_team_nav_point_with_flag_evaluate,
	union hs_evaluation_argument,
	3,
	hud_activate_team_nav_point_with_flag(arguments[0].unsigned_short_value, arguments[1].unsigned_short_value, arguments[2].unsigned_short_value, real_argument))
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	hud_activate_team_nav_point_with_object_evaluate,
	union hs_evaluation_argument,
	3,
	hud_activate_team_nav_point_with_object(arguments[0].unsigned_short_value, arguments[1].unsigned_short_value, arguments[2].long_value, real_argument))
static void scripted_player_effect_set_translation_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_real_real_real const *arguments;

	arguments = (struct hs_arguments_real_real_real const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;
		double value2 = arguments->value2;

		scripted_player_effect_set_translation(arguments->value0, value1, value2);
		hs_return(thread_index, 0);
	}

	return;
}
static void scripted_player_effect_set_rotation_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_real_real_real const *arguments;

	arguments = (struct hs_arguments_real_real_real const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;
		double value2 = arguments->value2;

		scripted_player_effect_set_rotation(arguments->value0, value1, value2);
		hs_return(thread_index, 0);
	}

	return;
}
static void scripted_player_effect_set_rumble_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_real_real const *arguments;

	arguments = (struct hs_arguments_real_real const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;

		scripted_player_effect_set_rumble(arguments->value0, value1);
		hs_return(thread_index, 0);
	}

	return;
}
static void scripted_player_effect_start_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_real_real const *arguments;

	arguments = (struct hs_arguments_real_real const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;

		scripted_player_effect_start(arguments->value0, value1);
		hs_return(thread_index, 0);
	}

	return;
}
static void rasterizer_model_ambient_reflection_tint_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_real_real_real_real const *arguments;

	arguments = (struct hs_arguments_real_real_real_real const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;
		double value2 = arguments->value2;
		double value3 = arguments->value3;

		rasterizer_model_ambient_reflection_tint(arguments->value0, value1, value2, value3);
		hs_return(thread_index, 0);
	}

	return;
}
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	rasterizer_script_screen_effect_set_value_evaluate,
	union hs_evaluation_argument,
	1,
	rasterizer_script_screen_effect_set_value(arguments[0].unsigned_short_value, real_argument))
static void rasterizer_screen_effect_set_convolution_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_short_word_real_real_real const *arguments;

	arguments = (struct hs_arguments_short_word_real_real_real const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		real value2 = arguments->value2;
		real value3 = arguments->value3;
		real value4 = arguments->value4;

		rasterizer_screen_effect_set_convolution(arguments->value0, arguments->value1, value2, value3, value4);
		hs_return(thread_index, 0);
	}

	return;
}
static void rasterizer_screen_effect_set_filter_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_real_real_real_real_boolean_real const *arguments;

	arguments = (struct hs_arguments_real_real_real_real_boolean_real const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;
		double value2 = arguments->value2;
		double value3 = arguments->value3;
		double value5 = arguments->value5;

		rasterizer_screen_effect_set_filter(arguments->value0, value1, value2, value3, arguments->value4, value5);
		hs_return(thread_index, 0);
	}

	return;
}
static void rasterizer_screen_effect_set_filter_desaturation_tint_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_real_real_real const *arguments;

	arguments = (struct hs_arguments_real_real_real const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double value1 = arguments->value1;
		double value2 = arguments->value2;

		rasterizer_screen_effect_set_filter_desaturation_tint(arguments->value0, value1, value2);
		hs_return(thread_index, 0);
	}

	return;
}
HS_EVALUATE_VOID_FROM_ARGUMENTS_WITH_REAL(
	rasterizer_screen_effect_set_video_evaluate,
	union hs_evaluation_argument,
	1,
	rasterizer_screen_effect_set_video(arguments[0].unsigned_short_value, real_argument))

static void hs_object_list_get_element_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_object_list_get_element_arguments *arguments;

	arguments = (struct hs_object_list_get_element_arguments *)hs_macro_function_evaluate(
		function_index, thread_index, initialize);
	if (arguments)
	{
		hs_return(
			thread_index,
			hs_object_list_get_element(arguments->object_list_index, arguments->element_index));
	}

	return;
}

static void hs_sound_get_gain_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	union hs_evaluation_argument *arguments = (union hs_evaluation_argument *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		union hs_real_value result;
		result.real_value = hs_sound_get_gain(arguments[0].string_value);
		hs_return(thread_index, result.long_value);
	}
	return;
}
HS_EVALUATE_REAL_FROM_LONG(unit_scripting_get_health_evaluate, unit_scripting_get_health)
HS_EVALUATE_REAL_FROM_LONG(unit_scripting_get_shield_evaluate, unit_scripting_get_shield)
HS_EVALUATE_REAL_FROM_LONG(device_get_power_evaluate, device_get_power)
HS_EVALUATE_REAL_FROM_LONG(device_get_position_evaluate, device_get_position)
HS_EVALUATE_REAL_FROM_UNSIGNED_SHORT(device_group_get_value_evaluate, device_group_get_value)
HS_EVALUATE_REAL_FROM_LONG(ai_scripting_living_fraction_evaluate, ai_scripting_living_fraction)
HS_EVALUATE_REAL_FROM_LONG(ai_scripting_strength_evaluate, ai_scripting_strength)
HS_EVALUATE_VOID_LONG(ai_scripting_maneuver_evaluate, ai_scripting_maneuver)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_maneuver_enable_evaluate, ai_scripting_maneuver_enable)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_migrate_evaluate, ai_scripting_migrate)
HS_EVALUATE_VOID_LONG_LONG_STRING(ai_scripting_migrate_and_speak_evaluate, ai_scripting_migrate_and_speak)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_migrate_by_unit_evaluate, ai_scripting_migrate_by_unit)
HS_EVALUATE_VOID_SHORT_SHORT(ai_scripting_allegiance_evaluate, ai_scripting_allegiance)
HS_EVALUATE_VOID_SHORT_SHORT(ai_scripting_allegiance_remove_evaluate, ai_scripting_allegiance_remove)
HS_EVALUATE_VOID_LONG_LONG_STRING(ai_scripting_go_to_vehicle_evaluate, ai_scripting_go_to_vehicle)
HS_EVALUATE_VOID_LONG_LONG_STRING(ai_scripting_go_to_vehicle_override_evaluate, ai_scripting_go_to_vehicle_override)
HS_EVALUATE_VOID_LONG(ai_scripting_exit_vehicle_evaluate, ai_scripting_exit_vehicle)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_braindead_evaluate, ai_scripting_braindead)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_braindead_by_unit_evaluate, ai_scripting_braindead_by_unit)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_ignore_evaluate, ai_scripting_ignore)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_prefer_target_evaluate, ai_scripting_prefer_target)
HS_EVALUATE_VOID_LONG(ai_scripting_teleport_starting_location_evaluate, ai_scripting_teleport_starting_location)
HS_EVALUATE_VOID_LONG(ai_scripting_teleport_starting_location_if_unsupported_evaluate, ai_scripting_teleport_starting_location_if_unsupported)
HS_EVALUATE_VOID_LONG(ai_scripting_renew_evaluate, ai_scripting_renew)
HS_EVALUATE_VOID_LONG(ai_scripting_try_to_fight_nothing_evaluate, ai_scripting_try_to_fight_nothing)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_try_to_fight_evaluate, ai_scripting_try_to_fight)
HS_EVALUATE_VOID_LONG(ai_scripting_try_to_fight_player_evaluate, ai_scripting_try_to_fight_player)
HS_EVALUATE_VOID_LONG_UNSIGNED_SHORT(ai_scripting_command_list_evaluate, ai_scripting_command_list)
HS_EVALUATE_VOID_LONG_UNSIGNED_SHORT(ai_scripting_command_list_by_unit_evaluate, ai_scripting_command_list_by_unit)
HS_EVALUATE_VOID_LONG(ai_scripting_command_list_advance_evaluate, ai_scripting_command_list_advance)
HS_EVALUATE_VOID_LONG(ai_scripting_command_list_advance_by_unit_evaluate, ai_scripting_command_list_advance_by_unit)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_force_active_evaluate, ai_scripting_force_active)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_force_active_by_unit_evaluate, ai_scripting_force_active_by_unit)
HS_EVALUATE_VOID_LONG_UNSIGNED_SHORT(ai_scripting_set_return_state_evaluate, ai_scripting_set_return_state)
HS_EVALUATE_VOID_LONG_UNSIGNED_SHORT(ai_scripting_set_current_state_evaluate, ai_scripting_set_current_state)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_playfight_evaluate, ai_scripting_playfight)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_vehicle_encounter_evaluate, ai_scripting_vehicle_encounter)
HS_EVALUATE_VOID_LONG_UNSIGNED_SHORT(ai_scripting_vehicle_enterable_team_evaluate, ai_scripting_vehicle_enterable_team)
HS_EVALUATE_VOID_LONG_UNSIGNED_SHORT(ai_scripting_vehicle_enterable_actor_type_evaluate, ai_scripting_vehicle_enterable_actor_type)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_vehicle_enterable_actors_evaluate, ai_scripting_vehicle_enterable_actors)
HS_EVALUATE_VOID_LONG(ai_scripting_vehicle_enterable_disable_evaluate, ai_scripting_vehicle_enterable_disable)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_look_at_object_evaluate, ai_scripting_look_at_object)
HS_EVALUATE_VOID_LONG(ai_scripting_stop_looking_evaluate, ai_scripting_stop_looking)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_automatic_migration_target_evaluate, ai_scripting_automatic_migration_target)
HS_EVALUATE_VOID_LONG(ai_scripting_follow_target_disable_evaluate, ai_scripting_follow_target_disable)
HS_EVALUATE_VOID_LONG(ai_scripting_follow_target_players_evaluate, ai_scripting_follow_target_players)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_follow_target_unit_evaluate, ai_scripting_follow_target_unit)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_follow_target_ai_evaluate, ai_scripting_follow_target_ai)
HS_EVALUATE_VOID_UNSIGNED_SHORT(ai_scripting_conversation_stop_evaluate, ai_scripting_conversation_stop)
HS_EVALUATE_VOID_UNSIGNED_SHORT(ai_scripting_conversation_advance_evaluate, ai_scripting_conversation_advance)
HS_EVALUATE_VOID_LONG_LONG(ai_scripting_link_activation_evaluate, ai_scripting_link_activation)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_berserk_evaluate, ai_scripting_berserk)
HS_EVALUATE_VOID_LONG_UNSIGNED_SHORT(ai_scripting_set_team_evaluate, ai_scripting_set_team)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_allow_charge_evaluate, ai_scripting_allow_charge)
HS_EVALUATE_VOID_LONG_BOOLEAN(ai_scripting_allow_dormant_evaluate, ai_scripting_allow_dormant)
HS_EVALUATE_VOID_FROM_ARGUMENTS(director_script_camera_evaluate, struct hs_arguments_boolean, (director_script_camera(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_camera_set_absolute_evaluate, struct hs_arguments_short_word, (scripted_camera_set_absolute(arguments->value0, arguments->value1)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_camera_set_evaluate, struct hs_arguments_word_word_long, (scripted_camera_set(arguments->value0, arguments->value1, arguments->value2)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_camera_set_animation_evaluate, struct hs_arguments_long_string, (scripted_camera_set_animation(arguments->value0, arguments->value1)))
HS_EVALUATE_VOID_LONG(scripted_camera_set_first_person_evaluate, scripted_camera_set_first_person)
HS_EVALUATE_VOID_LONG(scripted_camera_set_dead_evaluate, scripted_camera_set_dead)
HS_EVALUATE_VOID_FROM_ARGUMENTS(game_time_set_speed_evaluate, struct hs_arguments_real, (game_time_set_speed(arguments->value)))
HS_EVALUATE_VOID_STRING(game_set_game_variant_from_name_evaluate, game_set_game_variant_from_name)
HS_EVALUATE_VOID_BOOLEAN(player_input_enable_evaluate, player_input_enable)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player_control_action_test_jump_evaluate, player_control_action_test_jump)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player_control_action_test_primary_trigger_evaluate, player_control_action_test_primary_trigger)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player_control_action_test_grenade_trigger_evaluate, player_control_action_test_grenade_trigger)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player_control_action_test_zoom_evaluate, player_control_action_test_zoom)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player_control_action_test_action_evaluate, player_control_action_test_action)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player_control_action_test_accept_evaluate, player_control_action_test_accept)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player_control_action_test_back_evaluate, player_control_action_test_back)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player_control_action_test_look_relative_up_evaluate, player_control_action_test_look_relative_up)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player_control_action_test_look_relative_down_evaluate, player_control_action_test_look_relative_down)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player_control_action_test_look_relative_left_evaluate, player_control_action_test_look_relative_left)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player_control_action_test_look_relative_right_evaluate, player_control_action_test_look_relative_right)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player_control_action_test_look_relative_all_directions_evaluate, player_control_action_test_look_relative_all_directions)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player_control_action_test_move_relative_all_directions_evaluate, player_control_action_test_move_relative_all_directions)
/* port: in network co-op, also for the players the scripts can't name (coop_scripts.c) */
HS_EVALUATE_VOID_FROM_ARGUMENTS(player_add_equipment_evaluate, struct hs_arguments_long_word_boolean, (coop_scripts_player_add_equipment(arguments->value0, arguments->value1, arguments->value2)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(debug_player_teleport_evaluate, struct hs_arguments_short_word, (debug_player_teleport(arguments->value0, arguments->value1)))
HS_EVALUATE_VOID_STRING(main_set_map_name_evaluate, main_set_map_name)
HS_EVALUATE_VOID_STRING(main_set_multiplayer_map_name_evaluate, main_set_multiplayer_map_name)
HS_EVALUATE_VOID_UNSIGNED_SHORT(main_set_difficulty_evaluate, main_set_difficulty)
/* port: a campaign script still switches, and so does a player walking
through a BSP trigger (main_switch_structure_bsp, not this). */
static void scenario_switch_structure_bsp_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	struct hs_arguments_word const *arguments;
	short structure_bsp_index;

	arguments = (struct hs_arguments_word const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		structure_bsp_index = (short)arguments->value;
		if (!game_engine_running() || global_structure_bsp_index_get() == NONE)
		{
			scripted_multiplayer_bsp = NONE;
			scripted_multiplayer_bsp_reported = FALSE;
			scenario_switch_structure_bsp(structure_bsp_index);
		}
		else if (scripted_multiplayer_bsp == NONE ||
			scripted_multiplayer_bsp == structure_bsp_index)
		{
			scripted_multiplayer_bsp = structure_bsp_index;
			scenario_switch_structure_bsp(structure_bsp_index);
		}
		else if (!scripted_multiplayer_bsp_reported)
		{
			scripted_multiplayer_bsp_reported = TRUE;
			error(_error_silent, "switch_bsp from a script is ignored after the multiplayer game has chosen its bsp");
		}
		hs_return(thread_index, 0);
	}
	return;
}
HS_EVALUATE_VOID_STRING(main_crash_evaluate, main_crash)
HS_EVALUATE_VOID_STRING(debug_dump_memory_for_file_evaluate, debug_dump_memory_for_file)
HS_EVALUATE_VOID_STRING(profile_dump_to_file_evaluate, profile_dump_to_file)
HS_EVALUATE_VOID_STRING(profile_sections_activate_evaluate, profile_sections_activate)
HS_EVALUATE_VOID_STRING(profile_sections_deactivate_evaluate, profile_sections_deactivate)
HS_EVALUATE_VOID_STRING(profile_graph_toggle_evaluate, profile_graph_toggle)
HS_EVALUATE_VOID_BOOLEAN(debug_pvs_evaluate, debug_pvs)
static void ai_debug_vocalize_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	union hs_evaluation_argument *arguments = (union hs_evaluation_argument *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		ai_debug_vocalize(arguments[0].string_value, arguments[1].string_value);
		hs_return(thread_index, 0);
	}
	return;
}
HS_EVALUATE_VOID_LONG(ai_debug_teleport_to_evaluate, ai_debug_teleport_to)
HS_EVALUATE_VOID_STRING(ai_debug_speak_evaluate, ai_debug_speak)
HS_EVALUATE_VOID_STRING(ai_debug_speak_list_evaluate, ai_debug_speak_list)
HS_EVALUATE_VOID_BOOLEAN(cinematic_show_letterbox_evaluate, cinematic_show_letterbox)
HS_EVALUATE_VOID_UNSIGNED_SHORT(cinematic_set_title_evaluate, cinematic_set_title)
HS_EVALUATE_VOID_BOOLEAN(cinematic_suppress_bsp_object_creation_evaluate, cinematic_suppress_bsp_object_creation)
HS_EVALUATE_VOID_STRING(main_load_core_name_evaluate, main_load_core_name)
HS_EVALUATE_VOID_STRING(main_load_core_name_at_startup_evaluate, main_load_core_name_at_startup)
HS_EVALUATE_VOID_STRING(main_save_core_name_evaluate, main_save_core_name)
HS_EVALUATE_VOID_UNSIGNED_SHORT(main_skip_evaluate, main_skip)
HS_EVALUATE_VOID_LONG(scripted_sound_stop_evaluate, scripted_sound_stop)
HS_EVALUATE_VOID_LONG(scripted_foley_predict_evaluate, scripted_foley_predict)
HS_EVALUATE_VOID_LONG(scripted_looping_sound_stop_evaluate, scripted_looping_sound_stop)
HS_EVALUATE_VOID_LONG_BOOLEAN(scripted_looping_sound_set_alternate_evaluate, scripted_looping_sound_set_alternate)
static void debug_sound_classes_enable_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	union hs_evaluation_argument *arguments = (union hs_evaluation_argument *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		debug_sound_classes_enable(arguments[0].string_value, arguments[1].boolean_value);
		hs_return(thread_index, 0);
	}
	return;
}
HS_EVALUATE_VOID_BOOLEAN(sound_enable_evaluate, sound_enable)
HS_EVALUATE_VOID_LONG_BOOLEAN(vehicle_hover_evaluate, vehicle_hover)
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_set_flashing_state_evaluate, struct hs_arguments_boolean, (scripted_hud_set_flashing_state(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(hud_unit_deactivate_nav_point_with_flag_evaluate, struct hs_arguments_long_word, (hud_unit_deactivate_nav_point_with_flag(arguments->value0, arguments->value1)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(hud_unit_deactivate_nav_point_with_object_evaluate, struct hs_arguments_long_long, (hud_unit_deactivate_nav_point_with_object(arguments->value0, arguments->value1)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(hud_deactivate_team_nav_point_with_flag_evaluate, struct hs_arguments_short_word, (hud_deactivate_team_nav_point_with_flag(arguments->value0, arguments->value1)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(hud_deactivate_team_nav_point_with_object_evaluate, struct hs_arguments_short_long, (hud_deactivate_team_nav_point_with_object(arguments->value0, arguments->value1)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(errors_overflow_suppression_enable_evaluate, struct hs_arguments_boolean, (errors_overflow_suppression_enable(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_player_effect_stop_evaluate, struct hs_arguments_real, (scripted_player_effect_stop(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_show_health_evaluate, struct hs_arguments_boolean, (scripted_hud_show_health(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_blink_health_evaluate, struct hs_arguments_boolean, (scripted_hud_blink_health(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_show_shield_evaluate, struct hs_arguments_boolean, (scripted_hud_show_shield(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_blink_shield_evaluate, struct hs_arguments_boolean, (scripted_hud_blink_shield(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_show_motion_sensor_evaluate, struct hs_arguments_boolean, (scripted_hud_show_motion_sensor(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_blink_motion_sensor_evaluate, struct hs_arguments_boolean, (scripted_hud_blink_motion_sensor(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_show_crosshair_evaluate, struct hs_arguments_boolean, (scripted_hud_show_crosshair(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_set_state_message_evaluate, struct hs_arguments_word, (scripted_hud_set_state_message(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_set_objective_evaluate, struct hs_arguments_word, (scripted_hud_set_objective(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_set_timer_time_evaluate, struct hs_arguments_short_word, (scripted_hud_set_timer_time(arguments->value0, arguments->value1)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_set_timer_warning_cutoff_evaluate, struct hs_arguments_short_word, (scripted_hud_set_timer_warning_cutoff(arguments->value0, arguments->value1)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_set_timer_position_evaluate, struct hs_arguments_word_word_word, (scripted_hud_set_timer_position(arguments->value0, arguments->value1, arguments->value2)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_show_timer_evaluate, struct hs_arguments_boolean, (scripted_hud_show_timer(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_pause_timer_evaluate, struct hs_arguments_boolean, (scripted_hud_pause_timer(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_time_code_show_evaluate, struct hs_arguments_boolean, (scripted_hud_time_code_show(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(scripted_hud_time_code_start_evaluate, struct hs_arguments_boolean, (scripted_hud_time_code_start(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(rasterizer_screen_effect_start_evaluate, struct hs_arguments_boolean, (rasterizer_screen_effect_start(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(rasterizer_set_near_clip_distance_evaluate, struct hs_arguments_real, (rasterizer_set_near_clip_distance(arguments->value)))
HS_EVALUATE_VOID_FROM_ARGUMENTS(player0_look_invert_pitch_evaluate, struct hs_arguments_boolean, (player0_look_invert_pitch(arguments->value)))
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player0_look_pitch_is_inverted_evaluate, player0_look_pitch_is_inverted)
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(player0_joystick_set_is_normal_evaluate, player0_joystick_set_is_normal)
HS_EVALUATE_VOID_BOOLEAN(ui_widget_debug_show_path_evaluate, ui_widget_debug_show_path)
HS_EVALUATE_VOID_UNSIGNED_SHORT(display_scenario_help_evaluate, display_scenario_help)
HS_EVALUATE_VOID_STRING(xbox_set_machine_name_evaluate, xbox_set_machine_name)
HS_EVALUATE_VOID_STRING(hs_help_evaluate, hs_help)
HS_EVALUATE_RETURN_BOOLEAN(hs_not_evaluate, struct hs_arguments_boolean, (hs_not(arguments->value)))
HS_EVALUATE_RETURN_BOOLEAN(scenario_trigger_volume_test_object_evaluate, struct hs_arguments_short_long, (scenario_trigger_volume_test_object(arguments->value0, arguments->value1)))
HS_EVALUATE_RETURN_BOOLEAN(hs_trigger_volume_test_objects_any_evaluate, struct hs_arguments_short_long, (hs_trigger_volume_test_objects_any(arguments->value0, arguments->value1)))
HS_EVALUATE_RETURN_BOOLEAN(hs_trigger_volume_test_objects_all_evaluate, struct hs_arguments_short_long, (hs_trigger_volume_test_objects_all(arguments->value0, arguments->value1)))
HS_EVALUATE_RETURN_BOOLEAN(recorded_animation_play_evaluate, struct hs_arguments_long_word, (recorded_animation_play(arguments->value0, arguments->value1)))
HS_EVALUATE_RETURN_BOOLEAN(recorded_animation_play_and_delete_evaluate, struct hs_arguments_long_word, (recorded_animation_play_and_delete(arguments->value0, arguments->value1)))
HS_EVALUATE_RETURN_BOOLEAN(recorded_animation_play_and_hover_evaluate, struct hs_arguments_long_word, (recorded_animation_play_and_hover(arguments->value0, arguments->value1)))
HS_EVALUATE_RETURN_BOOLEAN(lights_enable_evaluate, struct hs_arguments_boolean, (lights_enable(arguments->value)))
HS_EVALUATE_RETURN_BOOLEAN(unit_start_user_animation_evaluate, struct hs_arguments_long_long_long_boolean, (unit_start_user_animation(arguments->value0, arguments->value1, arguments->value2, arguments->value3)))
HS_EVALUATE_RETURN_BOOLEAN(unit_scripting_start_user_animation_list_evaluate, struct hs_arguments_long_long_long_boolean, (unit_scripting_start_user_animation_list(arguments->value0, arguments->value1, arguments->value2, arguments->value3)))
HS_EVALUATE_RETURN_BOOLEAN(unit_custom_animation_at_frame_evaluate, struct hs_arguments_long_long_long_boolean_word, (unit_custom_animation_at_frame(arguments->value0, arguments->value1, arguments->value2, arguments->value3, arguments->value4)))
HS_EVALUATE_RETURN_BOOLEAN(unit_is_playing_custom_animation_evaluate, struct hs_arguments_long, (unit_is_playing_custom_animation(arguments->value)))
HS_EVALUATE_RETURN_BOOLEAN(unit_scripting_vehicle_test_seat_list_evaluate, struct hs_arguments_long_long_long, (unit_scripting_vehicle_test_seat_list(arguments->value0, arguments->value1, arguments->value2)))
HS_EVALUATE_RETURN_BOOLEAN(unit_scripting_vehicle_test_seat_evaluate, struct hs_arguments_long_long_long, (unit_scripting_vehicle_test_seat(arguments->value0, arguments->value1, arguments->value2)))
HS_EVALUATE_RETURN_BOOLEAN(unit_scripting_has_weapon_evaluate, struct hs_arguments_long_long, (unit_scripting_has_weapon(arguments->value0, arguments->value1)))
HS_EVALUATE_RETURN_BOOLEAN(unit_scripting_has_weapon_readied_evaluate, struct hs_arguments_long_long, (unit_scripting_has_weapon_readied(arguments->value0, arguments->value1)))
HS_EVALUATE_RETURN_BOOLEAN_NO_ARGUMENTS(unit_solo_player_integrated_night_vision_is_active_evaluate, unit_solo_player_integrated_night_vision_is_active)
HS_EVALUATE_RETURN_BOOLEAN(unit_get_current_flashlight_state_evaluate, struct hs_arguments_long, (unit_get_current_flashlight_state(arguments->value)))
HS_EVALUATE_RETURN_BOOLEAN(ai_scripting_is_attacking_evaluate, struct hs_arguments_long, (ai_scripting_is_attacking(arguments->value)))
HS_EVALUATE_RETURN_BOOLEAN(ai_scripting_conversation_evaluate, struct hs_arguments_word, (ai_scripting_conversation(arguments->value)))
HS_EVALUATE_RETURN_BOOLEAN(ai_scripting_allegiance_broken_evaluate, struct hs_arguments_short_word, (ai_scripting_allegiance_broken(arguments->value0, arguments->value1)))
HS_EVALUATE_RETURN_BOOLEAN(scripted_player_control_set_camera_control_evaluate, struct hs_arguments_boolean, (scripted_player_control_set_camera_control(arguments->value)))
HS_EVALUATE_RETURN_BOOLEAN(scripted_show_hud_evaluate, struct hs_arguments_boolean, (scripted_show_hud(arguments->value)))
HS_EVALUATE_RETURN_BOOLEAN(scripted_show_hud_help_text_evaluate, struct hs_arguments_boolean, (scripted_show_hud_help_text(arguments->value)))

static void hs_recompile_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	hs_recompile_pending = TRUE;
	hs_return(thread_index, 0);
	return;
}

static void random_range_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	union hs_short_result result;
	union hs_evaluation_argument const *arguments;
	word upper_bound;
	short lower_bound;
	result.value = 0;
	arguments = (union hs_evaluation_argument const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		upper_bound = arguments[1].unsigned_short_value;
		lower_bound = arguments[0].short_value;
		result.short_value = seed_random_range(get_global_random_seed_address(), lower_bound, upper_bound);
		hs_return(thread_index, result.value);
	}
	return;
}

static void real_random_range_evaluate(
	short function_index,
	long thread_index,
	boolean initialize)
{
	union hs_real_value result;
	union hs_evaluation_argument const *arguments;
	real upper_bound;
	real lower_bound;

	arguments = (union hs_evaluation_argument const *)hs_macro_function_evaluate(function_index, thread_index, initialize);
	if (arguments)
	{
		double upper = arguments[1].real_value;

		upper_bound = (real)upper;
		lower_bound = arguments[0].real_value;
		result.real_value = real_seed_random_range(get_global_random_seed_address(), lower_bound, upper_bound);
		hs_return(thread_index, result.long_value);
	}
	return;
}

boolean hs_scenario_postprocess(
	boolean restore_syntax_data)
{
	boolean success = TRUE;
	char const *error_source;
	char const *error_message;
	struct data_array *saved_syntax_data;
	struct scenario *scenario;
	boolean recompile;

	scenario = global_scenario_get();
	saved_syntax_data = hs_syntax_data;
	/* port: the last map's are let go of (hs_scenario_functions_check) */
	csmemset(hs_scenario_disabled_scripts, 0, sizeof(hs_scenario_disabled_scripts));
	csmemset(hs_scenario_disabled_globals, 0, sizeof(hs_scenario_disabled_globals));
	hs_allocate();
	/* port: script data that isn't sound isn't gone through (hs_allocate
	has an empty array stand in for it, and the map runs no scripts) */
	if (!hs_scenario_syntax_data_valid(scenario))
	{
		if (restore_syntax_data)
			hs_syntax_data = saved_syntax_data;

		return FALSE;
	}
	recompile = scenario->hs_scripts.count == 0 && scenario->hs_source_files.count>0;
	/* port: the map's globals take the "hs globals" array's datums after the
	external ones (hs_runtime_initialize_for_new_map); more than are left
	would be set through datums that aren't there. Each has a value's type,
	which the casts' and the type names' tables are looked up by. A map
	whose globals aren't so runs no scripts. The shipped maps' all are, and
	have far fewer */
	if (scenario->hs_globals.count<0 ||
		scenario->hs_globals.count>MAXIMUM_HS_GLOBALS-hs_external_global_count)
	{
		error(0, "the scenario has %ld script globals, more than the %d there is room for; its scripts won't run",
			scenario->hs_globals.count,
			MAXIMUM_HS_GLOBALS-hs_external_global_count);
		hs_scenario_scripts_disable(scenario);
	}
	else
	{
		short global_index;

		for (global_index = 0; global_index<scenario->hs_globals.count; global_index++)
		{
			struct hs_global const *global = TAG_BLOCK_GET_ELEMENT(
				&scenario->hs_globals,
				global_index,
				struct hs_global);

			if (!hs_type_valid(global->type))
			{
				error(0, "the scenario's script global #%d has no type (%d); its scripts won't run",
					global_index,
					global->type);
				hs_scenario_scripts_disable(scenario);
				break;
			}
		}
	}
	/* port: no more scripts than the scripts block holds (what
	hs_scenario_functions_check marks them by has room for). The shipped
	maps' most is d40's 297 */
	if (scenario->hs_scripts.count<0 ||
		scenario->hs_scripts.count>MAXIMUM_HS_SCRIPTS_PER_SCENARIO)
	{
		error(0, "the scenario has %ld scripts, more than the %d there is room for; its scripts won't run",
			scenario->hs_scripts.count,
			MAXIMUM_HS_SCRIPTS_PER_SCENARIO);
		hs_scenario_scripts_disable(scenario);
	}
	hs_syntax_data = (struct data_array *)scenario->hs_syntax_data.address;
	hs_syntax_data->data = (char *)hs_syntax_data+sizeof(struct data_array);
	if (!recompile && hs_compile_postprocess(&error_message, &error_source))
	{
		/* port: before the console's expressions are compiled into the
		same nodes */
		hs_scenario_functions_check(scenario);
		if (scenario->hs_string_constants.size<0x400)
		{
			success = tag_data_resize(
				&scenario->hs_string_constants,
				scenario->hs_string_constants.size + 0x400);
		}
	}
	else
	{
		if (recompile)
			error(0, "recompiling scripts after scenarios were merged.");
		else if (!error_message)
			error(0, "an unspecified error occurred loading scripts");
		else if (!error_source)
			error(0, "%s", error_message);
		else
			error(0, "%s: %s", error_source, error_message);

		/* port: the map's script source is not compiled again. A cache
		file's blocks can't be resized (tag_block_resize), so the recompile
		never reset the map's scripts and globals and none ran afterwards
		either way; and the source is the map's, which the compiler would
		recurse into as deep as it nests. The nodes go, and none run */
		error(0, "the scenario's scripts won't run");
		data_delete_all(hs_syntax_data);
		hs_scenario_scripts_disable(scenario);
		success = FALSE;
	}
	if (restore_syntax_data)
		hs_syntax_data = saved_syntax_data;

	return success;
}

/* port: whether this machine plays in another's game (joined to its lobby
or in its game), whose host decides the game */
static boolean hs_playing_in_anothers_game(
	void)
{
	return network_game_distributed_client() ||
		(global_network_game_client_get() && !global_network_game_server_get());
}

/* port: whether an expression typed at the console (or the telnet console,
or a cheat button's) changes nothing of the game: every name in it one of
these (what the machine shows its player, and how its controls feel), the
rest numbers, strings and true or false */
static boolean hs_expression_changes_no_game(
	char const *expression)
{
	static char const *const allowed[] = {
		"set", "cls", "help", "print", "script_doc",
		"display_framerate", "framerate_throttle", "framerate_lock", "rasterizer_fps_accumulate",
		"console_dump_to_file", "terminal_render", "screenshot_size", "screenshot_count",
		"show_hud", "show_hud_help_text", "show_hud_timer", "hud_show_crosshair", "hud_show_health",
		"hud_show_motion_sensor", "hud_show_shield", "sound_enable", "sound_set_gain",
		"controls_swapped", "controls_enable_crouch", "controls_enable_doubled_spin",
		"controls_swap_doubled_spin_state",
		"player0_look_yaw_rate", "player1_look_yaw_rate", "player2_look_yaw_rate", "player3_look_yaw_rate",
		"player0_look_pitch_rate", "player1_look_pitch_rate", "player2_look_pitch_rate",
		"player3_look_pitch_rate",
		/* (a machine's mods are its own: mods.c) */
		"mods_reload", "mods_enable", "mods_list",
		"structure_culling", /* port: only this machine's rendering */
		"debug_structure_culling", /* port: only this machine's rendering */
		"true", "false", "on", "off",
	};
	char const *character = expression;

	while (*character)
	{
		char token[64];
		size_t length = 0;
		boolean number = TRUE;
		short index;

		if (isspace((unsigned char)*character) || *character == '(' || *character == ')')
		{
			character++;
			continue;
		}
		/* (a string, as print takes) */
		if (*character == '"')
		{
			character = strchr(character + 1, '"');
			if (!character)
				return FALSE;
			character++;
			continue;
		}
		while (*character && !isspace((unsigned char)*character) && *character != '(' && *character != ')' &&
			*character != '"')
		{
			if (length + 1 >= sizeof(token))
				return FALSE;
			if (!(*character >= '0' && *character <= '9') && *character != '.' && *character != '-' &&
				*character != '+')
			{
				number = FALSE;
			}
			token[length++] = (char)(*character >= 'A' && *character <= 'Z' ? *character - 'A' + 'a' : *character);
			character++;
		}
		token[length] = 0;
		if (number)
			continue;
		for (index = 0; index < (short)NUMBEROF(allowed); index++)
		{
			if (!csstrcmp(token, allowed[index]))
				break;
		}
		if (index >= (short)NUMBEROF(allowed))
			return FALSE;
	}
	return TRUE;
}

static boolean hs_compile_and_evaluate_command(
	char const *expression);

/* port: the text after the host's command `word` ("ban", "kick") that an
expression starts with (spaces and an opening parenthesis before it, in
either case, then a space or the end), else NULL */
static char const *hs_host_player_command(
	char const *expression,
	char const *word)
{
	char const *text = expression;
	long index;

	while (*text == ' ' || *text == '\t' || *text == '(')
		text++;
	for (index = 0; word[index]; index++)
	{
		char character = text[index] >= 'A' && text[index] <= 'Z' ? text[index] - 'A' + 'a' : text[index];

		if (character != word[index])
			return NULL;
	}
	text += index;
	return *text == ' ' || *text == '\t' || *text == 0 ? text : NULL;
}

/* port: a command someone typed (the console, the telnet console, a cheat
button, init.txt): what it logs is its answer, shown whatever
config.toml's game.console_log is (terminal_command_running) */
boolean hs_compile_and_evaluate(
	char const *expression)
{
	boolean was_running = terminal_command_running;
	boolean result;

	terminal_command_running = TRUE;
	result = hs_compile_and_evaluate_command(expression);
	terminal_command_running = was_running;
	return result;
}

static boolean hs_compile_and_evaluate_command(
	char const *expression)
{
	boolean success = FALSE;
	char const *error_message;
	char const *error_source;
	char *character;
	char buffer[1024];
	char expanded[1024];

#ifdef HALO_PROFILE
	/* port: the profiling build's commands change nothing of the game: a client
	may give them, and they are no scripts */
	if (profile_console_command(expression))
		return TRUE;
#endif
	/* port: the co-op host's bringto, which brings every player to the host
	(players.c; a client is told it is the host's) */
	if (hs_host_player_command(expression, "bringto"))
		return players_coop_bring_to_host();
	/* port: the players' vote to kick a player ("votekick <player name>",
	or the name's start: Tab completes it), on any machine of a network
	game: the host counts (network_votekick.c) */
	{
		char const *text = hs_host_player_command(expression, "votekick");

		if (text)
		{
			char name[64];
			long length = 0;

			while (*text == ' ' || *text == '\t' || *text == '"')
				text++;
			while (*text && *text != '"' && *text != ')' && length < (long)sizeof(name) - 1)
				name[length++] = *text++;
			while (length > 0 && (name[length - 1] == ' ' || name[length - 1] == '\t'))
				length--;
			name[length] = 0;
			return network_votekick_player_named(name);
		}
	}
	/* port: profile_reset_campaign, which clears the first player's
	profile's campaign progress (player_ui_reset_campaign_progress) once
	confirmed: "profile_reset_campaign yes" */
	{
		char const *text = hs_host_player_command(expression, "profile_reset_campaign");

		if (text)
		{
			wchar_t wide_name[MAXIMUM_PLAYER_PROFILE_NAME_LENGTH];
			char name[MAXIMUM_PLAYER_PROFILE_NAME_LENGTH];
			boolean confirmed;
			long length;

			while (*text == ' ' || *text == '\t' || *text == '"')
				text++;
			confirmed = csstrncmp(text, "yes", 3) == 0 &&
				(!text[3] || text[3] == ' ' || text[3] == '\t' || text[3] == '"' || text[3] == ')');
			if (!player_ui_reset_campaign_progress(confirmed, wide_name, NUMBEROF(wide_name)))
			{
				console_warning("there is no profile to reset: make or choose one first");
				return FALSE;
			}
			for (length = 0; wide_name[length]; length++)
				name[length] = wide_name[length] < 0x80 ? (char)wide_name[length] : '?';
			name[length] = 0;
			if (!confirmed)
				console_printf(FALSE,
					"This clears every level %s finished and starts the campaign over at The Pillar of Autumn. "
					"To do it, type: profile_reset_campaign yes", name);
			else
				console_printf(FALSE, "%s's campaign progress is reset: The Pillar of Autumn is the only level open", name);
			return TRUE;
		}
	}
	/* port: playing in another's game, the host decides the game: no
	cheats, no game speed, nothing else a command changes of the game (the
	game run each tick also puts back what was changed before joining,
	cheats_network_client_enforce) */
	if (hs_playing_in_anothers_game() && !hs_expression_changes_no_game(expression))
	{
		console_warning("not while playing in another's game: the host decides the game");
		return FALSE;
	}
	/* port: the host's ban and kick commands ("ban <player name>", "kick
	<player name>", or the name's start: Tab completes it), which are no
	script's */
	{
		char const *text = hs_host_player_command(expression, "ban");
		boolean kick = FALSE;

		if (!text && (text = hs_host_player_command(expression, "kick")) != NULL)
			kick = TRUE;
		if (text)
		{
			char name[64];
			long length = 0;

			while (*text == ' ' || *text == '\t' || *text == '"')
				text++;
			while (*text && *text != '"' && *text != ')' && length < (long)sizeof(name) - 1)
				name[length++] = *text++;
			while (length > 0 && (name[length - 1] == ' ' || name[length - 1] == '\t'))
				length--;
			name[length] = 0;
			return kick ? network_game_server_kick_player(name) : network_game_server_ban_player(name);
		}
	}
	csstrncpy(buffer, expression, sizeof(buffer));
	buffer[sizeof(buffer)-1] = 0;
	if (strchr(buffer, ';'))
		buffer[0] = 0;
	character = buffer;
	if (buffer[0] != 0)
	{
		do
		{
			if (!isspace(*character))
			{
				short type;
				long expression_index;

				type = 0;
				hs_compile_initialize(FALSE);
				if (buffer[0] != '(')
				{
					char *space;

					space = strchr(buffer, ' ');
					if (space)
						*space = 0;
					if (hs_find_global_by_name(buffer) != NONE)
					{
						if (space)
							type = 2;
					}
					else
					{
						type = 1;
					}
					if (space)
						*space = ' ';
				}
				switch (type)
				{
				case 0:
					break;
				case 1:
					snprintf(expanded, sizeof(expanded), "(%s)", buffer);
					expression = expanded;
					break;
				case 2:
					snprintf(expanded, sizeof(expanded), "(set %s)", buffer);
					expression = expanded;
					break;
				default:
					display_assert(NULL, "c:\\halo\\SOURCE\\hs\\hs.c", 1287, TRUE);
					system_exit(-1);
					break;
				}
				/* BUG (original): January and HCEA pass the message/source outputs
				 * in reverse. Keep the authentic target behavior explicit. */
				expression_index = hs_compile_expression(csstrlen(expression), expression, &error_source, &error_message);
				if (expression_index != NONE)
				{
					success = TRUE;
					hs_runtime_evaluate(expression_index);
				}
				else if (error_source)
				{
					hs_compile_source_error(
						error_source,
						(char *)error_message,
						NULL,
						expression);
				}
				hs_compile_dispose();
				break;
			}
			character++;
		} while (*character != 0);
	}
	if (hs_recompile_pending)
	{
		if (hs_rebuild_source())
		{
			struct scenario *scenario;

			hs_compile_source();
			if (hs_syntax_data)
			{
				hs_node_gc();
				if (hs_syntax_data_allocated)
				{
					data_make_invalid(hs_syntax_data);
					data_dispose(hs_syntax_data);
					hs_syntax_data_allocated = FALSE;
				}
				hs_syntax_data = NULL;
			}
			hs_runtime_dispose_from_old_map();
			object_lists_dispose_from_old_map();
			scenario = global_scenario_index != NONE ? global_scenario_get() : NULL;
			hs_allocate();
			if (scenario && scenario->hs_syntax_data.size)
				hs_scenario_postprocess(FALSE);
			object_lists_initialize_for_new_map();
			hs_runtime_initialize_for_new_map();
		}
		hs_recompile_pending = FALSE;
	}

	return success;
}

/* ---------- private code */
