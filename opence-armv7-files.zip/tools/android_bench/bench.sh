#!/bin/sh
# bench.sh: bench.ps1 for macOS and Linux (tools/android_bench/README.md)
#   ./bench.sh [apk] [level] [seconds] [NAME=VALUE ...]
set -e
package=com.halo.decomp
files=/sdcard/Android/data/$package/files
apk=${1:-}; level=${2:-a30}; seconds=${3:-120}
[ $# -gt 3 ] && shift 3 || shift $#
stamp=$(date +%Y%m%d-%H%M%S)
mkdir -p bench-results
output=bench-results/bench-$stamp.txt
[ -n "$apk" ] && adb install -r "$apk"
adb shell am force-stop $package
tmp=$(mktemp -d)
printf 'map_name levels\\%s\\%s' "$level" "$level" > "$tmp/init.txt"
{ printf 'HALO_EXIT_AFTER=%s\nHALO_TEST_INPUT=look:1\nHALO_FRAME_TIMING=true\nHALO_SHOW_FPS=true\nHALO_RENDER_SCALE=1.0\n' "$seconds"
  for setting in "$@"; do printf '%s\n' "$setting"; done; } > "$tmp/benchmark.txt"
adb push "$tmp/init.txt" "$files/init.txt" >/dev/null
adb push "$tmp/benchmark.txt" "$files/benchmark.txt" >/dev/null
adb logcat -c
echo "running $level for $seconds seconds"
adb shell am start -n $package/.LauncherActivity >/dev/null
sleep 20
end=$(( $(date +%s) + seconds + 180 ))
while [ "$(date +%s)" -lt $end ] && adb shell ps | grep -q "$package:game"; do sleep 5; done
adb shell am force-stop $package
adb pull "$files/startup.txt" "$tmp/startup.txt" >/dev/null || true
adb pull "$files/debug.txt" "$tmp/debug.txt" >/dev/null || true
adb shell rm -f "$files/init.txt" "$files/benchmark.txt"
{ echo "=== benchmark $stamp: level $level, $seconds s, settings: $*"
  echo "=== device: $(adb shell getprop ro.product.model)"
  echo "=== startup.txt"; cat "$tmp/startup.txt" 2>/dev/null
  echo "=== debug.txt (its last 80 lines)"; tail -n 80 "$tmp/debug.txt" 2>/dev/null
  echo "=== logcat (the app's lines, and crashes)"
  adb logcat -d -v threadtime | grep -E "halo|SDL|AndroidRuntime|DEBUG|libc|linker|Fatal|FATAL"; } > "$output"
echo "done: $output"
grep "frame timing:" "$output" | tail -n 3
