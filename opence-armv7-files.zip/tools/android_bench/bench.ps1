# bench.ps1: one automated benchmark run of the Android app over adb
# (tools/android_bench/README.md). Run it from a folder where adb works:
#   .\bench.bat                          (the second campaign level, 120 s)
#   .\bench.bat -Apk halo-armv7-release.apk
#   .\bench.bat -Level a10 -Seconds 90 -Set HALO_RENDER_SCALE=0.75
param(
    [string]$Apk = "",
    [string]$Level = "a30",
    [int]$Seconds = 120,
    [string[]]$Set = @()
)

$ErrorActionPreference = "Stop"
# (-Set A=1,B=2 arrives as one string through bench.bat)
$Set = @($Set | ForEach-Object { $_ -split ',' } | Where-Object { $_ })
$package = "com.halo.decomp"
$files = "/sdcard/Android/data/$package/files"
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$results = Join-Path (Get-Location) "bench-results"
New-Item -ItemType Directory -Force -Path $results | Out-Null
$output = Join-Path $results "bench-$stamp.txt"

# (PowerShell, unlike Command Prompt, does not run a program from the
# current folder by its name alone: adb.exe beside this script, or in the
# current folder, else on the PATH)
$adb = @(
    (Join-Path $PSScriptRoot "adb.exe"),
    (Join-Path (Get-Location) "adb.exe")
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $adb) {
    $found = Get-Command adb -ErrorAction SilentlyContinue
    if (-not $found) { throw "adb was not found: put this script in the platform-tools folder, beside adb.exe" }
    $adb = $found.Source
}

function Invoke-Adb { & $adb @args; if ($LASTEXITCODE -ne 0) { throw "adb $args failed" } }

Write-Host "device:" (& $adb shell getprop ro.product.model)
if ($Apk) {
    Write-Host "installing $Apk"
    Invoke-Adb install -r $Apk
}
Invoke-Adb shell am force-stop $package

# init.txt loads the level at start; benchmark.txt holds this run's
# settings (port/android/native/native_main.c), both removed afterwards
$init = Join-Path $env:TEMP "halo-init.txt"
$benchmark = Join-Path $env:TEMP "halo-benchmark.txt"
"map_name levels\$Level\$Level" | Set-Content -Encoding ascii -NoNewline $init
$lines = @(
    "HALO_EXIT_AFTER=$Seconds",
    "HALO_TEST_INPUT=look:1",
    "HALO_FRAME_TIMING=true",
    "HALO_SHOW_FPS=true",
    # (the whole picture unless -Set says otherwise: config.toml's own
    # render_scale would make runs incomparable)
    "HALO_RENDER_SCALE=1.0"
) + $Set
$lines -join "`n" | Set-Content -Encoding ascii -NoNewline $benchmark
Invoke-Adb push $init "$files/init.txt" | Out-Null
Invoke-Adb push $benchmark "$files/benchmark.txt" | Out-Null

Write-Host "running $Level for $Seconds seconds ($($Set -join ', '))"
Invoke-Adb shell am start -n "$package/.LauncherActivity" | Out-Null
$deadline = (Get-Date).AddSeconds($Seconds + 180)
Start-Sleep -Seconds 20
while ((Get-Date) -lt $deadline) {
    $running = & $adb shell ps | Select-String "${package}:game"
    if (-not $running) { break }
    Start-Sleep -Seconds 5
}
if ((Get-Date) -ge $deadline) { Write-Host "still running past the time: stopping it" }
Invoke-Adb shell am force-stop $package

$startup = Join-Path $env:TEMP "halo-startup.txt"
$debug = Join-Path $env:TEMP "halo-debug.txt"
& $adb pull "$files/startup.txt" $startup | Out-Null
& $adb pull "$files/debug.txt" $debug | Out-Null
& $adb shell rm -f "$files/init.txt" "$files/benchmark.txt" | Out-Null

$report = @(
    "=== benchmark ${stamp}: level ${Level}, ${Seconds} s, settings: $($lines -join '; ')",
    "=== device: $(& $adb shell getprop ro.product.model) / Android $(& $adb shell getprop ro.build.version.release)",
    "=== startup.txt"
)
if (Test-Path $startup) { $report += Get-Content $startup }
$report += "=== debug.txt (its last 80 lines)"
if (Test-Path $debug) { $report += Get-Content $debug -Tail 80 }
$report | Set-Content -Encoding utf8 $output
Write-Host ""
Write-Host "done: $output"
$timing = $report | Select-String "frame timing:"
if ($timing) { $timing | Select-Object -Last 3 | ForEach-Object { Write-Host $_ } }
