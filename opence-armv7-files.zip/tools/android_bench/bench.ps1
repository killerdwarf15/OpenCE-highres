# bench.ps1: one automated benchmark run of the Android app over adb
# (tools/android_bench/README.md). Run it from a folder where adb works:
#   .\bench.bat                          (the second campaign level, 120 s)
#   .\bench.bat -Apk halo-armv7-release.apk
#   .\bench.bat -Level a10 -Seconds 90 -Set HALO_RENDER_SCALE=0.75
param(
    [string]$Apk = "",
    [string]$Level = "a30",
    [int]$Seconds = 120,
    [string[]]$Set = @(),
    # the shaders the GPU was given (debug.gpu_dump_shaders), pulled into
    # bench-results\shaders-<time>.zip
    [switch]$Shaders,
    # a video of the run (adb screenrecord, at most 3 minutes, a smaller
    # picture than the screen's to cost the game little), into the report's
    # media zip; and screenshots every so many seconds (0 none)
    [switch]$Record,
    [int]$ScreenshotEvery = 20
)

$ErrorActionPreference = "Stop"
# (-Set A=1,B=2 arrives as one string through bench.bat)
$Set = @($Set | ForEach-Object { $_ -split ',' } | Where-Object { $_ })
$package = "com.halo.decomp"
$files = "/sdcard/Android/data/$package/files"
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$results = Join-Path (Get-Location) "bench-results"
New-Item -ItemType Directory -Force -Path $results | Out-Null
$output = Join-Path $results "bench-$stamp.txt"

# (PowerShell, unlike Command Prompt, does not run a program from the
# current folder by its name alone: adb.exe beside this script, or in the
# current folder, else on the PATH)
$adb = @(
    (Join-Path $PSScriptRoot "adb.exe"),
    (Join-Path (Get-Location) "adb.exe")
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $adb) {
    $found = Get-Command adb -ErrorAction SilentlyContinue
    if (-not $found) { throw "adb was not found: put this script in the platform-tools folder, beside adb.exe" }
    $adb = $found.Source
}

function Invoke-Adb { & $adb @args; if ($LASTEXITCODE -ne 0) { throw "adb $args failed" } }

Write-Host "device:" (& $adb shell getprop ro.product.model)
# (remotely: the screen woken and kept on while the device is plugged in,
# or the game starts behind a sleeping display)
& $adb shell input keyevent KEYCODE_WAKEUP | Out-Null
& $adb shell svc power stayon usb | Out-Null
if ($Apk) {
    Write-Host "installing $Apk"
    Invoke-Adb install -r $Apk
}
Invoke-Adb shell am force-stop $package

# init.txt loads the level at start; benchmark.txt holds this run's
# settings (port/android/native/native_main.c), both removed afterwards
$init = Join-Path $env:TEMP "halo-init.txt"
$benchmark = Join-Path $env:TEMP "halo-benchmark.txt"
"map_name levels\$Level\$Level" | Set-Content -Encoding ascii -NoNewline $init
if ($Shaders) {
    Invoke-Adb shell rm -rf "$files/shaders" | Out-Null
    Invoke-Adb shell mkdir -p "$files/shaders" | Out-Null
    $Set += "HALO_GPU_DUMP_SHADERS=$files/shaders"
}
$lines = @(
    "HALO_EXIT_AFTER=$Seconds",
    "HALO_TEST_INPUT=look:1",
    "HALO_FRAME_TIMING=true",
    "HALO_SHOW_FPS=true",
    # (the whole picture unless -Set says otherwise: config.toml's own
    # render_scale would make runs incomparable)
    "HALO_RENDER_SCALE=1.0"
) + $Set
$lines -join "`n" | Set-Content -Encoding ascii -NoNewline $benchmark
Invoke-Adb push $init "$files/init.txt" | Out-Null
Invoke-Adb push $benchmark "$files/benchmark.txt" | Out-Null

& $adb logcat -c | Out-Null
& $adb shell input keyevent KEYCODE_WAKEUP | Out-Null
& $adb shell rm -rf /sdcard/halo-bench-media | Out-Null
& $adb shell mkdir -p /sdcard/halo-bench-media | Out-Null
Write-Host "running $Level for $Seconds seconds ($($Set -join ', '))"
Invoke-Adb shell am start -n "$package/.LauncherActivity" | Out-Null
$runStart = Get-Date
$recorder = $null
if ($Record) {
    # (after the level has loaded, about 25 seconds in: the most of the
    # 3 minutes screenrecord allows spent playing)
    Start-Sleep -Seconds 25
    $limit = [Math]::Min(180, [Math]::Max(10, $Seconds - 25))
    $recorder = Start-Process -FilePath $adb -ArgumentList @("shell", "screenrecord", "--size", "640x360",
        "--bit-rate", "2000000", "--time-limit", "$limit", "/sdcard/halo-bench-media/run.mp4") -PassThru -NoNewWindow
}
$nextShot = $runStart.AddSeconds(30)
$shot = 0
$deadline = (Get-Date).AddSeconds($Seconds + 180)
Start-Sleep -Seconds 20
while ((Get-Date) -lt $deadline) {
    $running = & $adb shell ps | Select-String "${package}:game"
    if (-not $running) { break }
    if ($ScreenshotEvery -gt 0 -and (Get-Date) -ge $nextShot) {
        $shot++
        $elapsed = [int]((Get-Date) - $runStart).TotalSeconds
        & $adb shell screencap -p "/sdcard/halo-bench-media/shot-$('{0:D2}' -f $shot)-${elapsed}s.png" | Out-Null
        $nextShot = (Get-Date).AddSeconds($ScreenshotEvery)
    }
    Start-Sleep -Seconds 5
}
if ((Get-Date) -ge $deadline) { Write-Host "still running past the time: stopping it" }
Invoke-Adb shell am force-stop $package
if ($recorder -and -not $recorder.HasExited) {
    & $adb shell pkill -INT screenrecord | Out-Null
    Start-Sleep -Seconds 3
}

$startup = Join-Path $env:TEMP "halo-startup.txt"
$debug = Join-Path $env:TEMP "halo-debug.txt"
& $adb pull "$files/startup.txt" $startup | Out-Null
& $adb pull "$files/debug.txt" $debug | Out-Null
& $adb shell rm -f "$files/init.txt" "$files/benchmark.txt" | Out-Null
# the screenshots and the video, into one zip beside the report
$mediaFolder = Join-Path $env:TEMP "halo-media-$stamp"
if (Test-Path $mediaFolder) { Remove-Item -Recurse -Force $mediaFolder }
& $adb pull /sdcard/halo-bench-media $mediaFolder | Out-Null
& $adb shell rm -rf /sdcard/halo-bench-media | Out-Null
$media = Get-ChildItem $mediaFolder -Recurse -File -ErrorAction SilentlyContinue
if ($media) {
    $mediaZip = Join-Path $results "media-$stamp.zip"
    Compress-Archive -Path $media.FullName -DestinationPath $mediaZip -Force
    Write-Host "media: $mediaZip ($($media.Count) files)"
}
if ($Shaders) {
    $shaderFolder = Join-Path $env:TEMP "halo-shaders-$stamp"
    & $adb pull "$files/shaders" $shaderFolder | Out-Null
    & $adb shell rm -rf "$files/shaders" | Out-Null
    $shaderZip = Join-Path $results "shaders-$stamp.zip"
    Compress-Archive -Path (Join-Path $shaderFolder "*") -DestinationPath $shaderZip -Force
    Write-Host "shaders: $shaderZip"
}

$report = @(
    "=== benchmark ${stamp}: level ${Level}, ${Seconds} s, settings: $($lines -join '; ')",
    "=== device: $(& $adb shell getprop ro.product.model) / Android $(& $adb shell getprop ro.build.version.release)",
    "=== startup.txt"
)
if (Test-Path $startup) { $report += Get-Content $startup }
$report += "=== debug.txt (its last 80 lines)"
if (Test-Path $debug) { $report += Get-Content $debug -Tail 80 }
# the app's own log lines and Android's report of a crash (the run's only:
# the log was cleared as it started)
$report += "=== logcat (the app's lines, and crashes)"
$report += & $adb logcat -d -v threadtime | Select-String -Pattern "halo|halo-linux|SDL|libEGL|no current context|AndroidRuntime|DEBUG|libc|linker|Fatal|FATAL"
$report | Set-Content -Encoding utf8 $output
Write-Host ""
Write-Host "done: $output"
$timing = $report | Select-String "frame timing:"
if ($timing) { $timing | Select-Object -Last 3 | ForEach-Object { Write-Host $_ } }
