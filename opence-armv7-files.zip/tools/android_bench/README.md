# Benchmarking the Android app over adb

`bench.bat` (Windows; `bench.sh` on macOS and Linux) runs the app once on a
device connected with adb, unattended, and writes one report:

1. installs an APK if one is given (`adb install -r`);
2. pushes `init.txt` (the game's console, which loads the level) and
   `benchmark.txt` (the run's settings, read by
   `port/android/native/native_main.c`) to the app's files folder;
3. starts the app; the game loads the level, turns and looks about on its
   own (`HALO_TEST_INPUT=look:1`) and quits after the given seconds
   (`HALO_EXIT_AFTER`), with `debug.frame_timing` on;
4. pulls `startup.txt` and the end of `debug.txt` into
   `bench-results/bench-<time>.txt`, and removes both files again.

```
bench.bat
bench.bat -Apk halo-armv7-release.apk
bench.bat -Level a10 -Seconds 90 -Set HALO_RENDER_SCALE=0.75,HALO_GPU_FILL_TEST=true
./bench.sh halo-armv7-release.apk a30 120 HALO_RENDER_SCALE=0.75
```

Levels: a10 (The Pillar of Autumn), a30 (Halo), a50 (The Truth and
Reconciliation), b30 (The Silent Cartographer), b40 (Assault on the Control
Room), c10 (343 Guilty Spark), c20 (The Library), c40 (Two Betrayals), d20
(Keyes), d40 (The Maw). Any setting's environment name (its `# (for one
run: ...)` line in config.toml) can be given with `-Set`.

## The whole cycle: update.bat

`update.bat` takes the newest `opence-armv7-files*.zip` from Downloads,
commits it to the fork (`killerdwarf15/opence-highres`, cloned into
`%USERPROFILE%\opence-highres` the first time), waits for the build, downloads
its APK, installs it and runs the benchmarks:

```
update.bat
update.bat -Runs "default;HALO_RENDER_SCALE=0.75;HALO_GPU_FILL_TEST=true"
```

It needs git (git-scm.com) and the GitHub CLI (cli.github.com), signed in
once with `gh auth login`.

## Screenshots and video

Each run wakes the screen first (`input keyevent KEYCODE_WAKEUP`, and
`svc power stayon usb` so that it stays on while plugged in), and takes a
screenshot every 20 seconds (`-ScreenshotEvery`, 0 none). `-Record` adds a
video (`screenrecord`, 640x360, from about 25 seconds in, at most 3
minutes), which costs the game some speed while it records. Both go into
`bench-results/media-<time>.zip` beside the report.

```
bench.bat -Record
update.bat -Record -Runs "default;HALO_RENDER_THREAD=true"
```
