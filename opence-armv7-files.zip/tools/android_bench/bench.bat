@echo off
rem bench.bat: runs bench.ps1 (tools/android_bench/README.md) with the
rem arguments given, PowerShell's script policy aside for it alone
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0bench.ps1" %*
