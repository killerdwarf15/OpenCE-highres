# update.ps1: the whole cycle from this computer (tools/android_bench/README.md):
# the newest opence-armv7-files*.zip from Downloads pushed to the fork, the
# build waited for, its APK downloaded, installed, and benchmarked.
#   .\update.bat
#   .\update.bat -Runs "default;HALO_RENDER_SCALE=0.75;HALO_GPU_FILL_TEST=true"
#   (one benchmark each, "default" with no settings of its own; a run's
#   settings separated by commas)
# Needs git and the GitHub CLI (gh), signed in once with: gh auth login
param(
    [string]$Repository = "killerdwarf15/opence-highres",
    [string]$Clone = (Join-Path $HOME "opence-highres"),
    [string]$Zip = "",
    # the benchmarks to run: "level[,record][,NAME=VALUE...];..." (or the old
    # "default;NAME=VALUE,..." form); none given, the zip's own plan
    # (tools/android_bench/plan.txt), else The Halo once
    [string]$Runs = "",
    # a video of each run as well as its screenshots (bench.ps1)
    [switch]$Record,
    # the reports kept to this computer (not pushed to the fork's
    # bench-results branch, where Claude reads them)
    [switch]$NoUpload
)

$ErrorActionPreference = "Stop"
foreach ($tool in "git", "gh") {
    if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) {
        throw "$tool was not found: install it (git-scm.com, cli.github.com), then run this again"
    }
}
function Run { param([string]$What) & $args[0] @($args | Select-Object -Skip 1); if ($LASTEXITCODE -ne 0) { throw "$What failed" } }

# ---------- room on the disk: what earlier rounds left (media copies in
# TEMP from older versions of bench.ps1; the reports' media zips, already
# uploaded or from a round that failed)
Get-ChildItem $env:TEMP -Directory -Filter "halo-media-*" -ErrorAction SilentlyContinue |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Get-ChildItem $env:TEMP -Directory -Filter "halo-shaders-*" -ErrorAction SilentlyContinue |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Get-ChildItem (Join-Path (Get-Location) "bench-results") -File -Filter "media-*.zip" -ErrorAction SilentlyContinue |
    Remove-Item -Force -ErrorAction SilentlyContinue

# ---------- the files
if (-not $Zip) {
    $downloads = Join-Path $HOME "Downloads"
    $newest = Get-ChildItem $downloads -Filter "opence-armv7-files*.zip" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $newest) { throw "no opence-armv7-files*.zip in $downloads" }
    $Zip = $newest.FullName
}
Write-Host "files: $Zip ($((Get-Item $Zip).LastWriteTime))"

# ---------- the benchmark tools in the zip (tools/android_bench) copied
# beside this script, and the zip's plan, if it has them
$unpacked = Join-Path $env:TEMP "halo-update-zip"
if (Test-Path $unpacked) { Remove-Item -Recurse -Force $unpacked }
Expand-Archive -Path $Zip -DestinationPath $unpacked -Force
$tools = Join-Path $unpacked "tools\android_bench"
$plan = ""
if (Test-Path $tools) {
    Get-ChildItem $tools -File | Where-Object { $_.Name -ne "plan.txt" } | ForEach-Object {
        Copy-Item $_.FullName (Join-Path $PSScriptRoot $_.Name) -Force
    }
    $planFile = Join-Path $tools "plan.txt"
    if (Test-Path $planFile) {
        $plan = (Get-Content $planFile | Where-Object { $_ -and -not $_.StartsWith("#") }) -join ";"
        Write-Host "plan from the zip: $plan"
    }
    Write-Host "benchmark tools updated from the zip"
}
if (-not $Runs) { $Runs = if ($plan) { $plan } else { "a30" } }

# ---------- the fork, pushed
if (-not (Test-Path (Join-Path $Clone ".git"))) {
    Write-Host "cloning $Repository into $Clone"
    Run "clone" gh repo clone $Repository $Clone
}
Push-Location $Clone
try {
    Run "pull" git pull --ff-only
    Copy-Item $Zip (Join-Path $Clone "opence-armv7-files.zip") -Force
    Run "add" git add opence-armv7-files.zip
    & git diff --cached --quiet
    if ($LASTEXITCODE -eq 0) {
        Write-Host "the fork already has these files: building them again"
        Run "dispatch" gh workflow run build.yml --repo $Repository --ref main
        Start-Sleep -Seconds 10
        $commit = (& git rev-parse HEAD).Trim()
    }
    else {
        Run "commit" git commit -q -m ("Add files via update.ps1 (" + (Split-Path $Zip -Leaf) + ")")
        Run "push" git push -q
        $commit = (& git rev-parse HEAD).Trim()
    }
}
finally { Pop-Location }
Write-Host "commit $commit"

# ---------- the build, waited for
$run = $null
for ($try = 0; $try -lt 60 -and -not $run; $try++) {
    $list = & gh run list --repo $Repository --workflow build.yml --commit $commit --json databaseId --limit 1 | ConvertFrom-Json
    if ($list) { $run = $list[0].databaseId } else { Start-Sleep -Seconds 10 }
}
if (-not $run) { throw "no build of $commit started (Actions tab: Run workflow)" }
Write-Host "build $run started; waiting for it (the Android job takes a while)"
do {
    Start-Sleep -Seconds 30
    $jobs = (& gh run view $run --repo $Repository --json jobs | ConvertFrom-Json).jobs
    $android = $jobs | Where-Object { $_.name -eq "android" }
    if ($android) { Write-Host ("  android: " + $android.status + " " + $android.conclusion) }
} while (-not $android -or $android.status -ne "completed")
if ($android.conclusion -ne "success") {
    throw "the Android build failed: gh run view $run --repo $Repository --log-failed shows why"
}

# ---------- the APK
# (each build's APK went into its own folder and none was removed: they
# filled the disk. Every earlier one is removed first now)
Get-ChildItem $env:TEMP -Directory -Filter "halo-artifact-*" -ErrorAction SilentlyContinue |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
$artifacts = Join-Path $env:TEMP "halo-artifact-$run"
Run "download" gh run download $run --repo $Repository --name halo-android-release --dir $artifacts
$apk = Get-ChildItem $artifacts -Recurse -Filter "halo-armv7-release.apk" | Select-Object -First 1
if (-not $apk) { throw "no halo-armv7-release.apk in the build's artifact" }
Write-Host "APK: $($apk.FullName)"

# ---------- installed and benchmarked
$bench = Join-Path $PSScriptRoot "bench.ps1"
$resultsFolder = Join-Path (Get-Location) "bench-results"
New-Item -ItemType Directory -Force -Path $resultsFolder | Out-Null
$before = @(Get-ChildItem $resultsFolder -File | ForEach-Object { $_.FullName })
$first = $true
foreach ($entry in ($Runs -split ';')) {
    $arguments = @{}
    if ($first) { $arguments.Apk = $apk.FullName; $first = $false }
    $settings = @()
    foreach ($part in ($entry -split ',')) {
        $part = $part.Trim()
        if (-not $part -or $part -eq "default") { continue }
        if ($part -eq "record") { $arguments.Record = $true; continue }
        if ($part -eq "shaders") { $arguments.Shaders = $true; continue }
        if ($part -match '^[a-d][0-9]{2}$') { $arguments.Level = $part; continue }
        if ($part -match '^seconds=([0-9]+)$') { $arguments.Seconds = [int]$Matches[1]; continue }
        if ($part -match '^shotevery=([0-9]+)$') { $arguments.ScreenshotEvery = [int]$Matches[1]; continue }
        if ($part -match '^firstshot=([0-9]+)$') { $arguments.FirstShot = [int]$Matches[1]; continue }
        $settings += $part
    }
    if ($settings) { $arguments.Set = $settings }
    if ($Record) { $arguments.Record = $true }
    & $bench @arguments
}
$new = @(Get-ChildItem $resultsFolder -File | Where-Object { $before -notcontains $_.FullName })
Write-Host ""
Write-Host "reports: $resultsFolder ($($new.Count) new files)"

# ---------- the reports pushed to the fork's bench-results branch (a
# worktree of its own beside the clone; [skip ci]: no build for them)
if (-not $NoUpload -and $new.Count) {
    $worktree = "$Clone-results"
    # (Windows PowerShell 5 makes a native command's error output a
    # terminating error under "Stop", redirected or not: git's expected
    # failures here, a branch not there yet, are not errors)
    $ErrorActionPreference = "Continue"
    Push-Location $Clone
    try {
        if (-not (Test-Path (Join-Path $worktree ".git"))) {
            & git fetch -q origin bench-results 2>$null
            & git show-ref --verify --quiet refs/remotes/origin/bench-results
            if ($LASTEXITCODE -eq 0) {
                Run "worktree" git worktree add -f $worktree -B bench-results origin/bench-results
            } else {
                Run "worktree" git worktree add -f --detach $worktree
                Push-Location $worktree
                Run "orphan" git checkout -q --orphan bench-results
                & git rm -rq --cached . 2>$null
                Get-ChildItem -Force | Where-Object { $_.Name -ne ".git" } | Remove-Item -Recurse -Force
                Pop-Location
            }
        }
    }
    finally { Pop-Location }
    Push-Location $worktree
    try {
        # (each upload is the branch's only commit, pushed over the last: the
        # rounds' videos, kept in its history, filled the disk with every
        # round's media in .git; the newest round is all Claude reads)
        $batch = Get-Date -Format "yyyyMMdd-HHmmss"
        & git checkout -q --orphan bench-results-upload 2>$null
        & git rm -rq --cached . 2>$null
        Get-ChildItem -Force | Where-Object { $_.Name -ne ".git" } | Remove-Item -Recurse -Force
        $target = Join-Path $worktree $batch
        New-Item -ItemType Directory -Force -Path $target | Out-Null
        $listed = @()
        foreach ($file in $new) {
            Copy-Item $file.FullName (Join-Path $target $file.Name) -Force
            $listed += "$batch/$($file.Name)"
        }
        $listed | Set-Content -Encoding ascii (Join-Path $worktree "latest.txt")
        Run "add" git add -A
        Run "commit" git commit -q -m "[skip ci] Benchmark results $batch"
        & git branch -D bench-results 2>$null
        Run "rename" git branch -m bench-results
        # (a round of 720p videos is 200+ MB: a larger HTTP buffer, and three
        # tries, as one timed out (HTTP 408) and lost the round's upload)
        & git config http.postBuffer 524288000
        $pushed = $false
        foreach ($try in 1..3) {
            & git push -q -f -u origin bench-results
            if ($LASTEXITCODE -eq 0) { $pushed = $true; break }
            Write-Host "push failed (try $try of 3)"
            Start-Sleep -Seconds 10
        }
        if (-not $pushed) {
            throw "push failed: the results are committed in $worktree; run 'git push -f -u origin bench-results' there to try again"
        }
        Write-Host ""
        Write-Host "uploaded to the bench-results branch ($batch): tell Claude the benchmark is done"
    }
    finally { Pop-Location }
    # (the old rounds' objects freed, and the uploaded media's local copies)
    Push-Location $Clone
    try {
        & git reflog expire --expire=now --all 2>$null
        & git gc -q --prune=now 2>$null
    }
    finally { Pop-Location }
    foreach ($file in $new) {
        if ($file.Name -like "media-*.zip" -or $file.Name -like "shaders-*.zip") {
            Remove-Item -Force $file.FullName -ErrorAction SilentlyContinue
        }
    }
}
