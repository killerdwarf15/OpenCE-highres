# update.ps1: the whole cycle from this computer (tools/android_bench/README.md):
# the newest opence-armv7-files*.zip from Downloads pushed to the fork, the
# build waited for, its APK downloaded, installed, and benchmarked.
#   .\update.bat
#   .\update.bat -Runs "default;HALO_RENDER_SCALE=0.75;HALO_GPU_FILL_TEST=true"
#   (one benchmark each, "default" with no settings of its own; a run's
#   settings separated by commas)
# Needs git and the GitHub CLI (gh), signed in once with: gh auth login
param(
    [string]$Repository = "killerdwarf15/opence-highres",
    [string]$Clone = (Join-Path $HOME "opence-highres"),
    [string]$Zip = "",
    [string]$Runs = "default"
)

$ErrorActionPreference = "Stop"
foreach ($tool in "git", "gh") {
    if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) {
        throw "$tool was not found: install it (git-scm.com, cli.github.com), then run this again"
    }
}
function Run { param([string]$What) & $args[0] @($args | Select-Object -Skip 1); if ($LASTEXITCODE -ne 0) { throw "$What failed" } }

# ---------- the files
if (-not $Zip) {
    $downloads = Join-Path $HOME "Downloads"
    $newest = Get-ChildItem $downloads -Filter "opence-armv7-files*.zip" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $newest) { throw "no opence-armv7-files*.zip in $downloads" }
    $Zip = $newest.FullName
}
Write-Host "files: $Zip"

# ---------- the fork, pushed
if (-not (Test-Path (Join-Path $Clone ".git"))) {
    Write-Host "cloning $Repository into $Clone"
    Run "clone" gh repo clone $Repository $Clone
}
Push-Location $Clone
try {
    Run "pull" git pull --ff-only
    Copy-Item $Zip (Join-Path $Clone "opence-armv7-files.zip") -Force
    Run "add" git add opence-armv7-files.zip
    & git diff --cached --quiet
    if ($LASTEXITCODE -eq 0) {
        Write-Host "the fork already has these files: building them again"
        Run "dispatch" gh workflow run build.yml --repo $Repository --ref main
        Start-Sleep -Seconds 10
        $commit = (& git rev-parse HEAD).Trim()
    }
    else {
        Run "commit" git commit -q -m ("Add files via update.ps1 (" + (Split-Path $Zip -Leaf) + ")")
        Run "push" git push -q
        $commit = (& git rev-parse HEAD).Trim()
    }
}
finally { Pop-Location }
Write-Host "commit $commit"

# ---------- the build, waited for
$run = $null
for ($try = 0; $try -lt 60 -and -not $run; $try++) {
    $list = & gh run list --repo $Repository --workflow build.yml --commit $commit --json databaseId --limit 1 | ConvertFrom-Json
    if ($list) { $run = $list[0].databaseId } else { Start-Sleep -Seconds 10 }
}
if (-not $run) { throw "no build of $commit started (Actions tab: Run workflow)" }
Write-Host "build $run started; waiting for it (the Android job takes a while)"
do {
    Start-Sleep -Seconds 30
    $jobs = (& gh run view $run --repo $Repository --json jobs | ConvertFrom-Json).jobs
    $android = $jobs | Where-Object { $_.name -eq "android" }
    if ($android) { Write-Host ("  android: " + $android.status + " " + $android.conclusion) }
} while (-not $android -or $android.status -ne "completed")
if ($android.conclusion -ne "success") {
    throw "the Android build failed: gh run view $run --repo $Repository --log-failed shows why"
}

# ---------- the APK
$artifacts = Join-Path $env:TEMP "halo-artifact-$run"
if (Test-Path $artifacts) { Remove-Item -Recurse -Force $artifacts }
Run "download" gh run download $run --repo $Repository --name halo-android-release --dir $artifacts
$apk = Get-ChildItem $artifacts -Recurse -Filter "halo-armv7-release.apk" | Select-Object -First 1
if (-not $apk) { throw "no halo-armv7-release.apk in the build's artifact" }
Write-Host "APK: $($apk.FullName)"

# ---------- installed and benchmarked
$bench = Join-Path $PSScriptRoot "bench.ps1"
$first = $true
foreach ($settings in ($Runs -split ';')) {
    $arguments = @{}
    if ($first) { $arguments.Apk = $apk.FullName; $first = $false }
    if ($settings -and $settings -ne "default") { $arguments.Set = @($settings -split ',') }
    & $bench @arguments
}
Write-Host ""
Write-Host "reports: $(Join-Path (Get-Location) 'bench-results')"
