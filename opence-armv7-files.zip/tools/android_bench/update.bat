@echo off
rem update.bat: runs update.ps1 (tools/android_bench/README.md) with the
rem arguments given, PowerShell's script policy aside for it alone
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update.ps1" %*
