"""Ninja rules for the 32-bit ARM Android build (``ninja android_armv7``).

A 32-bit ARM process has 32-bit pointers of its own, so the game needs no
guest image there (port/android/README.md, "ILP32 code"): the game, the
platform layer and port/android/native/native_main.c are compiled as the
Linux build compiles them (tools/linux_build.py), against bionic, into one
library, libmain.so, beside a 32-bit SDL3. Gradle packages them for
armeabi-v7a with -Phalo_abi=armeabi-v7a (port/android/app/build.gradle).
See port/android/native/README.md.
"""

import os
import sys
from pathlib import Path
from typing import Any, List

from .android_build import ANDROID_API, SDL_DIR, _find_ndk, _quote, fetch_third_party
from .embed_assets import hud_assets_build
from .linux_build import (EXPAT_DIR, EXPAT_SOURCES, GAME_FLAGS, KCP_DIR, MBEDTLS_DIR, MINIUPNPC_DEFINES,
                          MINIUPNPC_DIR, MONOCYPHER_DIR, PLATFORM_FLAGS, STB_VORBIS_SOURCE, TOML_DIR, XDK_INCLUDE,
                          ZLIB_DEFINES, ZLIB_DIR, ZLIB_SOURCES, _load_port_config, compile_launcher,
                          configuration_defines, game_defines_and_includes, game_sources, miniupnpc_sources,
                          musl_math_cflags, musl_math_sources, opus_cflags, opus_sources, updater_defines,
                          xdk_headers)

BUILD = Path("build/android-armv7")
LINUX_DIR = Path("port/linux")
NATIVE_DIR = Path("port/android/native")
HOST_DIR = Path("port/android/host")

TARGET = f"armv7a-linux-androideabi{ANDROID_API}"

# The target: ARMv7-A with NEON, Thumb-2 code, the softfp calling convention
# of armeabi-v7a (floats and doubles in core registers, so a call without a
# prototype, or with a variadic one, passes them as the callee expects),
# position-independent for a shared library.
TARGET_FLAGS = [
    f"--target={TARGET}",
    "-march=armv7-a",
    "-mfloat-abi=softfp",
    "-mfpu=neon",
    "-mthumb",
    "-fPIC",
    # (scheduled for the SHIELD Portable's Cortex-A15s, which costs older
    # cores nothing: no instruction they lack)
    "-mtune=cortex-a15",
]

# As the Linux build's ABI flags (tools/linux_build.py, LINUX_ABI_FLAGS),
# minus what only x86 has: ARM already aligns doubles to 8 as MSVC does
# (-malign-double), and returns structures of up to 4 bytes in r0.
ABI_FLAGS = [
    # (char is signed, as MSVC's, x86's and the 64-bit app's guest's, an
    # Apple ABI: 32-bit ARM Linux and Android make it unsigned, and the
    # game's chars that hold NONE (-1) or a signed count then hold 255)
    "-fsigned-char",
    "-fms-extensions",
    "-fshort-wchar",
    "-fcommon",
    "-fno-strict-aliasing",
    "-fwrapv",
    "-fno-delete-null-pointer-checks",
    "-fno-omit-frame-pointer",
    "-ffp-contract=off",
    # (-O3, without ThinLTO: the two together were tried, and the game
    # stopped as it started on the SHIELD Portable, its file and log output
    # gone; -O3 alone is the first of the two, measured on its own)
    "-O3",
    "-g",
    *(f"-fno-builtin-{name}" for name in (
        "wcslen", "wcsnlen", "wcschr", "wcsrchr", "wcscmp", "wcsncmp", "wcscpy",
        "wcsncpy", "wcscat", "wcsncat", "wmemchr", "wmemcmp", "wmemcpy",
        "wmemmove", "wmemset",
    )),
    # the platform layer's Android paths (touch, the app's folders), its
    # OpenGL ES renderer, and this build's own differences from the guest's
    "-DHALO_ANDROID=1",
    "-DHALO_GLES=1",
    "-DHALO_ANDROID_ARMV7=1",
]

# the posix_*.c units, as the Linux build's (POSIX_FLAGS), with bionic's ABI
POSIX_FLAGS = ["-std=gnu11", "-D_GNU_SOURCE", "-D_FILE_OFFSET_BITS=64", "-O2", "-g", "-Wall",
               "-DHALO_ANDROID=1", "-DHALO_ANDROID_ARMV7=1"]

# platform units this build does without
PLATFORM_EXCLUDE = {
    # a Linux GPU driver's trace markers: its open() and openat() stand in
    # for the C library's and reach it through dlsym(RTLD_NEXT), which finds
    # nothing in a library Android 5 loads (the calls of this library's own
    # code to open() came to it, and called a null pointer)
    "posix_trace_marker.c",
}

LIBRARIES = ["SDL3", "GLESv3", "EGL", "log", "android", "m", "dl"]


def android_armv7_configure_inputs() -> List[Path]:
    return [Path(__file__), NATIVE_DIR]


def generate_android_armv7_build(n: Any, sln: Any) -> None:
    config_path = LINUX_DIR / "port.json"
    if not config_path.is_file() or not NATIVE_DIR.is_dir():
        return
    ndk = Path(sln.android_ndk) if getattr(sln, "android_ndk", None) else _find_ndk()
    if not ndk or not ndk.is_dir():
        n.comment("32-bit ARM Android build: no NDK found (set ANDROID_NDK_HOME or pass --android-ndk)")
        return
    # (SDL3 as the 64-bit build fetches and patches it, which it has done
    # already when it ran first; this build needs no musl)
    if not (SDL_DIR / "CMakeLists.txt").is_file():
        try:
            fetch_third_party()
        except Exception as error:
            print(f"32-bit ARM Android build disabled: cannot fetch SDL3 ({error})", file=sys.stderr)
            return
    config = _load_port_config()

    prebuilt = ndk / "toolchains" / "llvm" / "prebuilt"
    tags = sorted(entry.name for entry in prebuilt.iterdir() if entry.is_dir()) if prebuilt.is_dir() else []
    if not tags:
        n.comment("32-bit ARM Android build: the NDK has no LLVM toolchain")
        return
    tag = "linux-x86_64" if "linux-x86_64" in tags else tags[0]
    toolchain = prebuilt / tag
    sysroot = toolchain / "sysroot"
    # (HALO_ARMV7_CC: another clang, given the target and system root below)
    cc = os.environ.get("HALO_ARMV7_CC") or str(toolchain / "bin" / "clang")
    target = TARGET_FLAGS + [f"--sysroot={_quote(sysroot)}"]

    obj_dir = BUILD / "obj"
    sdl_build = BUILD / "sdl3-build"
    libsdl = sdl_build / "libSDL3.so"
    jni_dir = BUILD / "jniLibs" / "armeabi-v7a"
    libmain = jni_dir / "libmain.so"
    assets_dir = BUILD / "assets"
    prefix_header = LINUX_DIR / "include" / "halo_linux_prefix.h"
    semantics_header = Path("build/linux/halo_msvc_semantics.h")
    platform_semantics_header = Path("build/linux/platform_msvc_semantics.h")
    port_include = LINUX_DIR / "include"
    sdk_flags = f"-idirafter {XDK_INCLUDE}"
    release = getattr(sln, "port_release", False)
    abi = " ".join(target + ABI_FLAGS + configuration_defines(sln))
    sdl_include = f"-I{SDL_DIR / 'include'}"

    n.comment("32-bit ARM Android build (ninja android_armv7); see port/android/native/README.md")
    n.variable("android_armv7_cc", cc)
    n.rule(
        name="android_armv7_cc",
        command=f"{compile_launcher(sln)}$android_armv7_cc -MMD -MF $out.d $cflags -c $in -o $out",
        description="ANDROID ARMV7 CC $out",
        depfile="$out.d",
        deps="gcc",
    )
    objects: List[Path] = []
    implicit = [*xdk_headers(), prefix_header, semantics_header, platform_semantics_header,
                SDL_DIR / "CMakeLists.txt"]

    def add_object(source: Path, cflags: str) -> None:
        obj = obj_dir / Path(str(source).lstrip("/")).with_suffix(".o")
        objects.append(obj)
        n.build(outputs=obj, rule="android_armv7_cc", inputs=source, implicit=implicit,
                variables={"cflags": cflags})

    # ---------- the game, as the Linux build's

    game_cflags = " ".join([
        abi, " ".join(GAME_FLAGS),
        f"-include {prefix_header}", f"-include {semantics_header}",
        f"-I{port_include}", f"-iquote {Path(config['game_sources'])}",
        game_defines_and_includes(config), sdk_flags,
    ])
    for source in game_sources(config):
        flags = game_cflags
        if source.as_posix() == "source/main/main.c":
            flags += " " + updater_defines(release)
        if source.as_posix() == "source/shell/shell_xbox.c":
            # (the game's main, which native_main.c starts on a thread of its
            # own: SDL's Android activity calls SDL_main)
            flags += " -Dmain=halo_game_main"
        add_object(source, flags)
    for source in sorted(Path(config["game_sources"]).glob("*.c")):
        add_object(source, game_cflags)
    add_object(STB_VORBIS_SOURCE, game_cflags)

    # ---------- the platform layer

    platform_dir = Path(config["platform_sources"])
    platform_cflags = " ".join([
        abi, " ".join(PLATFORM_FLAGS),
        f"-include {prefix_header}", f"-include {platform_semantics_header}",
        f"-I{platform_dir}", f"-I{port_include}", f"-I{TOML_DIR}", f"-I{EXPAT_DIR}", f"-I{KCP_DIR}",
        f"-I{MONOCYPHER_DIR}", f"-I{ZLIB_DIR}", "-Isource -Isource/cseries", sdl_include, sdk_flags,
    ])
    posix_cflags = " ".join([*target, *POSIX_FLAGS, f"-I{platform_dir}"])
    mbedtls_include = f"-I{MBEDTLS_DIR / 'include'} -DMBEDTLS_THREADING_C -DMBEDTLS_THREADING_PTHREAD"
    for source in sorted(platform_dir.glob("*.c")):
        if source.name in PLATFORM_EXCLUDE:
            continue
        if source.name in ("posix_update.c", "posix_dtls.c"):
            add_object(source, f"{posix_cflags} {mbedtls_include}")
        elif source.name == "posix_upnp.c":
            add_object(source, f"{posix_cflags} -I{MINIUPNPC_DIR / 'include'} -DMINIUPNP_STATICLIB")
        elif source.name.startswith("posix_"):
            add_object(source, posix_cflags)
        elif source.name == "updater.c":
            add_object(source, f"{platform_cflags} {updater_defines(release)}")
        else:
            add_object(source, platform_cflags)
    for source in hud_assets_build(n, "android_armv7", BUILD / "generated" / "hud_hires_assets.c"):
        add_object(source, platform_cflags)
    for source in sorted((MBEDTLS_DIR / "library").glob("*.c")):
        add_object(source, " ".join([*target, *POSIX_FLAGS, mbedtls_include, f"-I{MBEDTLS_DIR / 'library'}",
                                     "-fno-builtin-wcslen", "-w"]))
    for source in miniupnpc_sources():
        add_object(source, " ".join([*target, *POSIX_FLAGS, *MINIUPNPC_DEFINES, f"-I{MINIUPNPC_DIR / 'include'}",
                                     f"-I{MINIUPNPC_DIR / 'src'}", "-fno-builtin-wcslen", "-w"]))
    add_object(TOML_DIR / "tomlc17.c", " ".join([abi, "-std=gnu11", "-w"]))
    for name in EXPAT_SOURCES:
        add_object(EXPAT_DIR / name, " ".join([abi, "-std=gnu11", f"-I{EXPAT_DIR}", "-w"]))
    add_object(KCP_DIR / "ikcp.c", " ".join([abi, "-std=gnu11", "-w"]))
    for source in opus_sources():
        add_object(source, opus_cflags(abi))
    for name in ("monocypher.c", "monocypher-ed25519.c"):
        add_object(MONOCYPHER_DIR / name, " ".join([abi, "-std=gnu11", "-w"]))
    for name in ZLIB_SOURCES:
        add_object(ZLIB_DIR / name, " ".join([abi, "-std=gnu11", *ZLIB_DEFINES, "-w"]))
    for source in musl_math_sources():
        add_object(source, musl_math_cflags(abi))

    # ---------- the app's side: the entry point, touch and OpenGL ES helpers

    native_cflags = " ".join([
        *target, "-std=gnu11", "-O2", "-g", "-D_GNU_SOURCE", "-Wall", "-Wno-unused-function",
        "-DHALO_ANDROID=1", "-DHALO_GLES=1", "-DHALO_ANDROID_ARMV7=1",
        "-Iport/android/include", f"-I{HOST_DIR}", sdl_include, f"-I{LINUX_DIR / 'src'}", f"-I{TOML_DIR}",
    ])
    for source in [NATIVE_DIR / "native_main.c", HOST_DIR / "host_touch.c", HOST_DIR / "host_gl.c"]:
        add_object(source, native_cflags)

    # ---------- SDL3, for armeabi-v7a

    n.rule(
        name="android_armv7_sdl3",
        command=(f"cmake -S {SDL_DIR} -B {sdl_build} -G Ninja "
                 f"-DCMAKE_TOOLCHAIN_FILE={ndk}/build/cmake/android.toolchain.cmake "
                 f"-DANDROID_ABI=armeabi-v7a -DANDROID_PLATFORM=android-{ANDROID_API} -DCMAKE_BUILD_TYPE=Release "
                 f"-DSDL_SHARED=ON -DSDL_STATIC=OFF -DSDL_TEST_LIBRARY=OFF -DSDL_TESTS=OFF -DSDL_EXAMPLES=OFF "
                 f"> {BUILD}/sdl3-configure.log && ninja -C {sdl_build} > {BUILD}/sdl3-build.log"),
        description="ANDROID ARMV7 SDL3",
        pool="console",
    )
    n.build(outputs=libsdl, rule="android_armv7_sdl3", implicit=[SDL_DIR / "CMakeLists.txt"])

    # ---------- libmain.so

    n.rule(
        name="android_armv7_link",
        command=(f"$android_armv7_cc {' '.join(target)} -shared -fuse-ld=lld -g -o $out @$out.rsp "
                 f"-L{sdl_build} " + " ".join(f"-l{lib}" for lib in LIBRARIES)
                 + " -Wl,--no-undefined -Wl,-z,max-page-size=16384"
                 # (no debugging sections, but the symbol table, which
                 # Gradle keeps for this library: the crash reports name
                 # static functions by it, port/linux/src/memory_watch.c)
                 + " -Wl,--strip-debug"),
        description="ANDROID ARMV7 LINK $out",
        rspfile="$out.rsp",
        rspfile_content="$in_newline",
    )
    n.build(outputs=libmain, rule="android_armv7_link", inputs=objects, implicit=[libsdl])

    # ---------- staging for Gradle (-Phalo_abi=armeabi-v7a)

    # ---------- libhalocrash.so, the crash reporter HaloApplication loads first

    crash_object = obj_dir / "port/android/native/crash_report.o"
    n.build(outputs=crash_object, rule="android_armv7_cc", inputs=NATIVE_DIR / "crash_report.c",
            variables={"cflags": " ".join([*target, "-std=gnu11", "-O1", "-g", "-Wall", "-fno-omit-frame-pointer"])})
    libcrash = jni_dir / "libhalocrash.so"
    n.rule(
        name="android_armv7_link_crash",
        command=f"$android_armv7_cc {' '.join(target)} -shared -fuse-ld=lld -o $out $in -llog -ldl",
        description="ANDROID ARMV7 LINK $out",
    )
    n.build(outputs=libcrash, rule="android_armv7_link_crash", inputs=crash_object)

    n.rule(name="android_armv7_copy", command="cp $in $out", description="ANDROID ARMV7 STAGE $out")
    staged_sdl = jni_dir / "libSDL3.so"
    staged_brokers = assets_dir / "brokers.txt"
    n.build(outputs=staged_sdl, rule="android_armv7_copy", inputs=libsdl)
    n.build(outputs=staged_brokers, rule="android_armv7_copy", inputs=Path("port/assets/network/brokers.txt"))
    n.build(outputs="android_armv7", rule="phony", inputs=[libmain, libcrash, staged_sdl, staged_brokers])
    n.newline()
