package com.halo.decomp;

import android.app.Application;
import android.os.Build;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * The game (HaloActivity) runs in a process of its own, ":game", so that
 * its Java runtime starts fresh for it: nothing the launcher, the disc
 * image import or an earlier game did is left in its heap.
 *
 * There the native library is loaded first thing, and reserves the fixed
 * addresses the game needs at 0x80000000 (port/android/host/host_main.c,
 * JNI_OnLoad) before the Java side has allocated anything large: on some
 * devices, handhelds with a large Java heap especially, ART's large object
 * space covers those addresses, and only an idle part of it can be taken
 * back (port/android/host/host_memory.c).
 */
public class HaloApplication extends Application {
    /** this process's name: Application.getProcessName from Android 9, the
     * kernel's command line of the process before it */
    private static String processName() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
            return Application.getProcessName();
        try (FileInputStream input = new FileInputStream("/proc/self/cmdline")) {
            byte[] buffer = new byte[256];
            int length = input.read(buffer);
            int end = 0;

            while (end < length && buffer[end] != 0)
                end++;
            return end > 0 ? new String(buffer, 0, end, StandardCharsets.UTF_8) : null;
        } catch (IOException e) {
            return null;
        }
    }

    /** before Android 7.0 (where the 32-bit ARM app runs: port/android/native),
     * the game process's own log, the Java side's and the native side's
     * (a crash's "Fatal signal" line among them), into logcat.txt in the
     * files folder: a process may read its own log there without adb */
    private void captureLog() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
            return;
        File folder = getExternalFilesDir(null);
        if (folder == null)
            return;
        try {
            Runtime.getRuntime().exec(new String[] {
                "logcat", "-v", "threadtime", "-f", new File(folder, "logcat.txt").getAbsolutePath()
            });
        } catch (IOException | SecurityException e) {
            // (no log, then)
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        String process = processName();
        if (process == null || !process.endsWith(":game"))
            return;
        captureLog();
        try {
            // in SDLActivity's order (HaloActivity.getLibraries); it
            // finds them loaded
            System.loadLibrary("SDL3");
            System.loadLibrary("main");
        } catch (UnsatisfiedLinkError e) {
            // SDLActivity reports it (and logcat.txt has it)
            Log.e("halo", "cannot load the native libraries", e);
        }
    }
}
