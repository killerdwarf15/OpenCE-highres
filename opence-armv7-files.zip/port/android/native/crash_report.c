/*
CRASH_REPORT.C

libhalocrash.so, of the 32-bit ARM Android build (port/android/native): a
crash reporter with nothing to depend on, which HaloApplication loads before
SDL3 and the game, so that a crash anywhere after it (as libraries load,
before the game's own report, port/linux/src/memory_watch.c, can be written)
names its place in the log (logcat, and so logcat.txt, tag "halo-crash"):
the signal, the address, and the calls, each as its library, offset and
nearest exported function.

Android 5's own report of a crash (debuggerd's tombstone) is out of reach of
an app without adb, and is not written at all where the process is not
dumpable.
*/

#include <android/log.h>
#include <dlfcn.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <ucontext.h>
#include <unistd.h>

#define TAG "halo-crash"

static const int signals[] = { SIGSEGV, SIGBUS, SIGILL, SIGFPE, SIGABRT };
#define SIGNAL_COUNT (int)(sizeof(signals) / sizeof(signals[0]))
static struct sigaction previous[SIGNAL_COUNT];
static volatile sig_atomic_t reporting;

static void describe(const char *what, unsigned long address)
{
	Dl_info information;

	memset(&information, 0, sizeof(information));
	if (address && dladdr((void *)address, &information) && information.dli_fname)
	{
		const char *name = strrchr(information.dli_fname, '/');

		__android_log_print(ANDROID_LOG_FATAL, TAG, "%s %08lx %s+%lx %s+%lx", what, address,
			name ? name + 1 : information.dli_fname, address - (unsigned long)information.dli_fbase,
			information.dli_sname ? information.dli_sname : "?",
			information.dli_saddr ? address - (unsigned long)information.dli_saddr : 0UL);
	}
	else
	{
		__android_log_print(ANDROID_LOG_FATAL, TAG, "%s %08lx", what, address);
	}
}

static void handler(int signal_number, siginfo_t *information, void *context)
{
	ucontext_t *ucontext = context;
	int index;

	for (index = 0; index < SIGNAL_COUNT; index++)
	{
		if (signals[index] == signal_number)
			break;
	}
	if (!reporting && index < SIGNAL_COUNT)
	{
		reporting = 1;
		__android_log_print(ANDROID_LOG_FATAL, TAG, "signal %d (code %d) at %p in thread %d", signal_number,
			information ? information->si_code : 0, information ? information->si_addr : NULL, gettid());
#if defined(__arm__)
		{
			unsigned long pc = ucontext->uc_mcontext.arm_pc;
			unsigned long sp = ucontext->uc_mcontext.arm_sp;
			/* (Thumb code's frame pointer is r7, ARM code's r11) */
			unsigned long frame = (ucontext->uc_mcontext.arm_cpsr & 0x20) ? ucontext->uc_mcontext.arm_r7
				: ucontext->uc_mcontext.arm_fp;
			int depth;

			__android_log_print(ANDROID_LOG_FATAL, TAG, "r0 %08lx r1 %08lx r2 %08lx r3 %08lx sp %08lx cpsr %08lx",
				ucontext->uc_mcontext.arm_r0, ucontext->uc_mcontext.arm_r1, ucontext->uc_mcontext.arm_r2,
				ucontext->uc_mcontext.arm_r3, sp, ucontext->uc_mcontext.arm_cpsr);
			describe("pc", pc);
			describe("lr", ucontext->uc_mcontext.arm_lr & ~1UL);
			for (depth = 0; depth < 32; depth++)
			{
				const unsigned long *record = (const unsigned long *)frame;

				if (!frame || (frame & 3) || frame < sp || frame - sp > 0x1000000UL)
					break;
				describe("called from", record[1] & ~1UL);
				if (record[0] <= frame)
					break;
				frame = record[0];
			}
			/* the words at the stack, for a call through a null pointer,
			which leaves no frame */
			{
				const unsigned long *words = (const unsigned long *)sp;

				for (depth = 0; depth < 16; depth++)
				{
					Dl_info stack_information;

					if (dladdr((void *)(words[depth] & ~1UL), &stack_information) && stack_information.dli_fname)
						describe("on the stack", words[depth] & ~1UL);
				}
			}
		}
#else
		(void)ucontext;
#endif
	}
	/* then what was there before: the default action, and Android's own
	report */
	if (index < SIGNAL_COUNT)
	{
		sigaction(signal_number, &previous[index], NULL);
		if (!(previous[index].sa_flags & SA_SIGINFO) && previous[index].sa_handler == SIG_DFL)
		{
			signal(signal_number, SIG_DFL);
			if (information && information->si_code <= 0)
				raise(signal_number);
			return;
		}
		if (previous[index].sa_flags & SA_SIGINFO)
		{
			if (previous[index].sa_sigaction)
				previous[index].sa_sigaction(signal_number, information, context);
		}
		else if (previous[index].sa_handler != SIG_IGN)
		{
			previous[index].sa_handler(signal_number);
		}
	}
}

__attribute__((constructor)) static void install(void)
{
	struct sigaction action;
	int index;

	memset(&action, 0, sizeof(action));
	action.sa_sigaction = handler;
	action.sa_flags = SA_SIGINFO | SA_ONSTACK;
	sigemptyset(&action.sa_mask);
	for (index = 0; index < SIGNAL_COUNT; index++)
		sigaction(signals[index], &action, &previous[index]);
	__android_log_print(ANDROID_LOG_INFO, TAG, "crash reporter installed");
}
