/*
NATIVE_MAIN.C

Entry point of the 32-bit ARM Android build (armeabi-v7a, `ninja
android_armv7`; port/android/native/README.md).

A 32-bit ARM process has 32-bit pointers of its own, as the Xbox had, so
the game does not run as a guest image there (port/android/README.md, "ILP32
code"): the game, the platform layer and this file are one native library,
libmain.so, built as the Linux build is, against bionic and SDL3. This file
stands in for what the 64-bit app's host does around the guest
(port/android/host/host_main.c): it finds the data and save folders, passes
them and the display's shape to the game through its environment, and runs
the game's main (source/main/main.c, renamed halo_game_main by the build) on
a thread with a large stack.

The Xbox window at 0x80000000 is reserved as the library loads
(port/linux/src/xbox_memory.c, a constructor): HaloApplication loads this
library first thing in the game's process.

Until the renderer has an OpenGL ES 2.0 path (the Tegra 4 of the SHIELD
Portable has no OpenGL ES 3.0), such a GPU gets the game's window with a
test screen in it (d3d8_gl.c): the log (startup.txt, debug.txt and logcat,
tag "halo") shows how far the game gets.
*/

#include "host.h"
#include "tomlc17.h"

#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <android/log.h>
#include <jni.h>
#include <errno.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

/* (the build's date, for the startup log) */
#define HALO_ARMV7_BUILD __DATE__ " " __TIME__

/* the game's main (source/shell/shell_xbox.c, compiled with -Dmain=halo_game_main) */
int halo_game_main(int argc, char **argv);

/* the Custom Edition tag cache, reserved once the settings can be read
(port/linux/src/xbox_memory.c) */
void halo_custom_edition_tag_cache_reserve(void);

/* ---------- the startup log

Before the game opens debug.txt, what happens is written to startup.txt in
the app's files folder (Android/data/<package>/files), standard error
itself: the crash reports of port/linux/src/memory_watch.c go there too. It
is opened before anything else in this library runs (a constructor of the
first priority, before the Xbox window's, xbox_memory.c), from the folder's
usual path, as the app names its files folder only later. */

static int startup_log_open;

static void startup_log_line(const char *text)
{
	if (startup_log_open)
	{
		size_t length = strlen(text);

		write(STDERR_FILENO, text, length);
		if (!length || text[length - 1] != '\n')
			write(STDERR_FILENO, "\n", 1);
	}
}

/* (priority 100, before the Xbox window's, 101, so that a failure to
reserve it is written down) */
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wprio-ctor-dtor"
__attribute__((constructor(100))) static void startup_log_begin(void)
{
	char package[128] = "";
	char path[400];
	const char *storage = getenv("EXTERNAL_STORAGE");
	int file, length;

	file = open("/proc/self/cmdline", O_RDONLY);
	if (file >= 0)
	{
		length = (int)read(file, package, sizeof(package) - 1);
		close(file);
		package[length > 0 ? length : 0] = 0;
		/* (the game's process is <package>:game) */
		if (strchr(package, ':'))
			*strchr(package, ':') = 0;
	}
	if (!package[0])
		return;
	snprintf(path, sizeof(path), "%s/Android/data/%s/files/startup.txt", storage ? storage : "/sdcard", package);
	file = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0664);
	if (file < 0)
	{
		snprintf(path, sizeof(path), "/sdcard/Android/data/%s/files/startup.txt", package);
		file = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0664);
	}
	if (file < 0)
	{
		__android_log_print(ANDROID_LOG_ERROR, "halo", "cannot write %s", path);
		return;
	}
	dup2(file, STDERR_FILENO);
	close(file);
	setvbuf(stderr, NULL, _IONBF, 0);
	startup_log_open = 1;
	{
		char line[200];
		time_t now = time(NULL);

		snprintf(line, sizeof(line), "Halo (armeabi-v7a) %s: library loaded, process %s, %s",
			HALO_ARMV7_BUILD, package, ctime(&now));
		startup_log_line(line);
	}
}
#pragma clang diagnostic pop

/* ---------- logging and termination (host.h) */

void host_logf(int priority, const char *format, ...)
{
	char line[1024];
	va_list arguments;

	va_start(arguments, format);
	vsnprintf(line, sizeof(line), format, arguments);
	va_end(arguments);
	__android_log_write(priority, "halo", line);
	startup_log_line(line);
}

void host_log(int priority, const char *text)
{
	__android_log_write(priority, "halo", text);
	startup_log_line(text);
}

void host_fatal(const char *format, ...)
{
	char message[1024];
	va_list arguments;

	va_start(arguments, format);
	vsnprintf(message, sizeof(message), format, arguments);
	va_end(arguments);
	__android_log_write(ANDROID_LOG_FATAL, "halo", message);
	startup_log_line(message);
	SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Halo", message, NULL);
	_exit(1);
}

void host_exit(int code)
{
	host_logf(HOST_LOG_INFO, "the game exited (%d)", code);
	_exit(code);
}

int host_errno(void)
{
	return errno;
}

/* ---------- paths */

static char data_root[512];
static char save_root[512];

void host_android_path(int which, char *buffer, uint32_t size)
{
	snprintf(buffer, size, "%s", which ? save_root : data_root);
}

static int directory_has_maps(const char *root)
{
	char path[600];
	struct stat information;

	snprintf(path, sizeof(path), "%s/maps/ui.map", root);
	return stat(path, &information) == 0;
}

/* ---------- the system gesture insets (as host_main.c's) */

void host_gesture_insets(int *insets)
{
	JNIEnv *env = (JNIEnv *)SDL_GetAndroidJNIEnv();
	jobject activity = (jobject)SDL_GetAndroidActivity();
	jint values[4] = { 0, 0, 0, 0 };
	int index;

	if (env && activity)
	{
		jclass activity_class = (*env)->GetObjectClass(env, activity);
		jmethodID method = activity_class ? (*env)->GetMethodID(env, activity_class, "getSystemGestureInsetsPixels", "()[I") : NULL;
		jintArray array = method ? (jintArray)(*env)->CallObjectMethod(env, activity, method) : NULL;

		if (array && !(*env)->ExceptionCheck(env) && (*env)->GetArrayLength(env, array) == 4)
			(*env)->GetIntArrayRegion(env, array, 0, 4, values);
		if ((*env)->ExceptionCheck(env))
		{
			(*env)->ExceptionClear(env);
			for (index = 0; index < 4; index++)
				values[index] = 0;
		}
		if (array)
			(*env)->DeleteLocalRef(env, array);
		if (activity_class)
			(*env)->DeleteLocalRef(env, activity_class);
		(*env)->DeleteLocalRef(env, activity);
	}
	for (index = 0; index < 4; index++)
		insets[index] = (int)values[index];
}

/* ---------- settings read before the game starts */

/* a boolean setting of config.toml (a dotted name), or otherwise when the
file, the setting or a boolean is missing */
static int config_boolean_or(const char *path, const char *name, int otherwise)
{
	toml_result_t result = toml_parse_file_ex(path);
	int value = otherwise;

	if (!result.ok)
		return otherwise;
	{
		toml_datum_t datum = toml_seek(result.toptab, name);

		if (datum.type == TOML_BOOLEAN)
			value = datum.u.boolean ? 1 : 0;
	}
	toml_free(result);
	return value;
}

/* ---------- the process's memory map (maps.txt), and the Xbox window */

static void memory_map_report(const char *folder)
{
	char path[600];
	char buffer[4096];
	int input, output;
	ssize_t count;

	snprintf(path, sizeof(path), "%s/maps.txt", folder);
	input = open("/proc/self/maps", O_RDONLY);
	output = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0664);
	if (input >= 0 && output >= 0)
	{
		while ((count = read(input, buffer, sizeof(buffer))) > 0)
			write(output, buffer, (size_t)count);
	}
	if (input >= 0)
		close(input);
	if (output >= 0)
		close(output);
	/* the window xbox_memory.c reserves at 0x80000000, as the kernel lists it */
	{
		FILE *maps = fopen("/proc/self/maps", "r");
		char line[512];
		int found = 0;

		while (maps && fgets(line, sizeof(line), maps))
		{
			unsigned long start, end;

			if (sscanf(line, "%lx-%lx", &start, &end) == 2 && start < 0x88000000UL && end > 0x80000000UL)
			{
				line[strcspn(line, "\n")] = 0;
				host_logf(HOST_LOG_INFO, "at the Xbox window: %s", line);
				found = 1;
			}
		}
		if (maps)
			fclose(maps);
		if (!found)
			host_logf(HOST_LOG_ERROR, "nothing is mapped at 0x80000000-0x88000000: the Xbox window was not reserved");
	}
}

/* ---------- the GPU's report (gpu.txt)

What OpenGL ES this device offers, for the renderer's OpenGL ES 2.0 path:
the versions, the extensions and the limits of an ES 2.0 context (on a
1x1 off-screen surface of its own, apart from SDL's window), and whether an
ES 3.0 context can be made at all. */

static void gpu_line(FILE *file, const char *format, ...)
{
	va_list arguments;

	va_start(arguments, format);
	vfprintf(file, format, arguments);
	va_end(arguments);
	fputc('\n', file);
}

static void gpu_extensions(FILE *file, const char *title, const char *list)
{
	const char *cursor = list ? list : "";

	fprintf(file, "%s:\n", title);
	while (*cursor)
	{
		size_t length;

		while (*cursor == ' ')
			cursor++;
		length = strcspn(cursor, " ");
		if (length)
			fprintf(file, "  %.*s\n", (int)length, cursor);
		cursor += length;
	}
}

static int gpu_context_version(EGLDisplay display, EGLConfig config, int version)
{
	EGLint attributes[] = { EGL_CONTEXT_CLIENT_VERSION, version, EGL_NONE };
	EGLContext context = eglCreateContext(display, config, EGL_NO_CONTEXT, attributes);

	if (context == EGL_NO_CONTEXT)
		return 0;
	eglDestroyContext(display, context);
	return 1;
}

static void gpu_report(const char *folder)
{
	static const struct { GLenum name; const char *label; } limits[] = {
		{ GL_MAX_TEXTURE_SIZE, "max texture size" },
		{ GL_MAX_CUBE_MAP_TEXTURE_SIZE, "max cube map size" },
		{ GL_MAX_RENDERBUFFER_SIZE, "max renderbuffer size" },
		{ GL_MAX_VERTEX_ATTRIBS, "max vertex attributes" },
		{ GL_MAX_VERTEX_UNIFORM_VECTORS, "max vertex uniform vectors" },
		{ GL_MAX_FRAGMENT_UNIFORM_VECTORS, "max fragment uniform vectors" },
		{ GL_MAX_VARYING_VECTORS, "max varying vectors" },
		{ GL_MAX_TEXTURE_IMAGE_UNITS, "max fragment texture units" },
		{ GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS, "max vertex texture units" },
		{ GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS, "max combined texture units" },
	};
	static const struct { GLenum shader, precision; const char *label; } precisions[] = {
		{ GL_VERTEX_SHADER, GL_HIGH_FLOAT, "vertex highp float" },
		{ GL_FRAGMENT_SHADER, GL_HIGH_FLOAT, "fragment highp float" },
		{ GL_FRAGMENT_SHADER, GL_MEDIUM_FLOAT, "fragment mediump float" },
		{ GL_FRAGMENT_SHADER, GL_HIGH_INT, "fragment highp int" },
	};
	char path[600];
	FILE *file;
	EGLDisplay display;
	EGLConfig config;
	EGLint count = 0, major = 0, minor = 0;
	EGLint config_attributes[] = {
		EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT, EGL_SURFACE_TYPE, EGL_PBUFFER_BIT,
		EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_NONE
	};
	EGLint surface_attributes[] = { EGL_WIDTH, 1, EGL_HEIGHT, 1, EGL_NONE };
	EGLint context_attributes[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };
	EGLSurface surface;
	EGLContext context;
	unsigned index;

	snprintf(path, sizeof(path), "%s/gpu.txt", folder);
	file = fopen(path, "w");
	if (!file)
		return;
	display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
	if (display == EGL_NO_DISPLAY || !eglInitialize(display, &major, &minor))
	{
		gpu_line(file, "EGL cannot be initialized (%#x)", eglGetError());
		fclose(file);
		return;
	}
	gpu_line(file, "EGL %d.%d, %s, %s", major, minor, eglQueryString(display, EGL_VENDOR),
		eglQueryString(display, EGL_VERSION));
	if (!eglChooseConfig(display, config_attributes, &config, 1, &count) || count < 1)
	{
		gpu_line(file, "no OpenGL ES 2.0 configuration for an off-screen surface (%#x)", eglGetError());
		gpu_extensions(file, "EGL extensions", eglQueryString(display, EGL_EXTENSIONS));
		/* (the display stays initialized: SDL's window uses it too) */
		fclose(file);
		return;
	}
	gpu_line(file, "OpenGL ES 3.0 context: %s", gpu_context_version(display, config, 3) ? "can be made" : "cannot be made");
	surface = eglCreatePbufferSurface(display, config, surface_attributes);
	context = eglCreateContext(display, config, EGL_NO_CONTEXT, context_attributes);
	if (surface == EGL_NO_SURFACE || context == EGL_NO_CONTEXT || !eglMakeCurrent(display, surface, surface, context))
	{
		gpu_line(file, "an OpenGL ES 2.0 context cannot be made current (%#x)", eglGetError());
	}
	else
	{
		gpu_line(file, "GL_VENDOR: %s", (const char *)glGetString(GL_VENDOR));
		gpu_line(file, "GL_RENDERER: %s", (const char *)glGetString(GL_RENDERER));
		gpu_line(file, "GL_VERSION: %s", (const char *)glGetString(GL_VERSION));
		gpu_line(file, "GL_SHADING_LANGUAGE_VERSION: %s", (const char *)glGetString(GL_SHADING_LANGUAGE_VERSION));
		for (index = 0; index < sizeof(limits) / sizeof(limits[0]); index++)
		{
			GLint value = 0;

			glGetIntegerv(limits[index].name, &value);
			gpu_line(file, "%s: %d", limits[index].label, value);
		}
		for (index = 0; index < sizeof(precisions) / sizeof(precisions[0]); index++)
		{
			GLint range[2] = { 0, 0 }, precision = 0;

			glGetShaderPrecisionFormat(precisions[index].shader, precisions[index].precision, range, &precision);
			gpu_line(file, "%s: range %d..%d, precision %d bits", precisions[index].label, -range[0], range[1], precision);
		}
		{
			GLint formats = 0;

			glGetIntegerv(GL_NUM_COMPRESSED_TEXTURE_FORMATS, &formats);
			gpu_line(file, "compressed texture formats: %d", formats);
		}
		gpu_extensions(file, "GL extensions", (const char *)glGetString(GL_EXTENSIONS));
	}
	gpu_extensions(file, "EGL extensions", eglQueryString(display, EGL_EXTENSIONS));
	eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
	if (context != EGL_NO_CONTEXT)
		eglDestroyContext(display, context);
	if (surface != EGL_NO_SURFACE)
		eglDestroySurface(display, surface);
	fclose(file);
	host_logf(HOST_LOG_INFO, "the GPU's report: %s", path);
}

/* ---------- main */

#define GAME_STACK_SIZE (16 * 1024 * 1024)

static void *game_thread(void *unused)
{
	static char program[] = "halo";
	char *argv[] = { program, NULL };

	(void)unused;
	host_logf(HOST_LOG_INFO, "starting the game (32-bit ARM, native), stack %d MB", GAME_STACK_SIZE >> 20);
	host_exit(halo_game_main(1, argv));
	return NULL;
}

int main(int argc, char *argv[])
{
	const char *external;
	char path[600];
	pthread_attr_t attributes;
	pthread_t thread;

	(void)argc;
	(void)argv;
	host_logf(HOST_LOG_INFO, "Halo for Android (armeabi-v7a) starting");
	external = SDL_GetAndroidExternalStoragePath();
	if (!external)
		host_fatal("Android storage is unavailable: %s", SDL_GetError());
	snprintf(data_root, sizeof(data_root), "%s", external);
	host_logf(HOST_LOG_INFO, "files folder %s", external);
	memory_map_report(external);
	gpu_report(external);
	snprintf(save_root, sizeof(save_root), "%s/save", external);
	mkdir(save_root, 0775);
	if (!directory_has_maps(data_root))
	{
		host_fatal("The Halo game data was not found.\n\nCopy the game data, "
			"the folder that contains maps, into\n%s\nor import it from the launcher screen.", data_root);
	}
	setenv("HOME", save_root, 1);
	setenv("HALO_DATA_ROOT", data_root, 1);
	setenv("HALO_SAVE_ROOT", save_root, 1);
	{
		/* 480 lines at the display's shape (landscape), as host_main.c */
		const SDL_DisplayMode *mode;
		float density;
		char text[32];

		SDL_InitSubSystem(SDL_INIT_VIDEO);
		mode = SDL_GetDesktopDisplayMode(SDL_GetPrimaryDisplay());
		if (mode && mode->w > 0 && mode->h > 0)
		{
			int longer = mode->w > mode->h ? mode->w : mode->h;
			int shorter = mode->w > mode->h ? mode->h : mode->w;

			snprintf(text, sizeof(text), "%d", (480 * longer / shorter) & ~1);
			setenv("HALO_DISPLAY_WIDTH", text, 1);
			host_logf(HOST_LOG_INFO, "display %dx%d: rendering %sx480", mode->w, mode->h, text);
		}
		density = SDL_GetDisplayContentScale(SDL_GetPrimaryDisplay());
		if (density > 0.0f)
		{
			snprintf(text, sizeof(text), "%g", density);
			setenv("HALO_DISPLAY_DENSITY", text, 1);
		}
	}
	/* internet play's MQTT brokers, beside config.toml (as host_main.c) */
	{
		size_t brokers_size = 0;
		void *brokers = SDL_LoadFile("brokers.txt", &brokers_size);

		snprintf(path, sizeof(path), "%s/brokers.txt", data_root);
		if (!brokers || !SDL_SaveFile(path, brokers, brokers_size))
			host_logf(HOST_LOG_ERROR, "cannot write %s: %s", path, SDL_GetError());
		SDL_free(brokers);
	}
	/* (an OpenGL ES 2.0 GPU gets a window with a test screen in it until
	the renderer has a path for it: d3d8_gl.c) */
	snprintf(path, sizeof(path), "%s/config.toml", data_root);
	if (config_boolean_or(path, "debug.null_renderer", 0))
		host_logf(HOST_LOG_INFO, "starting without a renderer (debug.null_renderer)");
	host_logf(HOST_LOG_INFO, "data %s, saves %s", data_root, save_root);
	halo_custom_edition_tag_cache_reserve();

	pthread_attr_init(&attributes);
	pthread_attr_setstacksize(&attributes, GAME_STACK_SIZE);
	if (pthread_create(&thread, &attributes, game_thread, NULL) != 0)
		host_fatal("cannot start the game thread");
	pthread_attr_destroy(&attributes);
	/* the game ends the process itself (host_exit) */
	for (;;)
		pause();
}

/* ---------- MSVC intrinsics without a 32-bit ARM builtin */

/* (source/scenario/scenario.c: a compiler barrier, which a call to a
function the compiler cannot see into is) */
void _ReadWriteBarrier(void)
{
	__asm__ __volatile__("" ::: "memory");
}
