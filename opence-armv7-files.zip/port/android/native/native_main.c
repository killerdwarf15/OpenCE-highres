/*
NATIVE_MAIN.C

Entry point of the 32-bit ARM Android build (armeabi-v7a, `ninja
android_armv7`; port/android/native/README.md).

A 32-bit ARM process has 32-bit pointers of its own, as the Xbox had, so
the game does not run as a guest image there (port/android/README.md, "ILP32
code"): the game, the platform layer and this file are one native library,
libmain.so, built as the Linux build is, against bionic and SDL3. This file
stands in for what the 64-bit app's host does around the guest
(port/android/host/host_main.c): it finds the data and save folders, passes
them and the display's shape to the game through its environment, and runs
the game's main (source/main/main.c, renamed halo_game_main by the build) on
a thread with a large stack.

The Xbox window at 0x80000000 is reserved as the library loads
(port/linux/src/xbox_memory.c, a constructor): HaloApplication loads this
library first thing in the game's process.

Until the renderer has an OpenGL ES 2.0 path (the Tegra 4 of the SHIELD
Portable has no OpenGL ES 3.0), the game starts without one
(debug.null_renderer), unless config.toml sets debug.null_renderer = false:
the log (debug.txt and logcat, tag "halo") shows how far it gets.
*/

#include "host.h"
#include "tomlc17.h"

#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <android/log.h>
#include <jni.h>
#include <errno.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

/* the game's main (source/main/main.c, compiled with -Dmain=halo_game_main) */
int halo_game_main(int argc, char **argv);

/* ---------- logging and termination (host.h) */

void host_logf(int priority, const char *format, ...)
{
	va_list arguments;

	va_start(arguments, format);
	__android_log_vprint(priority, "halo", format, arguments);
	va_end(arguments);
}

void host_log(int priority, const char *text)
{
	__android_log_write(priority, "halo", text);
}

void host_fatal(const char *format, ...)
{
	char message[1024];
	va_list arguments;

	va_start(arguments, format);
	vsnprintf(message, sizeof(message), format, arguments);
	va_end(arguments);
	__android_log_write(ANDROID_LOG_FATAL, "halo", message);
	SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Halo", message, NULL);
	_exit(1);
}

void host_exit(int code)
{
	host_logf(HOST_LOG_INFO, "the game exited (%d)", code);
	_exit(code);
}

int host_errno(void)
{
	return errno;
}

/* ---------- paths */

static char data_root[512];
static char save_root[512];

void host_android_path(int which, char *buffer, uint32_t size)
{
	snprintf(buffer, size, "%s", which ? save_root : data_root);
}

static int directory_has_maps(const char *root)
{
	char path[600];
	struct stat information;

	snprintf(path, sizeof(path), "%s/maps/ui.map", root);
	return stat(path, &information) == 0;
}

/* ---------- the system gesture insets (as host_main.c's) */

void host_gesture_insets(int *insets)
{
	JNIEnv *env = (JNIEnv *)SDL_GetAndroidJNIEnv();
	jobject activity = (jobject)SDL_GetAndroidActivity();
	jint values[4] = { 0, 0, 0, 0 };
	int index;

	if (env && activity)
	{
		jclass activity_class = (*env)->GetObjectClass(env, activity);
		jmethodID method = activity_class ? (*env)->GetMethodID(env, activity_class, "getSystemGestureInsetsPixels", "()[I") : NULL;
		jintArray array = method ? (jintArray)(*env)->CallObjectMethod(env, activity, method) : NULL;

		if (array && !(*env)->ExceptionCheck(env) && (*env)->GetArrayLength(env, array) == 4)
			(*env)->GetIntArrayRegion(env, array, 0, 4, values);
		if ((*env)->ExceptionCheck(env))
		{
			(*env)->ExceptionClear(env);
			for (index = 0; index < 4; index++)
				values[index] = 0;
		}
		if (array)
			(*env)->DeleteLocalRef(env, array);
		if (activity_class)
			(*env)->DeleteLocalRef(env, activity_class);
		(*env)->DeleteLocalRef(env, activity);
	}
	for (index = 0; index < 4; index++)
		insets[index] = (int)values[index];
}

/* ---------- settings read before the game starts */

/* a boolean setting of config.toml (a dotted name), or otherwise when the
file, the setting or a boolean is missing */
static int config_boolean_or(const char *path, const char *name, int otherwise)
{
	toml_result_t result = toml_parse_file_ex(path);
	int value = otherwise;

	if (!result.ok)
		return otherwise;
	{
		toml_datum_t datum = toml_seek(result.toptab, name);

		if (datum.type == TOML_BOOLEAN)
			value = datum.u.boolean ? 1 : 0;
	}
	toml_free(result);
	return value;
}

/* ---------- main */

#define GAME_STACK_SIZE (16 * 1024 * 1024)

static void *game_thread(void *unused)
{
	static char program[] = "halo";
	char *argv[] = { program, NULL };

	(void)unused;
	host_logf(HOST_LOG_INFO, "starting the game (32-bit ARM, native)");
	host_exit(halo_game_main(1, argv));
	return NULL;
}

int main(int argc, char *argv[])
{
	const char *external;
	char path[600];
	pthread_attr_t attributes;
	pthread_t thread;

	(void)argc;
	(void)argv;
	host_logf(HOST_LOG_INFO, "Halo for Android (armeabi-v7a) starting");
	external = SDL_GetAndroidExternalStoragePath();
	if (!external)
		host_fatal("Android storage is unavailable: %s", SDL_GetError());
	snprintf(data_root, sizeof(data_root), "%s", external);
	snprintf(save_root, sizeof(save_root), "%s/save", external);
	mkdir(save_root, 0775);
	if (!directory_has_maps(data_root))
	{
		host_fatal("The Halo game data was not found.\n\nCopy the game data, "
			"the folder that contains maps, into\n%s\nor import it from the launcher screen.", data_root);
	}
	setenv("HOME", save_root, 1);
	setenv("HALO_DATA_ROOT", data_root, 1);
	setenv("HALO_SAVE_ROOT", save_root, 1);
	{
		/* 480 lines at the display's shape (landscape), as host_main.c */
		const SDL_DisplayMode *mode;
		float density;
		char text[32];

		SDL_InitSubSystem(SDL_INIT_VIDEO);
		mode = SDL_GetDesktopDisplayMode(SDL_GetPrimaryDisplay());
		if (mode && mode->w > 0 && mode->h > 0)
		{
			int longer = mode->w > mode->h ? mode->w : mode->h;
			int shorter = mode->w > mode->h ? mode->h : mode->w;

			snprintf(text, sizeof(text), "%d", (480 * longer / shorter) & ~1);
			setenv("HALO_DISPLAY_WIDTH", text, 1);
			host_logf(HOST_LOG_INFO, "display %dx%d: rendering %sx480", mode->w, mode->h, text);
		}
		density = SDL_GetDisplayContentScale(SDL_GetPrimaryDisplay());
		if (density > 0.0f)
		{
			snprintf(text, sizeof(text), "%g", density);
			setenv("HALO_DISPLAY_DENSITY", text, 1);
		}
	}
	/* internet play's MQTT brokers, beside config.toml (as host_main.c) */
	{
		size_t brokers_size = 0;
		void *brokers = SDL_LoadFile("brokers.txt", &brokers_size);

		snprintf(path, sizeof(path), "%s/brokers.txt", data_root);
		if (!brokers || !SDL_SaveFile(path, brokers, brokers_size))
			host_logf(HOST_LOG_ERROR, "cannot write %s: %s", path, SDL_GetError());
		SDL_free(brokers);
	}
	/* no renderer for OpenGL ES 2.0 yet (above) */
	snprintf(path, sizeof(path), "%s/config.toml", data_root);
	if (config_boolean_or(path, "debug.null_renderer", 1))
	{
		setenv("HALO_NULL_RENDERER", "1", 1);
		host_logf(HOST_LOG_INFO, "starting without a renderer (debug.null_renderer)");
	}
	host_logf(HOST_LOG_INFO, "data %s, saves %s", data_root, save_root);

	pthread_attr_init(&attributes);
	pthread_attr_setstacksize(&attributes, GAME_STACK_SIZE);
	if (pthread_create(&thread, &attributes, game_thread, NULL) != 0)
		host_fatal("cannot start the game thread");
	pthread_attr_destroy(&attributes);
	/* the game ends the process itself (host_exit) */
	for (;;)
		pause();
}

/* ---------- MSVC intrinsics without a 32-bit ARM builtin */

/* (source/scenario/scenario.c: a compiler barrier, which a call to a
function the compiler cannot see into is) */
void _ReadWriteBarrier(void)
{
	__asm__ __volatile__("" ::: "memory");
}
