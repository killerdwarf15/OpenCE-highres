# The 32-bit ARM Android build (armeabi-v7a)

An experimental build of the app for 32-bit ARM devices with Android 5.1
or later, such as the NVIDIA SHIELD Portable (Tegra 4).

## How it differs from the 64-bit app

The 64-bit app runs the game as an ILP32 guest image, because the game's
data needs 32-bit pointers (port/android/README.md, "ILP32 code"). A 32-bit
ARM process has 32-bit pointers of its own, so here the game, the platform
layer and `native_main.c` are compiled as the Linux build compiles them,
against bionic, into one library, `libmain.so`, beside a 32-bit SDL3
(`tools/android_armv7_build.py`). There is no guest image, loader or
system-call bridge. The macro `HALO_ANDROID_ARMV7` marks this build's
differences.

- `native_main.c` is SDL's entry point. It passes the data and save folders
  and the display's shape to the game through its environment, as
  `host/host_main.c` does for the guest, and runs the game's main
  (`source/shell/shell_xbox.c`, compiled as `halo_game_main`) on a thread
  with a 16 MB stack.
- The Xbox window at `0x80000000` (128 MB, as the 64-bit app's) is reserved
  by `port/linux/src/xbox_memory.c` as the library loads, which
  `HaloApplication` does first in the game's process.
- `host/host_touch.c` and `host/host_gl.c` are linked in as they are.

## Status

Stage 2: the renderer on OpenGL ES 2.0 (the Tegra 4 has no ES 3.0). The
window falls back to an ES 2.0 context (`port/linux/src/sdl_platform.c`),
the renderer's ES 3.0 calls are given by ES 2.0 extensions or emulated
(`port/linux/src/gl_es2.c`: sampler objects, sized formats, packed normals),
and its GLSL is rewritten as GLSL ES 1.00 (`port/linux/src/gl_es2_glsl.c`).
Known gaps: no stencil, 3D textures drawn as their first slice, no
post-processing (it needs `gl_VertexID`), no 32-bit indices. Set the
environment's `HALO_ES2_TEST_SCREEN` for the stage-1 test screen instead.

## Build

```sh
python configure.py --release
ninja android                 # the 64-bit app's native part (also fetches SDL3)
ninja android_armv7           # this build's libmain.so and SDL3
cd port/android && ./gradlew -Phalo_abi=armeabi-v7a assembleRelease
```

`tools/ci_build.py android release` builds both apps; the 32-bit one is
`halo-armv7-release.apk` in `dist/halo-android-release`.
