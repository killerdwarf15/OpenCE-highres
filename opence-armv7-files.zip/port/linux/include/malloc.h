/*
MALLOC.H

MSVC <malloc.h>.
*/

#ifndef __HALO_LINUX_MALLOC_H
#define __HALO_LINUX_MALLOC_H

#include <stdlib.h>
/* (bionic's <stdlib.h> takes malloc, calloc and free from its <malloc.h>,
which this header stands in front of) */
#if defined(HALO_ANDROID_ARMV7)
#include_next <malloc.h>
#endif

#define _alloca __builtin_alloca
#define alloca __builtin_alloca

size_t _msize(void *pointer);

#endif
