/*
HALO_STUTTER.H

debug.stutter_log (the 32-bit ARM Android build, port/linux/src/stutter.c):
the things that can hold a frame up, timed where they happen on whichever
thread, kept in a ring; a frame longer than 150 ms is logged with what of it
each thread spent on what. Elsewhere the macros leave nothing.

	unsigned long long start = STUTTER_START();
	... the work ...
	STUTTER_END(start, "what", label or NULL, a number or 0);
*/

#ifndef __HALO_STUTTER_H
#define __HALO_STUTTER_H

#ifdef HALO_ANDROID_ARMV7

extern int halo_stutter_enabled;
unsigned long long halo_stutter_now(void);
/* an event from start to now, kept if it took a millisecond or more */
void halo_stutter_event(const char *what, const char *label, unsigned long long start, long detail);
/* the calling thread's name in the log */
void halo_stutter_thread(const char *name);
/* the render thread, at each frame presented */
void halo_stutter_frame(void);

#define STUTTER_START() (halo_stutter_enabled ? halo_stutter_now() : 0ULL)
#define STUTTER_END(start, what, label, detail) \
	do { if (start) halo_stutter_event((what), (label), (start), (long)(detail)); } while (0)
#define STUTTER_THREAD(name) halo_stutter_thread(name)

#else

#define STUTTER_START() 0ULL
#define STUTTER_END(start, what, label, detail) ((void)(start))
#define STUTTER_THREAD(name) ((void)0)

#endif

#endif
