/* gl_context_test.c: debug.gl_context_test (the 32-bit ARM Android build)

Does the Tegra 4's OpenGL ES 2.0 driver do two threads' draws at once, each
thread with a context of its own? The GL thread is the frame's limit (the
driver's ~50 us a draw, on one core); a second context drawing part of the
frame on another core would help only if the driver does not hold one lock
for every context.

At startup, before the game draws, three contexts of their own are made (not
the game's: nothing it holds is touched), each on a thread of its own with a
small pbuffer: A; B, unshared; C, sharing A's objects (as a second context of
the game's would have to, for its textures and buffers). Each draws the same
synthetic frame's worth of draws, shaped like the game's (a program change,
16 uniform vectors, two textures, a buffer update, three attribute pointers,
an indexed strip of 300 vertices into a 64 by 64 target, so the GPU's part is
small): A alone, then A with B at once, then A with C at once. Two threads
that each take as long as one alone are done in parallel (speedup 2); twice
as long, one after the other (speedup 1). The driver's own libraries are
loaded here (dlopen), so no call goes through the game's table or glq.c. */

#ifdef HALO_ANDROID_ARMV7

#include "port_config.h"

#include <dlfcn.h>
#include <pthread.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include <EGL/egl.h>
#include <GLES2/gl2.h>

void platform_log(const char *format, ...);

#define TEST_DRAWS 3000
#define TEST_VERTICES 300
#define TEST_PROGRAMS 4
#define TEST_TEXTURES 4
#define TEST_CHUNK 8192
#define TEST_CHUNKS 64
#define TEST_WORKERS 3

/* the driver's entry points */
static struct
{
	EGLDisplay (*GetDisplay)(EGLNativeDisplayType);
	EGLBoolean (*Initialize)(EGLDisplay, EGLint *, EGLint *);
	EGLBoolean (*ChooseConfig)(EGLDisplay, const EGLint *, EGLConfig *, EGLint, EGLint *);
	EGLContext (*CreateContext)(EGLDisplay, EGLConfig, EGLContext, const EGLint *);
	EGLSurface (*CreatePbufferSurface)(EGLDisplay, EGLConfig, const EGLint *);
	EGLBoolean (*MakeCurrent)(EGLDisplay, EGLSurface, EGLSurface, EGLContext);
	EGLBoolean (*DestroyContext)(EGLDisplay, EGLContext);
	EGLBoolean (*DestroySurface)(EGLDisplay, EGLSurface);
	EGLint (*GetError)(void);

	GLuint (*CreateShader)(GLenum);
	void (*ShaderSource)(GLuint, GLsizei, const GLchar *const *, const GLint *);
	void (*CompileShader)(GLuint);
	void (*GetShaderiv)(GLuint, GLenum, GLint *);
	GLuint (*CreateProgram)(void);
	void (*AttachShader)(GLuint, GLuint);
	void (*BindAttribLocation)(GLuint, GLuint, const GLchar *);
	void (*LinkProgram)(GLuint);
	void (*GetProgramiv)(GLuint, GLenum, GLint *);
	GLint (*GetUniformLocation)(GLuint, const GLchar *);
	void (*UseProgram)(GLuint);
	void (*Uniform1i)(GLint, GLint);
	void (*Uniform4fv)(GLint, GLsizei, const GLfloat *);
	void (*GenTextures)(GLsizei, GLuint *);
	void (*BindTexture)(GLenum, GLuint);
	void (*ActiveTexture)(GLenum);
	void (*TexImage2D)(GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void *);
	void (*TexParameteri)(GLenum, GLenum, GLint);
	void (*GenBuffers)(GLsizei, GLuint *);
	void (*DeleteBuffers)(GLsizei, const GLuint *);
	void (*BindBuffer)(GLenum, GLuint);
	void (*BufferData)(GLenum, GLsizeiptr, const void *, GLenum);
	void (*BufferSubData)(GLenum, GLintptr, GLsizeiptr, const void *);
	void (*EnableVertexAttribArray)(GLuint);
	void (*VertexAttribPointer)(GLuint, GLint, GLenum, GLboolean, GLsizei, const void *);
	void (*DrawElements)(GLenum, GLsizei, GLenum, const void *);
	void (*Viewport)(GLint, GLint, GLsizei, GLsizei);
	void (*Clear)(GLbitfield);
	void (*Finish)(void);
	GLenum (*GetErrorGL)(void);
} t;

static EGLDisplay test_display;
static EGLConfig test_config;
static unsigned short test_indices[TEST_VERTICES];

static int test_load(void)
{
	void *egl = dlopen("libEGL.so", RTLD_NOW);
	void *gles = dlopen("libGLESv2.so", RTLD_NOW);

	if (!egl || !gles)
		return 0;
#define E(name) if (!(*(void **)&t.name = dlsym(egl, "egl" #name))) return 0;
#define G(name) if (!(*(void **)&t.name = dlsym(gles, "gl" #name))) return 0;
	E(GetDisplay) E(Initialize) E(ChooseConfig) E(CreateContext) E(CreatePbufferSurface) E(MakeCurrent)
	E(DestroyContext) E(DestroySurface) E(GetError)
	G(CreateShader) G(ShaderSource) G(CompileShader) G(GetShaderiv) G(CreateProgram) G(AttachShader)
	G(BindAttribLocation) G(LinkProgram) G(GetProgramiv) G(GetUniformLocation) G(UseProgram) G(Uniform1i)
	G(Uniform4fv) G(GenTextures) G(BindTexture) G(ActiveTexture) G(TexImage2D) G(TexParameteri) G(GenBuffers)
	G(DeleteBuffers) G(BindBuffer) G(BufferData) G(BufferSubData) G(EnableVertexAttribArray) G(VertexAttribPointer)
	G(DrawElements) G(Viewport) G(Clear) G(Finish)
#undef E
#undef G
	if (!(*(void **)&t.GetErrorGL = dlsym(gles, "glGetError")))
		return 0;
	return 1;
}

static unsigned long long test_now(void)
{
	struct timespec now;

	clock_gettime(CLOCK_MONOTONIC, &now);
	return (unsigned long long)now.tv_sec * 1000000000ULL + (unsigned long long)now.tv_nsec;
}

/* ---------- a worker: its context, its objects, its draws */

struct test_worker
{
	const char *name;
	EGLContext context, share;
	EGLSurface surface;
	pthread_t thread;
	/* (set by the main thread under test_lock: the run to do; done back) */
	int run, done, ready, failed, quit;
	unsigned long long nanoseconds;
	GLuint programs[TEST_PROGRAMS], textures[TEST_TEXTURES], vertex_buffer, index_buffer;
	GLint uniforms[TEST_PROGRAMS];
};

static pthread_mutex_t test_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t test_changed = PTHREAD_COND_INITIALIZER;
static int test_go;

static GLuint test_shader(GLenum kind, const char *source)
{
	GLuint shader = t.CreateShader(kind);
	GLint compiled = 0;

	t.ShaderSource(shader, 1, &source, NULL);
	t.CompileShader(shader);
	t.GetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
	return compiled ? shader : 0;
}

static int test_objects(struct test_worker *worker)
{
	static const char *vertex_source =
		"uniform vec4 u[64];\n"
		"attribute vec3 position; attribute vec2 uv; attribute vec4 color;\n"
		"varying vec2 v_uv; varying vec4 v_color;\n"
		"void main() {\n"
		"  vec4 p = vec4(position, 1.0);\n"
		"  gl_Position = vec4(dot(p, u[0]), dot(p, u[1]), dot(p, u[2]), dot(p, u[3]));\n"
		"  v_uv = uv * u[4].xy + u[5].xy * u[%d].z;\n"
		"  v_color = color * u[6] + u[7] * u[8].x + u[9] * u[10].y + u[11] * u[12].z + u[13] * u[14].w + u[15] + u[63];\n"
		"}\n";
	static const char *fragment_source =
		"precision mediump float;\n"
		"uniform sampler2D t0; uniform sampler2D t1;\n"
		"varying vec2 v_uv; varying vec4 v_color;\n"
		"void main() { gl_FragColor = texture2D(t0, v_uv) * texture2D(t1, v_uv.yx) * v_color; }\n";
	unsigned char texels[64 * 64 * 4];
	unsigned short indices[TEST_VERTICES];
	int index;

	for (index = 0; index < TEST_PROGRAMS; index++)
	{
		char source[1024];
		GLuint vertex, fragment, program;
		GLint linked = 0;

		snprintf(source, sizeof(source), vertex_source, 5 + index);
		vertex = test_shader(GL_VERTEX_SHADER, source);
		fragment = test_shader(GL_FRAGMENT_SHADER, fragment_source);
		if (!vertex || !fragment)
			return 0;
		program = t.CreateProgram();
		t.AttachShader(program, vertex);
		t.AttachShader(program, fragment);
		t.BindAttribLocation(program, 0, "position");
		t.BindAttribLocation(program, 1, "uv");
		t.BindAttribLocation(program, 2, "color");
		t.LinkProgram(program);
		t.GetProgramiv(program, GL_LINK_STATUS, &linked);
		if (!linked)
			return 0;
		worker->programs[index] = program;
		worker->uniforms[index] = t.GetUniformLocation(program, "u");
		t.UseProgram(program);
		t.Uniform1i(t.GetUniformLocation(program, "t0"), 0);
		t.Uniform1i(t.GetUniformLocation(program, "t1"), 1);
	}
	for (index = 0; index < (int)sizeof(texels); index++)
		texels[index] = (unsigned char)(index * 7);
	t.GenTextures(TEST_TEXTURES, worker->textures);
	for (index = 0; index < TEST_TEXTURES; index++)
	{
		t.BindTexture(GL_TEXTURE_2D, worker->textures[index]);
		t.TexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 64, 64, 0, GL_RGBA, GL_UNSIGNED_BYTE, texels);
		t.TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		t.TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	}
	for (index = 0; index < TEST_VERTICES; index++)
		indices[index] = test_indices[index] = (unsigned short)index;
	t.GenBuffers(1, &worker->vertex_buffer);
	t.BindBuffer(GL_ARRAY_BUFFER, worker->vertex_buffer);
	t.BufferData(GL_ARRAY_BUFFER, TEST_CHUNK * TEST_CHUNKS, NULL, GL_STREAM_DRAW);
	t.GenBuffers(1, &worker->index_buffer);
	t.BindBuffer(GL_ELEMENT_ARRAY_BUFFER, worker->index_buffer);
	t.BufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
	t.EnableVertexAttribArray(0);
	t.EnableVertexAttribArray(1);
	t.EnableVertexAttribArray(2);
	t.Viewport(0, 0, 64, 64);
	return t.GetErrorGL() == GL_NO_ERROR;
}

/* the parts of a draw left out (debug.gl_context_test's second part: what
of a draw's ~55 us is the driver's for which part) */
enum
{
	_skip_program = 1 << 0,
	_skip_uniforms = 1 << 1,
	_skip_textures = 1 << 2,
	_skip_upload = 1 << 3,
	_skip_pointers = 1 << 4,
	/* (the vertices' upload into a buffer of its own for each chunk, not
	one buffer the earlier draws still read) */
	_buffer_per_chunk = 1 << 5,
	/* (the whole buffer orphaned, glBufferData with no data, at each wrap) */
	_orphan = 1 << 6,
	/* (the vertices from memory, no buffer: client arrays) */
	_client_arrays = 1 << 7,
	_vertices_60 = 1 << 8,
	_uniforms_64 = 1 << 9,
	/* (the program changed only every 8th draw) */
	_program_every_8 = 1 << 10,
	/* (the draws' order: by program, so each program's draws are together) */
	_sorted = 1 << 11,
};

static int test_flags;
/* (a layout to make, on the worker's thread, before its draws) */
static int layout_wanted, layout_count, layout_upload, layout_index_mode, layout_side_mode, layout_unaligned;
static unsigned long layout_size;
static GLenum layout_usage;
static GLuint test_chunk_buffers[TEST_CHUNKS];

/* (the third part: where the vertices are: a number of buffers of a size and
usage, the draws' uploads going round their 8 KB slots) */
#define LAYOUT_BUFFERS_MAXIMUM 512
static struct
{
	int active, count, upload;
	/* (where the indices are: 0 the static buffer; 1 uploaded each draw
	into a 2 MB buffer; 2 into 4 KB buffers of their own) and other writes
	each draw: 0 none; 1 7 KB into another 16 MB buffer; 2 into 8 KB
	buffers of their own; and the attributes not aligned for four */
	int index_mode, side_mode, unaligned;
	GLuint big_index, small_index[64], big_side, small_side[64];
	unsigned long size;
	GLenum usage;
	GLuint buffers[LAYOUT_BUFFERS_MAXIMUM];
} layout;

static void layout_set(int count, unsigned long size, GLenum usage, int upload)
{
	static unsigned char zeros[TEST_CHUNK];
	int index;
	unsigned long at;

	if (layout.count)
		t.DeleteBuffers(layout.count, layout.buffers);
	layout.active = 1;
	layout.count = count;
	layout.size = size;
	layout.usage = usage;
	layout.upload = upload;
	layout.index_mode = layout_index_mode;
	layout.side_mode = layout_side_mode;
	layout.unaligned = layout_unaligned;
	if (!layout.big_index)
	{
		t.GenBuffers(1, &layout.big_index);
		t.BindBuffer(GL_ELEMENT_ARRAY_BUFFER, layout.big_index);
		t.BufferData(GL_ELEMENT_ARRAY_BUFFER, 2 * 1024 * 1024, NULL, GL_STREAM_DRAW);
		t.GenBuffers(64, layout.small_index);
		for (index = 0; index < 64; index++)
		{
			t.BindBuffer(GL_ELEMENT_ARRAY_BUFFER, layout.small_index[index]);
			t.BufferData(GL_ELEMENT_ARRAY_BUFFER, 4096, NULL, GL_STREAM_DRAW);
		}
		t.GenBuffers(1, &layout.big_side);
		t.BindBuffer(GL_ARRAY_BUFFER, layout.big_side);
		t.BufferData(GL_ARRAY_BUFFER, 16 * 1024 * 1024, NULL, GL_STREAM_DRAW);
		t.GenBuffers(64, layout.small_side);
		for (index = 0; index < 64; index++)
		{
			t.BindBuffer(GL_ARRAY_BUFFER, layout.small_side[index]);
			t.BufferData(GL_ARRAY_BUFFER, TEST_CHUNK, NULL, GL_STREAM_DRAW);
		}
	}
	t.GenBuffers(count, layout.buffers);
	for (index = 0; index < count; index++)
	{
		t.BindBuffer(GL_ARRAY_BUFFER, layout.buffers[index]);
		t.BufferData(GL_ARRAY_BUFFER, (GLsizeiptr)size, NULL, usage);
		/* (filled, so a draw without uploads reads vertices) */
		for (at = 0; at + TEST_CHUNK <= size; at += TEST_CHUNK)
			t.BufferSubData(GL_ARRAY_BUFFER, (GLintptr)at, TEST_CHUNK, zeros);
	}
}

/* a frame's worth of draws, as the game's are shaped */
static void test_draws(struct test_worker *worker)
{
	/* (24-byte vertices: a position, a uv, a color) */
	static unsigned char vertices[TEST_CHUNK];
	static GLfloat constants[64 * 4];
	int draw, index, flags = test_flags;
	int vertices_drawn = flags & _vertices_60 ? 60 : TEST_VERTICES;
	int vectors = flags & _uniforms_64 ? 64 : 16;
	int current = 0;
	size_t index_offset = 0;

	for (index = 0; index < TEST_VERTICES; index++)
	{
		float *position = (float *)(vertices + index * 24);

		position[0] = (float)(index % 20) * 0.05f - 0.5f;
		position[1] = (float)(index / 20) * 0.05f - 0.5f;
		position[2] = 0.0f;
		position[3] = position[0];
		position[4] = position[1];
		memset(vertices + index * 24 + 20, 0x80, 4);
	}
	for (index = 0; index < 64 * 4; index++)
		constants[index] = (index % 5) == 0 ? 1.0f : 0.01f * (float)index;
	if ((flags & _buffer_per_chunk) && !test_chunk_buffers[0])
	{
		t.GenBuffers(TEST_CHUNKS, test_chunk_buffers);
		for (index = 0; index < TEST_CHUNKS; index++)
		{
			t.BindBuffer(GL_ARRAY_BUFFER, test_chunk_buffers[index]);
			t.BufferData(GL_ARRAY_BUFFER, TEST_CHUNK, NULL, GL_STREAM_DRAW);
		}
	}
	if (layout_wanted)
	{
		layout_set(layout_count, layout_size, layout_usage, layout_upload);
		layout_wanted = 0;
		t.Finish();
	}
	t.Clear(GL_COLOR_BUFFER_BIT);
	t.BindBuffer(GL_ELEMENT_ARRAY_BUFFER, worker->index_buffer);
	if (flags & _client_arrays)
		t.BindBuffer(GL_ARRAY_BUFFER, 0);
	else
		t.BindBuffer(GL_ARRAY_BUFFER, worker->vertex_buffer);
	for (draw = 0; draw < TEST_DRAWS; draw++)
	{
		int chunk = draw % TEST_CHUNKS;
		int program = flags & _sorted ? draw * TEST_PROGRAMS / TEST_DRAWS : draw % TEST_PROGRAMS;
		GLuint buffer = flags & _buffer_per_chunk ? test_chunk_buffers[chunk] : worker->vertex_buffer;
		size_t offset = flags & _buffer_per_chunk ? 0 : (size_t)chunk * TEST_CHUNK;
		const unsigned char *base;

		if (!(flags & _skip_program) && (!(flags & _program_every_8) || draw % 8 == 0) &&
			(!(flags & _sorted) || draw == 0 || program != current))
		{
			t.UseProgram(worker->programs[program]);
			current = program;
		}
		else if (draw == 0)
		{
			t.UseProgram(worker->programs[0]);
			current = 0;
		}
		if (!(flags & _skip_uniforms))
		{
			constants[17] = (float)draw * 0.001f;
			t.Uniform4fv(worker->uniforms[current], vectors, constants);
		}
		if (!(flags & _skip_textures) || draw == 0)
		{
			t.ActiveTexture(GL_TEXTURE0);
			t.BindTexture(GL_TEXTURE_2D, worker->textures[draw % TEST_TEXTURES]);
			t.ActiveTexture(GL_TEXTURE1);
			t.BindTexture(GL_TEXTURE_2D, worker->textures[(draw + 1) % TEST_TEXTURES]);
		}
		if (layout.active)
		{
			unsigned long slots_per_buffer = layout.size / TEST_CHUNK;
			unsigned long slot = (unsigned long)draw % (slots_per_buffer * (unsigned long)layout.count);

			if (layout.side_mode == 1)
			{
				t.BindBuffer(GL_ARRAY_BUFFER, layout.big_side);
				t.BufferSubData(GL_ARRAY_BUFFER, (GLintptr)((draw % 2048) * TEST_CHUNK), TEST_VERTICES * 24, vertices);
			}
			else if (layout.side_mode == 2)
			{
				t.BindBuffer(GL_ARRAY_BUFFER, layout.small_side[draw % 64]);
				t.BufferSubData(GL_ARRAY_BUFFER, 0, TEST_VERTICES * 24, vertices);
			}
			if (layout.index_mode == 1)
			{
				index_offset = (size_t)(draw % 3000) * 640;
				t.BindBuffer(GL_ELEMENT_ARRAY_BUFFER, layout.big_index);
				t.BufferSubData(GL_ELEMENT_ARRAY_BUFFER, (GLintptr)index_offset, sizeof(test_indices), test_indices);
			}
			else if (layout.index_mode == 2)
			{
				index_offset = 0;
				t.BindBuffer(GL_ELEMENT_ARRAY_BUFFER, layout.small_index[draw % 64]);
				t.BufferSubData(GL_ELEMENT_ARRAY_BUFFER, 0, sizeof(test_indices), test_indices);
			}
			t.BindBuffer(GL_ARRAY_BUFFER, layout.buffers[slot / slots_per_buffer]);
			base = (const unsigned char *)((slot % slots_per_buffer) * TEST_CHUNK);
			if (layout.upload)
				t.BufferSubData(GL_ARRAY_BUFFER, (GLintptr)(size_t)base, TEST_VERTICES * 24, vertices);
		}
		else if (flags & _client_arrays)
			base = vertices;
		else
		{
			if (flags & _buffer_per_chunk)
				t.BindBuffer(GL_ARRAY_BUFFER, buffer);
			if ((flags & _orphan) && chunk == 0)
				t.BufferData(GL_ARRAY_BUFFER, TEST_CHUNK * TEST_CHUNKS, NULL, GL_STREAM_DRAW);
			if (!(flags & _skip_upload) || draw < TEST_CHUNKS)
				t.BufferSubData(GL_ARRAY_BUFFER, (GLintptr)offset, TEST_VERTICES * 24, vertices);
			base = (const unsigned char *)offset;
		}
		if (layout.active && layout.unaligned)
		{
			/* (22-byte vertices: shorts for the position and uv, the color's
			bytes at 10, not a multiple of four; the stride neither) */
			t.VertexAttribPointer(0, 3, GL_SHORT, GL_TRUE, 22, base);
			t.VertexAttribPointer(1, 2, GL_SHORT, GL_TRUE, 22, base + 6);
			t.VertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, 22, base + 10);
		}
		else if (!(flags & _skip_pointers) || draw < TEST_CHUNKS || (flags & _buffer_per_chunk) || layout.active)
		{
			t.VertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, base);
			t.VertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 24, base + 12);
			t.VertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, 24, base + 20);
		}
		t.DrawElements(GL_TRIANGLE_STRIP, vertices_drawn, GL_UNSIGNED_SHORT, (const void *)index_offset);
		if (layout.active && layout.index_mode)
			t.BindBuffer(GL_ELEMENT_ARRAY_BUFFER, worker->index_buffer);
	}
	t.Finish();
}

static void *test_worker_main(void *parameter)
{
	struct test_worker *worker = parameter;
	int ok = t.MakeCurrent(test_display, worker->surface, worker->surface, worker->context) && test_objects(worker);

	pthread_mutex_lock(&test_lock);
	worker->failed = !ok;
	worker->ready = 1;
	pthread_cond_broadcast(&test_changed);
	for (;;)
	{
		int run;
		unsigned long long start;

		while (!worker->quit && (!worker->run || test_go != worker->run))
			pthread_cond_wait(&test_changed, &test_lock);
		if (worker->quit)
			break;
		run = worker->run;
		pthread_mutex_unlock(&test_lock);
		start = test_now();
		if (ok)
			test_draws(worker);
		pthread_mutex_lock(&test_lock);
		worker->nanoseconds = test_now() - start;
		worker->run = 0;
		worker->done = run;
		pthread_cond_broadcast(&test_changed);
	}
	pthread_mutex_unlock(&test_lock);
	t.MakeCurrent(test_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
	return NULL;
}

static struct test_worker workers[TEST_WORKERS];
static int test_runs;

/* the given workers' draws at once; the time until the last is done (ns),
each one's into times */
static unsigned long long test_run(int first, int second, unsigned long long *times)
{
	int run = ++test_runs;
	unsigned long long start = test_now();

	pthread_mutex_lock(&test_lock);
	workers[first].run = run;
	if (second >= 0)
		workers[second].run = run;
	test_go = run;
	pthread_cond_broadcast(&test_changed);
	while (workers[first].done != run || (second >= 0 && workers[second].done != run))
		pthread_cond_wait(&test_changed, &test_lock);
	times[0] = workers[first].nanoseconds;
	times[1] = second >= 0 ? workers[second].nanoseconds : 0;
	pthread_mutex_unlock(&test_lock);
	return test_now() - start;
}

static void test_report_pair(const char *what, int second, unsigned long long alone)
{
	unsigned long long best = ~0ULL, times[2], best_times[2] = { 0, 0 };
	int repeat;

	for (repeat = 0; repeat < 3; repeat++)
	{
		unsigned long long wall = test_run(0, second, times);

		if (wall < best)
		{
			best = wall;
			best_times[0] = times[0];
			best_times[1] = times[1];
		}
	}
	platform_log("gl context test: %s: both threads' %d draws done in %.1f ms (%.1f and %.1f ms each, %.1f us a "
		"draw each); speedup %.2f over one thread doing both (2 parallel, 1 one after the other), %ld processors "
		"online", what, TEST_DRAWS, best / 1e6, best_times[0] / 1e6, best_times[1] / 1e6,
		best_times[0] / 1e3 / TEST_DRAWS, 2.0 * alone / (double)best, sysconf(_SC_NPROCESSORS_ONLN));
}

void gl_context_test_run(void)
{
	static const EGLint config_attributes[] = {
		EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT, EGL_SURFACE_TYPE, EGL_PBUFFER_BIT,
		EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_NONE
	};
	static const EGLint context_attributes[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };
	static const EGLint surface_attributes[] = { EGL_WIDTH, 64, EGL_HEIGHT, 64, EGL_NONE };
	EGLint count = 0;
	unsigned long long alone = ~0ULL, times[2];
	int index, repeat;

	if (!config_boolean("debug.gl_context_test"))
		return;
	if (!test_load())
	{
		platform_log("gl context test: the driver's libraries or entry points were not found");
		return;
	}
	test_display = t.GetDisplay(EGL_DEFAULT_DISPLAY);
	if (test_display == EGL_NO_DISPLAY || !t.Initialize(test_display, NULL, NULL) ||
		!t.ChooseConfig(test_display, config_attributes, &test_config, 1, &count) || count < 1)
	{
		platform_log("gl context test: no pbuffer configuration (EGL error %04x)", t.GetError());
		return;
	}
	workers[0].name = "A";
	workers[1].name = "B (unshared)";
	workers[2].name = "C (sharing A's objects)";
	for (index = 0; index < TEST_WORKERS; index++)
	{
		EGLContext share = index == 2 ? workers[0].context : EGL_NO_CONTEXT;

		workers[index].context = t.CreateContext(test_display, test_config, share, context_attributes);
		workers[index].surface = t.CreatePbufferSurface(test_display, test_config, surface_attributes);
		if (workers[index].context == EGL_NO_CONTEXT || workers[index].surface == EGL_NO_SURFACE)
		{
			platform_log("gl context test: context %s could not be made (EGL error %04x)", workers[index].name,
				t.GetError());
			return;
		}
	}
	for (index = 0; index < TEST_WORKERS; index++)
	{
		if (pthread_create(&workers[index].thread, NULL, test_worker_main, &workers[index]))
		{
			platform_log("gl context test: no thread");
			return;
		}
	}
	pthread_mutex_lock(&test_lock);
	for (index = 0; index < TEST_WORKERS; index++)
	{
		while (!workers[index].ready)
			pthread_cond_wait(&test_changed, &test_lock);
	}
	pthread_mutex_unlock(&test_lock);
	for (index = 0; index < TEST_WORKERS; index++)
	{
		if (workers[index].failed)
		{
			platform_log("gl context test: context %s: its programs, textures or buffers could not be made",
				workers[index].name);
			goto finish;
		}
	}
	/* (one run first, unmeasured: the driver's first-use work) */
	test_run(0, -1, times);
	test_run(1, -1, times);
	test_run(2, -1, times);
	for (repeat = 0; repeat < 3; repeat++)
	{
		unsigned long long wall = test_run(0, -1, times);

		if (wall < alone)
			alone = wall;
	}
	platform_log("gl context test: one thread alone (A): %d draws in %.1f ms, %.1f us a draw", TEST_DRAWS,
		alone / 1e6, alone / 1e3 / TEST_DRAWS);
	test_report_pair("two unshared contexts at once (A and B)", 1, alone);
	test_report_pair("two contexts sharing objects at once (A and C)", 2, alone);
	{
		unsigned long long again = test_run(0, -1, times);

		platform_log("gl context test: one thread alone again: %.1f ms (the first %.1f)", again / 1e6, alone / 1e6);
	}
	/* the parts of a draw: each left out (or changed) in turn, one thread */
	{
		static const struct { int flags; const char *name; } variants[] = {
			{ 0, "all of it (a program change, 16 uniform vectors, 2 textures, a 7 KB upload into a shared buffer, "
				"3 pointers, 300 vertices)" },
			{ _skip_program, "no program change" },
			{ _program_every_8, "a program change every 8th draw" },
			{ _sorted, "the draws sorted by program (4 changes in all)" },
			{ _skip_uniforms, "no uniforms" },
			{ _uniforms_64, "64 uniform vectors, not 16" },
			{ _skip_textures, "no texture binds" },
			{ _skip_upload, "no upload (the vertices already there)" },
			{ _buffer_per_chunk, "each upload into a buffer of its own (64 of them, round)" },
			{ _orphan, "the shared buffer orphaned at each wrap" },
			{ _client_arrays, "the vertices from memory (client arrays, no buffer)" },
			{ _skip_pointers | _skip_upload, "no upload, no pointers" },
			{ _vertices_60, "60 vertices, not 300" },
			{ _skip_program | _skip_uniforms | _skip_textures | _skip_upload | _skip_pointers,
				"the draw alone (nothing changed before it)" },
		};
		unsigned long variant;

		for (variant = 0; variant < sizeof(variants) / sizeof(variants[0]); variant++)
		{
			unsigned long long best = ~0ULL;

			test_flags = variants[variant].flags;
			test_run(0, -1, times);
			for (repeat = 0; repeat < 3; repeat++)
			{
				unsigned long long wall = test_run(0, -1, times);

				if (wall < best)
					best = wall;
			}
			platform_log("gl draw cost test: %s: %.1f us a draw", variants[variant].name, best / 1e3 / TEST_DRAWS);
		}
		test_flags = 0;
	}
	/* where the vertices are: buffers' sizes and usages (each draw's 7 KB
	upload into the next 8 KB slot, or none) */
	{
		static const struct { int count; unsigned long size; GLenum usage; int upload; const char *name; } layouts[] = {
			{ 1, 512 * 1024, GL_STREAM_DRAW, 1, "one 512 KB stream buffer" },
			{ 1, 512 * 1024, GL_DYNAMIC_DRAW, 1, "one 512 KB dynamic buffer" },
			{ 1, 512 * 1024, GL_STATIC_DRAW, 1, "one 512 KB static buffer" },
			{ 1, 16 * 1024 * 1024, GL_STREAM_DRAW, 1, "one 16 MB stream buffer (the game's)" },
			{ 1, 16 * 1024 * 1024, GL_DYNAMIC_DRAW, 1, "one 16 MB dynamic buffer" },
			{ 1, 16 * 1024 * 1024, GL_STREAM_DRAW, 0, "one 16 MB stream buffer, no uploads" },
			{ 64, 8 * 1024, GL_STREAM_DRAW, 1, "64 buffers of 8 KB, stream" },
			{ 64, 8 * 1024, GL_DYNAMIC_DRAW, 1, "64 buffers of 8 KB, dynamic" },
			{ 64, 8 * 1024, GL_STREAM_DRAW, 0, "64 buffers of 8 KB, no uploads" },
			{ 256, 8 * 1024, GL_STREAM_DRAW, 1, "256 buffers of 8 KB, stream" },
			{ 16, 64 * 1024, GL_STREAM_DRAW, 1, "16 buffers of 64 KB, stream" },
			{ 8, 256 * 1024, GL_STREAM_DRAW, 1, "8 buffers of 256 KB, stream" },
			{ 4, 1024 * 1024, GL_STREAM_DRAW, 1, "4 buffers of 1 MB, stream" },
		};
		unsigned long index;

		for (index = 0; index < sizeof(layouts) / sizeof(layouts[0]); index++)
		{
			unsigned long long best = ~0ULL;

			layout_count = layouts[index].count;
			layout_size = layouts[index].size;
			layout_usage = layouts[index].usage;
			layout_upload = layouts[index].upload;
			layout_wanted = 1;
			test_run(0, -1, times);
			for (repeat = 0; repeat < 3; repeat++)
			{
				unsigned long long wall = test_run(0, -1, times);

				if (wall < best)
					best = wall;
			}
			platform_log("gl buffer test: %s: %.1f us a draw", layouts[index].name, best / 1e3 / TEST_DRAWS);
		}
	}
	/* the vertices in a 16 MB buffer never written (as the game's mirror),
	with the game's other writes: its indices uploaded each draw, other
	buffers written, its attributes not aligned for four */
	{
		static const struct { int index_mode, side_mode, unaligned; const char *name; } sources[] = {
			{ 0, 0, 0, "static vertices and indices" },
			{ 1, 0, 0, "indices uploaded each draw into a 2 MB buffer" },
			{ 2, 0, 0, "indices uploaded each draw into a 4 KB buffer of their own" },
			{ 0, 1, 0, "7 KB written into another 16 MB buffer each draw" },
			{ 0, 2, 0, "7 KB written into another 8 KB buffer each draw" },
			{ 0, 0, 1, "attributes not aligned for four" },
			{ 2, 0, 1, "attributes not aligned, indices into 4 KB buffers" },
			{ 1, 0, 1, "attributes not aligned, indices into a 2 MB buffer" },
		};
		unsigned long index;

		for (index = 0; index < sizeof(sources) / sizeof(sources[0]); index++)
		{
			unsigned long long best = ~0ULL;

			layout_count = 1;
			layout_size = 16 * 1024 * 1024;
			layout_usage = GL_STATIC_DRAW;
			layout_upload = 0;
			layout_index_mode = sources[index].index_mode;
			layout_side_mode = sources[index].side_mode;
			layout_unaligned = sources[index].unaligned;
			layout_wanted = 1;
			test_run(0, -1, times);
			for (repeat = 0; repeat < 3; repeat++)
			{
				unsigned long long wall = test_run(0, -1, times);

				if (wall < best)
					best = wall;
			}
			platform_log("gl source test: vertices in a 16 MB buffer never written; %s: %.1f us a draw",
				sources[index].name, best / 1e3 / TEST_DRAWS);
		}
		layout_index_mode = layout_side_mode = layout_unaligned = 0;
	}

finish:
	pthread_mutex_lock(&test_lock);
	for (index = 0; index < TEST_WORKERS; index++)
		workers[index].quit = 1;
	pthread_cond_broadcast(&test_changed);
	pthread_mutex_unlock(&test_lock);
	for (index = 0; index < TEST_WORKERS; index++)
		pthread_join(workers[index].thread, NULL);
	for (index = 0; index < TEST_WORKERS; index++)
	{
		t.DestroySurface(test_display, workers[index].surface);
		t.DestroyContext(test_display, workers[index].context);
	}
}

#else

typedef int gl_context_test_unused;

#endif
