/* gl_context_test.c: debug.gl_context_test (the 32-bit ARM Android build)

Does the Tegra 4's OpenGL ES 2.0 driver do two threads' draws at once, each
thread with a context of its own? The GL thread is the frame's limit (the
driver's ~50 us a draw, on one core); a second context drawing part of the
frame on another core would help only if the driver does not hold one lock
for every context.

At startup, before the game draws, three contexts of their own are made (not
the game's: nothing it holds is touched), each on a thread of its own with a
small pbuffer: A; B, unshared; C, sharing A's objects (as a second context of
the game's would have to, for its textures and buffers). Each draws the same
synthetic frame's worth of draws, shaped like the game's (a program change,
16 uniform vectors, two textures, a buffer update, three attribute pointers,
an indexed strip of 300 vertices into a 64 by 64 target, so the GPU's part is
small): A alone, then A with B at once, then A with C at once. Two threads
that each take as long as one alone are done in parallel (speedup 2); twice
as long, one after the other (speedup 1). The driver's own libraries are
loaded here (dlopen), so no call goes through the game's table or glq.c. */

#ifdef HALO_ANDROID_ARMV7

#include "port_config.h"

#include <dlfcn.h>
#include <pthread.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include <EGL/egl.h>
#include <GLES2/gl2.h>

void platform_log(const char *format, ...);

#define TEST_DRAWS 3000
#define TEST_VERTICES 300
#define TEST_PROGRAMS 4
#define TEST_TEXTURES 4
#define TEST_CHUNK 8192
#define TEST_CHUNKS 64
#define TEST_WORKERS 3

/* the driver's entry points */
static struct
{
	EGLDisplay (*GetDisplay)(EGLNativeDisplayType);
	EGLBoolean (*Initialize)(EGLDisplay, EGLint *, EGLint *);
	EGLBoolean (*ChooseConfig)(EGLDisplay, const EGLint *, EGLConfig *, EGLint, EGLint *);
	EGLContext (*CreateContext)(EGLDisplay, EGLConfig, EGLContext, const EGLint *);
	EGLSurface (*CreatePbufferSurface)(EGLDisplay, EGLConfig, const EGLint *);
	EGLBoolean (*MakeCurrent)(EGLDisplay, EGLSurface, EGLSurface, EGLContext);
	EGLBoolean (*DestroyContext)(EGLDisplay, EGLContext);
	EGLBoolean (*DestroySurface)(EGLDisplay, EGLSurface);
	EGLint (*GetError)(void);

	GLuint (*CreateShader)(GLenum);
	void (*ShaderSource)(GLuint, GLsizei, const GLchar *const *, const GLint *);
	void (*CompileShader)(GLuint);
	void (*GetShaderiv)(GLuint, GLenum, GLint *);
	GLuint (*CreateProgram)(void);
	void (*AttachShader)(GLuint, GLuint);
	void (*BindAttribLocation)(GLuint, GLuint, const GLchar *);
	void (*LinkProgram)(GLuint);
	void (*GetProgramiv)(GLuint, GLenum, GLint *);
	GLint (*GetUniformLocation)(GLuint, const GLchar *);
	void (*UseProgram)(GLuint);
	void (*Uniform1i)(GLint, GLint);
	void (*Uniform4fv)(GLint, GLsizei, const GLfloat *);
	void (*GenTextures)(GLsizei, GLuint *);
	void (*BindTexture)(GLenum, GLuint);
	void (*ActiveTexture)(GLenum);
	void (*TexImage2D)(GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void *);
	void (*TexParameteri)(GLenum, GLenum, GLint);
	void (*GenBuffers)(GLsizei, GLuint *);
	void (*BindBuffer)(GLenum, GLuint);
	void (*BufferData)(GLenum, GLsizeiptr, const void *, GLenum);
	void (*BufferSubData)(GLenum, GLintptr, GLsizeiptr, const void *);
	void (*EnableVertexAttribArray)(GLuint);
	void (*VertexAttribPointer)(GLuint, GLint, GLenum, GLboolean, GLsizei, const void *);
	void (*DrawElements)(GLenum, GLsizei, GLenum, const void *);
	void (*Viewport)(GLint, GLint, GLsizei, GLsizei);
	void (*Clear)(GLbitfield);
	void (*Finish)(void);
	GLenum (*GetErrorGL)(void);
} t;

static EGLDisplay test_display;
static EGLConfig test_config;

static int test_load(void)
{
	void *egl = dlopen("libEGL.so", RTLD_NOW);
	void *gles = dlopen("libGLESv2.so", RTLD_NOW);

	if (!egl || !gles)
		return 0;
#define E(name) if (!(*(void **)&t.name = dlsym(egl, "egl" #name))) return 0;
#define G(name) if (!(*(void **)&t.name = dlsym(gles, "gl" #name))) return 0;
	E(GetDisplay) E(Initialize) E(ChooseConfig) E(CreateContext) E(CreatePbufferSurface) E(MakeCurrent)
	E(DestroyContext) E(DestroySurface) E(GetError)
	G(CreateShader) G(ShaderSource) G(CompileShader) G(GetShaderiv) G(CreateProgram) G(AttachShader)
	G(BindAttribLocation) G(LinkProgram) G(GetProgramiv) G(GetUniformLocation) G(UseProgram) G(Uniform1i)
	G(Uniform4fv) G(GenTextures) G(BindTexture) G(ActiveTexture) G(TexImage2D) G(TexParameteri) G(GenBuffers)
	G(BindBuffer) G(BufferData) G(BufferSubData) G(EnableVertexAttribArray) G(VertexAttribPointer)
	G(DrawElements) G(Viewport) G(Clear) G(Finish)
#undef E
#undef G
	if (!(*(void **)&t.GetErrorGL = dlsym(gles, "glGetError")))
		return 0;
	return 1;
}

static unsigned long long test_now(void)
{
	struct timespec now;

	clock_gettime(CLOCK_MONOTONIC, &now);
	return (unsigned long long)now.tv_sec * 1000000000ULL + (unsigned long long)now.tv_nsec;
}

/* ---------- a worker: its context, its objects, its draws */

struct test_worker
{
	const char *name;
	EGLContext context, share;
	EGLSurface surface;
	pthread_t thread;
	/* (set by the main thread under test_lock: the run to do; done back) */
	int run, done, ready, failed, quit;
	unsigned long long nanoseconds;
	GLuint programs[TEST_PROGRAMS], textures[TEST_TEXTURES], vertex_buffer, index_buffer;
	GLint uniforms[TEST_PROGRAMS];
};

static pthread_mutex_t test_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t test_changed = PTHREAD_COND_INITIALIZER;
static int test_go;

static GLuint test_shader(GLenum kind, const char *source)
{
	GLuint shader = t.CreateShader(kind);
	GLint compiled = 0;

	t.ShaderSource(shader, 1, &source, NULL);
	t.CompileShader(shader);
	t.GetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
	return compiled ? shader : 0;
}

static int test_objects(struct test_worker *worker)
{
	static const char *vertex_source =
		"uniform vec4 u[16];\n"
		"attribute vec3 position; attribute vec2 uv; attribute vec4 color;\n"
		"varying vec2 v_uv; varying vec4 v_color;\n"
		"void main() {\n"
		"  vec4 p = vec4(position, 1.0);\n"
		"  gl_Position = vec4(dot(p, u[0]), dot(p, u[1]), dot(p, u[2]), dot(p, u[3]));\n"
		"  v_uv = uv * u[4].xy + u[5].xy * u[%d].z;\n"
		"  v_color = color * u[6] + u[7] * u[8].x + u[9] * u[10].y + u[11] * u[12].z + u[13] * u[14].w + u[15];\n"
		"}\n";
	static const char *fragment_source =
		"precision mediump float;\n"
		"uniform sampler2D t0; uniform sampler2D t1;\n"
		"varying vec2 v_uv; varying vec4 v_color;\n"
		"void main() { gl_FragColor = texture2D(t0, v_uv) * texture2D(t1, v_uv.yx) * v_color; }\n";
	unsigned char texels[64 * 64 * 4];
	unsigned short indices[TEST_VERTICES];
	int index;

	for (index = 0; index < TEST_PROGRAMS; index++)
	{
		char source[1024];
		GLuint vertex, fragment, program;
		GLint linked = 0;

		snprintf(source, sizeof(source), vertex_source, 5 + index);
		vertex = test_shader(GL_VERTEX_SHADER, source);
		fragment = test_shader(GL_FRAGMENT_SHADER, fragment_source);
		if (!vertex || !fragment)
			return 0;
		program = t.CreateProgram();
		t.AttachShader(program, vertex);
		t.AttachShader(program, fragment);
		t.BindAttribLocation(program, 0, "position");
		t.BindAttribLocation(program, 1, "uv");
		t.BindAttribLocation(program, 2, "color");
		t.LinkProgram(program);
		t.GetProgramiv(program, GL_LINK_STATUS, &linked);
		if (!linked)
			return 0;
		worker->programs[index] = program;
		worker->uniforms[index] = t.GetUniformLocation(program, "u");
		t.UseProgram(program);
		t.Uniform1i(t.GetUniformLocation(program, "t0"), 0);
		t.Uniform1i(t.GetUniformLocation(program, "t1"), 1);
	}
	for (index = 0; index < (int)sizeof(texels); index++)
		texels[index] = (unsigned char)(index * 7);
	t.GenTextures(TEST_TEXTURES, worker->textures);
	for (index = 0; index < TEST_TEXTURES; index++)
	{
		t.BindTexture(GL_TEXTURE_2D, worker->textures[index]);
		t.TexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 64, 64, 0, GL_RGBA, GL_UNSIGNED_BYTE, texels);
		t.TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		t.TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	}
	for (index = 0; index < TEST_VERTICES; index++)
		indices[index] = (unsigned short)index;
	t.GenBuffers(1, &worker->vertex_buffer);
	t.BindBuffer(GL_ARRAY_BUFFER, worker->vertex_buffer);
	t.BufferData(GL_ARRAY_BUFFER, TEST_CHUNK * TEST_CHUNKS, NULL, GL_STREAM_DRAW);
	t.GenBuffers(1, &worker->index_buffer);
	t.BindBuffer(GL_ELEMENT_ARRAY_BUFFER, worker->index_buffer);
	t.BufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
	t.EnableVertexAttribArray(0);
	t.EnableVertexAttribArray(1);
	t.EnableVertexAttribArray(2);
	t.Viewport(0, 0, 64, 64);
	return t.GetErrorGL() == GL_NO_ERROR;
}

/* a frame's worth of draws, as the game's are shaped */
static void test_draws(struct test_worker *worker)
{
	/* (24-byte vertices: a position, a uv, a color) */
	static unsigned char vertices[TEST_CHUNK];
	GLfloat constants[16 * 4];
	int draw, index;

	for (index = 0; index < TEST_VERTICES; index++)
	{
		float *position = (float *)(vertices + index * 24);

		position[0] = (float)(index % 20) * 0.05f - 0.5f;
		position[1] = (float)(index / 20) * 0.05f - 0.5f;
		position[2] = 0.0f;
		position[3] = position[0];
		position[4] = position[1];
		memset(vertices + index * 24 + 20, 0x80, 4);
	}
	for (index = 0; index < 64; index++)
		constants[index] = (index % 5) == 0 ? 1.0f : 0.01f * (float)index;
	t.Clear(GL_COLOR_BUFFER_BIT);
	for (draw = 0; draw < TEST_DRAWS; draw++)
	{
		int chunk = draw % TEST_CHUNKS;

		t.UseProgram(worker->programs[draw % TEST_PROGRAMS]);
		constants[17] = (float)draw * 0.001f;
		t.Uniform4fv(worker->uniforms[draw % TEST_PROGRAMS], 16, constants);
		t.ActiveTexture(GL_TEXTURE0);
		t.BindTexture(GL_TEXTURE_2D, worker->textures[draw % TEST_TEXTURES]);
		t.ActiveTexture(GL_TEXTURE1);
		t.BindTexture(GL_TEXTURE_2D, worker->textures[(draw + 1) % TEST_TEXTURES]);
		t.BindBuffer(GL_ARRAY_BUFFER, worker->vertex_buffer);
		t.BufferSubData(GL_ARRAY_BUFFER, chunk * TEST_CHUNK, TEST_VERTICES * 24, vertices);
		t.VertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (const void *)(size_t)(chunk * TEST_CHUNK));
		t.VertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 24, (const void *)(size_t)(chunk * TEST_CHUNK + 12));
		t.VertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, 24, (const void *)(size_t)(chunk * TEST_CHUNK + 20));
		t.BindBuffer(GL_ELEMENT_ARRAY_BUFFER, worker->index_buffer);
		t.DrawElements(GL_TRIANGLE_STRIP, TEST_VERTICES, GL_UNSIGNED_SHORT, NULL);
	}
	t.Finish();
}

static void *test_worker_main(void *parameter)
{
	struct test_worker *worker = parameter;
	int ok = t.MakeCurrent(test_display, worker->surface, worker->surface, worker->context) && test_objects(worker);

	pthread_mutex_lock(&test_lock);
	worker->failed = !ok;
	worker->ready = 1;
	pthread_cond_broadcast(&test_changed);
	for (;;)
	{
		int run;
		unsigned long long start;

		while (!worker->quit && (!worker->run || test_go != worker->run))
			pthread_cond_wait(&test_changed, &test_lock);
		if (worker->quit)
			break;
		run = worker->run;
		pthread_mutex_unlock(&test_lock);
		start = test_now();
		if (ok)
			test_draws(worker);
		pthread_mutex_lock(&test_lock);
		worker->nanoseconds = test_now() - start;
		worker->run = 0;
		worker->done = run;
		pthread_cond_broadcast(&test_changed);
	}
	pthread_mutex_unlock(&test_lock);
	t.MakeCurrent(test_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
	return NULL;
}

static struct test_worker workers[TEST_WORKERS];
static int test_runs;

/* the given workers' draws at once; the time until the last is done (ns),
each one's into times */
static unsigned long long test_run(int first, int second, unsigned long long *times)
{
	int run = ++test_runs;
	unsigned long long start = test_now();

	pthread_mutex_lock(&test_lock);
	workers[first].run = run;
	if (second >= 0)
		workers[second].run = run;
	test_go = run;
	pthread_cond_broadcast(&test_changed);
	while (workers[first].done != run || (second >= 0 && workers[second].done != run))
		pthread_cond_wait(&test_changed, &test_lock);
	times[0] = workers[first].nanoseconds;
	times[1] = second >= 0 ? workers[second].nanoseconds : 0;
	pthread_mutex_unlock(&test_lock);
	return test_now() - start;
}

static void test_report_pair(const char *what, int second, unsigned long long alone)
{
	unsigned long long best = ~0ULL, times[2], best_times[2] = { 0, 0 };
	int repeat;

	for (repeat = 0; repeat < 3; repeat++)
	{
		unsigned long long wall = test_run(0, second, times);

		if (wall < best)
		{
			best = wall;
			best_times[0] = times[0];
			best_times[1] = times[1];
		}
	}
	platform_log("gl context test: %s: both threads' %d draws done in %.1f ms (%.1f and %.1f ms each, %.1f us a "
		"draw each); speedup %.2f over one thread doing both (2 parallel, 1 one after the other), %ld processors "
		"online", what, TEST_DRAWS, best / 1e6, best_times[0] / 1e6, best_times[1] / 1e6,
		best_times[0] / 1e3 / TEST_DRAWS, 2.0 * alone / (double)best, sysconf(_SC_NPROCESSORS_ONLN));
}

void gl_context_test_run(void)
{
	static const EGLint config_attributes[] = {
		EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT, EGL_SURFACE_TYPE, EGL_PBUFFER_BIT,
		EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_NONE
	};
	static const EGLint context_attributes[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };
	static const EGLint surface_attributes[] = { EGL_WIDTH, 64, EGL_HEIGHT, 64, EGL_NONE };
	EGLint count = 0;
	unsigned long long alone = ~0ULL, times[2];
	int index, repeat;

	if (!config_boolean("debug.gl_context_test"))
		return;
	if (!test_load())
	{
		platform_log("gl context test: the driver's libraries or entry points were not found");
		return;
	}
	test_display = t.GetDisplay(EGL_DEFAULT_DISPLAY);
	if (test_display == EGL_NO_DISPLAY || !t.Initialize(test_display, NULL, NULL) ||
		!t.ChooseConfig(test_display, config_attributes, &test_config, 1, &count) || count < 1)
	{
		platform_log("gl context test: no pbuffer configuration (EGL error %04x)", t.GetError());
		return;
	}
	workers[0].name = "A";
	workers[1].name = "B (unshared)";
	workers[2].name = "C (sharing A's objects)";
	for (index = 0; index < TEST_WORKERS; index++)
	{
		EGLContext share = index == 2 ? workers[0].context : EGL_NO_CONTEXT;

		workers[index].context = t.CreateContext(test_display, test_config, share, context_attributes);
		workers[index].surface = t.CreatePbufferSurface(test_display, test_config, surface_attributes);
		if (workers[index].context == EGL_NO_CONTEXT || workers[index].surface == EGL_NO_SURFACE)
		{
			platform_log("gl context test: context %s could not be made (EGL error %04x)", workers[index].name,
				t.GetError());
			return;
		}
	}
	for (index = 0; index < TEST_WORKERS; index++)
	{
		if (pthread_create(&workers[index].thread, NULL, test_worker_main, &workers[index]))
		{
			platform_log("gl context test: no thread");
			return;
		}
	}
	pthread_mutex_lock(&test_lock);
	for (index = 0; index < TEST_WORKERS; index++)
	{
		while (!workers[index].ready)
			pthread_cond_wait(&test_changed, &test_lock);
	}
	pthread_mutex_unlock(&test_lock);
	for (index = 0; index < TEST_WORKERS; index++)
	{
		if (workers[index].failed)
		{
			platform_log("gl context test: context %s: its programs, textures or buffers could not be made",
				workers[index].name);
			goto finish;
		}
	}
	/* (one run first, unmeasured: the driver's first-use work) */
	test_run(0, -1, times);
	test_run(1, -1, times);
	test_run(2, -1, times);
	for (repeat = 0; repeat < 3; repeat++)
	{
		unsigned long long wall = test_run(0, -1, times);

		if (wall < alone)
			alone = wall;
	}
	platform_log("gl context test: one thread alone (A): %d draws in %.1f ms, %.1f us a draw", TEST_DRAWS,
		alone / 1e6, alone / 1e3 / TEST_DRAWS);
	test_report_pair("two unshared contexts at once (A and B)", 1, alone);
	test_report_pair("two contexts sharing objects at once (A and C)", 2, alone);
	{
		unsigned long long again = test_run(0, -1, times);

		platform_log("gl context test: one thread alone again: %.1f ms (the first %.1f)", again / 1e6, alone / 1e6);
	}

finish:
	pthread_mutex_lock(&test_lock);
	for (index = 0; index < TEST_WORKERS; index++)
		workers[index].quit = 1;
	pthread_cond_broadcast(&test_changed);
	pthread_mutex_unlock(&test_lock);
	for (index = 0; index < TEST_WORKERS; index++)
		pthread_join(workers[index].thread, NULL);
	for (index = 0; index < TEST_WORKERS; index++)
	{
		t.DestroySurface(test_display, workers[index].surface);
		t.DestroyContext(test_display, workers[index].context);
	}
}

#else

typedef int gl_context_test_unused;

#endif
