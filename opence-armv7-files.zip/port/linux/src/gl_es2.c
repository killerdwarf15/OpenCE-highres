/*
GL_ES2.C

The renderer's OpenGL ES 3.0 calls on an OpenGL ES 2.0 context (the 32-bit
ARM Android build on the SHIELD Portable's Tegra 4, port/android/native).
gl_es2_install, which gl_functions_load calls for such a context, points the
renderer's function table (gl.h, halo_gl*) at:

- the extensions that are ES 3.0's functions under other names: vertex
  array objects (OES_vertex_array_object), blits (NV_framebuffer_blit), draw
  and read buffers (NV_draw_buffers, NV_read_buffer), occlusion queries
  (EXT_occlusion_query_boolean), multisampled renderbuffers
  (NV_framebuffer_multisample), buffer copies (NV_copy_buffer);
- emulations of the rest:
  - sampler objects: each sampler's state is kept here, and set on the
    texture of each unit it is bound to as the texture or the sampler is
    bound (glTexParameter); a texture whose levels stop short of a full chain
    (GL_TEXTURE_MAX_LEVEL, which ES 2.0 lacks, being kept here too) is
    sampled without mipmaps, as ES 2.0 would otherwise not sample it at all;
  - textures: ES 3.0's sized formats as ES 2.0's unsized ones and their
    extensions (BGRA8888, texture_rg, half floats, depth textures); a 3D
    texture, which ES 2.0 has none of, as a 2D texture of its first slice;
  - the Xbox's packed normals, an unsigned integer attribute in ES 3.0, as
    four bytes (unpacked in the shader: gl_es2_glsl.c);
  - what has no counterpart is left undone: memory barriers, buffer
    bindings, invalidation, 32-bit indices, and texture parameters ES 2.0
    has none of (swizzles, base level, level of detail range).
*/

#include "platform.h"
#include "gl.h"
#include "gl_es2.h"

#include <SDL3/SDL.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef HALO_ANDROID_ARMV7

/* ---------- ES 2.0 enumerants that ES 3.0's headers name otherwise */

#define ES2_HALF_FLOAT_OES 0x8D61
#define ES2_BGRA_EXT 0x80E1
#define ES2_RED_EXT 0x1903
#define ES2_RG_EXT 0x8227
#define ES2_DEPTH_COMPONENT24_OES 0x81A6
#define ES2_TEXTURE_3D 0x806F
#define ES2_TEXTURE_WRAP_R 0x8072
#define ES2_TEXTURE_MAX_ANISOTROPY 0x84FE
#define ES2_TEXTURE_COMPARE_MODE 0x884C
#define ES2_TEXTURE_COMPARE_FUNC 0x884D
#define ES2_TEXTURE_BORDER_COLOR 0x1004

static unsigned long long timing_now(void);
static void fill_test_before_draw(void);
static int skip_this_draw(void);
static void draw_class_note(unsigned long long start, unsigned long vertices, GLenum mode, int elements);
#ifdef HALO_ANDROID_ARMV7
/* (debug.frame_timing: the draws, vertices, draw time and program changes of
each frame phase, on the thread that makes the driver's calls; the phase is
the last halo_gpu_phase mark made there) */
static int es2_phase_now = -1;
static unsigned long es2_phase_frames;
static struct
{
	unsigned long draws, programs, unchanged, uniforms_only;
	unsigned long long vertices, nanoseconds;
} es2_phase_draws[64];

/* (glq.c: 0 nothing but buffers and pointers changed since the draw before,
1 only uniforms, 2 other state) */
void gl_es2_note_draw_change(int change)
{
	if (es2_phase_now < 0 || es2_phase_now >= 64)
		return;
	if (change == 0)
		es2_phase_draws[es2_phase_now].unchanged++;
	else if (change == 1)
		es2_phase_draws[es2_phase_now].uniforms_only++;
}
#endif
static void kick_after_draw(void);

/* ---------- the real entry points this file calls */

typedef void (GL_APIENTRY *bind_texture_function)(GLenum, GLuint);
typedef void (GL_APIENTRY *active_texture_function)(GLenum);
typedef void (GL_APIENTRY *tex_parameteri_function)(GLenum, GLenum, GLint);
typedef void (GL_APIENTRY *tex_parameterf_function)(GLenum, GLenum, GLfloat);
typedef void (GL_APIENTRY *tex_parameterfv_function)(GLenum, GLenum, const GLfloat *);
typedef void (GL_APIENTRY *tex_image_2d_function)(GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum,
	const void *);
typedef void (GL_APIENTRY *tex_sub_image_2d_function)(GLenum, GLint, GLint, GLint, GLsizei, GLsizei, GLenum, GLenum,
	const void *);
typedef void (GL_APIENTRY *compressed_tex_image_2d_function)(GLenum, GLint, GLenum, GLsizei, GLsizei, GLint, GLsizei,
	const void *);
typedef void (GL_APIENTRY *delete_textures_function)(GLsizei, const GLuint *);
typedef void (GL_APIENTRY *framebuffer_texture_2d_function)(GLenum, GLenum, GLenum, GLuint, GLint);
typedef void (GL_APIENTRY *framebuffer_renderbuffer_function)(GLenum, GLenum, GLenum, GLuint);
typedef void (GL_APIENTRY *vertex_attrib_pointer_function)(GLuint, GLint, GLenum, GLboolean, GLsizei, const void *);
typedef void (GL_APIENTRY *vertex_attrib_4f_function)(GLuint, GLfloat, GLfloat, GLfloat, GLfloat);
typedef void (GL_APIENTRY *draw_elements_function)(GLenum, GLsizei, GLenum, const void *);
typedef void (GL_APIENTRY *renderbuffer_storage_multisample_function)(GLenum, GLsizei, GLenum, GLsizei, GLsizei);

static struct
{
	bind_texture_function bind_texture;
	active_texture_function active_texture;
	tex_parameteri_function tex_parameteri;
	tex_parameterf_function tex_parameterf;
	tex_parameterfv_function tex_parameterfv;
	tex_image_2d_function tex_image_2d;
	tex_sub_image_2d_function tex_sub_image_2d;
	compressed_tex_image_2d_function compressed_tex_image_2d;
	delete_textures_function delete_textures;
	framebuffer_texture_2d_function framebuffer_texture_2d;
	framebuffer_renderbuffer_function framebuffer_renderbuffer;
	vertex_attrib_pointer_function vertex_attrib_pointer;
	vertex_attrib_4f_function vertex_attrib_4f;
	draw_elements_function draw_elements;
	renderbuffer_storage_multisample_function renderbuffer_storage_multisample;
} real;

static void *proc(const char *name)
{
	return SDL_GL_GetProcAddress(name);
}

/* ---------- textures: the state ES 2.0 has no place for */

struct texture_state
{
	/* the sampler state last set on it (sampler_state's), and its version */
	unsigned long applied_sampler, applied_version;
	/* its first level's size, and its levels (GL_TEXTURE_MAX_LEVEL + 1) */
	GLsizei width, height;
	int levels;
	BOOL cube;
	/* its chain was completed past its last level (texture_chain_complete) */
	BOOL completed;
	/* the parameters set on it, so that only a changed one is set again (a
	parameter set is the texture validated again at the next draw) */
	BOOL parameters_known;
	GLint minify, magnify, wrap_s, wrap_t, compare_mode, compare_function;
	GLfloat anisotropy;
	GLfloat border[4];
	/* its first level's format, as the driver was given it (1 in compressed:
	S3TC), for debug.stutter_log's slow draws */
	GLenum format, type;
	unsigned char compressed;
};

static struct texture_state *textures;
static unsigned long texture_capacity;

static struct texture_state *texture_state(GLuint texture)
{
	if (!texture)
		return NULL;
	if (texture >= texture_capacity)
	{
		unsigned long capacity = texture_capacity ? texture_capacity : 1024;
		struct texture_state *grown;

		while (texture >= capacity)
			capacity *= 2;
		grown = realloc(textures, capacity * sizeof(*textures));
		if (!grown)
			return NULL;
		memset(grown + texture_capacity, 0, (capacity - texture_capacity) * sizeof(*textures));
		textures = grown;
		texture_capacity = capacity;
	}
	return &textures[texture];
}

/* the units' bindings (GL_TEXTURE_2D and GL_TEXTURE_CUBE_MAP), the active
unit, and each unit's sampler */
#define UNITS 16

static GLuint unit_texture[UNITS][2];
static GLuint unit_sampler[UNITS];
static unsigned long active_unit;

static int target_slot(GLenum target)
{
	/* (a cube map's faces are its own: GL_TEXTURE_CUBE_MAP_POSITIVE_X on) */
	return target == GL_TEXTURE_CUBE_MAP ||
		(target >= GL_TEXTURE_CUBE_MAP_POSITIVE_X && target <= GL_TEXTURE_CUBE_MAP_NEGATIVE_Z) ? 1 : 0;
}

/* ---------- sampler objects */

struct sampler_state
{
	BOOL used;
	unsigned long version;
	GLint minify, magnify, wrap_s, wrap_t, compare_mode, compare_function;
	GLfloat anisotropy;
	GLfloat border[4];
};

/* (as many as d3d8_gl.c's sampler cache makes, 3/4 of its 512, with the
stages', the post-processing's and glq.c's names made ahead) */
#define SAMPLERS 512

static struct sampler_state samplers[SAMPLERS];
static BOOL anisotropy_available, border_clamp_available, shadow_available;

/* a mipmapped minification filter as its unmipmapped one */
static GLint without_mipmaps(GLint filter)
{
	switch (filter)
	{
	case GL_NEAREST_MIPMAP_NEAREST:
	case GL_NEAREST_MIPMAP_LINEAR:
		return GL_NEAREST;
	case GL_LINEAR_MIPMAP_NEAREST:
	case GL_LINEAR_MIPMAP_LINEAR:
		return GL_LINEAR;
	default:
		return filter;
	}
}

/* the levels a full chain of a texture of this size has */
static int full_chain(GLsizei width, GLsizei height)
{
	GLsizei side = width > height ? width : height;
	int levels = 1;

	while (side > 1)
	{
		side >>= 1;
		levels++;
	}
	return levels;
}

/* a sampler's state set on the texture bound to the active unit at target */
static void sampler_apply(GLenum target, GLuint texture, GLuint sampler)
{
	struct texture_state *state = texture_state(texture);
	struct sampler_state *values;
	GLint minify;

	if (!state || !sampler || sampler >= SAMPLERS || !samplers[sampler].used)
		return;
	values = &samplers[sampler];
	if (state->applied_sampler == sampler && state->applied_version == values->version)
		return;
	state->applied_sampler = sampler;
	state->applied_version = values->version;
	minify = values->minify;
	/* (a texture without its full chain of levels is incomplete to ES 2.0
	when sampled with mipmaps, and is drawn black: one level is all of it
	that is sampled then) */
	if (state->levels && state->width && state->levels < full_chain(state->width, state->height) && !state->completed)
		minify = without_mipmaps(minify);
#define SET_IF_CHANGED(field, value, call) \
	if (!state->parameters_known || state->field != (value)) \
	{ \
		state->field = (value); \
		call; \
		gl_es2_frame.texture_parameters++; \
	}
	SET_IF_CHANGED(minify, minify, real.tex_parameteri(target, GL_TEXTURE_MIN_FILTER, minify))
	SET_IF_CHANGED(magnify, values->magnify, real.tex_parameteri(target, GL_TEXTURE_MAG_FILTER, values->magnify))
	SET_IF_CHANGED(wrap_s, values->wrap_s, real.tex_parameteri(target, GL_TEXTURE_WRAP_S, values->wrap_s))
	SET_IF_CHANGED(wrap_t, values->wrap_t, real.tex_parameteri(target, GL_TEXTURE_WRAP_T, values->wrap_t))
	if (anisotropy_available)
		SET_IF_CHANGED(anisotropy, values->anisotropy, real.tex_parameterf(target, ES2_TEXTURE_MAX_ANISOTROPY, values->anisotropy))
	/* (a border only matters to a border clamp) */
	if (border_clamp_available && (values->wrap_s == 0x812D || values->wrap_t == 0x812D) &&
		(!state->parameters_known || memcmp(state->border, values->border, sizeof(state->border))))
	{
		memcpy(state->border, values->border, sizeof(state->border));
		real.tex_parameterfv(target, ES2_TEXTURE_BORDER_COLOR, values->border);
		gl_es2_frame.texture_parameters++;
	}
	if (shadow_available && target == GL_TEXTURE_2D)
	{
		SET_IF_CHANGED(compare_mode, values->compare_mode, real.tex_parameteri(target, ES2_TEXTURE_COMPARE_MODE, values->compare_mode))
		SET_IF_CHANGED(compare_function, values->compare_function,
			real.tex_parameteri(target, ES2_TEXTURE_COMPARE_FUNC, values->compare_function))
	}
#undef SET_IF_CHANGED
	state->parameters_known = TRUE;
}

/* a unit's sampler set on its textures (the unit made active, and put back) */
static void unit_apply(unsigned long unit)
{
	int slot;

	if (unit >= UNITS || !unit_sampler[unit])
		return;
	if (unit != active_unit)
		real.active_texture(GL_TEXTURE0 + (GLenum)unit);
	for (slot = 0; slot < 2; slot++)
	{
		if (unit_texture[unit][slot])
			sampler_apply(slot ? GL_TEXTURE_CUBE_MAP : GL_TEXTURE_2D, unit_texture[unit][slot], unit_sampler[unit]);
	}
	if (unit != active_unit)
		real.active_texture(GL_TEXTURE0 + (GLenum)active_unit);
}

static void GL_APIENTRY es2_gen_samplers(GLsizei count, GLuint *names)
{
	GLsizei index;
	GLuint sampler = 1;

	for (index = 0; index < count; index++)
	{
		while (sampler < SAMPLERS && samplers[sampler].used)
			sampler++;
		if (sampler >= SAMPLERS)
		{
			names[index] = 0;
			continue;
		}
		memset(&samplers[sampler], 0, sizeof(samplers[sampler]));
		samplers[sampler].used = TRUE;
		samplers[sampler].version = 1;
		samplers[sampler].minify = GL_NEAREST_MIPMAP_LINEAR;
		samplers[sampler].magnify = GL_LINEAR;
		samplers[sampler].wrap_s = GL_REPEAT;
		samplers[sampler].wrap_t = GL_REPEAT;
		samplers[sampler].compare_mode = GL_NONE;
		samplers[sampler].compare_function = GL_LEQUAL;
		samplers[sampler].anisotropy = 1.0f;
		names[index] = sampler;
	}
}

static void GL_APIENTRY es2_bind_sampler(GLuint unit, GLuint sampler)
{
	if (unit >= UNITS)
		return;
	unit_sampler[unit] = sampler;
	unit_apply(unit);
}

/* the units that use a sampler, given its changed state */
static void sampler_changed(GLuint sampler)
{
	unsigned long unit;

	samplers[sampler].version++;
	for (unit = 0; unit < UNITS; unit++)
	{
		if (unit_sampler[unit] == sampler)
			unit_apply(unit);
	}
}

static void GL_APIENTRY es2_sampler_parameteri(GLuint sampler, GLenum name, GLint value)
{
	struct sampler_state *state;

	if (!sampler || sampler >= SAMPLERS || !samplers[sampler].used)
		return;
	state = &samplers[sampler];
	switch (name)
	{
	case GL_TEXTURE_MIN_FILTER: state->minify = value; break;
	case GL_TEXTURE_MAG_FILTER: state->magnify = value; break;
	case GL_TEXTURE_WRAP_S: state->wrap_s = value; break;
	case GL_TEXTURE_WRAP_T: state->wrap_t = value; break;
	case ES2_TEXTURE_COMPARE_MODE: state->compare_mode = value; break;
	case ES2_TEXTURE_COMPARE_FUNC: state->compare_function = value; break;
	case ES2_TEXTURE_MAX_ANISOTROPY: state->anisotropy = (GLfloat)value; break;
	default: return;
	}
	sampler_changed(sampler);
}

static void GL_APIENTRY es2_sampler_parameterf(GLuint sampler, GLenum name, GLfloat value)
{
	if (name == ES2_TEXTURE_MAX_ANISOTROPY)
	{
		if (!sampler || sampler >= SAMPLERS || !samplers[sampler].used)
			return;
		samplers[sampler].anisotropy = value;
		sampler_changed(sampler);
		return;
	}
	es2_sampler_parameteri(sampler, name, (GLint)value);
}

static void GL_APIENTRY es2_sampler_parameterfv(GLuint sampler, GLenum name, const GLfloat *values)
{
	if (name == ES2_TEXTURE_BORDER_COLOR)
	{
		if (!sampler || sampler >= SAMPLERS || !samplers[sampler].used)
			return;
		memcpy(samplers[sampler].border, values, sizeof(samplers[sampler].border));
		sampler_changed(sampler);
		return;
	}
	es2_sampler_parameterf(sampler, name, values[0]);
}

/* ---------- textures */

static GLenum es2_target(GLenum target)
{
	return target == ES2_TEXTURE_3D ? GL_TEXTURE_2D : target;
}

static void GL_APIENTRY es2_active_texture(GLenum unit)
{
	active_unit = unit - GL_TEXTURE0;
	real.active_texture(unit);
}

static void GL_APIENTRY es2_bind_texture_untimed(GLenum target, GLuint texture);

static void GL_APIENTRY es2_bind_texture(GLenum target, GLuint texture)
{
	unsigned long long start = gl_es2_frame_timing ? timing_now() : 0;

	es2_bind_texture_untimed(target, texture);
	if (start)
		gl_es2_frame.texture_nanoseconds += timing_now() - start;
}

static void GL_APIENTRY es2_bind_texture_untimed(GLenum target, GLuint texture)
{
	struct texture_state *state;

	target = es2_target(target);
	real.bind_texture(target, texture);
	if (active_unit < UNITS)
	{
		unit_texture[active_unit][target_slot(target)] = texture;
		state = texture_state(texture);
		if (state && target == GL_TEXTURE_CUBE_MAP)
			state->cube = TRUE;
		if (unit_sampler[active_unit])
			sampler_apply(target, texture, unit_sampler[active_unit]);
	}
}

/* the texture bound to the active unit at target */
static struct texture_state *bound_state(GLenum target)
{
	return active_unit < UNITS ? texture_state(unit_texture[active_unit][target_slot(es2_target(target))]) : NULL;
}

static void GL_APIENTRY es2_tex_parameteri(GLenum target, GLenum name, GLint value)
{
	struct texture_state *state;

	target = es2_target(target);
	switch (name)
	{
	case GL_TEXTURE_MAX_LEVEL:
		/* (ES 2.0 has none: kept, for the sampling of a short chain) */
		state = bound_state(target);
		if (state)
		{
			state->levels = value + 1;
			state->applied_sampler = 0;
		}
		return;
	case GL_TEXTURE_BASE_LEVEL:
	case GL_TEXTURE_MIN_LOD:
	case GL_TEXTURE_MAX_LOD:
	case GL_TEXTURE_SWIZZLE_R:
	case GL_TEXTURE_SWIZZLE_G:
	case GL_TEXTURE_SWIZZLE_B:
	case GL_TEXTURE_SWIZZLE_A:
	case ES2_TEXTURE_WRAP_R:
		return;
	default:
		/* (a parameter set otherwise than through a sampler: the cache
		above no longer knows the texture's) */
		state = bound_state(target);
		if (state)
		{
			state->parameters_known = FALSE;
			state->applied_sampler = 0;
		}
		real.tex_parameteri(target, name, value);
		return;
	}
}

static void GL_APIENTRY es2_tex_parameterf(GLenum target, GLenum name, GLfloat value)
{
	switch (name)
	{
	case GL_TEXTURE_MAX_LEVEL:
	case GL_TEXTURE_BASE_LEVEL:
	case GL_TEXTURE_MIN_LOD:
	case GL_TEXTURE_MAX_LOD:
	case ES2_TEXTURE_WRAP_R:
		es2_tex_parameteri(target, name, (GLint)value);
		return;
	default:
		real.tex_parameterf(es2_target(target), name, value);
		return;
	}
}

/* ES 3.0's sized format and its data's format and type as ES 2.0's */
static void es2_format(GLint *internal_format, GLenum *format, GLenum *type)
{
	switch (*internal_format)
	{
	case GL_RGBA8:
		*internal_format = *format == ES2_BGRA_EXT ? ES2_BGRA_EXT : GL_RGBA;
		break;
	case GL_RGB8:
		*internal_format = GL_RGB;
		break;
	case GL_R8:
		*internal_format = ES2_RED_EXT;
		*format = ES2_RED_EXT;
		break;
	case GL_RG8:
		*internal_format = ES2_RG_EXT;
		*format = ES2_RG_EXT;
		break;
	case GL_RGBA16F:
		*internal_format = GL_RGBA;
		*type = ES2_HALF_FLOAT_OES;
		break;
	case GL_DEPTH24_STENCIL8:
	case GL_DEPTH_COMPONENT24:
	case GL_DEPTH_COMPONENT32F:
		/* (no packed depth and stencil: depth alone, OES_depth_texture) */
		*internal_format = GL_DEPTH_COMPONENT;
		*format = GL_DEPTH_COMPONENT;
		*type = GL_UNSIGNED_INT;
		break;
	default:
		break;
	}
	if (*type == GL_HALF_FLOAT)
		*type = ES2_HALF_FLOAT_OES;
}

static void texture_size_note(GLenum target, GLint level, GLsizei width, GLsizei height)
{
	struct texture_state *state = bound_state(target);

	if (state && level == 0)
	{
		state->width = width;
		state->height = height;
		state->completed = FALSE;
		state->applied_sampler = 0;
	}
}

static void texture_format_note(GLenum target, GLint level, GLenum format, GLenum type, int compressed)
{
	struct texture_state *state = bound_state(target);

	if (state && level == 0)
	{
		state->format = format;
		state->type = type;
		state->compressed = (unsigned char)compressed;
	}
}

unsigned long gl_es2_bound_texture_layout(struct gl_draw_layout *layout)
{
	unsigned long hash = 2166136261UL;
	int unit, slot;

	for (unit = 0; unit < 8; unit++)
	{
		for (slot = 0; slot < 2; slot++)
		{
			int at = unit * 2 + slot;
			GLuint name = unit_texture[unit][slot];
			struct texture_state *state = texture_state(name);
			unsigned long values[9];
			int index;

			layout->texture_bound[at] = 0;
			if (!name || !state || !state->format)
				continue;
			layout->texture_bound[at] = 1;
			layout->texture_format[at] = (unsigned short)state->format;
			layout->texture_type[at] = (unsigned short)state->type;
			layout->texture_compressed[at] = state->compressed;
			layout->texture_known[at] = (unsigned char)(state->parameters_known != 0);
			layout->texture_minify[at] = (unsigned short)(state->parameters_known ? state->minify : 0);
			layout->texture_magnify[at] = (unsigned short)(state->parameters_known ? state->magnify : 0);
			layout->texture_wrap_s[at] = (unsigned short)(state->parameters_known ? state->wrap_s : 0);
			layout->texture_wrap_t[at] = (unsigned short)(state->parameters_known ? state->wrap_t : 0);
			layout->texture_compare[at] = (unsigned char)(state->parameters_known && state->compare_mode ? 1 : 0);
			values[0] = (unsigned long)at + 1;
			values[1] = layout->texture_format[at];
			values[2] = layout->texture_type[at];
			values[3] = layout->texture_compressed[at];
			values[4] = layout->texture_minify[at];
			values[5] = layout->texture_magnify[at];
			values[6] = layout->texture_wrap_s[at];
			values[7] = layout->texture_wrap_t[at];
			values[8] = layout->texture_compare[at];
			for (index = 0; index < 9; index++)
				hash = (hash ^ values[index]) * 16777619UL;
		}
	}
	return hash ? hash : 1;
}

/* (debug.stutter_log, on the GL thread) the textures bound on units 0-7 as
text (name, format, size, filter, wrap, compare), and a hash of what the
driver could key a program's variant on (format, compare, cube, filter,
wrap; not the name or size) */
unsigned long gl_es2_bound_textures(char *text, size_t size)
{
	unsigned long hash = 2166136261UL;
	size_t length = 0;
	int unit, slot;

	if (size)
		text[0] = 0;
	for (unit = 0; unit < 8; unit++)
	{
		for (slot = 0; slot < 2; slot++)
		{
			GLuint name = unit_texture[unit][slot];
			struct texture_state *state = texture_state(name);
			unsigned long values[7];
			int index;

			if (!name || !state)
				continue;
			values[0] = (unsigned long)unit * 2 + (unsigned long)slot;
			values[1] = state->format;
			values[2] = state->compressed;
			values[3] = state->parameters_known ? (unsigned long)state->compare_mode : 0xffff;
			values[4] = state->parameters_known ? (unsigned long)state->minify : 0xffff;
			values[5] = state->parameters_known ? (unsigned long)state->wrap_s : 0xffff;
			values[6] = state->parameters_known ? (unsigned long)state->wrap_t : 0xffff;
			for (index = 0; index < 7; index++)
				hash = (hash ^ values[index]) * 16777619UL;
			if (length + 96 < size)
			{
				length += (size_t)snprintf(text + length, size - length, "%s%d%s:%u 0x%x%s %dx%d",
					length ? " " : "", unit, slot ? "cube" : "", name, (unsigned)state->format,
					state->compressed ? "c" : "", (int)state->width, (int)state->height);
				if (state->parameters_known)
					length += (size_t)snprintf(text + length, size - length, " f%x w%x/%x%s", (unsigned)state->minify,
						(unsigned)state->wrap_s, (unsigned)state->wrap_t, state->compare_mode ? " cmp" : "");
			}
		}
	}
	return hash;
}

/* the bytes of a texel of an uncompressed format, or 0 */
static int texel_bytes(GLenum format, GLenum type)
{
	int channels;

	switch (format)
	{
	case GL_RGBA: case ES2_BGRA_EXT: channels = 4; break;
	case GL_RGB: channels = 3; break;
	case GL_LUMINANCE_ALPHA: case ES2_RG_EXT: channels = 2; break;
	case GL_LUMINANCE: case GL_ALPHA: case ES2_RED_EXT: channels = 1; break;
	default: return 0;
	}
	switch (type)
	{
	case GL_UNSIGNED_BYTE: return channels;
	case ES2_HALF_FLOAT_OES: return channels * 2;
	case GL_UNSIGNED_SHORT_5_6_5: case GL_UNSIGNED_SHORT_4_4_4_4: case GL_UNSIGNED_SHORT_5_5_5_1: return 2;
	default: return 0;
	}
}

/* a texture whose levels stop short of 1x1 (the Xbox's bitmaps often do:
GL_TEXTURE_MAX_LEVEL, which ES 2.0 lacks, said where) is incomplete to
ES 2.0 with mipmaps, and was sampled without them: a shimmer of single
texels in the distance, and slow. Its last level given, the levels below
it are given too, each made from the one above it (below) */
static void texture_chain_complete(GLenum target, GLint level, GLsizei width, GLsizei height, int compressed,
	GLenum internal_format, GLenum format, GLenum type, const void *data)
{
	struct texture_state *state = bound_state(target);
	int full, block = 0, bytes;
	unsigned char *previous, *next;
	GLsizei previous_width, previous_height;
	size_t size;

	if (!state || !data || !state->levels || level != state->levels - 1 || !state->width)
		return;
	full = full_chain(state->width, state->height);
	if (state->levels >= full)
		return;
	if (compressed)
	{
		/* (DXT1 and ETC1: 8 bytes a block; DXT3 and DXT5, and the rest, 16) */
		block = internal_format == 0x83F0 || internal_format == 0x83F1 || internal_format == 0x8D64 ? 8 : 16;
		bytes = block;
	}
	else
	{
		bytes = texel_bytes(format, type);
		if (!bytes)
			return;
	}
	/* (each level below made from the one above it: every other texel, or
	every other 4x4 block, of it, the nearest. The Xbox sampled such a
	texture's last level at any distance (its maximum level); a level of one
	texel's colour, as these were before, turned the alpha-tested leaves of
	b30's trees (DXT3, 2 or 3 levels of 9) to nothing past a few metres: the
	first block of the leaves' sheet is clear) */
	/* (rows of uncompressed texels at GL_UNPACK_ALIGNMENT's 4) */
#define CHAIN_ROW(texels) (compressed ? (size_t)(texels) * (size_t)bytes : ((size_t)(texels) * (size_t)bytes + 3) & ~(size_t)3)
	size = compressed ? CHAIN_ROW((width + 3) / 4) * (size_t)((height + 3) / 4) : CHAIN_ROW(width) * (size_t)height;
	previous = (unsigned char *)malloc(size);
	next = (unsigned char *)malloc(size);
	if (!previous || !next)
	{
		free(previous);
		free(next);
		return;
	}
	memcpy(previous, data, size);
	previous_width = width;
	previous_height = height;
	while (++level < full)
	{
		GLsizei x, y, across, down, previous_across, previous_down, count;
		unsigned char *swap;

		width = width > 1 ? width / 2 : 1;
		height = height > 1 ? height / 2 : 1;
		if (compressed)
		{
			across = (width + 3) / 4;
			down = (height + 3) / 4;
			previous_across = (previous_width + 3) / 4;
			previous_down = (previous_height + 3) / 4;
		}
		else
		{
			across = width;
			down = height;
			previous_across = previous_width;
			previous_down = previous_height;
		}
		for (y = 0; y < down; y++)
		{
			GLsizei from_y = y * 2 < previous_down ? y * 2 : previous_down - 1;

			for (x = 0; x < across; x++)
			{
				GLsizei from_x = x * 2 < previous_across ? x * 2 : previous_across - 1;

				memcpy(next + (size_t)y * CHAIN_ROW(across) + (size_t)x * (size_t)bytes,
					previous + (size_t)from_y * CHAIN_ROW(previous_across) + (size_t)from_x * (size_t)bytes, (size_t)bytes);
			}
		}
		count = across * down;
		if (compressed)
			real.compressed_tex_image_2d(target, level, internal_format, width, height, 0, count * bytes, next);
		else
			real.tex_image_2d(target, level, (GLint)internal_format, width, height, 0, format, type, next);
		swap = previous;
		previous = next;
		next = swap;
		previous_width = width;
		previous_height = height;
	}
#undef CHAIN_ROW
	free(previous);
	free(next);
	state->completed = TRUE;
	state->applied_sampler = 0;
}

static void GL_APIENTRY es2_tex_image_2d(GLenum target, GLint level, GLint internal_format, GLsizei width,
	GLsizei height, GLint border, GLenum format, GLenum type, const void *data)
{
	es2_format(&internal_format, &format, &type);
	texture_size_note(target, level, width, height);
	texture_format_note(target, level, (GLenum)internal_format, type, 0);
	if (data)
		gl_es2_frame.texture_bytes += (unsigned long)width * (unsigned long)height * 4;
	real.tex_image_2d(es2_target(target), level, internal_format, width, height, border, format, type, data);
	texture_chain_complete(es2_target(target), level, width, height, 0, (GLenum)internal_format, format, type, data);
}

static void GL_APIENTRY es2_tex_sub_image_2d(GLenum target, GLint level, GLint x, GLint y, GLsizei width,
	GLsizei height, GLenum format, GLenum type, const void *data)
{
	if (type == GL_HALF_FLOAT)
		type = ES2_HALF_FLOAT_OES;
	gl_es2_frame.texture_bytes += (unsigned long)width * (unsigned long)height * 4;
	real.tex_sub_image_2d(es2_target(target), level, x, y, width, height, format, type, data);
}

static void GL_APIENTRY es2_compressed_tex_image_2d(GLenum target, GLint level, GLenum internal_format,
	GLsizei width, GLsizei height, GLint border, GLsizei size, const void *data)
{
	texture_size_note(target, level, width, height);
	texture_format_note(target, level, internal_format, 0, 1);
	gl_es2_frame.texture_bytes += (unsigned long)size;
	real.compressed_tex_image_2d(es2_target(target), level, internal_format, width, height, border, size, data);
	texture_chain_complete(es2_target(target), level, width, height, 1, internal_format, 0, 0, data);
}

/* a 3D texture as its first slice */
static void GL_APIENTRY es2_tex_image_3d(GLenum target, GLint level, GLint internal_format, GLsizei width,
	GLsizei height, GLsizei depth, GLint border, GLenum format, GLenum type, const void *data)
{
	(void)depth;
	es2_tex_image_2d(es2_target(target), level, internal_format, width, height, border, format, type, data);
}

static void GL_APIENTRY es2_compressed_tex_image_3d(GLenum target, GLint level, GLenum internal_format,
	GLsizei width, GLsizei height, GLsizei depth, GLint border, GLsizei size, const void *data)
{
	es2_compressed_tex_image_2d(es2_target(target), level, internal_format, width, height, border,
		depth > 0 ? size / depth : size, data);
}

static void GL_APIENTRY es2_delete_textures(GLsizei count, const GLuint *names)
{
	GLsizei index;
	unsigned long unit;

	for (index = 0; index < count; index++)
	{
		struct texture_state *state = names[index] < texture_capacity ? &textures[names[index]] : NULL;

		if (state)
			memset(state, 0, sizeof(*state));
		for (unit = 0; unit < UNITS; unit++)
		{
			if (unit_texture[unit][0] == names[index])
				unit_texture[unit][0] = 0;
			if (unit_texture[unit][1] == names[index])
				unit_texture[unit][1] = 0;
		}
	}
	real.delete_textures(count, names);
}

/* ---------- framebuffers */

static void GL_APIENTRY es2_framebuffer_texture_2d(GLenum target, GLenum attachment, GLenum texture_target,
	GLuint texture, GLint level)
{
	if (target == GL_DRAW_FRAMEBUFFER || target == GL_READ_FRAMEBUFFER)
		target = GL_FRAMEBUFFER;
	if (attachment == GL_DEPTH_STENCIL_ATTACHMENT)
		attachment = GL_DEPTH_ATTACHMENT;
	real.framebuffer_texture_2d(target, attachment, texture_target, texture, level);
}

static void GL_APIENTRY es2_framebuffer_renderbuffer(GLenum target, GLenum attachment, GLenum renderbuffer_target,
	GLuint renderbuffer)
{
	if (target == GL_DRAW_FRAMEBUFFER || target == GL_READ_FRAMEBUFFER)
		target = GL_FRAMEBUFFER;
	if (attachment == GL_DEPTH_STENCIL_ATTACHMENT)
		attachment = GL_DEPTH_ATTACHMENT;
	real.framebuffer_renderbuffer(target, attachment, renderbuffer_target, renderbuffer);
}

static void GL_APIENTRY es2_renderbuffer_storage_multisample(GLenum target, GLsizei samples, GLenum format,
	GLsizei width, GLsizei height)
{
	if (format == GL_DEPTH24_STENCIL8)
		format = ES2_DEPTH_COMPONENT24_OES;
	if (real.renderbuffer_storage_multisample)
		real.renderbuffer_storage_multisample(target, samples, format, width, height);
}

/* ---------- vertices */

/* an Xbox packed normal (one unsigned integer) as its four bytes */
static void GL_APIENTRY es2_vertex_attrib_i_pointer(GLuint index, GLint size, GLenum type, GLsizei stride,
	const void *pointer)
{
	if (size == 1 && (type == GL_UNSIGNED_INT || type == GL_INT))
		real.vertex_attrib_pointer(index, 4, GL_UNSIGNED_BYTE, GL_FALSE, stride, pointer);
	else
		real.vertex_attrib_pointer(index, size, type, GL_FALSE, stride, pointer);
}

static void GL_APIENTRY es2_vertex_attrib_i_4ui(GLuint index, GLuint x, GLuint y, GLuint z, GLuint w)
{
	(void)y;
	(void)z;
	(void)w;
	if (real.vertex_attrib_4f)
	{
		real.vertex_attrib_4f(index, (GLfloat)(x & 0xff), (GLfloat)((x >> 8) & 0xff), (GLfloat)((x >> 16) & 0xff),
			(GLfloat)(x >> 24));
	}
}

/* (32-bit indices, which ES 2.0 has only with OES_element_index_uint, which
the Tegra 4 lacks: a quad list from past the first 65536 vertices is not
drawn) */
static void GL_APIENTRY es2_draw_elements(GLenum mode, GLsizei count, GLenum type, const void *indices)
{
	if (type == GL_UNSIGNED_INT)
	{
		static int logged;

		if (logged < 3)
		{
			logged++;
			platform_log("OpenGL ES 2.0: a draw of %d 32-bit indices is not drawn", (int)count);
		}
		return;
	}
	{
		unsigned long long start = gl_es2_frame_timing ? timing_now() : 0;

		if (start && !gl_es2_frame.first_draw)
			gl_es2_frame.first_draw = start;
		if (skip_this_draw())
			return;
		fill_test_before_draw();
		real.draw_elements(mode, count, type, indices);
		draw_class_note(start, (unsigned long)count, mode, 1);
		kick_after_draw();
		gl_es2_frame.draws++;
		gl_es2_frame.vertices += (unsigned long)count;
		if (start)
			gl_es2_frame.draw_nanoseconds += timing_now() - start;
	}
}

/* ---------- what ES 2.0 has no counterpart of */

static void GL_APIENTRY es2_memory_barrier(GLbitfield barriers)
{
	(void)barriers;
}

static void GL_APIENTRY es2_bind_buffer_base(GLenum target, GLuint index, GLuint buffer)
{
	(void)target;
	(void)index;
	(void)buffer;
}

static void GL_APIENTRY es2_bind_buffer_range(GLenum target, GLuint index, GLuint buffer, GLintptr offset,
	GLsizeiptr size)
{
	(void)target;
	(void)index;
	(void)buffer;
	(void)offset;
	(void)size;
}

static void GL_APIENTRY es2_invalidate_framebuffer(GLenum target, GLsizei count, const GLenum *attachments)
{
	(void)target;
	(void)count;
	(void)attachments;
}

static void GL_APIENTRY es2_get_internalformativ(GLenum target, GLenum format, GLenum name, GLsizei count,
	GLint *values)
{
	(void)target;
	(void)format;
	(void)name;
	if (count > 0 && values)
		values[0] = 0;
}

/* ---------- the frame's work (debug.frame_timing, d3d8_gl.c's report)

What a frame asks of the driver, counted as it is asked: draws, and the time
the processor spends in them (the driver's validation and the copy of their
indices); vertex and pixel shader constants; vertices, indices and textures
sent. */

struct gl_es2_frame_statistics gl_es2_frame;
int gl_es2_frame_timing;
/* debug.gpu_fill_test (d3d8_gl.c reads it): each draw scissored to one
pixel, its vertices shaded but next to none of its pixels, to tell a GPU
that shades too few pixels in time from a driver slow on the processor */
int gl_es2_fill_test;
int gl_es2_skip_unaligned, gl_es2_next_draw_unaligned;

/* whether this draw is left undrawn (debug.skip_unaligned_draws) */
/* whether the next draw has an attribute not aligned for four, as the
thread that makes the draws sees it: set by d3d8_gl.c's setup_streams through
gl_es2_note_draw_unaligned (with debug.gl_queue, in its place among the
queued calls, so the GL thread reads it with the draw it belongs to), taken
by the draw */
static int draw_unaligned;

int glq_call_name(void (*function)(const char *), const char *name);

static void es2_set_draw_unaligned(const char *value)
{
	draw_unaligned = value != NULL;
}

void gl_es2_note_draw_unaligned(int unaligned)
{
	if (!gl_es2_frame_timing && !gl_es2_skip_unaligned)
		return;
	if (glq_call_name(es2_set_draw_unaligned, unaligned ? "unaligned" : NULL))
		return;
	draw_unaligned = unaligned;
}

/* (debug.frame_timing: the driver's draws, those with an attribute not
aligned for four apart from the rest: the time, the draws and the vertices
(indices) drawn) */
static struct
{
	unsigned long long nanoseconds[2], vertices[2];
	unsigned long draws[2];
} draw_classes;

static int draw_class_taken;

/* (debug.frame_timing: the next draw's source in d3d8_gl.c, set the same way
as draw_unaligned, and the driver's draws timed by source, primitive and kind,
indexed or not) */
static const char *draw_source, *draw_source_taken;

static void es2_set_draw_source(const char *name)
{
	draw_source = name;
}

void gl_es2_note_draw_source(const char *name)
{
	if (!gl_es2_frame_timing)
		return;
	if (glq_call_name(es2_set_draw_source, name))
		return;
	draw_source = name;
}

#define DRAW_SOURCES 24

static struct
{
	const char *source;
	GLenum mode;
	int elements;
	unsigned long calls;
	unsigned long long vertices, nanoseconds;
} draw_sources[DRAW_SOURCES];

static int skip_this_draw(void)
{
	draw_class_taken = draw_unaligned;
	draw_unaligned = 0;
	draw_source_taken = draw_source;
	draw_source = NULL;
	return gl_es2_skip_unaligned && draw_class_taken;
}

static void draw_class_note(unsigned long long start, unsigned long vertices, GLenum mode, int elements)
{
	unsigned long long took;
	int index;

	if (!start)
		return;
	took = timing_now() - start;
	draw_classes.nanoseconds[draw_class_taken] += took;
	draw_classes.vertices[draw_class_taken] += vertices;
	draw_classes.draws[draw_class_taken]++;
#ifdef HALO_ANDROID_ARMV7
	if (es2_phase_now >= 0 && es2_phase_now < 64)
	{
		es2_phase_draws[es2_phase_now].draws++;
		es2_phase_draws[es2_phase_now].vertices += vertices;
		es2_phase_draws[es2_phase_now].nanoseconds += took;
	}
#endif
	for (index = 0; index < DRAW_SOURCES; index++)
	{
		if (!draw_sources[index].calls || (draw_sources[index].source == draw_source_taken &&
			draw_sources[index].mode == mode && draw_sources[index].elements == elements))
			break;
	}
	if (index == DRAW_SOURCES)
		return;
	draw_sources[index].source = draw_source_taken;
	draw_sources[index].mode = mode;
	draw_sources[index].elements = elements;
	draw_sources[index].calls++;
	draw_sources[index].vertices += vertices;
	draw_sources[index].nanoseconds += took;
}

static const char *draw_mode_name(GLenum mode)
{
	switch (mode)
	{
	case GL_POINTS: return "points";
	case GL_LINES: return "lines";
	case GL_LINE_LOOP: return "line loop";
	case GL_LINE_STRIP: return "line strip";
	case GL_TRIANGLES: return "triangles";
	case GL_TRIANGLE_STRIP: return "strip";
	case GL_TRIANGLE_FAN: return "fan";
	default: return "?";
	}
}

void gl_es2_draw_classes_report(unsigned long frames)
{
	int class;
	char line[2][160];

	if (!frames || !(draw_classes.draws[0] + draw_classes.draws[1]))
		return;
	for (class = 0; class < 2; class++)
	{
		unsigned long draws = draw_classes.draws[class];

		snprintf(line[class], sizeof(line[class]), "%.0f draws, %.0f vertices, %.1f ms a frame (%.0f us a draw, "
			"%.0f ns a vertex)", draws / (double)frames, draw_classes.vertices[class] / (double)frames,
			draw_classes.nanoseconds[class] / (double)frames / 1e6,
			draws ? draw_classes.nanoseconds[class] / (double)draws / 1e3 : 0.0,
			draw_classes.vertices[class] ? draw_classes.nanoseconds[class] / (double)draw_classes.vertices[class] : 0.0);
	}
	platform_log("driver draws: with every attribute aligned for four %s; with one not %s", line[0], line[1]);
	memset(&draw_classes, 0, sizeof(draw_classes));
	{
		char sources[1600];
		int length = 0, shown;
		unsigned char used[DRAW_SOURCES];

		memset(used, 0, sizeof(used));
		for (shown = 0; shown < DRAW_SOURCES && length < (int)sizeof(sources) - 140; shown++)
		{
			int index, best = -1;

			for (index = 0; index < DRAW_SOURCES; index++)
			{
				if (draw_sources[index].calls && !used[index] &&
					(best < 0 || draw_sources[index].nanoseconds > draw_sources[best].nanoseconds))
					best = index;
			}
			if (best < 0)
				break;
			used[best] = 1;
			length += snprintf(sources + length, sizeof(sources) - (size_t)length,
				"%s%s, %s %s: %.1f ms (%.0f calls, %.0f vertices each, %.0f us each)", length ? "; " : "",
				draw_sources[best].source ? draw_sources[best].source : "other",
				draw_mode_name(draw_sources[best].mode), draw_sources[best].elements ? "indexed" : "arrays",
				draw_sources[best].nanoseconds / (double)frames / 1e6, draw_sources[best].calls / (double)frames,
				draw_sources[best].vertices / (double)draw_sources[best].calls,
				draw_sources[best].nanoseconds / (double)draw_sources[best].calls / 1e3);
		}
		platform_log("driver draws by source (a frame): %s", length ? sources : "none");
		memset(draw_sources, 0, sizeof(draw_sources));
	}
}

typedef void (GL_APIENTRY *scissor_function)(GLint, GLint, GLsizei, GLsizei);
typedef void (GL_APIENTRY *enable_function)(GLenum);
static scissor_function real_scissor;
static enable_function real_enable;

static void fill_test_before_draw(void)
{
	if (gl_es2_fill_test && real_scissor && real_enable)
	{
		real_enable(GL_SCISSOR_TEST);
		real_scissor(0, 0, 1, 1);
	}
}

typedef void (GL_APIENTRY *draw_arrays_function)(GLenum, GLint, GLsizei);
typedef void (GL_APIENTRY *uniform_4fv_function)(GLint, GLsizei, const GLfloat *);
typedef void (GL_APIENTRY *buffer_data_function)(GLenum, GLsizeiptr, const void *, GLenum);
typedef void (GL_APIENTRY *buffer_sub_data_function)(GLenum, GLintptr, GLsizeiptr, const void *);
typedef void (GL_APIENTRY *use_program_function)(GLuint);

static draw_arrays_function real_draw_arrays;
static uniform_4fv_function real_uniform_4fv;
static buffer_data_function real_buffer_data;
static buffer_sub_data_function real_buffer_sub_data;
static use_program_function real_use_program;

static unsigned long long timing_now(void)
{
	struct timespec now;

	clock_gettime(CLOCK_MONOTONIC, &now);
	return (unsigned long long)now.tv_sec * 1000000000ULL + (unsigned long long)now.tv_nsec;
}

static void GL_APIENTRY es2_draw_arrays(GLenum mode, GLint first, GLsizei count)
{
	unsigned long long start = gl_es2_frame_timing ? timing_now() : 0;

	if (start && !gl_es2_frame.first_draw)
		gl_es2_frame.first_draw = start;
	if (skip_this_draw())
		return;
	fill_test_before_draw();
	real_draw_arrays(mode, first, count);
	draw_class_note(start, (unsigned long)count, mode, 0);
	kick_after_draw();
	gl_es2_frame.draws++;
	gl_es2_frame.vertices += (unsigned long)count;
	if (start)
		gl_es2_frame.draw_nanoseconds += timing_now() - start;
}

static void GL_APIENTRY es2_uniform_4fv(GLint location, GLsizei count, const GLfloat *values)
{
	unsigned long long start = gl_es2_frame_timing ? timing_now() : 0;

	real_uniform_4fv(location, count, values);
	gl_es2_frame.constants += (unsigned long)count;
	if (start)
		gl_es2_frame.uniform_nanoseconds += timing_now() - start;
}

static void GL_APIENTRY es2_buffer_data(GLenum target, GLsizeiptr size, const void *data, GLenum usage)
{
	real_buffer_data(target, size, data, usage);
	if (data)
		gl_es2_frame.buffer_bytes += (unsigned long)size;
}

static void GL_APIENTRY es2_buffer_sub_data(GLenum target, GLintptr offset, GLsizeiptr size, const void *data)
{
	unsigned long long start = gl_es2_frame_timing ? timing_now() : 0;

	real_buffer_sub_data(target, offset, size, data);
	gl_es2_frame.buffer_bytes += (unsigned long)size;
	if (start)
		gl_es2_frame.upload_nanoseconds += timing_now() - start;
}

static void GL_APIENTRY es2_use_program(GLuint program)
{
	unsigned long long start = gl_es2_frame_timing ? timing_now() : 0;

	real_use_program(program);
	gl_es2_frame.programs++;
#ifdef HALO_ANDROID_ARMV7
	if (start && es2_phase_now >= 0 && es2_phase_now < 64)
		es2_phase_draws[es2_phase_now].programs++;
#endif
	if (start)
		gl_es2_frame.program_nanoseconds += timing_now() - start;
}

typedef void (GL_APIENTRY *vertex_attrib_pointer_timed_function)(GLuint, GLint, GLenum, GLboolean, GLsizei, const void *);
static vertex_attrib_pointer_timed_function real_vertex_attrib_pointer_timed;

static void GL_APIENTRY es2_vertex_attrib_pointer(GLuint index, GLint size, GLenum type, GLboolean normalized,
	GLsizei stride, const void *pointer)
{
	unsigned long long start = gl_es2_frame_timing ? timing_now() : 0;

	real_vertex_attrib_pointer_timed(index, size, type, normalized, stride, pointer);
	if (start)
		gl_es2_frame.attribute_nanoseconds += timing_now() - start;
}

unsigned long long gl_es2_now(void)
{
	return gl_es2_frame_timing ? timing_now() : 0;
}

/* host_gl.c's stream writes (the vertices and indices streamed for each
draw): through the renderer's table like every other call, so that
debug.gl_queue records them in order with the bind before them and the draws
around them. They went to the driver's own glBufferSubData, which with the
queue on wrote at once, into whatever buffer the driver had bound then and
ahead of the queued draws still to read the range: the broken picture. The
table's entry is es2_buffer_sub_data, which counts the bytes and the time. */
void gl_es2_buffer_sub_data(unsigned int target, long offset, long size, const void *data)
{
	halo_glBufferSubData((GLenum)target, (GLintptr)offset, (GLsizeiptr)size, data);
}

/* a render target's pixels into any level of a texture (ES 2.0 attaches
only level 0 to a framebuffer: d3d8_gl.c's mip composites, the water's bump
map's levels): glCopyTexSubImage2D from the target's framebuffer, done where
the queue does it, the bindings it changes put back */
struct level_copy
{
	GLuint framebuffer, texture;
	GLint level;
	GLsizei width, height;
};

static void level_copy_now(const char *argument)
{
	typedef void (GL_APIENTRY *copy_function)(GLenum, GLint, GLint, GLint, GLint, GLint, GLsizei, GLsizei);
	typedef void (GL_APIENTRY *get_integerv_function)(GLenum, GLint *);
	typedef void (GL_APIENTRY *bind_framebuffer_function)(GLenum, GLuint);
	typedef GLenum (GL_APIENTRY *get_error_function)(void);
	static copy_function copy;
	static get_integerv_function get_integerv;
	static bind_framebuffer_function bind_framebuffer;
	static get_error_function get_error;
	static int logged;
	struct level_copy *request = (struct level_copy *)(void *)argument;
	GLint framebuffer = 0, texture = 0;

	if (!copy)
	{
		copy = (copy_function)proc("glCopyTexSubImage2D");
		get_integerv = (get_integerv_function)proc("glGetIntegerv");
		bind_framebuffer = (bind_framebuffer_function)proc("glBindFramebuffer");
		get_error = (get_error_function)proc("glGetError");
	}
	if (copy && get_integerv && bind_framebuffer)
	{
		get_integerv(GL_FRAMEBUFFER_BINDING, &framebuffer);
		get_integerv(GL_TEXTURE_BINDING_2D, &texture);
		bind_framebuffer(GL_FRAMEBUFFER, request->framebuffer);
		real.bind_texture(GL_TEXTURE_2D, request->texture);
		if (get_error && logged < 4)
			while (get_error() != GL_NO_ERROR)
				;
		copy(GL_TEXTURE_2D, request->level, 0, 0, 0, 0, request->width, request->height);
		if (get_error && logged < 4)
		{
			GLenum error = get_error();

			logged++;
			platform_log("OpenGL ES 2.0: a render target copied into level %d (%dx%d) of texture %u: %s (0x%x)",
				(int)request->level, (int)request->width, (int)request->height, (unsigned)request->texture,
				error == GL_NO_ERROR ? "done" : "failed", (unsigned)error);
		}
		real.bind_texture(GL_TEXTURE_2D, (GLuint)texture);
		bind_framebuffer(GL_FRAMEBUFFER, (GLuint)framebuffer);
	}
	free(request);
}

int glq_call_name(void (*function)(const char *), const char *name);

void gl_es2_copy_to_level(unsigned int framebuffer, unsigned int texture, int level, int width, int height)
{
	struct level_copy *request = (struct level_copy *)malloc(sizeof(*request));

	if (!request)
		return;
	request->framebuffer = framebuffer;
	request->texture = texture;
	request->level = level;
	request->width = width;
	request->height = height;
	if (!glq_call_name(level_copy_now, (const char *)(void *)request))
		level_copy_now((const char *)(void *)request);
}

/* (what host_gl.c's stream writes counted before going through the table) */
void gl_es2_count_upload(unsigned long bytes, unsigned long long nanoseconds)
{
	gl_es2_frame.buffer_bytes += bytes;
	gl_es2_frame.upload_nanoseconds += nanoseconds;
}

/* ---------- installation */

/* an extension's entry point in place of the renderer's, where it has one */
#define USE_EXTENSION(name, extension_name) \
	do { \
		void *function = proc(extension_name); \
		if (function) \
			halo_##name = (__typeof__(halo_##name))function; \
		else \
			missing++; \
	} while (0)

int gl_es2_fragment_highp;

void gl_es2_install(void)
{
	const char *extensions = (const char *)halo_glGetString(GL_EXTENSIONS);
	int missing = 0;

	{
		typedef void (GL_APIENTRY *precision_function)(GLenum, GLenum, GLint *, GLint *);
		precision_function precision = (precision_function)proc("glGetShaderPrecisionFormat");
		GLint range[2] = { 0, 0 }, bits = 0;

		if (precision)
			precision(GL_FRAGMENT_SHADER, GL_HIGH_FLOAT, range, &bits);
		gl_es2_fragment_highp = bits > 0;
	}

	extensions = extensions ? extensions : "";
	anisotropy_available = strstr(extensions, "GL_EXT_texture_filter_anisotropic") != NULL;
	border_clamp_available = strstr(extensions, "_texture_border_clamp") != NULL;
	shadow_available = strstr(extensions, "GL_EXT_shadow_samplers") != NULL;

	real.bind_texture = halo_glBindTexture;
	real.active_texture = halo_glActiveTexture;
	real.tex_parameteri = halo_glTexParameteri;
	real.tex_parameterf = halo_glTexParameterf;
	real.tex_parameterfv = (tex_parameterfv_function)proc("glTexParameterfv");
	real.tex_image_2d = halo_glTexImage2D;
	real.tex_sub_image_2d = halo_glTexSubImage2D;
	real.compressed_tex_image_2d = halo_glCompressedTexImage2D;
	real.delete_textures = halo_glDeleteTextures;
	real.framebuffer_texture_2d = halo_glFramebufferTexture2D;
	real.framebuffer_renderbuffer = halo_glFramebufferRenderbuffer;
	real.vertex_attrib_pointer = halo_glVertexAttribPointer;
	real.vertex_attrib_4f = (vertex_attrib_4f_function)proc("glVertexAttrib4f");
	real.draw_elements = halo_glDrawElements;
	real.renderbuffer_storage_multisample =
		(renderbuffer_storage_multisample_function)proc("glRenderbufferStorageMultisampleNV");
	if (!real.tex_parameterfv)
		border_clamp_available = FALSE;

	USE_EXTENSION(glGenVertexArrays, "glGenVertexArraysOES");
	USE_EXTENSION(glBindVertexArray, "glBindVertexArrayOES");
	USE_EXTENSION(glBlitFramebuffer, "glBlitFramebufferNV");
	USE_EXTENSION(glDrawBuffers, "glDrawBuffersNV");
	USE_EXTENSION(glReadBuffer, "glReadBufferNV");
	USE_EXTENSION(glGenQueries, "glGenQueriesEXT");
	USE_EXTENSION(glBeginQuery, "glBeginQueryEXT");
	USE_EXTENSION(glEndQuery, "glEndQueryEXT");
	USE_EXTENSION(glGetQueryObjectuiv, "glGetQueryObjectuivEXT");
	USE_EXTENSION(glCopyBufferSubData, "glCopyBufferSubDataNV");

	halo_glRenderbufferStorageMultisample = es2_renderbuffer_storage_multisample;
	halo_glGenSamplers = es2_gen_samplers;
	halo_glBindSampler = es2_bind_sampler;
	halo_glSamplerParameteri = es2_sampler_parameteri;
	halo_glSamplerParameterf = es2_sampler_parameterf;
	halo_glSamplerParameterfv = es2_sampler_parameterfv;
	halo_glActiveTexture = es2_active_texture;
	halo_glBindTexture = es2_bind_texture;
	halo_glTexParameteri = es2_tex_parameteri;
	halo_glTexParameterf = es2_tex_parameterf;
	halo_glTexImage2D = es2_tex_image_2d;
	halo_glTexSubImage2D = es2_tex_sub_image_2d;
	halo_glCompressedTexImage2D = es2_compressed_tex_image_2d;
	halo_glTexImage3D = es2_tex_image_3d;
	halo_glCompressedTexImage3D = es2_compressed_tex_image_3d;
	halo_glDeleteTextures = es2_delete_textures;
	halo_glFramebufferTexture2D = es2_framebuffer_texture_2d;
	halo_glFramebufferRenderbuffer = es2_framebuffer_renderbuffer;
	halo_glVertexAttribIPointer = es2_vertex_attrib_i_pointer;
	halo_glVertexAttribI4ui = es2_vertex_attrib_i_4ui;
	halo_glDrawElements = es2_draw_elements;
	real_draw_arrays = halo_glDrawArrays;
	halo_glDrawArrays = es2_draw_arrays;
	real_uniform_4fv = halo_glUniform4fv;
	halo_glUniform4fv = es2_uniform_4fv;
	real_buffer_data = halo_glBufferData;
	halo_glBufferData = es2_buffer_data;
	real_buffer_sub_data = halo_glBufferSubData;
	halo_glBufferSubData = es2_buffer_sub_data;
	real_scissor = (scissor_function)proc("glScissor");
	real_enable = (enable_function)proc("glEnable");
	real_use_program = halo_glUseProgram;
	halo_glUseProgram = es2_use_program;
	/* (after the packed normals' own: es2_vertex_attrib_i_pointer calls the
	real one through real.vertex_attrib_pointer) */
	real_vertex_attrib_pointer_timed = halo_glVertexAttribPointer;
	halo_glVertexAttribPointer = es2_vertex_attrib_pointer;
	halo_glMemoryBarrier = es2_memory_barrier;
	halo_glBindBufferBase = es2_bind_buffer_base;
	halo_glBindBufferRange = es2_bind_buffer_range;
	halo_glInvalidateFramebuffer = es2_invalidate_framebuffer;
	halo_glGetInternalformativ = es2_get_internalformativ;
	/* (no base vertex and no image copies: the renderer works without
	either, xgpu_capabilities) */
	halo_glDrawElementsBaseVertex = NULL;
	halo_glCopyImageSubData = NULL;
	platform_log("OpenGL ES 2.0: the renderer's ES 3.0 calls by extensions and emulation (%d extension "
		"functions missing)", missing);
}

#endif

#ifdef HALO_ANDROID_ARMV7
/* ---------- where the GPU's and the processor's time goes, by phase of
the game's rendering (debug.frame_timing; render.c's render_window marks the
phases: halo_gpu_phase)

At each mark, a GPU timestamp (NV_timer_query: when the GPU reaches it) and
the processor's clock; a phase's GPU time is the time from its mark to the
next one on the GPU's clock, its processor time the same on the processor's.
The timestamps are read some frames later, once the GPU has them. */

#define PHASE_FRAMES 4
#define PHASE_MARKS 48
#define PHASE_NAMES 32
#define ES2_TIMESTAMP_NV 0x8E28
#define ES2_QUERY_RESULT 0x8866
#define ES2_QUERY_RESULT_AVAILABLE 0x8867

typedef void (GL_APIENTRY *gen_queries_function)(GLsizei, GLuint *);
typedef void (GL_APIENTRY *query_counter_function)(GLuint, GLenum);
typedef void (GL_APIENTRY *get_query_uiv_function)(GLuint, GLenum, GLuint *);
typedef void (GL_APIENTRY *get_query_ui64v_function)(GLuint, GLenum, unsigned long long *);

static struct
{
	int state; /* 0 unknown, 1 available, -1 none */
	query_counter_function counter;
	get_query_uiv_function get_uiv;
	get_query_ui64v_function get_ui64v;
	GLuint queries[PHASE_FRAMES][PHASE_MARKS];
	unsigned char phase[PHASE_FRAMES][PHASE_MARKS];
	unsigned long long cpu[PHASE_FRAMES][PHASE_MARKS];
	int count[PHASE_FRAMES];
	int frame;
	const char *names[PHASE_NAMES];
	int name_count;
	unsigned long long gpu_total[PHASE_NAMES], cpu_total[PHASE_NAMES];
	unsigned long frames_read;
} phases;

static int phases_available(void)
{
	if (!phases.state)
	{
		gen_queries_function gen = (gen_queries_function)proc("glGenQueriesEXT");
		const char *extensions = (const char *)halo_glGetString(GL_EXTENSIONS);

		phases.counter = (query_counter_function)proc("glQueryCounterNV");
		phases.get_uiv = (get_query_uiv_function)proc("glGetQueryObjectuivEXT");
		phases.get_ui64v = (get_query_ui64v_function)proc("glGetQueryObjectui64vNV");
		if (!gen || !phases.counter || !phases.get_uiv || !phases.get_ui64v || !extensions ||
			!strstr(extensions, "GL_NV_timer_query"))
		{
			phases.state = -1;
			platform_log("frame phases: no GPU timer queries (NV_timer_query): processor times only");
		}
		else
		{
			gen(PHASE_FRAMES * PHASE_MARKS, &phases.queries[0][0]);
			phases.state = 1;
		}
	}
	return phases.state > 0;
}

/* a GPU timestamp nobody reads (NV_timer_query): measured on the Tegra 4,
a frame with one at each phase of its rendering took 24 ms where one with a
glFlush there took 36 and one with neither 41; the timestamp, it seems,
sets the GPU to work on what came before it as a flush alone does not. The
queries are reused round a ring, long done by the time they come round. */
#define KICK_QUERIES 256
static GLuint kick_queries[KICK_QUERIES];
static int kick_next, kick_ready;

int glq_call(void (*function)(void));

void gl_es2_kick(void)
{
	/* (with debug.gl_queue, made in its place among the queued calls) */
	if (glq_call(gl_es2_kick))
		return;
	if (!gl_es2_timer_queries || !gl_functions_es2 || !phases_available())
		return;
	if (!kick_ready)
	{
		gen_queries_function gen = (gen_queries_function)proc("glGenQueriesEXT");

		if (!gen)
			return;
		gen(KICK_QUERIES, kick_queries);
		kick_ready = 1;
	}
	phases.counter(kick_queries[kick_next], ES2_TIMESTAMP_NV);
	kick_next = (kick_next + 1) % KICK_QUERIES;
}


static int phase_index(const char *name)
{
	int index;

	for (index = 0; index < phases.name_count; index++)
	{
		if (phases.names[index] == name || !strcmp(phases.names[index], name))
			return index;
	}
	if (phases.name_count == PHASE_NAMES)
		return PHASE_NAMES - 1;
	phases.names[phases.name_count] = name;
	return phases.name_count++;
}

/* debug.render_flush, debug.gpu_timer_queries and debug.gpu_kick_draws
(d3d8_gl.c reads them) */
int gl_es2_render_flush = 1, gl_es2_timer_queries = 1, gl_es2_kick_draws;

static int phases_available(void);
void gl_es2_kick(void);

/* (debug.gpu_kick_draws: one every so many draws too) */
static unsigned long kick_draw_count;

static void kick_after_draw(void)
{
	if (gl_es2_kick_draws > 0 && ++kick_draw_count % (unsigned long)gl_es2_kick_draws == 0)
		gl_es2_kick();
}

int d3d8_deferred_call(void (*function)(const char *), const char *name);
int glq_on_gl_thread(void);
int glq_call_name(void (*function)(const char *), const char *name);

/* a mark's own part: the processor's clock and the GPU's timestamp (with
debug.gl_queue, made in its place among the queued calls: the timestamp is
the driver's own call, past the queue, and with debug.gl_thread only the GL
thread holds the context to make it; the processor's times are then the GL
thread's, the driver's work by phase) */
static void phase_mark(const char *name)
{
	int frame = phases.frame % PHASE_FRAMES, mark;

	mark = phases.count[frame];
	if (mark >= PHASE_MARKS)
		return;
	phases.phase[frame][mark] = (unsigned char)phase_index(name);
	es2_phase_now = phases.phase[frame][mark];
	if (!strcmp(name, "(end of frame)"))
		es2_phase_frames++;
	phases.cpu[frame][mark] = timing_now();
	if (gl_es2_timer_queries && phases_available())
		phases.counter(phases.queries[frame][mark], ES2_TIMESTAMP_NV);
	phases.count[frame] = mark + 1;
}

void halo_gpu_phase(const char *name)
{
	if (!gl_functions_es2)
		return;
	/* (with the deferred draws, a mark is recorded among them, and made
	when the replay reaches it: on the thread that holds the context; the GL
	thread's, the frame's end, is made there: its deferred draws are the
	game's thread's, not its own) */
	if (!glq_on_gl_thread() && d3d8_deferred_call(halo_gpu_phase, name))
		return;
	/* the work so far sent to the GPU at each phase (a flush): the Tegra 4's
	driver otherwise keeps a frame's commands until the swap, the GPU idle
	while the processor builds them, then the processor idle while the GPU
	draws them; measured, a frame 41 ms long became 28 */
	if (gl_es2_render_flush)
		halo_glFlush();
	/* (the timestamp that sets the GPU working, profiling or not: the
	profiler's own, read back, were measured slower as the only ones) */
	gl_es2_kick();
	if (!gl_es2_frame_timing)
		return;
	if (glq_call_name(phase_mark, name))
		return;
	phase_mark(name);
}

/* the frame's end (d3d8_gl.c, before the swap): its last mark, and the
oldest frame's timestamps read */
void gl_es2_phases_frame_end(void)
{
	int frame, oldest, mark;

	/* (with debug.gl_queue, in its place among the queued calls: the marks
	before it are, and its readback is the driver's own calls) */
	if (glq_call(gl_es2_phases_frame_end))
		return;
	if (!gl_es2_frame_timing || !gl_functions_es2 || !phases.count[phases.frame % PHASE_FRAMES])
	{
		phases.count[phases.frame % PHASE_FRAMES] = 0;
		return;
	}
	halo_gpu_phase("(end of frame)");
	phases.frame++;
	frame = phases.frame % PHASE_FRAMES;
	/* (the slot about to be reused is the oldest: read it first) */
	oldest = frame;
	if (phases.count[oldest] > 1)
	{
		unsigned long long times[PHASE_MARKS];
		int ready = 1;

		if (phases.state > 0 && gl_es2_timer_queries)
		{
			GLuint available = 0;

			phases.get_uiv(phases.queries[oldest][phases.count[oldest] - 1], ES2_QUERY_RESULT_AVAILABLE, &available);
			ready = available != 0;
			for (mark = 0; ready && mark < phases.count[oldest]; mark++)
				phases.get_ui64v(phases.queries[oldest][mark], ES2_QUERY_RESULT, &times[mark]);
		}
		if (ready)
		{
			for (mark = 0; mark + 1 < phases.count[oldest]; mark++)
			{
				int phase = phases.phase[oldest][mark];

				if (phases.state > 0 && gl_es2_timer_queries && times[mark + 1] >= times[mark])
					phases.gpu_total[phase] += times[mark + 1] - times[mark];
				phases.cpu_total[phase] += phases.cpu[oldest][mark + 1] - phases.cpu[oldest][mark];
			}
			phases.frames_read++;
		}
	}
	phases.count[frame] = 0;
}

/* the report (d3d8_gl.c, every ten seconds), and the totals cleared */
void gl_es2_phases_report(void)
{
	char line[1024], draws[3072];
	int index, length = 0, draws_length = 0;

	if (!phases.frames_read)
		return;
	for (index = 0; es2_phase_frames && index < phases.name_count && index < 64; index++)
	{
		double frames = (double)es2_phase_frames;

		if (!es2_phase_draws[index].draws)
			continue;
		draws_length += snprintf(draws + draws_length, sizeof(draws) - (size_t)draws_length,
			"%s%s %.0f draws (%.0f programs, %.0f state unchanged, %.0f uniforms only, %.1fk vertices, %.1f ms in draws)",
			draws_length ? ", " : "", phases.names[index], es2_phase_draws[index].draws / frames,
			es2_phase_draws[index].programs / frames, es2_phase_draws[index].unchanged / frames,
			es2_phase_draws[index].uniforms_only / frames,
			es2_phase_draws[index].vertices / frames / 1000.0, es2_phase_draws[index].nanoseconds / frames / 1e6);
		if (draws_length >= (int)sizeof(draws) - 128)
			break;
	}
	if (draws_length)
		platform_log("frame phases (a frame): %s", draws);
	memset(es2_phase_draws, 0, sizeof(es2_phase_draws));
	es2_phase_frames = 0;
	for (index = 0; index < phases.name_count; index++)
	{
		if (!strcmp(phases.names[index], "(end of frame)"))
			continue;
		length += snprintf(line + length, sizeof(line) - (size_t)length, "%s%s %.1f/%.1f",
			length ? ", " : "", phases.names[index], phases.gpu_total[index] / (double)phases.frames_read / 1e6,
			phases.cpu_total[index] / (double)phases.frames_read / 1e6);
		if (length >= (int)sizeof(line) - 64)
			break;
	}
	platform_log("frame phases (GPU/processor ms a frame): %s", line);
	memset(phases.gpu_total, 0, sizeof(phases.gpu_total));
	memset(phases.cpu_total, 0, sizeof(phases.cpu_total));
	phases.frames_read = 0;
}
#endif

#ifdef HALO_ANDROID_ARMV7
/* ---------- the game's own sections on the processor (debug.frame_timing:
profile_sections.h's, game_tick's steps, the main loop's), each its time a
frame with what it calls; the main loop's thread's only */

#include <pthread.h>

#include "halo_stutter.h"

#define CPU_SECTIONS 96
#define CPU_DEPTH 24

static struct
{
	const char *name[CPU_SECTIONS];
	unsigned long long total[CPU_SECTIONS];
	unsigned long calls[CPU_SECTIONS];
	int count;
	int stack[CPU_DEPTH];
	unsigned long long started[CPU_DEPTH];
	int depth;
	pthread_t thread;
	int thread_known;
} cpu_sections;

static int cpu_section_index(const char *name)
{
	int index;

	for (index = 0; index < cpu_sections.count; index++)
	{
		if (cpu_sections.name[index] == name)
			return index;
	}
	if (cpu_sections.count == CPU_SECTIONS)
		return -1;
	cpu_sections.name[cpu_sections.count] = name;
	return cpu_sections.count++;
}

static int cpu_sections_this_thread(void)
{
	if (!cpu_sections.thread_known)
	{
		cpu_sections.thread = pthread_self();
		cpu_sections.thread_known = 1;
		halo_stutter_thread("game");
	}
	return pthread_equal(cpu_sections.thread, pthread_self());
}

void halo_cpu_section_enter(const char *name)
{
	if ((!gl_es2_frame_timing && !halo_stutter_enabled) || !cpu_sections_this_thread())
		return;
	if (cpu_sections.depth < CPU_DEPTH)
	{
		cpu_sections.stack[cpu_sections.depth] = cpu_section_index(name);
		cpu_sections.started[cpu_sections.depth] = timing_now();
	}
	cpu_sections.depth++;
}

void halo_cpu_section_exit(const char *name)
{
	if ((!gl_es2_frame_timing && !halo_stutter_enabled) || !cpu_sections_this_thread() || cpu_sections.depth <= 0)
		return;
	cpu_sections.depth--;
	if (cpu_sections.depth < CPU_DEPTH)
	{
		int index = cpu_sections.stack[cpu_sections.depth];

		/* (debug.stutter_log: each step's time, where it was) */
		halo_stutter_event(name, NULL, cpu_sections.started[cpu_sections.depth], 0);
		if (index >= 0 && gl_es2_frame_timing)
		{
			cpu_sections.total[index] += timing_now() - cpu_sections.started[cpu_sections.depth];
			cpu_sections.calls[index]++;
		}
	}
}

/* the report: the sections that took the most, a frame each */
void gl_es2_cpu_sections_report(unsigned long frames)
{
	char line[1400];
	int length = 0, shown, index;
	unsigned char used[CPU_SECTIONS];

	if (!frames || !cpu_sections.count)
		return;
	memset(used, 0, sizeof(used));
	for (shown = 0; shown < 18; shown++)
	{
		int best = -1;

		for (index = 0; index < cpu_sections.count; index++)
		{
			if (!used[index] && cpu_sections.total[index] &&
				(best < 0 || cpu_sections.total[index] > cpu_sections.total[best]))
			{
				best = index;
			}
		}
		if (best < 0 || cpu_sections.total[best] / (double)frames < 50000.0)
			break;
		used[best] = 1;
		length += snprintf(line + length, sizeof(line) - (size_t)length, "%s%s %.1f (%.1f calls)", length ? ", " : "",
			cpu_sections.name[best], cpu_sections.total[best] / (double)frames / 1e6,
			cpu_sections.calls[best] / (double)frames);
		if (length >= (int)sizeof(line) - 80)
			break;
	}
	if (length)
		platform_log("frame sections (processor ms a frame, with what they call): %s", line);
	memset(cpu_sections.total, 0, sizeof(cpu_sections.total));
	memset(cpu_sections.calls, 0, sizeof(cpu_sections.calls));
}
#endif
