/*
GL_ES2.C

The renderer's OpenGL ES 3.0 calls on an OpenGL ES 2.0 context (the 32-bit
ARM Android build on the SHIELD Portable's Tegra 4, port/android/native).
gl_es2_install, which gl_functions_load calls for such a context, points the
renderer's function table (gl.h, halo_gl*) at:

- the extensions that are ES 3.0's functions under other names: vertex
  array objects (OES_vertex_array_object), blits (NV_framebuffer_blit), draw
  and read buffers (NV_draw_buffers, NV_read_buffer), occlusion queries
  (EXT_occlusion_query_boolean), multisampled renderbuffers
  (NV_framebuffer_multisample), buffer copies (NV_copy_buffer);
- emulations of the rest:
  - sampler objects: each sampler's state is kept here, and set on the
    texture of each unit it is bound to as the texture or the sampler is
    bound (glTexParameter); a texture whose levels stop short of a full chain
    (GL_TEXTURE_MAX_LEVEL, which ES 2.0 lacks, being kept here too) is
    sampled without mipmaps, as ES 2.0 would otherwise not sample it at all;
  - textures: ES 3.0's sized formats as ES 2.0's unsized ones and their
    extensions (BGRA8888, texture_rg, half floats, depth textures); a 3D
    texture, which ES 2.0 has none of, as a 2D texture of its first slice;
  - the Xbox's packed normals, an unsigned integer attribute in ES 3.0, as
    four bytes (unpacked in the shader: gl_es2_glsl.c);
  - what has no counterpart is left undone: memory barriers, buffer
    bindings, invalidation, 32-bit indices, and texture parameters ES 2.0
    has none of (swizzles, base level, level of detail range).
*/

#include "platform.h"
#include "gl.h"
#include "gl_es2.h"

#include <SDL3/SDL.h>
#include <stdlib.h>
#include <string.h>

#ifdef HALO_ANDROID_ARMV7

/* ---------- ES 2.0 enumerants that ES 3.0's headers name otherwise */

#define ES2_HALF_FLOAT_OES 0x8D61
#define ES2_BGRA_EXT 0x80E1
#define ES2_RED_EXT 0x1903
#define ES2_RG_EXT 0x8227
#define ES2_DEPTH_COMPONENT24_OES 0x81A6
#define ES2_TEXTURE_3D 0x806F
#define ES2_TEXTURE_WRAP_R 0x8072
#define ES2_TEXTURE_MAX_ANISOTROPY 0x84FE
#define ES2_TEXTURE_COMPARE_MODE 0x884C
#define ES2_TEXTURE_COMPARE_FUNC 0x884D
#define ES2_TEXTURE_BORDER_COLOR 0x1004

/* ---------- the real entry points this file calls */

typedef void (GL_APIENTRY *bind_texture_function)(GLenum, GLuint);
typedef void (GL_APIENTRY *active_texture_function)(GLenum);
typedef void (GL_APIENTRY *tex_parameteri_function)(GLenum, GLenum, GLint);
typedef void (GL_APIENTRY *tex_parameterf_function)(GLenum, GLenum, GLfloat);
typedef void (GL_APIENTRY *tex_parameterfv_function)(GLenum, GLenum, const GLfloat *);
typedef void (GL_APIENTRY *tex_image_2d_function)(GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum,
	const void *);
typedef void (GL_APIENTRY *tex_sub_image_2d_function)(GLenum, GLint, GLint, GLint, GLsizei, GLsizei, GLenum, GLenum,
	const void *);
typedef void (GL_APIENTRY *compressed_tex_image_2d_function)(GLenum, GLint, GLenum, GLsizei, GLsizei, GLint, GLsizei,
	const void *);
typedef void (GL_APIENTRY *delete_textures_function)(GLsizei, const GLuint *);
typedef void (GL_APIENTRY *framebuffer_texture_2d_function)(GLenum, GLenum, GLenum, GLuint, GLint);
typedef void (GL_APIENTRY *framebuffer_renderbuffer_function)(GLenum, GLenum, GLenum, GLuint);
typedef void (GL_APIENTRY *vertex_attrib_pointer_function)(GLuint, GLint, GLenum, GLboolean, GLsizei, const void *);
typedef void (GL_APIENTRY *vertex_attrib_4f_function)(GLuint, GLfloat, GLfloat, GLfloat, GLfloat);
typedef void (GL_APIENTRY *draw_elements_function)(GLenum, GLsizei, GLenum, const void *);
typedef void (GL_APIENTRY *renderbuffer_storage_multisample_function)(GLenum, GLsizei, GLenum, GLsizei, GLsizei);

static struct
{
	bind_texture_function bind_texture;
	active_texture_function active_texture;
	tex_parameteri_function tex_parameteri;
	tex_parameterf_function tex_parameterf;
	tex_parameterfv_function tex_parameterfv;
	tex_image_2d_function tex_image_2d;
	tex_sub_image_2d_function tex_sub_image_2d;
	compressed_tex_image_2d_function compressed_tex_image_2d;
	delete_textures_function delete_textures;
	framebuffer_texture_2d_function framebuffer_texture_2d;
	framebuffer_renderbuffer_function framebuffer_renderbuffer;
	vertex_attrib_pointer_function vertex_attrib_pointer;
	vertex_attrib_4f_function vertex_attrib_4f;
	draw_elements_function draw_elements;
	renderbuffer_storage_multisample_function renderbuffer_storage_multisample;
} real;

static void *proc(const char *name)
{
	return SDL_GL_GetProcAddress(name);
}

/* ---------- textures: the state ES 2.0 has no place for */

struct texture_state
{
	/* the sampler state last set on it (sampler_state's), and its version */
	unsigned long applied_sampler, applied_version;
	/* its first level's size, and its levels (GL_TEXTURE_MAX_LEVEL + 1) */
	GLsizei width, height;
	int levels;
	BOOL cube;
	/* its chain was completed past its last level (texture_chain_complete) */
	BOOL completed;
};

static struct texture_state *textures;
static unsigned long texture_capacity;

static struct texture_state *texture_state(GLuint texture)
{
	if (!texture)
		return NULL;
	if (texture >= texture_capacity)
	{
		unsigned long capacity = texture_capacity ? texture_capacity : 1024;
		struct texture_state *grown;

		while (texture >= capacity)
			capacity *= 2;
		grown = realloc(textures, capacity * sizeof(*textures));
		if (!grown)
			return NULL;
		memset(grown + texture_capacity, 0, (capacity - texture_capacity) * sizeof(*textures));
		textures = grown;
		texture_capacity = capacity;
	}
	return &textures[texture];
}

/* the units' bindings (GL_TEXTURE_2D and GL_TEXTURE_CUBE_MAP), the active
unit, and each unit's sampler */
#define UNITS 16

static GLuint unit_texture[UNITS][2];
static GLuint unit_sampler[UNITS];
static unsigned long active_unit;

static int target_slot(GLenum target)
{
	/* (a cube map's faces are its own: GL_TEXTURE_CUBE_MAP_POSITIVE_X on) */
	return target == GL_TEXTURE_CUBE_MAP ||
		(target >= GL_TEXTURE_CUBE_MAP_POSITIVE_X && target <= GL_TEXTURE_CUBE_MAP_NEGATIVE_Z) ? 1 : 0;
}

/* ---------- sampler objects */

struct sampler_state
{
	BOOL used;
	unsigned long version;
	GLint minify, magnify, wrap_s, wrap_t, compare_mode, compare_function;
	GLfloat anisotropy;
	GLfloat border[4];
};

#define SAMPLERS 64

static struct sampler_state samplers[SAMPLERS];
static BOOL anisotropy_available, border_clamp_available, shadow_available;

/* a mipmapped minification filter as its unmipmapped one */
static GLint without_mipmaps(GLint filter)
{
	switch (filter)
	{
	case GL_NEAREST_MIPMAP_NEAREST:
	case GL_NEAREST_MIPMAP_LINEAR:
		return GL_NEAREST;
	case GL_LINEAR_MIPMAP_NEAREST:
	case GL_LINEAR_MIPMAP_LINEAR:
		return GL_LINEAR;
	default:
		return filter;
	}
}

/* the levels a full chain of a texture of this size has */
static int full_chain(GLsizei width, GLsizei height)
{
	GLsizei side = width > height ? width : height;
	int levels = 1;

	while (side > 1)
	{
		side >>= 1;
		levels++;
	}
	return levels;
}

/* a sampler's state set on the texture bound to the active unit at target */
static void sampler_apply(GLenum target, GLuint texture, GLuint sampler)
{
	struct texture_state *state = texture_state(texture);
	struct sampler_state *values;
	GLint minify;

	if (!state || !sampler || sampler >= SAMPLERS || !samplers[sampler].used)
		return;
	values = &samplers[sampler];
	if (state->applied_sampler == sampler && state->applied_version == values->version)
		return;
	state->applied_sampler = sampler;
	state->applied_version = values->version;
	minify = values->minify;
	/* (a texture without its full chain of levels is incomplete to ES 2.0
	when sampled with mipmaps, and is drawn black: one level is all of it
	that is sampled then) */
	if (state->levels && state->width && state->levels < full_chain(state->width, state->height) && !state->completed)
		minify = without_mipmaps(minify);
	real.tex_parameteri(target, GL_TEXTURE_MIN_FILTER, minify);
	real.tex_parameteri(target, GL_TEXTURE_MAG_FILTER, values->magnify);
	real.tex_parameteri(target, GL_TEXTURE_WRAP_S, values->wrap_s);
	real.tex_parameteri(target, GL_TEXTURE_WRAP_T, values->wrap_t);
	if (anisotropy_available)
		real.tex_parameterf(target, ES2_TEXTURE_MAX_ANISOTROPY, values->anisotropy);
	if (border_clamp_available)
		real.tex_parameterfv(target, ES2_TEXTURE_BORDER_COLOR, values->border);
	if (shadow_available && target == GL_TEXTURE_2D)
	{
		real.tex_parameteri(target, ES2_TEXTURE_COMPARE_MODE, values->compare_mode);
		real.tex_parameteri(target, ES2_TEXTURE_COMPARE_FUNC, values->compare_function);
	}
}

/* a unit's sampler set on its textures (the unit made active, and put back) */
static void unit_apply(unsigned long unit)
{
	int slot;

	if (unit >= UNITS || !unit_sampler[unit])
		return;
	if (unit != active_unit)
		real.active_texture(GL_TEXTURE0 + (GLenum)unit);
	for (slot = 0; slot < 2; slot++)
	{
		if (unit_texture[unit][slot])
			sampler_apply(slot ? GL_TEXTURE_CUBE_MAP : GL_TEXTURE_2D, unit_texture[unit][slot], unit_sampler[unit]);
	}
	if (unit != active_unit)
		real.active_texture(GL_TEXTURE0 + (GLenum)active_unit);
}

static void GL_APIENTRY es2_gen_samplers(GLsizei count, GLuint *names)
{
	GLsizei index;
	GLuint sampler = 1;

	for (index = 0; index < count; index++)
	{
		while (sampler < SAMPLERS && samplers[sampler].used)
			sampler++;
		if (sampler >= SAMPLERS)
		{
			names[index] = 0;
			continue;
		}
		memset(&samplers[sampler], 0, sizeof(samplers[sampler]));
		samplers[sampler].used = TRUE;
		samplers[sampler].version = 1;
		samplers[sampler].minify = GL_NEAREST_MIPMAP_LINEAR;
		samplers[sampler].magnify = GL_LINEAR;
		samplers[sampler].wrap_s = GL_REPEAT;
		samplers[sampler].wrap_t = GL_REPEAT;
		samplers[sampler].compare_mode = GL_NONE;
		samplers[sampler].compare_function = GL_LEQUAL;
		samplers[sampler].anisotropy = 1.0f;
		names[index] = sampler;
	}
}

static void GL_APIENTRY es2_bind_sampler(GLuint unit, GLuint sampler)
{
	if (unit >= UNITS)
		return;
	unit_sampler[unit] = sampler;
	unit_apply(unit);
}

/* the units that use a sampler, given its changed state */
static void sampler_changed(GLuint sampler)
{
	unsigned long unit;

	samplers[sampler].version++;
	for (unit = 0; unit < UNITS; unit++)
	{
		if (unit_sampler[unit] == sampler)
			unit_apply(unit);
	}
}

static void GL_APIENTRY es2_sampler_parameteri(GLuint sampler, GLenum name, GLint value)
{
	struct sampler_state *state;

	if (!sampler || sampler >= SAMPLERS || !samplers[sampler].used)
		return;
	state = &samplers[sampler];
	switch (name)
	{
	case GL_TEXTURE_MIN_FILTER: state->minify = value; break;
	case GL_TEXTURE_MAG_FILTER: state->magnify = value; break;
	case GL_TEXTURE_WRAP_S: state->wrap_s = value; break;
	case GL_TEXTURE_WRAP_T: state->wrap_t = value; break;
	case ES2_TEXTURE_COMPARE_MODE: state->compare_mode = value; break;
	case ES2_TEXTURE_COMPARE_FUNC: state->compare_function = value; break;
	case ES2_TEXTURE_MAX_ANISOTROPY: state->anisotropy = (GLfloat)value; break;
	default: return;
	}
	sampler_changed(sampler);
}

static void GL_APIENTRY es2_sampler_parameterf(GLuint sampler, GLenum name, GLfloat value)
{
	if (name == ES2_TEXTURE_MAX_ANISOTROPY)
	{
		if (!sampler || sampler >= SAMPLERS || !samplers[sampler].used)
			return;
		samplers[sampler].anisotropy = value;
		sampler_changed(sampler);
		return;
	}
	es2_sampler_parameteri(sampler, name, (GLint)value);
}

static void GL_APIENTRY es2_sampler_parameterfv(GLuint sampler, GLenum name, const GLfloat *values)
{
	if (name == ES2_TEXTURE_BORDER_COLOR)
	{
		if (!sampler || sampler >= SAMPLERS || !samplers[sampler].used)
			return;
		memcpy(samplers[sampler].border, values, sizeof(samplers[sampler].border));
		sampler_changed(sampler);
		return;
	}
	es2_sampler_parameterf(sampler, name, values[0]);
}

/* ---------- textures */

static GLenum es2_target(GLenum target)
{
	return target == ES2_TEXTURE_3D ? GL_TEXTURE_2D : target;
}

static void GL_APIENTRY es2_active_texture(GLenum unit)
{
	active_unit = unit - GL_TEXTURE0;
	real.active_texture(unit);
}

static void GL_APIENTRY es2_bind_texture(GLenum target, GLuint texture)
{
	struct texture_state *state;

	target = es2_target(target);
	real.bind_texture(target, texture);
	if (active_unit < UNITS)
	{
		unit_texture[active_unit][target_slot(target)] = texture;
		state = texture_state(texture);
		if (state && target == GL_TEXTURE_CUBE_MAP)
			state->cube = TRUE;
		if (unit_sampler[active_unit])
			sampler_apply(target, texture, unit_sampler[active_unit]);
	}
}

/* the texture bound to the active unit at target */
static struct texture_state *bound_state(GLenum target)
{
	return active_unit < UNITS ? texture_state(unit_texture[active_unit][target_slot(es2_target(target))]) : NULL;
}

static void GL_APIENTRY es2_tex_parameteri(GLenum target, GLenum name, GLint value)
{
	struct texture_state *state;

	target = es2_target(target);
	switch (name)
	{
	case GL_TEXTURE_MAX_LEVEL:
		/* (ES 2.0 has none: kept, for the sampling of a short chain) */
		state = bound_state(target);
		if (state)
		{
			state->levels = value + 1;
			state->applied_sampler = 0;
		}
		return;
	case GL_TEXTURE_BASE_LEVEL:
	case GL_TEXTURE_MIN_LOD:
	case GL_TEXTURE_MAX_LOD:
	case GL_TEXTURE_SWIZZLE_R:
	case GL_TEXTURE_SWIZZLE_G:
	case GL_TEXTURE_SWIZZLE_B:
	case GL_TEXTURE_SWIZZLE_A:
	case ES2_TEXTURE_WRAP_R:
		return;
	default:
		real.tex_parameteri(target, name, value);
		return;
	}
}

static void GL_APIENTRY es2_tex_parameterf(GLenum target, GLenum name, GLfloat value)
{
	switch (name)
	{
	case GL_TEXTURE_MAX_LEVEL:
	case GL_TEXTURE_BASE_LEVEL:
	case GL_TEXTURE_MIN_LOD:
	case GL_TEXTURE_MAX_LOD:
	case ES2_TEXTURE_WRAP_R:
		es2_tex_parameteri(target, name, (GLint)value);
		return;
	default:
		real.tex_parameterf(es2_target(target), name, value);
		return;
	}
}

/* ES 3.0's sized format and its data's format and type as ES 2.0's */
static void es2_format(GLint *internal_format, GLenum *format, GLenum *type)
{
	switch (*internal_format)
	{
	case GL_RGBA8:
		*internal_format = *format == ES2_BGRA_EXT ? ES2_BGRA_EXT : GL_RGBA;
		break;
	case GL_RGB8:
		*internal_format = GL_RGB;
		break;
	case GL_R8:
		*internal_format = ES2_RED_EXT;
		*format = ES2_RED_EXT;
		break;
	case GL_RG8:
		*internal_format = ES2_RG_EXT;
		*format = ES2_RG_EXT;
		break;
	case GL_RGBA16F:
		*internal_format = GL_RGBA;
		*type = ES2_HALF_FLOAT_OES;
		break;
	case GL_DEPTH24_STENCIL8:
	case GL_DEPTH_COMPONENT24:
	case GL_DEPTH_COMPONENT32F:
		/* (no packed depth and stencil: depth alone, OES_depth_texture) */
		*internal_format = GL_DEPTH_COMPONENT;
		*format = GL_DEPTH_COMPONENT;
		*type = GL_UNSIGNED_INT;
		break;
	default:
		break;
	}
	if (*type == GL_HALF_FLOAT)
		*type = ES2_HALF_FLOAT_OES;
}

static void texture_size_note(GLenum target, GLint level, GLsizei width, GLsizei height)
{
	struct texture_state *state = bound_state(target);

	if (state && level == 0)
	{
		state->width = width;
		state->height = height;
		state->completed = FALSE;
		state->applied_sampler = 0;
	}
}

/* the bytes of a texel of an uncompressed format, or 0 */
static int texel_bytes(GLenum format, GLenum type)
{
	int channels;

	switch (format)
	{
	case GL_RGBA: case ES2_BGRA_EXT: channels = 4; break;
	case GL_RGB: channels = 3; break;
	case GL_LUMINANCE_ALPHA: case ES2_RG_EXT: channels = 2; break;
	case GL_LUMINANCE: case GL_ALPHA: case ES2_RED_EXT: channels = 1; break;
	default: return 0;
	}
	switch (type)
	{
	case GL_UNSIGNED_BYTE: return channels;
	case ES2_HALF_FLOAT_OES: return channels * 2;
	case GL_UNSIGNED_SHORT_5_6_5: case GL_UNSIGNED_SHORT_4_4_4_4: case GL_UNSIGNED_SHORT_5_5_5_1: return 2;
	default: return 0;
	}
}

/* a texture whose levels stop short of 1x1 (the Xbox's bitmaps often do:
GL_TEXTURE_MAX_LEVEL, which ES 2.0 lacks, said where) is incomplete to
ES 2.0 with mipmaps, and was sampled without them: a shimmer of single
texels in the distance, and slow. Its last level given, the levels below
it are given too, each of the last level's first texel (or block): too
small to be seen as more than a colour */
static void texture_chain_complete(GLenum target, GLint level, GLsizei width, GLsizei height, int compressed,
	GLenum internal_format, GLenum format, GLenum type, const void *data)
{
	struct texture_state *state = bound_state(target);
	int full, block = 0, bytes;
	unsigned char *buffer;
	GLsizei size;

	if (!state || !data || !state->levels || level != state->levels - 1 || !state->width)
		return;
	full = full_chain(state->width, state->height);
	if (state->levels >= full)
		return;
	if (compressed)
	{
		/* (DXT1 and ETC1: 8 bytes a block; DXT3 and DXT5, and the rest, 16) */
		block = internal_format == 0x83F0 || internal_format == 0x83F1 || internal_format == 0x8D64 ? 8 : 16;
		bytes = block;
	}
	else
	{
		bytes = texel_bytes(format, type);
		if (!bytes)
			return;
	}
	/* (the largest level below this one, whole: a quarter of its texels,
	at most 8 bytes each, or its blocks) */
	size = (GLsizei)(((width + 3) / 4) * ((height + 3) / 4) * 16 + (long)width * height * 2 + 64);
	buffer = malloc((size_t)size);
	if (!buffer)
		return;
	while (++level < full)
	{
		GLsizei count, at;

		width = width > 1 ? width / 2 : 1;
		height = height > 1 ? height / 2 : 1;
		count = compressed ? ((width + 3) / 4) * ((height + 3) / 4) : width * height;
		for (at = 0; at < count; at++)
			memcpy(buffer + at * bytes, data, (size_t)bytes);
		if (compressed)
			real.compressed_tex_image_2d(target, level, internal_format, width, height, 0, count * bytes, buffer);
		else
			real.tex_image_2d(target, level, (GLint)internal_format, width, height, 0, format, type, buffer);
	}
	free(buffer);
	state->completed = TRUE;
	state->applied_sampler = 0;
}

static void GL_APIENTRY es2_tex_image_2d(GLenum target, GLint level, GLint internal_format, GLsizei width,
	GLsizei height, GLint border, GLenum format, GLenum type, const void *data)
{
	es2_format(&internal_format, &format, &type);
	texture_size_note(target, level, width, height);
	real.tex_image_2d(es2_target(target), level, internal_format, width, height, border, format, type, data);
	texture_chain_complete(es2_target(target), level, width, height, 0, (GLenum)internal_format, format, type, data);
}

static void GL_APIENTRY es2_tex_sub_image_2d(GLenum target, GLint level, GLint x, GLint y, GLsizei width,
	GLsizei height, GLenum format, GLenum type, const void *data)
{
	if (type == GL_HALF_FLOAT)
		type = ES2_HALF_FLOAT_OES;
	real.tex_sub_image_2d(es2_target(target), level, x, y, width, height, format, type, data);
}

static void GL_APIENTRY es2_compressed_tex_image_2d(GLenum target, GLint level, GLenum internal_format,
	GLsizei width, GLsizei height, GLint border, GLsizei size, const void *data)
{
	texture_size_note(target, level, width, height);
	real.compressed_tex_image_2d(es2_target(target), level, internal_format, width, height, border, size, data);
	texture_chain_complete(es2_target(target), level, width, height, 1, internal_format, 0, 0, data);
}

/* a 3D texture as its first slice */
static void GL_APIENTRY es2_tex_image_3d(GLenum target, GLint level, GLint internal_format, GLsizei width,
	GLsizei height, GLsizei depth, GLint border, GLenum format, GLenum type, const void *data)
{
	(void)depth;
	es2_tex_image_2d(es2_target(target), level, internal_format, width, height, border, format, type, data);
}

static void GL_APIENTRY es2_compressed_tex_image_3d(GLenum target, GLint level, GLenum internal_format,
	GLsizei width, GLsizei height, GLsizei depth, GLint border, GLsizei size, const void *data)
{
	es2_compressed_tex_image_2d(es2_target(target), level, internal_format, width, height, border,
		depth > 0 ? size / depth : size, data);
}

static void GL_APIENTRY es2_delete_textures(GLsizei count, const GLuint *names)
{
	GLsizei index;
	unsigned long unit;

	for (index = 0; index < count; index++)
	{
		struct texture_state *state = names[index] < texture_capacity ? &textures[names[index]] : NULL;

		if (state)
			memset(state, 0, sizeof(*state));
		for (unit = 0; unit < UNITS; unit++)
		{
			if (unit_texture[unit][0] == names[index])
				unit_texture[unit][0] = 0;
			if (unit_texture[unit][1] == names[index])
				unit_texture[unit][1] = 0;
		}
	}
	real.delete_textures(count, names);
}

/* ---------- framebuffers */

static void GL_APIENTRY es2_framebuffer_texture_2d(GLenum target, GLenum attachment, GLenum texture_target,
	GLuint texture, GLint level)
{
	if (target == GL_DRAW_FRAMEBUFFER || target == GL_READ_FRAMEBUFFER)
		target = GL_FRAMEBUFFER;
	if (attachment == GL_DEPTH_STENCIL_ATTACHMENT)
		attachment = GL_DEPTH_ATTACHMENT;
	real.framebuffer_texture_2d(target, attachment, texture_target, texture, level);
}

static void GL_APIENTRY es2_framebuffer_renderbuffer(GLenum target, GLenum attachment, GLenum renderbuffer_target,
	GLuint renderbuffer)
{
	if (target == GL_DRAW_FRAMEBUFFER || target == GL_READ_FRAMEBUFFER)
		target = GL_FRAMEBUFFER;
	if (attachment == GL_DEPTH_STENCIL_ATTACHMENT)
		attachment = GL_DEPTH_ATTACHMENT;
	real.framebuffer_renderbuffer(target, attachment, renderbuffer_target, renderbuffer);
}

static void GL_APIENTRY es2_renderbuffer_storage_multisample(GLenum target, GLsizei samples, GLenum format,
	GLsizei width, GLsizei height)
{
	if (format == GL_DEPTH24_STENCIL8)
		format = ES2_DEPTH_COMPONENT24_OES;
	if (real.renderbuffer_storage_multisample)
		real.renderbuffer_storage_multisample(target, samples, format, width, height);
}

/* ---------- vertices */

/* an Xbox packed normal (one unsigned integer) as its four bytes */
static void GL_APIENTRY es2_vertex_attrib_i_pointer(GLuint index, GLint size, GLenum type, GLsizei stride,
	const void *pointer)
{
	if (size == 1 && (type == GL_UNSIGNED_INT || type == GL_INT))
		real.vertex_attrib_pointer(index, 4, GL_UNSIGNED_BYTE, GL_FALSE, stride, pointer);
	else
		real.vertex_attrib_pointer(index, size, type, GL_FALSE, stride, pointer);
}

static void GL_APIENTRY es2_vertex_attrib_i_4ui(GLuint index, GLuint x, GLuint y, GLuint z, GLuint w)
{
	(void)y;
	(void)z;
	(void)w;
	if (real.vertex_attrib_4f)
	{
		real.vertex_attrib_4f(index, (GLfloat)(x & 0xff), (GLfloat)((x >> 8) & 0xff), (GLfloat)((x >> 16) & 0xff),
			(GLfloat)(x >> 24));
	}
}

/* (32-bit indices, which ES 2.0 has only with OES_element_index_uint, which
the Tegra 4 lacks: a quad list from past the first 65536 vertices is not
drawn) */
static void GL_APIENTRY es2_draw_elements(GLenum mode, GLsizei count, GLenum type, const void *indices)
{
	if (type == GL_UNSIGNED_INT)
	{
		static int logged;

		if (logged < 3)
		{
			logged++;
			platform_log("OpenGL ES 2.0: a draw of %d 32-bit indices is not drawn", (int)count);
		}
		return;
	}
	real.draw_elements(mode, count, type, indices);
}

/* ---------- what ES 2.0 has no counterpart of */

static void GL_APIENTRY es2_memory_barrier(GLbitfield barriers)
{
	(void)barriers;
}

static void GL_APIENTRY es2_bind_buffer_base(GLenum target, GLuint index, GLuint buffer)
{
	(void)target;
	(void)index;
	(void)buffer;
}

static void GL_APIENTRY es2_bind_buffer_range(GLenum target, GLuint index, GLuint buffer, GLintptr offset,
	GLsizeiptr size)
{
	(void)target;
	(void)index;
	(void)buffer;
	(void)offset;
	(void)size;
}

static void GL_APIENTRY es2_invalidate_framebuffer(GLenum target, GLsizei count, const GLenum *attachments)
{
	(void)target;
	(void)count;
	(void)attachments;
}

static void GL_APIENTRY es2_get_internalformativ(GLenum target, GLenum format, GLenum name, GLsizei count,
	GLint *values)
{
	(void)target;
	(void)format;
	(void)name;
	if (count > 0 && values)
		values[0] = 0;
}

/* ---------- installation */

/* an extension's entry point in place of the renderer's, where it has one */
#define USE_EXTENSION(name, extension_name) \
	do { \
		void *function = proc(extension_name); \
		if (function) \
			halo_##name = (__typeof__(halo_##name))function; \
		else \
			missing++; \
	} while (0)

int gl_es2_fragment_highp;

void gl_es2_install(void)
{
	const char *extensions = (const char *)halo_glGetString(GL_EXTENSIONS);
	int missing = 0;

	{
		typedef void (GL_APIENTRY *precision_function)(GLenum, GLenum, GLint *, GLint *);
		precision_function precision = (precision_function)proc("glGetShaderPrecisionFormat");
		GLint range[2] = { 0, 0 }, bits = 0;

		if (precision)
			precision(GL_FRAGMENT_SHADER, GL_HIGH_FLOAT, range, &bits);
		gl_es2_fragment_highp = bits > 0;
	}

	extensions = extensions ? extensions : "";
	anisotropy_available = strstr(extensions, "GL_EXT_texture_filter_anisotropic") != NULL;
	border_clamp_available = strstr(extensions, "_texture_border_clamp") != NULL;
	shadow_available = strstr(extensions, "GL_EXT_shadow_samplers") != NULL;

	real.bind_texture = halo_glBindTexture;
	real.active_texture = halo_glActiveTexture;
	real.tex_parameteri = halo_glTexParameteri;
	real.tex_parameterf = halo_glTexParameterf;
	real.tex_parameterfv = (tex_parameterfv_function)proc("glTexParameterfv");
	real.tex_image_2d = halo_glTexImage2D;
	real.tex_sub_image_2d = halo_glTexSubImage2D;
	real.compressed_tex_image_2d = halo_glCompressedTexImage2D;
	real.delete_textures = halo_glDeleteTextures;
	real.framebuffer_texture_2d = halo_glFramebufferTexture2D;
	real.framebuffer_renderbuffer = halo_glFramebufferRenderbuffer;
	real.vertex_attrib_pointer = halo_glVertexAttribPointer;
	real.vertex_attrib_4f = (vertex_attrib_4f_function)proc("glVertexAttrib4f");
	real.draw_elements = halo_glDrawElements;
	real.renderbuffer_storage_multisample =
		(renderbuffer_storage_multisample_function)proc("glRenderbufferStorageMultisampleNV");
	if (!real.tex_parameterfv)
		border_clamp_available = FALSE;

	USE_EXTENSION(glGenVertexArrays, "glGenVertexArraysOES");
	USE_EXTENSION(glBindVertexArray, "glBindVertexArrayOES");
	USE_EXTENSION(glBlitFramebuffer, "glBlitFramebufferNV");
	USE_EXTENSION(glDrawBuffers, "glDrawBuffersNV");
	USE_EXTENSION(glReadBuffer, "glReadBufferNV");
	USE_EXTENSION(glGenQueries, "glGenQueriesEXT");
	USE_EXTENSION(glBeginQuery, "glBeginQueryEXT");
	USE_EXTENSION(glEndQuery, "glEndQueryEXT");
	USE_EXTENSION(glGetQueryObjectuiv, "glGetQueryObjectuivEXT");
	USE_EXTENSION(glCopyBufferSubData, "glCopyBufferSubDataNV");

	halo_glRenderbufferStorageMultisample = es2_renderbuffer_storage_multisample;
	halo_glGenSamplers = es2_gen_samplers;
	halo_glBindSampler = es2_bind_sampler;
	halo_glSamplerParameteri = es2_sampler_parameteri;
	halo_glSamplerParameterf = es2_sampler_parameterf;
	halo_glSamplerParameterfv = es2_sampler_parameterfv;
	halo_glActiveTexture = es2_active_texture;
	halo_glBindTexture = es2_bind_texture;
	halo_glTexParameteri = es2_tex_parameteri;
	halo_glTexParameterf = es2_tex_parameterf;
	halo_glTexImage2D = es2_tex_image_2d;
	halo_glTexSubImage2D = es2_tex_sub_image_2d;
	halo_glCompressedTexImage2D = es2_compressed_tex_image_2d;
	halo_glTexImage3D = es2_tex_image_3d;
	halo_glCompressedTexImage3D = es2_compressed_tex_image_3d;
	halo_glDeleteTextures = es2_delete_textures;
	halo_glFramebufferTexture2D = es2_framebuffer_texture_2d;
	halo_glFramebufferRenderbuffer = es2_framebuffer_renderbuffer;
	halo_glVertexAttribIPointer = es2_vertex_attrib_i_pointer;
	halo_glVertexAttribI4ui = es2_vertex_attrib_i_4ui;
	halo_glDrawElements = es2_draw_elements;
	halo_glMemoryBarrier = es2_memory_barrier;
	halo_glBindBufferBase = es2_bind_buffer_base;
	halo_glBindBufferRange = es2_bind_buffer_range;
	halo_glInvalidateFramebuffer = es2_invalidate_framebuffer;
	halo_glGetInternalformativ = es2_get_internalformativ;
	/* (no base vertex and no image copies: the renderer works without
	either, xgpu_capabilities) */
	halo_glDrawElementsBaseVertex = NULL;
	halo_glCopyImageSubData = NULL;
	platform_log("OpenGL ES 2.0: the renderer's ES 3.0 calls by extensions and emulation (%d extension "
		"functions missing)", missing);
}

#endif
