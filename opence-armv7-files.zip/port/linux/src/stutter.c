/* stutter.c: debug.stutter_log (the 32-bit ARM Android build)

What can hold a frame up is timed where it happens, on whichever thread
(halo_stutter.h's STUTTER_START and STUTTER_END): a checkpoint's save, the
OpenGL context taken from the GL thread and held, a slow driver call, a
texture or map read waited for, the game's steps. Each that took a
millisecond or more goes into a ring (written by any thread at once, without
a lock: a slot's sequence number is written last, and a reader takes a slot
only if its number is the same before and after). At each frame presented
(the render thread), a frame longer than 150 ms is logged with the events of
its time: by thread and kind, how much of the frame's time each covered, and
the longest of them, from the frame's start. */

#ifdef HALO_ANDROID_ARMV7

#include "halo_stutter.h"
#include "port_config.h"

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/syscall.h>

void platform_log(const char *format, ...);

int halo_stutter_enabled;

#define STUTTER_RING 4096
#define STUTTER_MINIMUM 1000000ULL
#define STUTTER_LONG_FRAME 150000000ULL
/* (logcat's buffer holds the whole run: a few a window, the first and then
only a frame longer than any logged in it yet) */
#define STUTTER_LOGS_A_WINDOW 6
#define STUTTER_FIRST_LOGGED 2
#define STUTTER_GROUPS 64

struct stutter_entry
{
	volatile unsigned long sequence;
	unsigned long long start, end;
	const char *what, *label, *thread;
	long detail;
	int tid;
};

static struct stutter_entry stutter_ring[STUTTER_RING];
static unsigned long stutter_next;
static __thread const char *stutter_thread_name;
static __thread int stutter_tid;

unsigned long long halo_stutter_now(void)
{
	struct timespec now;

	clock_gettime(CLOCK_MONOTONIC, &now);
	return (unsigned long long)now.tv_sec * 1000000000ULL + (unsigned long long)now.tv_nsec;
}

void halo_stutter_thread(const char *name)
{
	stutter_thread_name = name;
}

void halo_stutter_event(const char *what, const char *label, unsigned long long start, long detail)
{
	unsigned long long end;
	unsigned long index;
	struct stutter_entry *entry;

	if (!halo_stutter_enabled || !start)
		return;
	end = halo_stutter_now();
	if (end - start < STUTTER_MINIMUM)
		return;
	if (!stutter_tid)
		stutter_tid = (int)syscall(__NR_gettid);
	index = __sync_fetch_and_add(&stutter_next, 1);
	entry = &stutter_ring[index % STUTTER_RING];
	entry->sequence = 0;
	__sync_synchronize();
	entry->start = start;
	entry->end = end;
	entry->what = what;
	entry->label = label;
	entry->thread = stutter_thread_name;
	entry->detail = detail;
	entry->tid = stutter_tid;
	__sync_synchronize();
	entry->sequence = index + 1;
}

/* ---------- the log of a long frame */

struct stutter_group
{
	const char *thread, *what, *label;
	int tid;
	unsigned long count;
	unsigned long long covered, longest;
	long detail;
};

static struct stutter_entry stutter_seen[STUTTER_RING];
static struct stutter_group stutter_groups[STUTTER_GROUPS];

static const char *stutter_thread_label(const char *thread, int tid, char *buffer, size_t size)
{
	if (thread)
		return thread;
	snprintf(buffer, size, "thread %d", tid);
	return buffer;
}

static void stutter_log_frame(unsigned long long from, unsigned long long to, unsigned long long origin)
{
	unsigned long index, seen = 0, groups = 0, oldest_sequence = 0;
	unsigned long long oldest = ~0ULL;
	char line[1800], name[24];
	int length, used[STUTTER_GROUPS], shown;

	for (index = 0; index < STUTTER_RING; index++)
	{
		struct stutter_entry *entry = &stutter_ring[index];
		unsigned long sequence = entry->sequence;
		struct stutter_entry copy;

		if (!sequence)
			continue;
		__sync_synchronize();
		copy = *entry;
		__sync_synchronize();
		if (entry->sequence != sequence)
			continue;
		if (copy.start < oldest)
		{
			oldest = copy.start;
			oldest_sequence = sequence;
		}
		if (copy.end <= from || copy.start >= to)
			continue;
		stutter_seen[seen++] = copy;
	}
	(void)oldest_sequence;
	for (index = 0; index < seen; index++)
	{
		struct stutter_entry *entry = &stutter_seen[index];
		unsigned long long start = entry->start > from ? entry->start : from;
		unsigned long long end = entry->end < to ? entry->end : to;
		unsigned long group;

		for (group = 0; group < groups; group++)
		{
			struct stutter_group *g = &stutter_groups[group];

			if (g->what == entry->what && g->label == entry->label && g->thread == entry->thread &&
				(entry->thread || g->tid == entry->tid))
				break;
		}
		if (group == groups)
		{
			if (groups == STUTTER_GROUPS)
				continue;
			memset(&stutter_groups[group], 0, sizeof(stutter_groups[group]));
			stutter_groups[group].thread = entry->thread;
			stutter_groups[group].tid = entry->tid;
			stutter_groups[group].what = entry->what;
			stutter_groups[group].label = entry->label;
			groups++;
		}
		stutter_groups[group].count++;
		stutter_groups[group].covered += end - start;
		stutter_groups[group].detail += entry->detail;
		if (entry->end - entry->start > stutter_groups[group].longest)
			stutter_groups[group].longest = entry->end - entry->start;
	}
	/* by thread and kind, the most of the frame first */
	length = snprintf(line, sizeof(line), "stutter: a %.0f ms frame, %.1f s in%s: ", (to - from) / 1e6,
		(from - origin) / 1e9, oldest > from ? " (the ring's oldest event is after its start)" : "");
	memset(used, 0, sizeof(used));
	for (shown = 0; shown < 12; shown++)
	{
		long best = -1;
		struct stutter_group *g;

		for (index = 0; index < groups; index++)
		{
			if (!used[index] && (best < 0 || stutter_groups[index].covered > stutter_groups[best].covered))
				best = (long)index;
		}
		if (best < 0)
			break;
		used[best] = 1;
		g = &stutter_groups[best];
		length += snprintf(line + length, sizeof(line) - (size_t)length, "%s%s: %s%s%s%s %.0f ms (%lu, longest %.0f",
			shown ? "; " : "", stutter_thread_label(g->thread, g->tid, name, sizeof(name)), g->what,
			g->label ? " (" : "", g->label ? g->label : "", g->label ? ")" : "", g->covered / 1e6, g->count,
			g->longest / 1e6);
		if (g->detail)
			length += snprintf(line + length, sizeof(line) - (size_t)length, ", %ld", g->detail);
		length += snprintf(line + length, sizeof(line) - (size_t)length, ")");
		if (length >= (int)sizeof(line) - 160)
			break;
	}
	if (!groups)
		snprintf(line + length, sizeof(line) - (size_t)length, "nothing timed");
	platform_log("%s", line);
	/* the longest events, from the frame's start (the one before's present) */
	length = snprintf(line, sizeof(line), "stutter: its longest:");
	for (shown = 0; shown < 6; shown++)
	{
		long best = -1;
		struct stutter_entry *entry;

		for (index = 0; index < seen; index++)
		{
			if (stutter_seen[index].what && (best < 0 ||
				stutter_seen[index].end - stutter_seen[index].start >
					stutter_seen[best].end - stutter_seen[best].start))
				best = (long)index;
		}
		if (best < 0)
			break;
		entry = &stutter_seen[best];
		length += snprintf(line + length, sizeof(line) - (size_t)length, "%s %s %s%s%s%s %.0f ms at %+.0f ms",
			shown ? ";" : "", stutter_thread_label(entry->thread, entry->tid, name, sizeof(name)), entry->what,
			entry->label ? " (" : "", entry->label ? entry->label : "", entry->label ? ")" : "",
			(entry->end - entry->start) / 1e6, ((double)entry->start - (double)from) / 1e6);
		if (entry->detail)
			length += snprintf(line + length, sizeof(line) - (size_t)length, " [%ld]", entry->detail);
		entry->what = NULL;
		if (length >= (int)sizeof(line) - 160)
			break;
	}
	if (seen)
		platform_log("%s", line);
}

void halo_stutter_frame(void)
{
	static int read_at = -1;
	static unsigned long long previous, origin, window_start;
	static unsigned long logged, long_frames, skipped;
	static unsigned long long longest_logged;
	unsigned long long now;

	if (read_at != (int)config_changes())
	{
		read_at = (int)config_changes();
		if (config_boolean("debug.stutter_log") && !halo_stutter_enabled)
			platform_log("debug.stutter_log: frames longer than %llu ms logged with what held them up",
				STUTTER_LONG_FRAME / 1000000ULL);
		halo_stutter_enabled = config_boolean("debug.stutter_log");
	}
	if (!halo_stutter_enabled)
	{
		previous = 0;
		return;
	}
	if (!stutter_thread_name)
		stutter_thread_name = "render";
	now = halo_stutter_now();
	if (!origin)
		origin = window_start = now;
	if (previous && now - previous > STUTTER_LONG_FRAME)
	{
		long_frames++;
		if (logged < STUTTER_LOGS_A_WINDOW && (logged < STUTTER_FIRST_LOGGED || now - previous > longest_logged))
		{
			logged++;
			if (now - previous > longest_logged)
				longest_logged = now - previous;
			stutter_log_frame(previous, now, origin);
		}
		else
			skipped++;
	}
	if (now - window_start >= 10000000000ULL)
	{
		platform_log("stutter: %lu frames longer than %llu ms in the last ten seconds%s", long_frames,
			STUTTER_LONG_FRAME / 1000000ULL, skipped ? " (not all logged)" : "");
		window_start = now;
		logged = long_frames = skipped = 0;
		longest_logged = 0;
	}
	/* (the log's own time is not the next frame's) */
	previous = halo_stutter_now();
}

#else

typedef int stutter_unused;

#endif
