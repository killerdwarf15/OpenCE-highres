/*
GL_ES2.H

The renderer on an OpenGL ES 2.0 context (the 32-bit ARM Android build on the
SHIELD Portable's Tegra 4, port/android/native): its GLSL rewritten as GLSL
ES 1.00 (gl_es2_glsl.c), and the ES 3.0 functions it calls given by ES 2.0
extensions or emulated (gl_es2.c).
*/

#ifndef __HALO_LINUX_GL_ES2_H
#define __HALO_LINUX_GL_ES2_H

#define GL_ES2_VERTEX_SHADER 0x8B31
#define GL_ES2_FRAGMENT_SHADER 0x8B30

#define GL_ES2_MAXIMUM_ATTRIBUTES 16

/* a vertex shader's attributes and the locations its ES 3.00 text gave
them (-1: none), for glBindAttribLocation before the program is linked */
struct gl_es2_attribute_locations
{
	char name[GL_ES2_MAXIMUM_ATTRIBUTES][32];
	int location[GL_ES2_MAXIMUM_ATTRIBUTES];
	int count;
};

/* the GLSL ES 1.00 text of a shader's ES 3.00 one (to free), the vertex
shader's attribute locations in *locations; fragment_highp whether the GPU
has highp in fragment shaders */
char *gl_es2_glsl_translate(unsigned int shader_type, const char *source, struct gl_es2_attribute_locations *locations,
	int fragment_highp);

/* the renderer's function table (gl.h) on an OpenGL ES 2.0 context: its
ES 3.0 entries by extensions and emulation (gl_es2.c); and whether the GPU
has highp floats in fragment shaders */
void gl_es2_install(void);
extern int gl_es2_fragment_highp;

#endif
