/*
GL_ES2.H

The renderer on an OpenGL ES 2.0 context (the 32-bit ARM Android build on the
SHIELD Portable's Tegra 4, port/android/native): its GLSL rewritten as GLSL
ES 1.00 (gl_es2_glsl.c), and the ES 3.0 functions it calls given by ES 2.0
extensions or emulated (gl_es2.c).
*/

#ifndef __HALO_LINUX_GL_ES2_H
#define __HALO_LINUX_GL_ES2_H

#define GL_ES2_VERTEX_SHADER 0x8B31
#define GL_ES2_FRAGMENT_SHADER 0x8B30

#define GL_ES2_MAXIMUM_ATTRIBUTES 16

/* a vertex shader's attributes and the locations its ES 3.00 text gave
them (-1: none), for glBindAttribLocation before the program is linked */
struct gl_es2_attribute_locations
{
	char name[GL_ES2_MAXIMUM_ATTRIBUTES][32];
	int location[GL_ES2_MAXIMUM_ATTRIBUTES];
	int count;
};

/* the GLSL ES 1.00 text of a shader's ES 3.00 one (to free), the vertex
shader's attribute locations in *locations; fragment_highp whether the GPU
has highp in fragment shaders */
char *gl_es2_glsl_translate(unsigned int shader_type, const char *source, struct gl_es2_attribute_locations *locations,
	int fragment_highp);

/* the renderer's function table (gl.h) on an OpenGL ES 2.0 context: its
ES 3.0 entries by extensions and emulation (gl_es2.c); and whether the GPU
has highp floats in fragment shaders */
void gl_es2_install(void);

/* a frame's work, counted by gl_es2.c, reported and reset by d3d8_gl.c
(debug.frame_timing: then times too) */
struct gl_es2_frame_statistics
{
	unsigned long draws, vertices, constants, programs, texture_parameters;
	unsigned long buffer_bytes, texture_bytes;
	unsigned long long draw_nanoseconds, upload_nanoseconds;
	/* (debug.frame_timing) the processor's time in the calls that set a
	draw's state, before the draw itself */
	unsigned long long uniform_nanoseconds, program_nanoseconds, texture_nanoseconds, attribute_nanoseconds;
	/* (d3d8_gl.c's setup_streams) the vertices of draws with an attribute
	not aligned for four (its offset, its stream's stride or its size),
	which a driver may convert on the processor at each draw; and the
	vertex types of those attributes (D3DVSDT_*), up to eight */
	unsigned long vertices_unaligned;
	unsigned char unaligned_types[8];
	unsigned char unaligned_type_count;
	/* (d3d8_gl.c, debug.frame_timing) the renderer's own time in a draw's
	stages: its textures, targets and raster state; its shaders and program
	(the key, the lookups); the rest of its preparation (uniforms); its
	vertex streams; its indices; and the whole of the Draw* calls, the
	driver's draw with them */
	unsigned long long prepare_state_nanoseconds, prepare_program_nanoseconds, prepare_rest_nanoseconds;
	unsigned long long streams_nanoseconds, indices_nanoseconds, draw_api_nanoseconds;
	/* (d3d8_gl.c) when the frame's first draw was asked for */
	unsigned long long first_draw;
};
extern struct gl_es2_frame_statistics gl_es2_frame;
extern int gl_es2_frame_timing;
extern int gl_es2_fill_test;
/* debug.skip_unaligned_draws: the next draw has an attribute not aligned
for four (d3d8_gl.c's setup_streams) and is not drawn; reset by each draw */
extern int gl_es2_skip_unaligned, gl_es2_next_draw_unaligned;
void gl_es2_count_upload(unsigned long bytes, unsigned long long nanoseconds);
/* the phases of a frame's rendering, timed on the GPU and the processor
(gl_es2.c; render.c marks them) */
void halo_gpu_phase(const char *name);
void gl_es2_phases_frame_end(void);
void gl_es2_phases_report(void);
/* the monotonic clock in nanoseconds, or 0 when debug.frame_timing is off */
unsigned long long gl_es2_now(void);
extern int gl_es2_fragment_highp;

#endif
