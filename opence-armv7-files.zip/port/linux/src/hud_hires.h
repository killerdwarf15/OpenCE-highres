/*
HUD_HIRES.H

The high-res HUD: textures drawn from the hand-made SVG redraws of the Halo PC
HUD sheets (port/assets/hud, made by tools/hud_assets.py), each 8x the size
of the bitmap of the Xbox maps it stands for (4x for the largest) and in that
bitmap's layout. The menus' titles, pictures of text in the maps, are drawn
the same way (port/assets/titles, made by tools/title_assets.py), and so are
their controller button icons (port/assets/buttons, made by
tools/button_assets.py).
tools/embed_assets.py makes them C data (hud_hires_embedded); hud_hires.c
decodes them, and the texture cache (xbox_textures.c) draws one in place of
its bitmap whenever that bitmap's pixels are uploaded: the game still sizes
and places the bitmap by its tag, so nothing else changes.
A texture may instead stand for only some of a bitmap's sprites (the
buttons among the message icons the menus set into their text): the game
draws those sprites from a placeholder bitmap of the same size
(port/linux/game/hud_hires_tags.c), which the texture cache draws the
texture for, and the bitmap's other sprites from the bitmap as before.
*/

#ifndef HUD_HIRES_H
#define HUD_HIRES_H

/* an embedded texture: an 8-bit RGBA PNG, and the bitmap it stands for (its
bitmap group tag's name, its index there, and the CRC-32 of its first mip
level's pixels as the English maps have them); coverage: a meter's, whose
green is how much of each texel its shapes cover (the meter shader reads
only its blue and alpha); point_threshold: its red
holds exact discrete segment thresholds (zero in continuous meter sprites),
read without filtering while blue, alpha and coverage retain their mips;
title: a menu title (port/assets/titles, made by tools/title_assets.py) or a
button icon (port/assets/buttons, made by tools/button_assets.py), drawn with
display.high_res_text rather than display.high_res_hud; sprites: the sequences
of its bitmap's group (a bit each) whose sprites it is drawn for, through a
placeholder, or 0: the whole bitmap, in its place */
struct hud_hires_embedded
{
	const char *tag;
	int bitmap;
	unsigned int width, height;
	unsigned int crc;
	int coverage;
	int point_threshold; /* red: exact discrete meter thresholds, zero elsewhere */
	int title;
	unsigned int sprites;
	/* drawn for a Custom Edition map's stock bitmap of its name too, whose
	layout is its own (port/assets/hud/custom_edition.json) */
	int custom_edition;
	const unsigned int *png;
	unsigned int png_size;
};

extern const struct hud_hires_embedded hud_hires_embedded[];
extern const unsigned int hud_hires_embedded_count;

/* At the frame boundary, identify cached bitmaps affected by committed HUD
 * or title setting changes. Pixel/CRC validation still occurs on upload. */
unsigned long hud_hires_settings_changed(void);
int hud_hires_bitmap_affected(unsigned long address, long width, long height, unsigned long changed);

/* the texture standing for the bitmap whose pixels are uploaded from address
(guest virtual) with this size, its first mip level being level0_size bytes,
or -1: none, its setting (display.high_res_hud, or display.high_res_text for
the menus') off, or pixels other than those the
texture was drawn for (another language's maps, which have their own text,
or modified ones) */
long hud_hires_override_find(unsigned long address, unsigned long width, unsigned long height,
	unsigned long level0_size);
/* its GL texture (decoded and uploaded, mipmapped, on first use; 0 if it
could not be), and the number of its mip levels */
unsigned int hud_hires_override_texture(long asset, unsigned long *levels);
/* the same, without waiting for its art's decode: 0 with *pending set while
it is decoded on a thread of its own (the 32-bit ARM Android build), the map's
own texture drawn meanwhile; elsewhere hud_hires_override_texture's */
unsigned int hud_hires_override_texture_nowait(long asset, unsigned long *levels, int *pending);
/* a GL texture drawn from an 8-bit RGBA PNG (as the tools write them), with
all its mip levels, and their number; 0 if it could not be */
unsigned int hud_hires_png_texture(const void *png, unsigned long size, unsigned long *levels);
/* the HUD's textures for a map's bitmaps (port/linux/game/hud_hires_tags.c),
decoded from their PNGs as it loads, on a thread of their own, so that they
are only uploaded when first drawn; and, as it is unloaded, that stopped and
what was decoded and not drawn let go. The desktop builds' alone: Android
and the web decode each when it is first drawn */
void hud_hires_map_loaded(const long *assets, long count);
void hud_hires_map_unloaded(void);
/* whether its green is its coverage (d3d8_gl.c, nv2a_psh.c: coverage_alpha) */
int hud_hires_override_coverage(long asset);
/* the GL texture of the texture drawn for some of a bitmap's sprites whose
placeholder's D3D texture has this Data, and the number of its mip levels;
0 if data is no placeholder's */
unsigned int hud_hires_placeholder_texture(unsigned long data, unsigned long *levels);
/* whether its red holds exact segment thresholds, read unfiltered (d3d8_gl.c,
nv2a_psh.c: point_threshold) */
int hud_hires_override_point_threshold(long asset);

/* Original HUD sheets lacking redraws, with their tag coordinates unchanged.
 * The cache owns the upscaled texture and invalidates it with the source. */
long hud_hires_upscale_at(unsigned long address, long width, long height);
unsigned int hud_hires_upscale_texture(const unsigned char *bgra, unsigned long width,
	unsigned long height, long kind, unsigned long *levels);

#endif
