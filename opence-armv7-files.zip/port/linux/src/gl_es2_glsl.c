/*
GL_ES2_GLSL.C

The renderer's GLSL (ES 3.00 or 3.10, as nv2a_vsh.c, nv2a_psh.c, xgpu_post.c
and the rest write it) rewritten as GLSL ES 1.00, for an OpenGL ES 2.0
context (the 32-bit ARM Android build on the SHIELD Portable's Tegra 4,
port/android/native): gl_es2_glsl_translate, which xgpu_compile_shader calls.

It is a rewrite of the generated text, not a compiler: it knows the shapes
the generators write.

- #version 100, and the extensions the text needs (OES_standard_derivatives,
  EXT_frag_depth, EXT_shadow_samplers, NV_draw_buffers);
- a vertex shader's inputs become attributes, their locations kept for
  glBindAttribLocation (gl_es2_glsl_attribute_locations); its outputs, and a
  fragment shader's inputs, varyings; flat and centroid dropped;
- a fragment shader's outputs become gl_FragColor (or gl_FragData[n]);
- texture() and its kin become texture2D, textureCube and shadow2DEXT by the
  sampler's type; a 3D texture, which ES 2.0 has none of, is sampled as its
  first slice (a 2D texture, xbox_textures.c, and coordinates .xy);
  textureLod's level is dropped in a fragment shader (ES 2.0 has no such
  function there without EXT_shader_texture_lod), its bias kept;
- precision: a fragment shader's highp is mediump where the GPU has no
  highp there (the Tegra 4's), its int mediump;
- an Xbox packed normal (NORMPACKED3, an unsigned integer attribute in
  ES 3.00) arrives as four bytes instead (gl_es2.c, glVertexAttribIPointer)
  and is unpacked with float arithmetic;
- what ES 2.0 has no use for is dropped: early fragment tests, atomic
  counters, sampler precisions.
*/

#include "port_config.h"
#include "gl_es2.h"

#ifdef HALO_ANDROID_ARMV7

int gl_es2_unclamped_index;

#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---------- text */

struct text
{
	char *buffer;
	size_t length, capacity;
};

static void text_append_length(struct text *text, const char *string, size_t length)
{
	if (text->length + length + 1 > text->capacity)
	{
		size_t capacity = text->capacity ? text->capacity : 4096;

		while (text->length + length + 1 > capacity)
			capacity *= 2;
		text->buffer = realloc(text->buffer, capacity);
		text->capacity = capacity;
	}
	memcpy(text->buffer + text->length, string, length);
	text->length += length;
	text->buffer[text->length] = 0;
}

static void text_append(struct text *text, const char *string)
{
	text_append_length(text, string, strlen(string));
}

static void text_appendf(struct text *text, const char *format, ...)
{
	char line[512];
	va_list arguments;
	int length;

	va_start(arguments, format);
	length = vsnprintf(line, sizeof(line), format, arguments);
	va_end(arguments);
	if (length > (int)sizeof(line) - 1)
		length = (int)sizeof(line) - 1;
	text_append_length(text, line, (size_t)length);
}

static int identifier_character(char c)
{
	return isalnum((unsigned char)c) || c == '_';
}

/* whether text appears in a line (from line to end) */
static int line_contains(const char *line, const char *end, const char *what)
{
	size_t length = strlen(what);

	for (; line + length <= end; line++)
	{
		if (!strncmp(line, what, length))
			return 1;
	}
	return 0;
}

static int starts_with(const char *string, const char *prefix)
{
	return strncmp(string, prefix, strlen(prefix)) == 0;
}

/* whether an identifier appears in the text, as a whole word */
static int has_word(const char *text, const char *word)
{
	size_t length = strlen(word);
	const char *at = text;

	while ((at = strstr(at, word)))
	{
		if ((at == text || !identifier_character(at[-1])) && !identifier_character(at[length]))
			return 1;
		at += length;
	}
	return 0;
}

/* ---------- the samplers and outputs a shader declares */

enum { _sampler_2d, _sampler_cube, _sampler_3d, _sampler_shadow };

#define MAXIMUM_NAMES 64

struct names
{
	char name[MAXIMUM_NAMES][48];
	int value[MAXIMUM_NAMES];
	int count;
};

static void names_add(struct names *names, const char *name, size_t length, int value)
{
	if (names->count < MAXIMUM_NAMES && length < sizeof(names->name[0]))
	{
		memcpy(names->name[names->count], name, length);
		names->name[names->count][length] = 0;
		names->value[names->count] = value;
		names->count++;
	}
}

static int names_find(const struct names *names, const char *name, size_t length)
{
	int index;

	for (index = 0; index < names->count; index++)
	{
		if (strlen(names->name[index]) == length && !strncmp(names->name[index], name, length))
			return index;
	}
	return -1;
}

/* the identifier after a type in a declaration ("uniform sampler2D tex0;"),
and its length */
static const char *declared_name(const char *after_type, size_t *length)
{
	while (*after_type == ' ' || *after_type == '\t')
		after_type++;
	*length = 0;
	while (identifier_character(after_type[*length]))
		(*length)++;
	return after_type;
}

/* ---------- calls: a call's arguments, at the top level of its parentheses */

#define MAXIMUM_ARGUMENTS 4

struct call
{
	const char *argument[MAXIMUM_ARGUMENTS];
	size_t argument_length[MAXIMUM_ARGUMENTS];
	int count;
	/* past the closing parenthesis */
	const char *end;
};

static int call_parse(const char *open, struct call *call)
{
	const char *cursor = open + 1, *start = open + 1;
	int depth = 0;

	call->count = 0;
	for (; *cursor; cursor++)
	{
		if (*cursor == '(' || *cursor == '[')
			depth++;
		else if ((*cursor == ')' || *cursor == ']') && depth > 0)
			depth--;
		else if ((*cursor == ',' && depth == 0) || (*cursor == ')' && depth == 0))
		{
			if (call->count == MAXIMUM_ARGUMENTS)
				return 0;
			call->argument[call->count] = start;
			call->argument_length[call->count] = (size_t)(cursor - start);
			call->count++;
			start = cursor + 1;
			if (*cursor == ')')
			{
				call->end = cursor + 1;
				return 1;
			}
		}
	}
	return 0;
}

/* ---------- the rewrite of the body: calls and identifiers */

struct rewrite
{
	int fragment;
	const struct names *samplers;
	const struct names *outputs;
	int output_count;
};

static void rewrite_body(struct text *out, const char *text, size_t length, const struct rewrite *rewrite);

static void rewrite_argument(struct text *out, const struct call *call, int index, const struct rewrite *rewrite)
{
	rewrite_body(out, call->argument[index], call->argument_length[index], rewrite);
}

static int sampler_type_of(const struct call *call, const struct rewrite *rewrite)
{
	const char *name = call->argument[0];
	size_t length;
	int found;

	while (*name == ' ')
		name++;
	length = 0;
	while (identifier_character(name[length]))
		length++;
	found = names_find(rewrite->samplers, name, length);
	return found < 0 ? _sampler_2d : rewrite->samplers->value[found];
}

/* texture(s, c[, bias]), textureLod(s, c, lod), textureProj(s, c[, bias]) */
static const char *rewrite_texture_call(struct text *out, const char *word, size_t word_length, const char *open,
	const struct rewrite *rewrite)
{
	struct call call;
	int type, lod, projected;
	const char *function;

	if (!call_parse(open, &call) || call.count < 2)
		return NULL;
	type = sampler_type_of(&call, rewrite);
	lod = word_length == 10 && !strncmp(word, "textureLod", 10);
	projected = word_length == 11 && !strncmp(word, "textureProj", 11);
	switch (type)
	{
	case _sampler_cube: function = lod && !rewrite->fragment ? "textureCubeLod" : "textureCube"; break;
	case _sampler_shadow: function = projected ? "shadow2DProjEXT" : "shadow2DEXT"; break;
	default:
		function = projected ? (lod && !rewrite->fragment ? "texture2DProjLod" : "texture2DProj") :
			(lod && !rewrite->fragment ? "texture2DLod" : "texture2D");
		break;
	}
	text_append(out, function);
	text_append(out, "(");
	rewrite_argument(out, &call, 0, rewrite);
	text_append(out, ",");
	if (type == _sampler_3d)
	{
		/* (the first slice: ES 2.0 has no 3D textures) */
		text_append(out, " vec2((");
		rewrite_argument(out, &call, 1, rewrite);
		text_append(out, ").xy)");
	}
	else
	{
		rewrite_argument(out, &call, 1, rewrite);
	}
	/* a bias stays (a fragment shader's); a level only where the
	function has one (a vertex shader's) */
	if (call.count > 2 && (!lod || !rewrite->fragment))
	{
		text_append(out, ",");
		rewrite_argument(out, &call, 2, rewrite);
	}
	text_append(out, ")");
	return call.end;
}

/* round(x), trunc(x): ES 2.0 has neither */
static const char *rewrite_rounding_call(struct text *out, const char *word, const char *open,
	const struct rewrite *rewrite)
{
	struct call call;

	if (!call_parse(open, &call) || call.count != 1)
		return NULL;
	if (word[0] == 'r')
	{
		text_append(out, "floor((");
		rewrite_argument(out, &call, 0, rewrite);
		text_append(out, ") + 0.5)");
	}
	else
	{
		text_append(out, "(sign(");
		rewrite_argument(out, &call, 0, rewrite);
		text_append(out, ") * floor(abs(");
		rewrite_argument(out, &call, 0, rewrite);
		text_append(out, ")))");
	}
	return call.end;
}

/* whether a call's argument is an integer literal (" 191") */
static int integer_literal(const struct call *call, int index)
{
	size_t at, digits = 0;

	for (at = 0; at < call->argument_length[index]; at++)
	{
		char c = call->argument[index][at];

		if (isdigit((unsigned char)c))
			digits++;
		else if (c != ' ' && !(c == '-' && !digits))
			return 0;
	}
	return digits > 0;
}

static void rewrite_body(struct text *out, const char *text, size_t length, const struct rewrite *rewrite)
{
	const char *cursor = text, *end = text + length;

	while (cursor < end)
	{
		if (identifier_character(*cursor) && (cursor == text || !identifier_character(cursor[-1])) &&
			!isdigit((unsigned char)*cursor))
		{
			const char *word = cursor;
			size_t word_length = 0;
			const char *after;
			int output;

			while (word + word_length < end && identifier_character(word[word_length]))
				word_length++;
			after = word + word_length;
			while (after < end && *after == ' ')
				after++;
			if (after < end && *after == '(')
			{
				const char *next = NULL;

				if ((word_length == 7 && !strncmp(word, "texture", 7)) ||
					(word_length == 10 && !strncmp(word, "textureLod", 10)) ||
					(word_length == 11 && !strncmp(word, "textureProj", 11)))
				{
					next = rewrite_texture_call(out, word, word_length, after, rewrite);
				}
				else if (word_length == 3 && !strncmp(word, "int", 3))
				{
					/* nv2a_psh.c's mux on the low bit of a byte:
					(int(x) & 1) != 0, without integer operators */
					struct call call;

					if (call_parse(after, &call) && call.count == 1 && starts_with(call.end, " & 1) != 0"))
					{
						text_append(out, "mod(floor(");
						rewrite_argument(out, &call, 0, rewrite);
						text_append(out, "), 2.0)) != 0.0");
						next = call.end + strlen(" & 1) != 0");
					}
				}
				else if (word_length == 5 && !strncmp(word, "clamp", 5) && gl_es2_unclamped_index)
				{
					/* (debug.vs_unclamped_index: the index alone, the Xbox's
					shaders keeping their own in range: its conversions and
					clamp are some 6 instructions a constant read, a model's
					skinning a dozen of them a vertex) */
					struct call call;

					if (call_parse(after, &call) && call.count == 3 && integer_literal(&call, 1) &&
						integer_literal(&call, 2))
					{
						text_append(out, "(");
						rewrite_argument(out, &call, 0, rewrite);
						text_append(out, ")");
						next = call.end;
					}
				}
				if (!next && word_length == 5 && !strncmp(word, "clamp", 5))
				{
					/* an integer clamp (nv2a_vsh.c's relative constant
					index), which ES 2.0 has none of: through floats */
					struct call call;

					if (call_parse(after, &call) && call.count == 3 && integer_literal(&call, 1) &&
						integer_literal(&call, 2))
					{
						text_append(out, "int(clamp(float(");
						rewrite_argument(out, &call, 0, rewrite);
						text_append(out, "), ");
						text_append_length(out, call.argument[1], call.argument_length[1]);
						text_append(out, ".0, ");
						text_append_length(out, call.argument[2], call.argument_length[2]);
						text_append(out, ".0))");
						next = call.end;
					}
				}
				else if ((word_length == 5 && !strncmp(word, "round", 5)) ||
					(word_length == 5 && !strncmp(word, "trunc", 5)))
				{
					next = rewrite_rounding_call(out, word, after, rewrite);
				}
				if (next)
				{
					cursor = next;
					continue;
				}
			}
			output = rewrite->fragment ? names_find(rewrite->outputs, word, word_length) : -1;
			if (output >= 0)
			{
				if (rewrite->output_count > 1)
					text_appendf(out, "gl_FragData[%d]", rewrite->outputs->value[output]);
				else
					text_append(out, "gl_FragColor");
			}
			else if (word_length == 12 && !strncmp(word, "gl_FragDepth", 12))
			{
				text_append(out, "gl_FragDepthEXT");
			}
			else
			{
				text_append_length(out, word, word_length);
			}
			cursor = word + word_length;
			continue;
		}
		/* an unsigned literal's suffix (12u) */
		if ((*cursor == 'u' || *cursor == 'U') && cursor > text && isdigit((unsigned char)cursor[-1]) &&
			(cursor + 1 >= end || !identifier_character(cursor[1])))
		{
			cursor++;
			continue;
		}
		text_append_length(out, cursor, 1);
		cursor++;
	}
}

/* ---------- the declarations */

/* NORMPACKED3 from its four bytes, low first: x 11 bits, y 11, z 10, each
signed (nv2a_vsh.c's unpack_normpacked3, without integers) */
static const char packed_normal_function[] =
	"vec4 unpack_normpacked3(vec4 b)\n"
	"{\n"
	"\tfloat x = b.x + mod(b.y, 8.0) * 256.0;\n"
	"\tfloat y = floor(b.y / 8.0) + mod(b.z, 64.0) * 32.0;\n"
	"\tfloat z = floor(b.z / 64.0) + b.w * 4.0;\n"
	"\tif (x >= 1024.0) x -= 2048.0;\n"
	"\tif (y >= 1024.0) y -= 2048.0;\n"
	"\tif (z >= 512.0) z -= 1024.0;\n"
	"\treturn vec4(x / 1023.0, y / 1023.0, z / 511.0, 1.0);\n"
	"}\n";

/* a line's text without its leading space, and whether it starts with a
qualifier, which it is then past */
static int take_qualifier(const char **line, const char *qualifier)
{
	size_t length = strlen(qualifier);

	if (starts_with(*line, qualifier) && ((*line)[length] == ' ' || (*line)[length] == '\t'))
	{
		*line += length;
		while (**line == ' ' || **line == '\t')
			(*line)++;
		return 1;
	}
	return 0;
}

char *gl_es2_glsl_translate(unsigned int shader_type, const char *source, struct gl_es2_attribute_locations *locations,
	int fragment_highp)
{
	struct text out = { 0 }, body = { 0 };
	struct names samplers = { 0 }, outputs = { 0 };
	struct rewrite rewrite;
	int fragment = shader_type == GL_ES2_FRAGMENT_SHADER;
	const char *line = source, *next;
	int skip_function = 0, depth = 0;
	char *scaled_source = NULL;

	if (locations)
		locations->count = 0;
	/* the samplers and the outputs first: the body refers to both */
	for (line = source; *line; line = next)
	{
		const char *cursor = line, *name;
		size_t length;

		next = strchr(line, '\n');
		next = next ? next + 1 : line + strlen(line);
		while (*cursor == ' ' || *cursor == '\t')
			cursor++;
		if (take_qualifier(&cursor, "uniform"))
		{
			(void)(take_qualifier(&cursor, "highp") || take_qualifier(&cursor, "mediump") || take_qualifier(&cursor, "lowp"));
			if (take_qualifier(&cursor, "sampler2DShadow"))
			{
				name = declared_name(cursor, &length);
				names_add(&samplers, name, length, _sampler_shadow);
			}
			else if (take_qualifier(&cursor, "samplerCube"))
			{
				name = declared_name(cursor, &length);
				names_add(&samplers, name, length, _sampler_cube);
			}
			else if (take_qualifier(&cursor, "sampler3D"))
			{
				name = declared_name(cursor, &length);
				names_add(&samplers, name, length, _sampler_3d);
			}
			else if (take_qualifier(&cursor, "sampler2D"))
			{
				name = declared_name(cursor, &length);
				names_add(&samplers, name, length, _sampler_2d);
			}
		}
		else if (fragment)
		{
			int location = 0;

			if (starts_with(cursor, "layout(location"))
			{
				const char *equals = strchr(cursor, '=');
				const char *close = strchr(cursor, ')');

				if (equals && close && equals < close)
					location = atoi(equals + 1);
				cursor = close ? close + 1 : cursor;
				while (*cursor == ' ')
					cursor++;
			}
			if (take_qualifier(&cursor, "out"))
			{
				(void)(take_qualifier(&cursor, "highp") || take_qualifier(&cursor, "mediump") || take_qualifier(&cursor, "lowp"));
				while (identifier_character(*cursor))
					cursor++;
				name = declared_name(cursor, &length);
				names_add(&outputs, name, length, location);
			}
		}
	}

	/* the version, and the extensions the text needs */
	text_append(&out, "#version 100\n");
	if (fragment && (has_word(source, "dFdx") || has_word(source, "dFdy") || has_word(source, "fwidth")))
		text_append(&out, "#extension GL_OES_standard_derivatives : enable\n");
	if (fragment && has_word(source, "gl_FragDepth"))
		text_append(&out, "#extension GL_EXT_frag_depth : enable\n");
	if (has_word(source, "sampler2DShadow"))
		text_append(&out, "#extension GL_EXT_shadow_samplers : enable\n");
	if (fragment && outputs.count > 1)
		text_append(&out, "#extension GL_NV_draw_buffers : enable\n");

	/* the texture coordinates' scale (a linear texture's, to its texels:
	1 for the rest) is applied in the vertex shader instead, so that a
	coordinate reaches the sampler as the vertex shader interpolated it: a
	fragment shader's mediump (the Tegra 4's has no highp) holds too few
	bits for a coordinate many times round a tiled texture, which it then
	samples in blocks */
	if (fragment)
	{
		char *copy = malloc(strlen(source) + 1);
		const char *read = source;
		char *write = copy;

		if (copy)
		{
			while (*read)
			{
				if (starts_with(read, ").xy * texture_scale[") && isdigit((unsigned char)read[21]) &&
					starts_with(read + 22, "].xy"))
				{
					memcpy(write, ").xy", 4);
					write += 4;
					read += 26;
					continue;
				}
				*write++ = *read++;
			}
			*write = 0;
			source = scaled_source = copy;
		}
		/* a 2D stage's projected coordinates, divided in the shader
		(nv2a_psh.c's xyz / w, w 0 as 1), sampled with texture2DProj
		instead: a coordinate computed in the shader is a dependent read to
		the Tegra 4, its texture fetched only once the arithmetic is done,
		where one straight from a varying is fetched ahead (some 170 of a
		level's 190 samples). (A w of 0 is the hardware's, not 1.) */
		if (scaled_source)
		{
			char pattern[160], replacement[64];
			int stage, unit;

			for (stage = 0; stage < 4; stage++)
			{
				for (unit = 0; unit < 4; unit++)
				{
					char declaration[32];
					char *found;

					snprintf(declaration, sizeof(declaration), "uniform sampler2D tex%d;", unit);
					if (!strstr(scaled_source, declaration))
						continue;
					snprintf(pattern, sizeof(pattern),
						"texture(tex%d, (vec4(xT%d.xyz / (xT%d.w != 0.0 ? xT%d.w : 1.0), 1.0)).xy",
						unit, stage, stage, stage);
					snprintf(replacement, sizeof(replacement), "textureProj(tex%d, xT%d.xyw", unit, stage);
					while ((found = strstr(scaled_source, pattern)))
					{
						size_t pattern_length = strlen(pattern), replacement_length = strlen(replacement);

						memcpy(found, replacement, replacement_length);
						memmove(found + replacement_length, found + pattern_length,
							strlen(found + pattern_length) + 1);
					}
				}
			}
		}
	}
	rewrite.fragment = fragment;
	rewrite.samplers = &samplers;
	rewrite.outputs = &outputs;
	rewrite.output_count = outputs.count;
	for (line = source; *line; line = next)
	{
		const char *cursor = line;
		size_t line_length;

		next = strchr(line, '\n');
		next = next ? next + 1 : line + strlen(line);
		line_length = (size_t)(next - line);
		while (*cursor == ' ' || *cursor == '\t')
			cursor++;

		/* nv2a_vsh.c's integer unpacking, replaced as a whole */
		if (skip_function)
		{
			const char *character;

			for (character = line; character < next; character++)
			{
				if (*character == '{')
					depth++;
				else if (*character == '}' && --depth == 0)
					skip_function = 0;
			}
			continue;
		}
		if (starts_with(cursor, "vec4 unpack_normpacked3("))
		{
#ifdef HALO_ANDROID_ARMV7
			/* (debug.vs_flat_normals, a test of what unpacking costs: every
			packed normal (0, 0, 1); lighting wrong) */
			if (config_boolean("debug.vs_flat_normals"))
				text_append(&body, "vec4 unpack_normpacked3(vec4 b)\n{\n\treturn vec4(0.0, 0.0, 1.0, 1.0);\n}\n");
			else
#endif
			text_append(&body, packed_normal_function);
			skip_function = 1;
			depth = line_contains(line, next, "{") ? 1 : 0;
			continue;
		}
		if (starts_with(cursor, "#version") || starts_with(cursor, "#extension") ||
			starts_with(cursor, "layout(early_fragment_tests)") || line_contains(cursor, next, "atomic_uint") ||
			(starts_with(cursor, "precision") && line_contains(cursor, next, "sampler")))
		{
			continue;
		}
		if (starts_with(cursor, "precision highp float;"))
		{
			if (fragment && !fragment_highp)
				text_append(&body, "precision mediump float;\n");
			else
				text_append(&body, "precision highp float;\n");
			continue;
		}
		if (starts_with(cursor, "precision highp int;"))
		{
			text_append(&body, fragment && !fragment_highp ? "precision mediump int;\n" : "precision highp int;\n");
			continue;
		}
		{
			const char *declaration = cursor;
			int location = -1;

			if (starts_with(declaration, "layout(location"))
			{
				const char *equals = strchr(declaration, '=');
				const char *close = strchr(declaration, ')');

				if (!close)
					continue;
				if (equals && equals < close)
					location = atoi(equals + 1);
				declaration = close + 1;
				while (*declaration == ' ')
					declaration++;
			}
			else if (starts_with(declaration, "layout("))
			{
				/* (another layout, of what ES 2.0 has none of: binding,
				std140) */
				const char *close = strchr(declaration, ')');

				declaration = close ? close + 1 : declaration;
				while (*declaration == ' ')
					declaration++;
			}
			take_qualifier(&declaration, "flat");
			take_qualifier(&declaration, "centroid");
			take_qualifier(&declaration, "smooth");
			if (!fragment && take_qualifier(&declaration, "in"))
			{
				const char *name, *type;
				size_t length;
				int packed = 0;

				(void)(take_qualifier(&declaration, "highp") || take_qualifier(&declaration, "mediump") ||
					take_qualifier(&declaration, "lowp"));
				type = declaration;
				if (take_qualifier(&declaration, "uint") || take_qualifier(&declaration, "int"))
					packed = 1;
				else
				{
					while (identifier_character(*declaration))
						declaration++;
				}
				name = declared_name(declaration, &length);
				if (locations && locations->count < GL_ES2_MAXIMUM_ATTRIBUTES && length < sizeof(locations->name[0]))
				{
					memcpy(locations->name[locations->count], name, length);
					locations->name[locations->count][length] = 0;
					locations->location[locations->count] = location;
					locations->count++;
				}
				if (packed)
				{
					text_append(&body, "attribute vec4 ");
					text_append_length(&body, name, length);
					text_append(&body, ";\n");
				}
				else
				{
					text_append(&body, "attribute ");
					text_append_length(&body, type, (size_t)(next - type));
				}
				continue;
			}
			if ((!fragment && take_qualifier(&declaration, "out")) || (fragment && take_qualifier(&declaration, "in")))
			{
				text_append(&body, "varying ");
				rewrite_body(&body, declaration, (size_t)(next - declaration), &rewrite);
				continue;
			}
			if (fragment && take_qualifier(&declaration, "out"))
				continue;
			if (take_qualifier(&declaration, "uniform") && take_qualifier(&declaration, "sampler3D"))
			{
				text_append(&body, "uniform sampler2D ");
				text_append_length(&body, declaration, (size_t)(next - declaration));
				continue;
			}
		}
		rewrite_body(&body, line, line_length, &rewrite);
	}
	text_append(&out, body.buffer ? body.buffer : "");
	free(body.buffer);
	free(scaled_source);
	/* (the vertex shader's half of the scale above: its main, renamed, and
	the outputs scaled after it) */
	if (!fragment && out.buffer && has_word(out.buffer, "xT0") && has_word(out.buffer, "xT3"))
	{
		char *main_at = strstr(out.buffer, "void main()");

		if (main_at)
		{
			struct text wrapped = { 0 };

			text_append_length(&wrapped, out.buffer, (size_t)(main_at - out.buffer));
			text_append(&wrapped, "void es2_main()");
			text_append(&wrapped, main_at + strlen("void main()"));
			text_appendf(&wrapped,
				"uniform %s vec4 texture_scale[4];\n"
				"void main()\n"
				"{\n"
				"\tes2_main();\n"
				"\txT0.xy *= texture_scale[0].xy;\n"
				"\txT1.xy *= texture_scale[1].xy;\n"
				"\txT2.xy *= texture_scale[2].xy;\n"
				"\txT3.xy *= texture_scale[3].xy;\n"
				"}\n", fragment_highp ? "highp" : "mediump");
			free(out.buffer);
			return wrapped.buffer;
		}
	}
	return out.buffer;
}

#endif
